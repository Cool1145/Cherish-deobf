package cn.cool.cherish.utils.player;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.RotationRender;
import cn.cool.cherish.module.impl.misc.友何树友何友何树树友;
import cn.cool.cherish.module.impl.movement.何树友树友友树何友树;
import cn.cool.cherish.utils.友友友树何友树友树友;
import cn.cool.cherish.utils.树何树树何何树友何何;
import cn.cool.cherish.utils.helper.Rotation;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import cn.lzq.injection.asm.invoked.move.FallFlyingEvent;
import cn.lzq.injection.asm.invoked.move.JumpEvent;
import cn.lzq.injection.asm.invoked.move.MotionEvent;
import cn.lzq.injection.asm.invoked.move.MoveInputEvent;
import cn.lzq.injection.asm.invoked.move.StrafeEvent;
import cn.lzq.injection.asm.invoked.other.BlinkEvent;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import cn.lzq.injection.asm.invoked.player.LookEvent;
import cn.lzq.injection.asm.invoked.player.UpdateEvent;
import cn.lzq.injection.asm.invoked.player.UseItemEvent;
import cn.lzq.injection.asm.invoked.render.RenderPitchEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.AirBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class RotationUtils implements IWrapper, 何树友 {
   public static boolean waitForNextUpdate = false;
   public static Rotation rotation;
   public static Rotation 友树树何友何树友何何;
   public static Rotation 树何何何友树何树何树 = null;
   public static int keepLength = 0;
   private static boolean 树友树友树何友树何友 = false;
   private static boolean 树友友何何友树友友树;
   private static final long a;
   private static final Object[] b = new Object[78];
   private static final String[] c = new String[78];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3802466666665270176L, -2760050300648963157L, MethodHandles.lookup().lookupClass()).a(211015591315192L);
      // $VF: monitorexit
      a = var10000;
      a();
      t(false);
   }

   public static void reset() {
      if (mc.player != null) {
         树何何何友树何树何树 = null;
         友树树何友何树友何何 = null;
         rotation = null;
         keepLength = 0;
      }
   }

   private static float C(long a, RotationUtils.何树友何友树友何友友 a) {
      a = 137331640367587L ^ a;
      int ax = a<"ô">(6788379893799797533L, (long)a);
      if (mc.player == null) {
         return 0.0F;
      } else {
         float direction = mc.player.getYRot();
         switch (a<"$">(6786902340624978274L, (long)a)[a.ordinal()]) {
            case 1:
               direction += 0.0F;
               if (a < 0L) {
                  return ax * 45;
               }

               if (ax == 0) {
                  break;
               }
            case 2:
               direction += 180.0F;
               if (a < 0L) {
                  return ax * 45;
               }

               if (ax == 0) {
                  break;
               }
            case 3:
               direction += 90.0F;
               if (a < 0L) {
                  return ax * 45;
               }

               if (ax == 0) {
                  break;
               }
            case 4:
               direction += -90.0F;
               if (a < 0L) {
                  return ax * 45;
               }

               if (ax == 0) {
                  break;
               }
            case 5:
               direction += 45.0F;
               if (a <= 0L) {
                  return ax * 45;
               }

               if (ax == 0) {
                  break;
               }
            case 6:
               direction += -45.0F;
               if (a <= 0L) {
                  return ax * 45;
               }

               if (ax == 0) {
                  break;
               }
            case 7:
               direction += 135.0F;
               if (a <= 0L) {
                  return ax * 45;
               }

               if (ax == 0) {
                  break;
               }
            case 8:
               direction += -135.0F;
         }

         return Math.round((direction + 180.0F) / 45.0F) * 45;
      }
   }

   public static Vec3 C(BlockPos a, long blockPos, Direction a) {
      Vec3 eyes = new Vec3(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ());
      return 友友友树何友树友树友.O(new AABB(a, a.offset(1, 1, 1)), a, eyes, 71128165073070L);
   }

   private static RotationUtils.何树友何友树友何友友 D(long a) {
      a = 137331640367587L ^ a;
      int ax = a<"ô">(8599751141540610339L, (long)a);
      if (mc.player == null) {
         return a<"$">(8593216560224417909L, (long)a);
      } else {
         boolean forward;
         boolean backward;
         boolean left;
         boolean right;
         boolean var10000;
         boolean var10001;
         label265: {
            label264: {
               forward = a<"x">(a<"x">(mc, 8592920528859515782L, (long)a), 8593680123114995431L, (long)a).isDown();
               backward = a<"x">(a<"x">(mc, 8592920528859515782L, (long)a), 8600282593769978100L, (long)a).isDown();
               left = a<"x">(a<"x">(mc, 8592920528859515782L, (long)a), 8600184938308795003L, (long)a).isDown();
               right = a<"x">(a<"x">(mc, 8592920528859515782L, (long)a), 8593481118340359645L, (long)a).isDown();
               if (forward) {
                  var10000 = left;
                  if (a <= 0L) {
                     break label264;
                  }

                  if (left) {
                     var10000 = backward;
                     if (a < 0L) {
                        break label264;
                     }

                     if (!backward) {
                        var10000 = right;
                        var10001 = ax;
                        if (a < 0L) {
                           break label265;
                        }

                        if (!ax) {
                           break label264;
                        }

                        if (!right) {
                           RotationUtils.何树友何友树友何友友 directional = a<"$">(8594275330291165374L, (long)a);
                           var10000 = ax;
                           if (a < 0L) {
                              break label264;
                           }

                           if (ax) {
                              return directional;
                           }
                        }
                     }
                  }
               }

               var10000 = forward;
            }

            var10001 = ax;
         }

         label244: {
            label243:
            if (var10001) {
               if (var10000) {
                  var10000 = right;
                  if (a <= 0L) {
                     break label243;
                  }

                  if (right) {
                     var10000 = backward;
                     if (a <= 0L) {
                        break label243;
                     }

                     if (!backward) {
                        var10000 = left;
                        var10001 = ax;
                        if (a <= 0L) {
                           break label244;
                        }

                        if (!ax) {
                           break label243;
                        }

                        if (!left) {
                           RotationUtils.何树友何友树友何友友 directionalx = a<"$">(8592974685460813345L, (long)a);
                           var10000 = ax;
                           if (a < 0L) {
                              break label243;
                           }

                           if (ax) {
                              return directionalx;
                           }
                        }
                     }
                  }
               }

               var10000 = backward;
            }

            var10001 = ax;
         }

         label222: {
            label221:
            if (var10001) {
               if (var10000) {
                  var10000 = left;
                  if (a < 0L) {
                     break label221;
                  }

                  if (left) {
                     var10000 = forward;
                     if (a <= 0L) {
                        break label221;
                     }

                     if (!forward) {
                        var10000 = right;
                        var10001 = ax;
                        if (a < 0L) {
                           break label222;
                        }

                        if (!ax) {
                           break label221;
                        }

                        if (!right) {
                           RotationUtils.何树友何友树友何友友 directionalxx = a<"$">(8594491997092430754L, (long)a);
                           var10000 = ax;
                           if (a < 0L) {
                              break label221;
                           }

                           if (ax) {
                              return directionalxx;
                           }
                        }
                     }
                  }
               }

               var10000 = backward;
            }

            var10001 = ax;
         }

         label200: {
            label199:
            if (var10001) {
               if (var10000) {
                  var10000 = right;
                  if (a < 0L) {
                     break label199;
                  }

                  if (right) {
                     var10000 = forward;
                     if (a <= 0L) {
                        break label199;
                     }

                     if (!forward) {
                        var10000 = left;
                        var10001 = ax;
                        if (a <= 0L) {
                           break label200;
                        }

                        if (!ax) {
                           break label199;
                        }

                        if (!left) {
                           RotationUtils.何树友何友树友何友友 directionalxxx = a<"$">(8600443219483157437L, (long)a);
                           var10000 = ax;
                           if (a < 0L) {
                              break label199;
                           }

                           if (ax) {
                              return directionalxxx;
                           }
                        }
                     }
                  }
               }

               var10000 = forward;
            }

            var10001 = ax;
         }

         label178: {
            label177:
            if (var10001) {
               if (var10000) {
                  var10000 = backward;
                  if (a <= 0L) {
                     break label177;
                  }

                  if (!backward) {
                     var10000 = left;
                     var10001 = ax;
                     if (a <= 0L) {
                        break label178;
                     }

                     if (!ax) {
                        break label177;
                     }

                     if (!left) {
                        RotationUtils.何树友何友树友何友友 directionalxxxx = a<"$">(8594589593483562413L, (long)a);
                        var10000 = ax;
                        if (a < 0L) {
                           break label177;
                        }

                        if (ax) {
                           return directionalxxxx;
                        }
                     }
                  }
               }

               var10000 = backward;
            }

            var10001 = ax;
         }

         label159: {
            label158:
            if (var10001) {
               if (var10000) {
                  var10000 = forward;
                  if (a <= 0L) {
                     break label158;
                  }

                  if (!forward) {
                     var10000 = left;
                     var10001 = ax;
                     if (a < 0L) {
                        break label159;
                     }

                     if (!ax) {
                        break label158;
                     }

                     if (!left) {
                        RotationUtils.何树友何友树友何友友 directionalxxxxx = a<"$">(8599974049823571290L, (long)a);
                        var10000 = ax;
                        if (a < 0L) {
                           break label158;
                        }

                        if (ax) {
                           return directionalxxxxx;
                        }
                     }
                  }
               }

               var10000 = left;
            }

            var10001 = ax;
         }

         label140: {
            label139:
            if (var10001) {
               if (var10000) {
                  var10000 = right;
                  if (a <= 0L) {
                     break label139;
                  }

                  if (!right) {
                     var10000 = forward;
                     var10001 = ax;
                     if (a <= 0L) {
                        break label140;
                     }

                     if (!ax) {
                        break label139;
                     }

                     if (!forward) {
                        RotationUtils.何树友何友树友何友友 directionalxxxxxx = a<"$">(8600649010836381129L, (long)a);
                        var10000 = ax;
                        if (a <= 0L) {
                           break label139;
                        }

                        if (ax) {
                           return directionalxxxxxx;
                        }
                     }
                  }
               }

               var10000 = right;
            }

            var10001 = ax;
         }

         label121: {
            label278: {
               if (a > 0L) {
                  if (var10001) {
                     if (!var10000) {
                        break label278;
                     }

                     var10000 = left;
                  }

                  var10001 = ax;
               }

               if (var10001) {
                  if (var10000) {
                     break label278;
                  }

                  var10000 = forward;
               }

               if (!var10000) {
                  var10 = a<"$">(8596509076824365537L, (long)a);
                  if (a < 0L) {
                     break label121;
                  }
               }
            }

            var10 = a<"$">(8593216560224417909L, (long)a);
         }

         RotationUtils.何树友何友树友何友友 directionalxxxxxxx = var10;
         return directionalxxxxxxx;
      }
   }

   private static Rotation D(Vec3 a, Vec3 from, long a) {
      a = 137331640367587L ^ a;
      long ax = a ^ 84785713032133L;
      Vec3 direction = from.subtract(a);
      float yaw = (float)Math.toDegrees(Math.atan2(a<"x">(direction, -3086574455896990397L, a), a<"x">(direction, -3086193182994113284L, a))) - 90.0F;
      float pitch = (float)(
         -Math.toDegrees(
            Math.atan2(
               a<"x">(direction, -3083339952023503051L, a),
               Math.sqrt(
                  a<"x">(direction, -3086193182994113284L, a) * a<"x">(direction, -3086193182994113284L, a)
                     + a<"x">(direction, -3086574455896990397L, a) * a<"x">(direction, -3086574455896990397L, a)
               )
            )
         )
      );
      return new Rotation(ax, Mth.wrapDegrees(yaw), Mth.clamp(pitch, -90.0F, 90.0F));
   }

   public static void F(Rotation a, long rotation) {
      树何何何友树何树何树 = a;
      RotationUtils.rotation = 树何何何友树何树何树;
      树友树友树何友树何友 = true;
      keepLength = 0;
      waitForNextUpdate = true;
   }

   @EventTarget(4)
   public void F(RenderPitchEvent event) {
      q();
      if (RotationRender.instance != null && RotationRender.instance.树友友树树何树树何友.getValue() && rotation != null) {
         event.setPitch(rotation.l(5377274095808L));
      }
   }

   public static Rotation J(Vec3 a, long vec, boolean a) {
      Vec3 eyesPos = new Vec3(mc.player.getX(), mc.player.getBoundingBox().minY + mc.player.getEyeHeight(), mc.player.getZ());
      eyesPos = eyesPos.add(mc.player.getX(), mc.player.getY(), mc.player.getZ());
      double diffX = a.x - eyesPos.x;
      double diffY = a.y - eyesPos.y;
      double diffZ = a.z - eyesPos.z;
      float yaw = Mth.wrapDegrees((float)(Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0));
      float pitch = Mth.wrapDegrees((float)(-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ)))));
      return new Rotation(21273681362686L, yaw, pitch);
   }

   public static Rotation V(Entity a, float verticalRandomness, float aimPointFactor, long horizontalRandomness, float a) {
      Random random = new Random();
      q();
      double randomXOffset = (random.nextDouble() - 0.5) * a.getBbWidth() * 0.5 * 0.1F;
      double randomZOffset = (random.nextDouble() - 0.5) * a.getBbWidth() * 0.5 * verticalRandomness;
      double baseTargetY = a.getY();
      if (a >= 0.9F) {
         baseTargetY += a.getEyeHeight() * (0.8F + random.nextFloat() * 0.2F);
      }

      baseTargetY += a.getBbHeight() * Mth.clamp((float)a, 0.1F, 0.9F);
      double randomYOffset = (random.nextDouble() - 0.5) * a.getBbHeight() * 0.3 * 0.1F;
      double targetX = a.getX() + randomXOffset;
      double targetY = baseTargetY + randomYOffset;
      double targetZ = a.getZ() + randomZOffset;
      double diffX = targetX - mc.player.getX();
      double diffY = targetY - (mc.player.getY() + mc.player.getEyeHeight());
      double diffZ = targetZ - mc.player.getZ();
      double dist = Mth.sqrt((float)(diffX * diffX + diffZ * diffZ));
      float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0F;
      float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
      float finalYaw = mc.player.getYRot() + Mth.wrapDegrees(yaw - mc.player.getYRot());
      float finalPitch = mc.player.getXRot() + Mth.wrapDegrees(pitch - mc.player.getXRot());
      finalPitch = Mth.clamp(finalPitch, -90.0F, 90.0F);
      return new Rotation(21273681362686L, finalYaw, finalPitch);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 55;
               case 2 -> 23;
               case 3 -> 31;
               case 4 -> 60;
               case 5 -> 2;
               case 6 -> 9;
               case 7 -> 16;
               case 8 -> 7;
               case 9 -> 35;
               case 10 -> 25;
               case 11 -> 63;
               case 12 -> 50;
               case 13 -> 0;
               case 14 -> 62;
               case 15 -> 33;
               case 16 -> 20;
               case 17 -> 54;
               case 18 -> 4;
               case 19 -> 1;
               case 20 -> 38;
               case 21 -> 59;
               case 22 -> 22;
               case 23 -> 10;
               case 24 -> 56;
               case 25 -> 3;
               case 26 -> 30;
               case 27 -> 48;
               case 28 -> 6;
               case 29 -> 51;
               case 30 -> 19;
               case 31 -> 5;
               case 32 -> 43;
               case 33 -> 18;
               case 34 -> 37;
               case 35 -> 15;
               case 36 -> 47;
               case 37 -> 17;
               case 38 -> 53;
               case 39 -> 12;
               case 40 -> 41;
               case 41 -> 14;
               case 42 -> 24;
               case 43 -> 32;
               case 44 -> 8;
               case 45 -> 13;
               case 46 -> 44;
               case 47 -> 46;
               case 48 -> 11;
               case 49 -> 21;
               case 50 -> 58;
               case 51 -> 49;
               case 52 -> 39;
               case 53 -> 52;
               case 54 -> 29;
               case 55 -> 61;
               case 56 -> 28;
               case 57 -> 34;
               case 58 -> 36;
               case 59 -> 27;
               case 60 -> 26;
               case 61 -> 40;
               case 62 -> 45;
               default -> 57;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static Vec3 e(Rotation a, long a) {
      float yawCos = (float)Math.cos(-a.getYaw() * (float) (Math.PI / 180.0) - (float) Math.PI);
      float yawSin = (float)Math.sin(-a.getYaw() * (float) (Math.PI / 180.0) - (float) Math.PI);
      float pitchCos = (float)(-Math.cos(-a.l(5377274095808L) * (float) (Math.PI / 180.0)));
      float pitchSin = (float)Math.sin(-a.l(5377274095808L) * (float) (Math.PI / 180.0));
      return new Vec3(yawSin * pitchCos, pitchSin, yawCos * pitchCos);
   }

   @EventTarget(4)
   public void e(UseItemEvent event) {
      if (!O()) {
         if (rotation == null) {
            return;
         }

         event.setYaw(rotation.getYaw());
      }

      event.setPitch(rotation.l(5377274095808L));
   }

   public static void i(Rotation a, long a, boolean rotation, boolean waitForNextUpdate) {
      树何何何友树何树何树 = a;
      RotationUtils.rotation = 树何何何友树何树何树;
      树友树友树何友树何友 = (boolean)rotation;
      keepLength = 0;
      RotationUtils.waitForNextUpdate = waitForNextUpdate;
   }

   public static float i(Entity a, long a) {
      q();
      if (mc.player == null) {
         return Float.MAX_VALUE;
      } else {
         Vec3 playerEyes = mc.player.getEyePosition(1.0F);
         Vec3 targetEyes = new Vec3(a.getX(), a.getY() + a.getEyeHeight(), a.getZ());
         return (float)playerEyes.distanceTo(targetEyes);
      }
   }

   public static double b(long a, Rotation a, Rotation var3) {
      return Math.hypot(友友友树何友树友树友.E(a.getYaw(), var3.getYaw()), a.l(5377274095808L) - var3.l(5377274095808L));
   }

   public static boolean b(long a, LivingEntity a) {
      return d(86372664010617L, a) != null;
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @EventTarget(0)
   public void b(BlinkEvent e) {
      O();
      if (e.getPacket() instanceof ServerboundMovePlayerPacket wrapper
         && 友何树友何友何树树友.何友友何树树树何何树.isEnabled()
         && 友何树友何友何树树友.何友友何树树树何何树.友树友友树友何何树友.getValue()
         && 友何树友何友何树树友.何友友何树树树何何树.树何友何树何友何树何.getValue()
         && !e.isCancelled()
         && wrapper.getYRot(0.0F) < 360.0F
         && wrapper.getYRot(0.0F) > -360.0F) {
         WrapperUtils.C(wrapper, 46240972690895L, wrapper.getYRot(0.0F) + 720.0F);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'x' && var8 != 213 && var8 != '$' && var8 != 'E') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 181) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 244) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'x') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static Rotation n(long a, Entity a) {
      q();
      if (mc.player == null) {
         return null;
      } else {
         double diffX = a.getX() - mc.player.getX();
         double diffZ = a.getZ() - mc.player.getZ();
         double diffY = a.getY() + a.getEyeHeight() - (mc.player.getY() + mc.player.getEyeHeight());
         double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
         float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
         float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
         return new Rotation(21273681362686L, Mth.wrapDegrees(yaw), Mth.wrapDegrees(pitch));
      }
   }

   public static Rotation h(Vec3 a, Vec3 a, long var2) {
      var2 = 137331640367587L ^ var2;
      long ax = var2 ^ 22452287102522L;
      Vec3 diff = a.subtract(a);
      double distance = Math.hypot(a<"x">(diff, -6857580553236829949L, var2), a<"x">(diff, -6857555523309311812L, var2));
      float yaw = (float)(Mth.atan2(a<"x">(diff, -6857555523309311812L, var2), a<"x">(diff, -6857580553236829949L, var2)) * (float) (180.0 / Math.PI)) - 90.0F;
      float pitch = (float)(-(Mth.atan2(a<"x">(diff, -6860495360217314614L, var2), distance) * (float) (180.0 / Math.PI)));
      return new Rotation(ax, yaw, pitch);
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   // $VF: Irreducible bytecode was duplicated to produce valid code
   public static Vec3 f(long a, Vec3 a, AABB var3) {
      a = 137331640367587L ^ a;
      double[] origin = new double[]{
         a<"x">(a, -8435095689036168409L, (long)a), a<"x">(a, -8435558581324275474L, (long)a), a<"x">(a, -8434839212447874408L, (long)a)
      };
      double[] destMinis = new double[]{
         a<"x">(var3, -8437292166452704484L, (long)a), a<"x">(var3, -8434722588061860814L, (long)a), a<"x">(var3, -8436880027561861386L, (long)a)
      };
      int var10000 = a<"ô">(-8434611645454772262L, (long)a);
      double[] destMaxis = new double[]{
         a<"x">(var3, -8434325638542849569L, (long)a), a<"x">(var3, -8437763787063589476L, (long)a), a<"x">(var3, -8435715408849147306L, (long)a)
      };
      int i = 0;
      int ax = (byte)var10000;

      while (i < 3 || a < 0L) {
         while (true) {
            double var14;
            var10000 = (var14 = origin[i] - destMaxis[i]) == 0.0 ? 0 : (var14 < 0.0 ? -1 : 1);
            if (a > 0L) {
               if (var10000 > 0) {
                  origin[i] = destMaxis[i];
                  if (a >= 0L) {
                     if (ax != 0) {
                        double var15;
                        var10000 = (var15 = origin[i] - destMinis[i]) == 0.0 ? 0 : (var15 < 0.0 ? -1 : 1);
                        if (a > 0L) {
                           if (var10000 < 0) {
                              origin[i] = destMinis[i];
                           }

                           i++;
                           var10000 = ax;
                        }

                        if (var10000 == 0) {
                           continue;
                        }
                     } else {
                        i++;
                        if (ax == 0) {
                           continue;
                        }
                     }
                  } else if (ax == 0) {
                     continue;
                  }
               } else {
                  double var16;
                  var10000 = (var16 = origin[i] - destMinis[i]) == 0.0 ? 0 : (var16 < 0.0 ? -1 : 1);
                  if (a > 0L) {
                     if (var10000 < 0) {
                        origin[i] = destMinis[i];
                     }

                     i++;
                     var10000 = ax;
                  }

                  if (var10000 == 0) {
                     continue;
                  }
               }
            } else {
               if (a > 0L) {
                  if (var10000 < 0) {
                     origin[i] = destMinis[i];
                  }

                  i++;
                  var10000 = ax;
               }

               if (var10000 == 0) {
                  continue;
               }
            }

            if (a >= 0L) {
               break;
            }
         }

         return new Vec3(origin[0], origin[1], origin[2]);
      }

      return new Vec3(origin[0], origin[1], origin[2]);
   }

   public static void f(Rotation a, boolean waitForNextUpdate, long movementFix, boolean keepLength, int a) {
      movementFix = (boolean)(137331640367587L ^ movementFix);
      long ax = movementFix ^ 74795977099896L;
      w(a, waitForNextUpdate, ax, (int)a);
      a<"E">((boolean)keepLength, 6453102587694717373L, (long)movementFix);
   }

   private static float[] l(float a) {
      return new float[]{a + (float)(Math.random() - 0.5), 75.6F + (float)(Math.random() - 10.0)};
   }

   public static Vec3 d(long a, LivingEntity var2) {
      a = 137331640367587L ^ a;
      long ax = a ^ 79564611246508L;
      int axx = a<"ô">(2200140112432399264L, (long)a);
      if (mc.player != null && mc.level != null) {
         Vec3 eyePos = mc.player.getEyePosition(1.0F);
         AABB targetBox = var2.getBoundingBox();
         List<Vec3> checkPoints = new ArrayList<>();
         checkPoints.add(targetBox.getCenter());
         checkPoints.add(new Vec3(var2.getX(), var2.getY() + var2.getEyeHeight(), var2.getZ()));
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               (a<"x">(targetBox, 2203102276987527014L, (long)a) + a<"x">(targetBox, 2200302158660476325L, (long)a)) / 2.0,
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               (a<"x">(targetBox, 2202371216369699468L, (long)a) + a<"x">(targetBox, 2203415962119929388L, (long)a)) / 2.0
            )
         );
         checkPoints.add(
            new Vec3(
               (a<"x">(targetBox, 2203102276987527014L, (long)a) + a<"x">(targetBox, 2200302158660476325L, (long)a)) / 2.0,
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               (a<"x">(targetBox, 2202371216369699468L, (long)a) + a<"x">(targetBox, 2203415962119929388L, (long)a)) / 2.0
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               (a<"x">(targetBox, 2201014324415129672L, (long)a) + a<"x">(targetBox, 2205989939110154726L, (long)a)) / 2.0,
               (a<"x">(targetBox, 2202371216369699468L, (long)a) + a<"x">(targetBox, 2203415962119929388L, (long)a)) / 2.0
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               (a<"x">(targetBox, 2201014324415129672L, (long)a) + a<"x">(targetBox, 2205989939110154726L, (long)a)) / 2.0,
               (a<"x">(targetBox, 2202371216369699468L, (long)a) + a<"x">(targetBox, 2203415962119929388L, (long)a)) / 2.0
            )
         );
         checkPoints.add(
            new Vec3(
               (a<"x">(targetBox, 2203102276987527014L, (long)a) + a<"x">(targetBox, 2200302158660476325L, (long)a)) / 2.0,
               (a<"x">(targetBox, 2201014324415129672L, (long)a) + a<"x">(targetBox, 2205989939110154726L, (long)a)) / 2.0,
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               (a<"x">(targetBox, 2203102276987527014L, (long)a) + a<"x">(targetBox, 2200302158660476325L, (long)a)) / 2.0,
               (a<"x">(targetBox, 2201014324415129672L, (long)a) + a<"x">(targetBox, 2205989939110154726L, (long)a)) / 2.0,
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               (a<"x">(targetBox, 2203102276987527014L, (long)a) + a<"x">(targetBox, 2200302158660476325L, (long)a)) / 2.0,
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               (a<"x">(targetBox, 2203102276987527014L, (long)a) + a<"x">(targetBox, 2200302158660476325L, (long)a)) / 2.0,
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               (a<"x">(targetBox, 2202371216369699468L, (long)a) + a<"x">(targetBox, 2203415962119929388L, (long)a)) / 2.0
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               a<"x">(targetBox, 2201014324415129672L, (long)a),
               (a<"x">(targetBox, 2202371216369699468L, (long)a) + a<"x">(targetBox, 2203415962119929388L, (long)a)) / 2.0
            )
         );
         checkPoints.add(
            new Vec3(
               (a<"x">(targetBox, 2203102276987527014L, (long)a) + a<"x">(targetBox, 2200302158660476325L, (long)a)) / 2.0,
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               (a<"x">(targetBox, 2203102276987527014L, (long)a) + a<"x">(targetBox, 2200302158660476325L, (long)a)) / 2.0,
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               (a<"x">(targetBox, 2202371216369699468L, (long)a) + a<"x">(targetBox, 2203415962119929388L, (long)a)) / 2.0
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               a<"x">(targetBox, 2205989939110154726L, (long)a),
               (a<"x">(targetBox, 2202371216369699468L, (long)a) + a<"x">(targetBox, 2203415962119929388L, (long)a)) / 2.0
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               (a<"x">(targetBox, 2201014324415129672L, (long)a) + a<"x">(targetBox, 2205989939110154726L, (long)a)) / 2.0,
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               (a<"x">(targetBox, 2201014324415129672L, (long)a) + a<"x">(targetBox, 2205989939110154726L, (long)a)) / 2.0,
               a<"x">(targetBox, 2202371216369699468L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2203102276987527014L, (long)a),
               (a<"x">(targetBox, 2201014324415129672L, (long)a) + a<"x">(targetBox, 2205989939110154726L, (long)a)) / 2.0,
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         checkPoints.add(
            new Vec3(
               a<"x">(targetBox, 2200302158660476325L, (long)a),
               (a<"x">(targetBox, 2201014324415129672L, (long)a) + a<"x">(targetBox, 2205989939110154726L, (long)a)) / 2.0,
               a<"x">(targetBox, 2203415962119929388L, (long)a)
            )
         );
         double stepX = (a<"x">(targetBox, 2200302158660476325L, (long)a) - a<"x">(targetBox, 2203102276987527014L, (long)a)) / 3.0;
         double stepY = (a<"x">(targetBox, 2205989939110154726L, (long)a) - a<"x">(targetBox, 2201014324415129672L, (long)a)) / 3.0;
         double stepZ = (a<"x">(targetBox, 2203415962119929388L, (long)a) - a<"x">(targetBox, 2202371216369699468L, (long)a)) / 3.0;
         int i = 1;

         label122:
         while (i <= 2) {
            int j = 1;
            checkPoints.add(
               new Vec3(
                  a<"x">(targetBox, 2203102276987527014L, (long)a) + stepX * i,
                  a<"x">(targetBox, 2201014324415129672L, (long)a) + stepY * 1.0,
                  a<"x">(targetBox, 2202371216369699468L, (long)a)
               )
            );
            checkPoints.add(
               new Vec3(
                  a<"x">(targetBox, 2203102276987527014L, (long)a) + stepX * i,
                  a<"x">(targetBox, 2201014324415129672L, (long)a) + stepY * 1.0,
                  a<"x">(targetBox, 2203415962119929388L, (long)a)
               )
            );
            j++;

            while (true) {
               byte var10000 = axx;
               if (a > 0L) {
                  if (axx == 0) {
                     if (a < 0L) {
                        continue;
                     }

                     i++;
                  }

                  var10000 = axx;
               }

               if (var10000 != 0) {
                  break label122;
               }
               break;
            }
         }

         if (a > 0L) {
            i = 1;
         }

         label106:
         while (i <= 2) {
            int j = 1;
            checkPoints.add(
               new Vec3(
                  a<"x">(targetBox, 2203102276987527014L, (long)a),
                  a<"x">(targetBox, 2201014324415129672L, (long)a) + stepY * i,
                  a<"x">(targetBox, 2202371216369699468L, (long)a) + stepZ * 1.0
               )
            );
            checkPoints.add(
               new Vec3(
                  a<"x">(targetBox, 2200302158660476325L, (long)a),
                  a<"x">(targetBox, 2201014324415129672L, (long)a) + stepY * i,
                  a<"x">(targetBox, 2202371216369699468L, (long)a) + stepZ * 1.0
               )
            );
            j++;

            while (true) {
               byte var32 = axx;
               if (a >= 0L) {
                  if (axx == 0) {
                     if (a < 0L) {
                        continue;
                     }

                     i++;
                  }

                  var32 = axx;
               }

               if (var32 != 0) {
                  break label106;
               }
               break;
            }
         }

         if (a > 0L) {
            i = 1;
         }

         label90:
         while (i <= 2) {
            int j = 1;
            checkPoints.add(
               new Vec3(
                  a<"x">(targetBox, 2203102276987527014L, (long)a) + stepX * i,
                  a<"x">(targetBox, 2201014324415129672L, (long)a),
                  a<"x">(targetBox, 2202371216369699468L, (long)a) + stepZ * 1.0
               )
            );
            checkPoints.add(
               new Vec3(
                  a<"x">(targetBox, 2203102276987527014L, (long)a) + stepX * i,
                  a<"x">(targetBox, 2205989939110154726L, (long)a),
                  a<"x">(targetBox, 2202371216369699468L, (long)a) + stepZ * 1.0
               )
            );
            j++;

            while (true) {
               byte var33 = axx;
               if (a >= 0L) {
                  if (axx == 0) {
                     if (a < 0L) {
                        continue;
                     }

                     i++;
                  }

                  var33 = axx;
               }

               if (var33 != 0) {
                  break label90;
               }
               break;
            }
         }

         Vec3 bestPoint = null;
         double closestDistance = Double.MAX_VALUE;
         if (r(ax, eyePos, targetBox.getCenter())) {
            return targetBox.getCenter();
         } else {
            Vec3 eyePoint = new Vec3(var2.getX(), var2.getY() + var2.getEyeHeight(), var2.getZ());
            if (r(ax, eyePos, eyePoint)) {
               return eyePoint;
            } else {
               for (Vec3 point : checkPoints) {
                  int var34;
                  var34 = r(ax, eyePos, point);
                  label71:
                  if (a >= 0L) {
                     label69:
                     if (var34 != 0) {
                        double distance = eyePos.distanceToSqr(point);
                        if (a > 0L) {
                           double var35;
                           var34 = (var35 = distance - closestDistance) == 0.0 ? 0 : (var35 < 0.0 ? -1 : 1);
                           if (a <= 0L) {
                              break label71;
                           }

                           if (var34 >= 0) {
                              break label69;
                           }

                           closestDistance = distance;
                        }

                        bestPoint = point;
                     }

                     var34 = axx;
                  }

                  if (var34 != 0) {
                     break;
                  }
               }

               return bestPoint;
            }
         }
      } else {
         return null;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   public static void d(Rotation a, boolean movementFix, boolean waitForNextUpdate, boolean rotationSpeed, long rotation, float var6) {
      q();
      i(a, 21965559892785L, true, waitForNextUpdate);
      RotationUtils.rotation = 树何何何友树何树何树;
      RotationUtils.rotation = j(友树树何友何树友何何, 树何何何友树何树何树, 79451040753610L, 0.0F);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/utils/player/RotationUtils" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "fYEw\u00125i\u0019\b|\u0018(lD\u0003:\u00105aB\u0007qS3hG\u0007:\u00193vG\u0007u\u0004tWX\u001fu\t3jY9q\u0013>`E";
      b[1] = "p90n$Y\u007fy}e.Dz$v#&Yw\"rhe_~'r#&Ye2sh%B=伂栏叆桚叽变框佋叆桚";
      b[2] = boolean.class;
      c[2] = "java/lang/Boolean";
      b[3] = "`{v#'\fo;;(-\u0011jf0n=\u0017jy+n8\u000fbl=2f1la94!\fm@,)$\u0010";
      b[4] = "_+4IFTPkyBLIU6r\u0004\\OU)i\u0004A^P5\u007fX\u0007iS1{^@TR";
      b[5] = "2\u001bE,mW9\u0014Tc\u0011N6\u000eZ &~ \u0019V=7R7\u0014";
      b[6] = int.class;
      c[6] = "java/lang/Integer";
      b[7] = "=Kkl\u0000P2\u000b&g\nM7V-!\u001aK7I6!\u001fS?\\ }Am1Q${\u0006P0p1f\u0003Lz叮桔佚厤叴厕叮厎栞厤";
      b[8] = "\u001a<";
      b[9] = "j\u001f\t(^Jj\u001f\u001etREpT\niAO`T\rnJP*;<Dq";
      b[10] = double.class;
      c[10] = "java/lang/Double";
      b[11] = "t(\u00047Kzt(\u0013kGunc\u0007vT\u007f~c\u0000q_`4\u001b\u0015z\u0015";
      b[12] = "NqjR`5Nq}\u000el:T:i\u0013\u007f0D:n\u0014t/\u000e\\w\b_9Sar\b)\bYd{";
      b[13] = "s \u0007~\t>s \u0010\"\u00051ik\u0004?\u0016;yk\u001f5\u00122qk0<\r'^*\u001d$\u0001/ia1<\u000b4v";
      b[14] = "?\u0011^J\nq?\u0011I\u0016\u0006~%Z]\u000b\u0015t5ZF\u0001\u0011}=Zi\b\u000eh\u0012\u001bD\u0010\u0002`%Pl\b\u0012q5";
      b[15] = ">WmM\u0004W1\u0017 F\u000eJ4J+\u0000\u0006W9L/KEQ0I/\u0000\u0006Q.Zm句伾栩厖佬厈佻桺栩厖";
      b[16] = "Y\u00151!K#VU|*A>S\bwlR-V\u000ezlM!J\u00171\u0000K#V\u001e~,r-V\u000ez";
      b[17] = "YI\u000e7\\^V\tC<VCSTHzFESKSzC][^E&\u001dcUSA Z^TrT=_B\u001e佲栱原佦叺栫召併原司";
      b[18] = "wC&<@\u0018wC1`L\u0017m\b1~D\u0014wR|]]\u0005pI<a";
      b[19] = "\u0014yor\u0017Y\u0014yx.\u001bV\u000e2x0\u0013U\u0014h5\u0017\u001fI7}k,\u0013^\u001d";
      b[20] = "/0\u0019'\u0001//0\u000e{\r 5{\u000ee\u0005#/!CD\u0005($6\u001fh\n2";
      b[21] = "g\u0002p@!rhB=K+om\u001f6\r#r`\u00192F`Pk\b+O+";
      b[22] = "I\u0013\"2o6}0-r\"=w-(/){\u007f0%)-0<\u0012.849wd";
      b[23] = "\u0012\u0010nKbU&3a\u000b/^,.dV$\u0018$3iP Sg\u0011bA9Z,g";
      b[24] = void.class;
      c[24] = "java/lang/Void";
      b[25] = "\u0003M&)\u007fU\f\rk\"uH\tP`duL\u0005M|duL\u0005M|9>\u007f\u0016Ff>4i\tGm";
      b[26] = "V}{e>3V}l92<L6l':?Vl!;?;A}}e\u001f5[yc\u001b?;A}}";
      b[27] = float.class;
      c[27] = "java/lang/Float";
      b[28] = "\u000eiT\nbx\u0005fEE\u0003v\u000emA\u001f";
      b[29] = "t\u0012<y}\u0003/\n o\u0010\u0010\u001dGc(!D\u001dwfy~\f8\u000b%`o@";
      b[30] = "I}EUC`Zw\u000fA<栃佽叞伣格佡叙佽栄伣%V}\u001ao\u001b[\\+Gf";
      b[31] = "-\u0013\u0006\u0001\u0007O;\u0018F\u001c8桬厅叠伣厡佥厶伛佾桧bSE>@AXEN~]";
      b[32] = "\u0003\b\fb\t*\u0010\u0002Fvv伍厩厫佪栋桯桉伷伵栮\u0012\u001f0Q\u0018Hh\f:\u001b\f";
      b[33] = "\fb\u0000\u000182\\{U\u000f\u0003\u0019ak\u0001\r9w\u000b4F\byK";
      b[34] = "\u0014O\u0003mi\u0007D\u001dTz\u0004栢只栺株佞余栢只叠台\u0003:\u0003\u0019B_=k\\FO";
      b[35] = "s=#\u00007>(%?\u0016Z-\u001ah|Qjs\u001aXy\u000041?$:\u0019%}";
      b[36] = "\u00027\fR\u0015 VrQMo>9;\u0006\u0013_`9\nP@\f6UiWD\u001e>";
      b[37] = "\u0005\u000e<d{G\\_dg\u0016栯叼栫厘栅佋叵栦佯厘\u001c/X_\u0002<%s\\]Y";
      b[38] = "\u000577;r\u000e\\fo8\u001f厼栦栒伍厀佂桦叼佖伍C%\u0003\u0007y4=.\u0001T6";
      b[39] = "xK+B\u0019|,\u000ev]cbCG!\u0003S1CvwP\u0000j/\u0015pT\u0012b";
      b[40] = "\fkM\u001b2\u0017\u001a`\r\u0006\r栴伺伆栬去佐佰桾桂叶xf\u001d\u001f8\nBp\u0016_%";
      b[41] = ".\u001eP\u007f\b.u\u0006Lie=GK\u000f.TkG{\n\u007f\u000b!b\u0007If\u001am";
      b[42] = "(M'?\u0003%q\u001c\u007f<n桍住伬伝厄桷伉栋伬桙GT(*\u0003$9_*yL";
      b[43] = "\\PdqVh\u0005\u0001<r;c\u0001\u0010juZ~\u0000l9u\u0003k\u0002\u00122wP$";
      b[44] = "@=\u0013RX<\u0010?\rW3izbZ\u0016\r9zS\u000f\u0013\u0003~W#[V^a";
      b[45] = ";C\u000eT8\u0005-HNI\u0007佢厓伮厵叴叄佢厓伮伫7l\u000f(\u0010I\rz\u0004h\r";
      b[46] = "Yyy6Jo\u0004};x0桍伽伜伛伕右伉厣伜厅H\tl_?<sTh\u001dq";
      b[47] = "}IaG<\u0002$\u00189DQ\u001aGNxA8\u0010\u007f\u000e>Bos|\u000bxV2K<M{\u0001Q";
      b[48] = "0_\u0019\u00048ei\u000eA\u0007Ukc\u0002\u000222nL\u000e\u000e\u0000\blf\n\u0002\u0011U-d\u0003N\u001blq`\u0001\u0015";
      b[49] = "FH/\u001cn[\u001bLmR\u0014厣桦桩叓桻栍伽厼伭位b-\u000e\u001f@w[q\n\u001d\u001b";
      b[50] = "}EST{d#\u001cF\tC\u001b\u0011$}x\u0005\u0011LI\u0004S.dt\u0017]Fs";
      b[51] = "^=g\u0005^`_\"t\b2\u0003y\u0006DcR;A;tXS$R6";
      b[52] = "o \u0002.i}y+B3V厄叇位厹桔厕桞叇位档M=w|sEw+|<n";
      b[53] = "\u0006bF\rb}\u001cj\u0012P]/0hG\u0000m|0R\u001d\\&q\u0016n\u0006_18";
      b[54] = "@-wf^E\u0019|/e3Hz(~~\u0003SCtz|X4\u001a*t$\tRC-an3";
      b[55] = "8`n$[\"+j$0$厛案參厖桍叧伅伌栙厖TN?kr0*Di6{";
      b[56] = "&R\u0010\u0013Mh}J\f\u0005 {O\u0007OB\u0011.O7J\u0013NgjK\t\n_+";
      b[57] = "PJ\u00006\"T\u0000SU8\u0019s=C\u0001:#\u0011W\u001cF?c-]\u0017]n#K\u0004\u0010H$\u0019";
      b[58] = "_2)\u000f':\u0010e.\u0015\u0017?8?jY'i8\u000fo\u000ey#\u001ds,\u0017ho";
      b[59] = "\u0002i\u0003dup\u0014bCyJ桓伴桀厸佚众众厪桀桢\u0007!z\u0011:D=7qQ'";
      b[60] = "9\u0019<=0I2N\"4A>\u00176\u0014P(\u00115\u001d(a#F+\u0014";
      b[61] = "jXf9\r!3\t>:`3=\ty\u0005\r6?\u0018aA\\:j\u00038:\u001c\"n\u0007";
      b[62] = ":8\b1u:v-\u0017i\u0015\u0012N\u00132L\u0015hf%Gow$s:\u001f";
      b[63] = "&R$\u0007,c0Yd\u001a\u0013厚厎桻原厧栊桀伐桻桅dxi5\u0001c^nbu\u001c";
      b[64] = "i\u0012n7(\f#\n3S3^1\u00144(5R3!<,IY?J'67Si\u0017.";
      b[65] = "J\n$mU]\u0000\u0012y\tU\u0004\u0000\u0014vo_\u000f{Y}2P\u0003D\u0013eo";
      b[66] = "\u0018pj\fzH\u000e{*\u0011E桫桪厃住厬优桫桪厃住o.B\u000b#-U8IK>";
      b[67] = ";INobmt\u001eIuRh\\D\r9m7\\t\bn<ty\bKw-8";
      b[68] = "jEgg6\u0015%\u0012`}\u0006\u0010\rH$16G\rx!fh\f(\u0004b\u007fy@";
      b[69] = "\u0003\u001f.UySWZsJ\u0003M8\u0013$\u00143\u001c8\"rG`ETAuCrM";
      b[70] = "[Hz[!\\\u0000PfMLO2\u001d%\n|\u00102- [\"S\u0017QcB3\u001f";
      b[71] = "\bW]FG\u000f\u001e\\\u001d[x叶桺厤佸另桡栬桺厤格%\u0013\u0005\u001b\u0004\u001a\u001f\u0005\u000e[\u0019";
      b[72] = "U\u0005\u0004\u001dLJC\u000eD\u0000s桩栧佨伡伣桪伭佣叶桥~\u0018@FVCD\u000eK\u0006K";
      b[73] = "Mq7\u001aa}\u0014 o\u0019\fKwt>\u0002<kN(:\u0000g\f";
      b[74] = "OQ'\u001e\\:\u0005Izz栤叆厽株栅伧栤栜伣台\u001c\u0010Z?\fVb\u001a\fb\u0005";
      b[75] = "y27\u0019\u0004t-wj\u0006~jB>=XN:B\u000fk\u000b\u001db.ll\u000f\u000fj";
      b[76] = "]]\u0006\u0017-t\u0006E\u001a\u0001@g4\bYFq048\\\u0017.{\u0011D\u001f\u000e?7";
      b[77] = "lT\".QI5\u0005z-<AVQ+6\f_o\r/4W8";
   }

   public static float[] m(long a, BlockPos a, float var3) {
      long ax = 137331640367587L ^ a ^ 135641194622989L;
      return mc.player == null
         ? null
         : E(a.getX() + var3, a.getY() + var3, a.getZ() + var3, mc.player.getX(), mc.player.getY() + mc.player.getEyeHeight(), ax, mc.player.getZ());
   }

   public static Rotation m(Entity a, long entity) {
      q();
      if (mc.player == null) {
         return null;
      } else if (!(a instanceof LivingEntity)) {
         return null;
      } else {
         Vec3 eyePos = mc.player.getEyePosition(1.0F);
         Vec3 bestVisiblePoint = d(86372664010617L, (LivingEntity)a);
         return bestVisiblePoint != null ? D(eyePos, bestVisiblePoint, 38081861594328L) : null;
      }
   }

   private static float[] o(Vec3 a, long a, Vec3 position) {
      a = 137331640367587L ^ a;
      Vec3 difference = position.subtract(a);
      double distance = new Vec3(a<"x">(difference, 8127185605602310430L, a), 0.0, a<"x">(difference, 8126881299450804385L, a)).length();
      float yaw = (float)Math.toDegrees(Math.atan2(a<"x">(difference, 8126881299450804385L, a), a<"x">(difference, 8127185605602310430L, a))) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(a<"x">(difference, 8131237304165391063L, a), distance)));
      return new float[]{yaw, pitch};
   }

   @EventTarget(4)
   public void p(StrafeEvent event) {
      if (rotation != null && 树友树友树何友树何友) {
         event.setRotationYaw(rotation.getYaw());
      }
   }

   public static Rotation k(Entity a, long entity) {
      q();
      double diffX = a.getX() - mc.player.getX();
      double diffY = a.getY() + a.getEyeHeight() * 0.9 - (mc.player.getY() + mc.player.getEyeHeight());
      double diffZ = a.getZ() - mc.player.getZ();
      double dist = Mth.sqrt((float)(diffX * diffX + diffZ * diffZ));
      float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0F;
      float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
      Rotation var10000 = new Rotation(
         21273681362686L, mc.player.getYRot() + Mth.wrapDegrees(yaw - mc.player.getYRot()), mc.player.getXRot() + Mth.wrapDegrees(pitch - mc.player.getXRot())
      );
      if (Module.Z() == null) {
         t(false);
      }

      return var10000;
   }

   public static void init() {
      Cherish.instance.getEventManager().register(new RotationUtils());
   }

   public static Vec3 t(long a, AABB var2) {
      return new Vec3(var2.minX + (var2.maxX - var2.minX) * 0.5, var2.minY + (var2.maxY - var2.minY) * 0.5, var2.minZ + (var2.maxZ - var2.minZ) * 0.5);
   }

   @EventTarget(4)
   public void t(FallFlyingEvent event) {
      if (rotation != null) {
         event.setPitch(rotation.l(5377274095808L));
      }
   }

   public static void t(boolean var0) {
      树友友何何友树友友树 = var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Rotation j(Rotation a, Rotation speed, long lastRotation, float a) {
      lastRotation = 137331640367587L ^ lastRotation;
      long ax = lastRotation ^ 273613337719L;
      long axx = lastRotation ^ 43965610205399L;
      long axxx = lastRotation ^ 53078786012905L;
      float yaw = speed.getYaw();
      float pitch = speed.l(axxx);
      a<"ô">(6790145151246549779L, (long)lastRotation);
      float lastYaw = a.getYaw();
      float lastPitch = a.l(axxx);
      if (a != 0.0F) {
         float deltaYaw = Mth.wrapDegrees(speed.getYaw() - a.getYaw());
         float deltaPitch = pitch - lastPitch;
         float moveYaw = Mth.clamp(deltaYaw, (float)(-a), (float)a);
         yaw = lastYaw + moveYaw;
         pitch = lastPitch + deltaPitch;
      }

      Rotation rotations = new Rotation(axx, yaw, pitch);
      Rotation fixedRotations = E(ax, rotations);
      yaw = fixedRotations.getYaw();
      pitch = Math.max(-90.0F, Math.min(90.0F, fixedRotations.l(axxx)));
      return new Rotation(axx, yaw, pitch);
   }

   public static double q(Entity entity) {
      O();
      if (mc.player != null && mc.level != null) {
         Rotation rotation = J(t(91707708189899L, entity.getBoundingBox()), 132835120243482L, true);
         return b(108219604503164L, rotation, new Rotation(21273681362686L, mc.player.getYRot(), mc.player.getXRot()));
      } else {
         return 0.0;
      }
   }

   public static boolean q() {
      O();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public static void w(Rotation a, boolean a, long var2, int keepLength) {
      var2 = 137331640367587L ^ var2;
      a<"E">(a, -1579718358833944219L, var2);
      a<"E">(a<"$">(-1579718358833944219L, var2), -1579701279828061609L, var2);
      a<"E">((boolean)a, -1580672691592496293L, var2);
      a<"E">(keepLength, -1578984789499536315L, var2);
   }

   public static Rotation u(Entity a, long a) {
      q();
      if (mc.player == null) {
         return null;
      } else {
         Vec3 playerEyePos = mc.player.getEyePosition(1.0F);
         Vec3 targetPos = new Vec3(a.getX(), a.getY() + a.getBbHeight() * 0.5, a.getZ());
         Vec3 direction = targetPos.subtract(playerEyePos).normalize();
         float yaw = (float)Math.toDegrees(Math.atan2(direction.z, direction.x)) - 90.0F;
         float pitch = (float)(-Math.toDegrees(Math.atan2(direction.y, Math.sqrt(direction.x * direction.x + direction.z * direction.z))));
         return new Rotation(21273681362686L, yaw, pitch);
      }
   }

   public static boolean r(long a, Vec3 var2, Vec3 to) {
      a = 137331640367587L ^ a;
      BlockHitResult hit = mc.level.clip(new ClipContext(var2, to, a<"$">(4528800764046807990L, (long)a), a<"$">(4528942727647906522L, (long)a), mc.player));
      return hit.getType() != a<"$">(4529090615649771424L, (long)a);
   }

   public static double r(long a, Rotation a) {
      O();
      return 友树树何友何树友何何 == null ? 0.0 : Math.hypot(友友友树何友树友树友.E(a.getYaw(), 友树树何友何树友何何.getYaw()), a.l(5377274095808L) - 友树树何友何树友何何.l(5377274095808L));
   }

   public static Rotation E(long a, Rotation a) {
      a = 137331640367587L ^ a;
      long ax = a ^ 39716352487884L;
      long axx = a ^ 132381796806554L;
      long axxx = a ^ 100211210317123L;
      long axxxx = a ^ 84245400566653L;
      Rotation previousRotation = new Rotation(axxx, WrapperUtils.x(ax), WrapperUtils.o(axx));
      double mouseSensitivity = (Double)a<"x">(mc, -7802922428847968400L, (long)a).sensitivity().get() * 0.6F + 0.2F;
      double multiplier = mouseSensitivity * mouseSensitivity * mouseSensitivity * 8.0 * 0.15;
      float yaw = previousRotation.getYaw() + (float)(Math.round((a.getYaw() - previousRotation.getYaw()) / multiplier) * multiplier);
      float pitch = previousRotation.l(axxxx) + (float)(Math.round((a.l(axxxx) - previousRotation.l(axxxx)) / multiplier) * multiplier);
      return new Rotation(axxx, yaw, Mth.clamp(pitch, -90.0F, 90.0F));
   }

   private static RotationUtils.何树友何友树友何友友 E(long a) {
      boolean ax;
      boolean forward;
      boolean backward;
      boolean left;
      boolean right;
      boolean var9;
      boolean var10001;
      label208: {
         label207: {
            a = 137331640367587L ^ a;
            forward = a<"x">(a<"x">(mc, 1515546795053951438L, (long)a), 1516166045287832751L, (long)a).isDown();
            var9 = a<"ô">(1518051113639413817L, (long)a);
            backward = a<"x">(a<"x">(mc, 1515546795053951438L, (long)a), 1518334323052976828L, (long)a).isDown();
            left = a<"x">(a<"x">(mc, 1515546795053951438L, (long)a), 1518166987588900915L, (long)a).isDown();
            right = a<"x">(a<"x">(mc, 1515546795053951438L, (long)a), 1516112161280968597L, (long)a).isDown();
            ax = var9;
            if (forward && left && !backward) {
               var9 = right;
               var10001 = ax;
               if (a < 0L) {
                  break label208;
               }

               if (ax) {
                  break label207;
               }

               if (!right) {
                  return a<"$">(1516760445268069110L, (long)a);
               }
            }

            var9 = forward;
         }

         var10001 = ax;
      }

      label196: {
         label195:
         if (!var10001) {
            if (var9 && right && !backward) {
               var9 = left;
               var10001 = ax;
               if (a <= 0L) {
                  break label196;
               }

               if (ax) {
                  break label195;
               }

               if (!left) {
                  return a<"$">(1515464043600131177L, (long)a);
               }
            }

            var9 = backward;
         }

         var10001 = ax;
      }

      label183: {
         label182:
         if (!var10001) {
            if (var9 && left && !forward) {
               var9 = right;
               var10001 = ax;
               if (a < 0L) {
                  break label183;
               }

               if (ax) {
                  break label182;
               }

               if (!right) {
                  return a<"$">(1517051829074567658L, (long)a);
               }
            }

            var9 = backward;
         }

         var10001 = ax;
      }

      label170: {
         label169:
         if (!var10001) {
            if (var9 && right && !forward) {
               var9 = left;
               var10001 = ax;
               if (a < 0L) {
                  break label170;
               }

               if (ax) {
                  break label169;
               }

               if (!left) {
                  return a<"$">(1518429942554853877L, (long)a);
               }
            }

            var9 = forward;
         }

         var10001 = ax;
      }

      label157: {
         label156:
         if (!var10001) {
            if (var9 && !backward && !left) {
               var9 = right;
               var10001 = ax;
               if (a < 0L) {
                  break label157;
               }

               if (ax) {
                  break label156;
               }

               if (!right) {
                  return a<"$">(1517290607006068709L, (long)a);
               }
            }

            var9 = backward;
         }

         var10001 = ax;
      }

      label144: {
         label143:
         if (!var10001) {
            if (var9 && !forward && !left) {
               var9 = right;
               var10001 = ax;
               if (a <= 0L) {
                  break label144;
               }

               if (ax) {
                  break label143;
               }

               if (!right) {
                  return a<"$">(1518096405409226514L, (long)a);
               }
            }

            var9 = left;
         }

         var10001 = ax;
      }

      label131: {
         label130:
         if (!var10001) {
            if (var9 && !right && !forward) {
               var9 = backward;
               var10001 = ax;
               if (a < 0L) {
                  break label131;
               }

               if (ax) {
                  break label130;
               }

               if (!backward) {
                  return a<"$">(1518776041631317889L, (long)a);
               }
            }

            var9 = right;
         }

         var10001 = ax;
      }

      if (a > 0L) {
         if (!var10001) {
            if (!var9) {
               return a<"$">(1515846759070784061L, (long)a);
            }

            var9 = left;
         }

         var10001 = ax;
      }

      if (a >= 0L) {
         if (!var10001) {
            if (var9) {
               return a<"$">(1515846759070784061L, (long)a);
            }

            var9 = forward;
         }

         if (a <= 0L) {
            return !var9 ? a<"$">(1514490422333864873L, (long)a) : a<"$">(1515846759070784061L, (long)a);
         }

         var10001 = ax;
      }

      if (!var10001) {
         if (var9) {
            return a<"$">(1515846759070784061L, (long)a);
         }

         var9 = backward;
      }

      return !var9 ? a<"$">(1514490422333864873L, (long)a) : a<"$">(1515846759070784061L, (long)a);
   }

   @EventTarget(4)
   public void E(UpdateEvent event) {
      O();
      if (mc.player != null) {
         if (rotation == null || 友树树何友何树友何何 == null || 树何何何友树何树何树 == null || Float.isNaN(友树树何友何树友何何.getYaw()) || Float.isNaN(rotation.getYaw())) {
            rotation = 友树树何友何树友何何 = 树何何何友树何树何树 = new Rotation(21273681362686L, mc.player.getYRot(), mc.player.getXRot());
         }
      }
   }

   public static float[] E(double a, double var2, double var4, double var6, double var8, long var10, double var12) {
      long var10000 = 137331640367587L ^ var10;
      if (mc.player == null) {
         return null;
      } else {
         double x = a - var6;
         double y = var2 - var8;
         double z = var4 - var12;
         double dist = Math.sqrt(x * x + z * z);
         float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0F;
         float pitch = (float)(-(Math.atan2(y, dist) * 180.0 / Math.PI));
         return new float[]{yaw, pitch};
      }
   }

   public static boolean A(long a, float var2, LivingEntity entity) {
      q();
      if (mc.player == null) {
         return false;
      } else {
         Vec3 playerPos = mc.player.getEyePosition(1.0F);
         Vec3 targetPos = entity.getBoundingBox().getCenter();
         Vec3 lookVec = mc.player.getLookAngle();
         Vec3 toTarget = targetPos.subtract(playerPos);
         if (toTarget.lengthSqr() < 1.0E-7) {
            return true;
         } else {
            Vec3 toTargetVec = toTarget.normalize();
            double dotProduct = Mth.clamp(lookVec.dot(toTargetVec), -1.0, 1.0);
            double angle = Math.toDegrees(Math.acos(dotProduct));
            return var2 >= 180.0F || angle <= var2;
         }
      }
   }

   @EventTarget(4)
   public void A(MoveInputEvent event) {
      q();
      if (树友树友树何友树何友) {
         if (mc.player != null
            && rotation != null
            && RotationRender.instance != null
            && (!何树友树友友树何友树.树何何何何友何友何友.友树树友树树何友何何 || !何树友树友友树何友树.树何何何何友何友何友.isEnabled())) {
            float forward = event.getForwardImpulse();
            float strafe = event.getLeftImpulse();
            double yaw = Mth.wrapDegrees(Math.toDegrees(友友何树树友友树树树.B(52590846628474L, Mth.wrapDegrees(mc.player.getYRot()), forward, strafe)));
            if (forward != 0.0F || strafe != 0.0F) {
               float closestForward = 0.0F;
               float closestStrafe = 0.0F;
               float a = Mth.wrapDegrees(rotation.getYaw());
               double predictedAngle = Mth.wrapDegrees(Math.toDegrees(友友何树树友友树树树.B(52590846628474L, a, -1.0, -1.0)));
               double difference = Math.abs(yaw - predictedAngle);
               if (difference < Float.MAX_VALUE) {
                  float var10000 = (float)difference;
                  closestForward = -1.0F;
                  closestStrafe = -1.0F;
               }

               event.setForwardImpulse(closestForward);
               event.setLeftImpulse(closestStrafe);
            }
         }
      }
   }

   private static float L(long a, float var2, RotationUtils.何树友何友树友何友友 input) {
      float direction;
      label65: {
         label66: {
            label67: {
               label68: {
                  label69: {
                     label56: {
                        a = 137331640367587L ^ a;
                        boolean var10000 = a<"ô">(-3982211388563030329L, (long)a);
                        direction = var2;
                        int ax = var10000;
                        switch (a<"$">(-3988022143619332118L, (long)a)[input.ordinal()]) {
                           case 1:
                              direction = var2 + 0.0F;
                              var10000 = ax;
                              if (a < 0L) {
                                 break;
                              }

                              if (ax) {
                                 return direction;
                              }
                           case 2:
                              float var9 = direction + 180.0F;
                              if (a < 0L) {
                                 return var9;
                              }

                              direction = var9;
                              var10000 = ax;
                              break;
                           case 3:
                              break label56;
                           case 4:
                              break label69;
                           case 5:
                              break label68;
                           case 6:
                              break label67;
                           case 7:
                              break label66;
                           case 8:
                              break label65;
                           default:
                              return var2;
                        }

                        if (var10000) {
                           return direction;
                        }
                     }

                     float var10 = direction + 90.0F;
                     if (a <= 0L) {
                        return var10;
                     }

                     direction = var10;
                  }

                  float var11 = direction + -90.0F;
                  if (a < 0L) {
                     return var11;
                  }

                  direction = var11;
               }

               float var12 = direction + 45.0F;
               if (a <= 0L) {
                  return var12;
               }

               direction = var12;
            }

            float var13 = direction + -45.0F;
            if (a <= 0L) {
               return var13;
            }

            direction = var13;
         }

         float var14 = direction + 135.0F;
         if (a <= 0L) {
            return var14;
         }

         direction = var14;
      }

      direction += -135.0F;
      return direction;
   }

   public static float[] N(Vec3 a, long vec) {
      return mc.player == null ? null : G(a.x, a.y, a.z, 103100646439616L);
   }

   @EventTarget(0)
   public void N(PacketEvent e) {
      q();
      if (e.getSide() == Event.Side.POST
         && 友何树友何友何树树友.何友友何树树树何何树.isEnabled()
         && 友何树友何友何树树友.何友友何树树树何何树.友树友友树友何何树友.getValue()
         && 友何树友何友何树树友.何友友何树树树何何树.树何友何树何友何树何.getValue()
         && e.getPacket() instanceof ServerboundMovePlayerPacket wrapper
         && !e.isCancelled()
         && wrapper.getYRot(0.0F) < 360.0F
         && wrapper.getYRot(0.0F) > -360.0F) {
         WrapperUtils.C(wrapper, 46240972690895L, wrapper.getYRot(0.0F) + 720.0F);
      }
   }

   public static void P(long a, Rotation rotation, boolean a) {
      a = 137331640367587L ^ a;
      a<"E">(rotation, 7311238496611051008L, (long)a);
      a<"E">(a<"$">(7311238496611051008L, (long)a), 7311255511192427826L, (long)a);
      a<"E">(true, 7310847046088684606L, (long)a);
      a<"E">(0, 7310287343812940576L, (long)a);
      a<"E">((boolean)a, 7309399732426089795L, (long)a);
   }

   public static Rotation W(LivingEntity a, long a) {
      double x = a.getX() - mc.player.getX();
      double z = a.getZ() - mc.player.getZ();
      double y = a.getY() + a.getEyeHeight() - (mc.player.getY() + mc.player.getEyeHeight());
      double d3 = Math.sqrt(x * x + z * z);
      float yaw = (float)Math.toDegrees(Math.atan2(z, x)) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(y, d3)));
      return new Rotation(21273681362686L, yaw, pitch);
   }

   @EventTarget(4)
   public void W(MotionEvent event) {
      q();
      if (rotation != null && event.isPre() && mc.player != null) {
         event.setYaw(rotation.getYaw());
         event.setPitch(rotation.l(5377274095808L));
         if (RotationRender.instance != null && RotationRender.instance.realisticYaw.getValue()) {
            mc.player.yHeadRot = rotation.getYaw();
         }
      }
   }

   @EventTarget(4)
   public void H(LookEvent event) {
      if (q()) {
         if (rotation == null) {
            return;
         }

         event.setRotationYaw(rotation.getYaw());
      }

      event.setRotationPitch(rotation.l(5377274095808L));
   }

   private static float[] T(float a, long a) {
      boolean right;
      byte var10000;
      label36: {
         a = 137331640367587L ^ a;
         long ax = a ^ 81998378327944L;
         a<"ô">(5170779608550300394L, a);
         right = false;
         if (mc.player.onGround()) {
            right = Math.floor(mc.player.getX() + Math.cos(Math.toRadians(a)) * 0.5) != Math.floor(mc.player.getX())
               || Math.floor(mc.player.getZ() + Math.sin(Math.toRadians(a)) * 0.5) != Math.floor(mc.player.getZ());
            boolean ccb = 树何树树何何树友何何.Y(mc.player.blockPosition().below(), ax) instanceof AirBlock;
            boolean cb = 树何树树何何树友何何.Y(mc.player.blockPosition().relative(Direction.fromYRot(a), 1).below(), ax) instanceof AirBlock;
            if (ccb) {
               var10000 = cb;
               if (a < 0L) {
                  break label36;
               }

               if (cb != 0) {
                  right = !right;
               }
            }
         }

         var10000 = 2;
      }

      float[] var11 = new float[var10000];
      var11[0] = a + (right ? 45 : -45);
      var11[1] = 75.0F + (float)(Math.random() - 0.5);
      return var11;
   }

   public static float[] R(BlockPos a, long a) {
      return o(mc.player.position().add(0.0, mc.player.getEyeHeight(), 0.0), 18949280729402L, new Vec3(a.getX() + 0.51, a.getY() + 0.51, a.getZ() + 0.51));
   }

   public static float K(long a, float var2, float angle2) {
      q();
      float angle3 = Math.abs(var2 - angle2) % 360.0F;
      if (angle3 > 180.0F) {
         angle3 = 0.0F;
      }

      return angle3;
   }

   private static float[] K(BlockPos a, long a) {
      long ax = 137331640367587L ^ a ^ 50076409159658L;
      float move = (float)(Math.floor(R(a, ax)[0] / 90.0F) * 90.0);
      float yaw = move + 45.0F;
      return new float[]{yaw + (float)(Math.random() - 0.5), 75.0F + (float)(Math.random() - 0.5)};
   }

   private static String HE_SHU_YOU() {
      return "刘凤楠230622109211173513";
   }

   public static float[] G(double a, double var2, double var4, long var6) {
      long ax = 137331640367587L ^ var6 ^ 18753489429050L;
      return mc.player == null ? null : E((double)a, var2, var4, mc.player.getX(), mc.player.getEyeY(), ax, mc.player.getZ());
   }

   public static Rotation G(Vec3 a, long to) {
      q();
      if (mc.player == null) {
         return null;
      } else {
         Vec3 from = mc.player.position().add(0.0, mc.player.getEyeHeight(), 0.0);
         Vec3 diff = a.add(0.0, -0.7, 0.0).subtract(from);
         double horizontalDistance = Math.hypot(diff.x, diff.z);
         float yaw = (float)(Mth.atan2(diff.z, diff.x) * (180.0 / Math.PI)) - 90.0F;
         double timeEstimate = horizontalDistance / 1.5;
         double gravityCompensation = 0.015 * timeEstimate * timeEstimate;
         double compensatedY = diff.y + gravityCompensation;
         double pitchRadians = Math.atan2(compensatedY, horizontalDistance);
         float pitch = (float)(-(pitchRadians * (180.0 / Math.PI)));
         return new Rotation(21273681362686L, yaw, pitch);
      }
   }

   public static Rotation O(long a, Vec3 var2) {
      return h(mc.player.getPosition(1.0F).add(0.0, mc.player.getEyeHeight(), 0.0), var2, 136157929363751L);
   }

   @EventTarget(4)
   public void O(JumpEvent event) {
      if (rotation != null && 树友树友树何友树何友) {
         event.setRotationYaw(rotation.getYaw());
      }
   }

   public static boolean O() {
      return 树友友何何友树友友树;
   }

   public static enum 何树友何友树友何友友 implements  {
      树何何树友何何树树友,
      友友何友树友树友何树,
      树树何何何树何何友树,
      树树友何友何树树友何,
      树友友何友何友何何树,
      友友树友友树树何树树,
      何友何友友友何友何何,
      树何树友何何何友树树,
      友树友何友树树树友树;

      private static final long a;
      private static final Object[] b = new Object[13];
      private static final String[] c = new String[13];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-1767657117425006666L, -5974706840306881118L, MethodHandles.lookup().lookupClass()).a(188027924876175L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(386166223538L << var2 * 8 >>> 56);
         }

         var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[9];
         int var6 = 0;
         String var5 = "\u0001Ga'Ä^à5\u0010+!¤ÅÁ\u0011\u009bvîøå/Ô\u008f-\u009f\bö\"Ñ\u00ad\u0005\u000bÿ)\u0010+!¤ÅÁ\u0011\u009bvx\u001a\u0019\u008aÎ\u008fï\u0088\u0010\u008bæÇ\u001aÊ\u0080\u008eQ\u00001ÿ»\u0081¶©§\bHæÃ\\æ\u008få8\u0010+!¤ÅÁ\u0011\u009bv\u009f~\u001bj\u0013:D¶";
         byte var7 = 94;
         char var4 = '\b';
         int var9 = -1;

         label28:
         while (true) {
            String var11 = var5.substring(++var9, var9 + var4);
            byte var10001 = -1;

            while (true) {
               String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var17;
                     if ((var9 += var4) >= var7) {
                        树何何树友何何树树友 = new RotationUtils.何树友何友树友何友友();
                        友友何友树友树友何树 = new RotationUtils.何树友何友树友何友友();
                        树树何何何树何何友树 = new RotationUtils.何树友何友树友何友友();
                        树树友何友何树树友何 = new RotationUtils.何树友何友树友何友友();
                        树友友何友何友何何树 = new RotationUtils.何树友何友树友何友友();
                        友友树友友树树何树树 = new RotationUtils.何树友何友树友何友友();
                        何友何友友友何友何何 = new RotationUtils.何树友何友树友何友友();
                        树何树友何何何友树树 = new RotationUtils.何树友何友树友何友友();
                        友树友何友树树树友树 = new RotationUtils.何树友何友树友何友友();
                        return;
                     }

                     var4 = var5.charAt(var9);
                     break;
                  default:
                     var0[var6++] = var17;
                     if ((var9 += var4) < var7) {
                        var4 = var5.charAt(var9);
                        continue label28;
                     }

                     var5 = "\u008bæÇ\u001aÊ\u0080\u008eQ Â\tM©¯\u008fH\u0010\u008bæÇ\u001aÊ\u0080\u008eQò^\u0094H\u0018ü\u001d\u0010";
                     var7 = 33;
                     var4 = 16;
                     var9 = -1;
               }

               var11 = var5.substring(++var9, var9 + var4);
               var10001 = 0;
            }
         }
      }

      public static RotationUtils.何树友何友树友何友友 e(String a) {
         return Enum.valueOf(RotationUtils.何树友何友树友何友友.class, a);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/utils/player/RotationUtils$何树友何友树友何友友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'B' && var8 != 244 && var8 != 232 && var8 != 217) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'i') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'x') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'B') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 244) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 232) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      public static RotationUtils.何树友何友树友何友友[] a(long var0) {
         var0 = 3228216137300L ^ var0;
         return (RotationUtils.何树友何友树友何友友[])a<"è">(-6737234961286352280L, var0).clone();
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 18;
                  case 1 -> 20;
                  case 2 -> 56;
                  case 3 -> 58;
                  case 4 -> 54;
                  case 5 -> 25;
                  case 6 -> 35;
                  case 7 -> 31;
                  case 8 -> 42;
                  case 9 -> 27;
                  case 10 -> 51;
                  case 11 -> 33;
                  case 12 -> 24;
                  case 13 -> 60;
                  case 14 -> 6;
                  case 15 -> 32;
                  case 16 -> 61;
                  case 17 -> 12;
                  case 18 -> 40;
                  case 19 -> 29;
                  case 20 -> 62;
                  case 21 -> 11;
                  case 22 -> 37;
                  case 23 -> 17;
                  case 24 -> 28;
                  case 25 -> 19;
                  case 26 -> 55;
                  case 27 -> 52;
                  case 28 -> 45;
                  case 29 -> 13;
                  case 30 -> 23;
                  case 31 -> 48;
                  case 32 -> 0;
                  case 33 -> 30;
                  case 34 -> 49;
                  case 35 -> 15;
                  case 36 -> 41;
                  case 37 -> 10;
                  case 38 -> 14;
                  case 39 -> 2;
                  case 40 -> 7;
                  case 41 -> 47;
                  case 42 -> 39;
                  case 43 -> 59;
                  case 44 -> 3;
                  case 45 -> 44;
                  case 46 -> 46;
                  case 47 -> 43;
                  case 48 -> 8;
                  case 49 -> 22;
                  case 50 -> 16;
                  case 51 -> 34;
                  case 52 -> 53;
                  case 53 -> 9;
                  case 54 -> 21;
                  case 55 -> 1;
                  case 56 -> 63;
                  case 57 -> 4;
                  case 58 -> 57;
                  case 59 -> 26;
                  case 60 -> 38;
                  case 61 -> 36;
                  case 62 -> 50;
                  default -> 5;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "Hc\u0001M?.G#LF53B~G\u0000%5Ba\\\u0000 -JtJ\\~\u0013DyNZ9.EX[G<2\u000f佘栾句伅厊栺叆佺句厛";
         b[1] = "G\"\u0003\u001da\u001ds\u0001\f],\u0016y\u001c\t\u0000'Pi\u001a\t\u001f<Pl\u0002\u0001\n*\f2<\u000f\u0007.\nu\u0001\u000e&;\u0017p\u001dD伦桞厵佉厥桱厸会厵受U";
         b[2] = "\b/zc|\u000e\u0003 k,\u001d\u0000\b+ov";
         b[3] = "\u0018J>]@4XD#0司厝格叶厂栩栢伃格栬A\rD!HN+MJ<";
         b[4] = "O\u0010p\u0013U\u001f\u000f\u001em~叭厶伯厬栖厽样厶伯桶\u000fCQ\n\u001f\u0014e\u0003_\u0017";
         b[5] = "=VrY\\{}Xo4栾栈參佴収佩栾栈參佴\r\tXnmRgIVs";
         b[6] = "|R\u0014oR\u000b<\\\t\u0002栰厢伜栴厨栛只厢厂佰k;\u0014\u00038\u0015\u0004;H\rx";
         b[7] = "\u0015lV\\-6UbK1伋原併叐只史伋原併低)\f)#EhCL'>";
         b[8] = "fp\u001e(\u001d6&~\u0003E桿原厘佒厢优厥企伆栖ax\u0019#6t\u000b8\u0017>";
         b[9] = "|;D$\u0019s<5YI桻佄桘厇佦伔伿叚桘桝;t\u001df,?Q4\u0013{";
         b[10] = "\u0013|vdV)Srk\t栴伞佳栚及佔佰桚样叀\t4R<Cxct\\!";
         b[11] = "$:76,nd4*[厔栝叚优压桂桎栝叚桜Hf({t>\"&&f";
         b[12] = "\u0003\u0017\brzhC\u0019\u0015\u001f栘栛佣伵伪栆作佟叽桱w\"~}S\u0013\u001dbp`";
      }

      private static String HE_WEI_LIN() {
         return "刘凤楠230622109211173513";
      }
   }
}
