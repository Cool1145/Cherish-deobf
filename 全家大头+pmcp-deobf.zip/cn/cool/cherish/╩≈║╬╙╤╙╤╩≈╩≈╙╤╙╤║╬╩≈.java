package cn.cool.cherish;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树何友友树树友友何树 extends 何何何何何何何友树友 implements 何树友 {
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[7];
   private static final String[] i = new String[7];
   private static int _我是何树友 _;

   public 树何友友树树友友何树() {
      super("friend", "f", "hy");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7923423250421660476L, -5502187168881897907L, MethodHandles.lookup().lookupClass()).a(137793429090603L);
      // $VF: monitorexit
      b = var10000;
      b();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(100343083880000L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[17];
      int var7 = 0;
      String var6 = "D¹à\u008cUu;¦·D\u0003YB\u001a\u008aNzò¿³\u008ev}\u0097 P:Óä\u001bD±{GP\"-\u009e8©(ä\u0003«ô1ø\u0094²E\u0014\u0088\u0083a\u0095]Æ'\u0010[¾÷üRû:0Ò\u0088\u0012óñs\r$\\ÙÂÛ¿#X)Uêð9l»Ä;!\u0088\u001djR\u0001ª\u0097ÜÀ`|xc©ó\u008e½g\u0002\u008a2ø<\u0018;\u00997er¶ååW^Ç¢Á\nÅ\u0001ú¬ßÌ\u0083\u0011\u0094Ø`@Ê¯\u001d\r\u0017¯\\Øµ<ØÝÅ\u0018KB\u0094üÀÜ6(\u0087Î\u0012\u0094Õ\u001cHnKdç\u00804Y)\u0006×µJøG\báñ>Õ¦S\u001aõ\u0000X3MFN\u001bß¢x\u0019Â\u0002¡ÝÒ¹Ör%\u0001\u0010\u001aþÅ<xò\u000b\u0085\u0003î½Òü'!½Í\u0016Ör\u0092ÛUåòýá\u0010?h\u009fá¢UDº\u0002=d'ó+§{\u0010L|/MÐz\u0093\u0098\u009dpÿ\nún\n+\u00105åì±ªØXøs\u000boüeÌoË 8ÿó(,z&sÞar!NÃÆ©s®ÅLÔ\u0089´â\u000bw\u0093;Ë\u0088\u001e\u001b BËè°«yi[1\u0099\u0088W\u0091.\u0016¡\u001c¶ã\u0011\u0082\u0003Ï¶;\u0083\u007fÝÜïa6\u0010_\"Æ\u000eI¯\u001aoÅîfÓÈ¿\u009fN\u0010û\u001b3ª²C\"Ôì0í=\u0098@\t](Õ¤\t§\r4Ye\u008c\u0088+Ëä\u009bÛ^Ig\u001fûTÞ-aêÊÂº\u001bHw\u009aj\u0093D\u0094òt/3\u0010ÃÜ\u0011±ôs\u0016u\u009dè\u0083®ýüHqX\u009c?à\u008fðuÍ\u008c\u0099\u0088MõãK\u000b[V\u0016\u0092\u001c\u009c¢\u0000l±@:5\u0002÷$¸Ç\tb]\u00178\u00ad\u0012üçº\u0001B>õ\u0017\u007fFHêü\u0085\u009cB \u0098ãÒ\u008e\u008daU\u0080Gd«\u0003ºµÖÁ\ra\u008fz¢<º\u0001^GØZ%#Q\u0010m+ÿG\u0019\u0006Ýt\u0087¹$\u009dÚWñ\u0098";
      short var8 = 558;
      char var5 = '(';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     d = new String[17];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "\u009d\u007f\u009ckGÌBõtÛf]å|ì\"ÖD\u0098´Ù`ü§ë$JP<Ðê\"\nwbÿ²á\tAIqº¡\u008fÑvV\u00ad(¿Ì¢\u0019\tjoïÖ+£¨;_\u0010\u0098\u009bK¼è{þ\n -Ó\u001c»Ò¼j";
                  var8 = 81;
                  var5 = '@';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 25;
               case 1 -> 7;
               case 2 -> 35;
               case 3 -> 37;
               case 4 -> 6;
               case 5 -> 27;
               case 6 -> 8;
               case 7 -> 34;
               case 8 -> 1;
               case 9 -> 15;
               case 10 -> 12;
               case 11 -> 23;
               case 12 -> 5;
               case 13 -> 19;
               case 14 -> 31;
               case 15 -> 30;
               case 16 -> 14;
               case 17 -> 58;
               case 18 -> 49;
               case 19 -> 51;
               case 20 -> 32;
               case 21 -> 4;
               case 22 -> 20;
               case 23 -> 40;
               case 24 -> 36;
               case 25 -> 54;
               case 26 -> 13;
               case 27 -> 0;
               case 28 -> 44;
               case 29 -> 52;
               case 30 -> 48;
               case 31 -> 17;
               case 32 -> 46;
               case 33 -> 3;
               case 34 -> 50;
               case 35 -> 47;
               case 36 -> 29;
               case 37 -> 33;
               case 38 -> 16;
               case 39 -> 42;
               case 40 -> 63;
               case 41 -> 39;
               case 42 -> 9;
               case 43 -> 24;
               case 44 -> 56;
               case 45 -> 41;
               case 46 -> 10;
               case 47 -> 43;
               case 48 -> 61;
               case 49 -> 11;
               case 50 -> 57;
               case 51 -> 22;
               case 52 -> 28;
               case 53 -> 55;
               case 54 -> 26;
               case 55 -> 62;
               case 56 -> 59;
               case 57 -> 18;
               case 58 -> 38;
               case 59 -> 53;
               case 60 -> 60;
               case 61 -> 21;
               case 62 -> 45;
               default -> 2;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   @Override
   public void i(String[] params) {
      友树友友何树何何树树.B();
      if (params.length < 1) {
         ClientUtils.P(125527250587045L, "Usage: .friend <add/remove/list/clear> [player name]");
      } else {
         String action = params[0].toLowerCase();
         byte var9 = -1;
         switch (action.hashCode()) {
            case 96417:
               if (!action.equals("add")) {
                  break;
               }

               var9 = 0;
            case 97:
               if (!action.equals("a")) {
                  break;
               }

               var9 = 1;
            case -934610812:
               if (!action.equals("remove")) {
                  break;
               }

               var9 = 2;
            case 99339:
               if (!action.equals("del")) {
                  break;
               }

               var9 = 3;
            case 114:
               if (!action.equals("r")) {
                  break;
               }

               var9 = 4;
            case 3322014:
               if (!action.equals("list")) {
                  break;
               }

               var9 = 5;
            case 108:
               if (!action.equals("l")) {
                  break;
               }

               var9 = 6;
            case 94746189:
               if (!action.equals("clear")) {
                  break;
               }

               var9 = 7;
            case 99:
               if (action.equals("c")) {
                  var9 = 8;
               }
         }

         switch (var9) {
            case 0:
            case 1:
               if (params.length == 1) {
                  ClientUtils.P(125527250587045L, "Usage: .friend add <player name>");
                  return;
               } else {
                  String name = params[1];
                  Cherish.instance.P().j(name);
                  ClientUtils.P(125527250587045L, "Added friend: " + name);
               }
            case 2:
            case 3:
            case 4:
               if (params.length == 1) {
                  ClientUtils.P(125527250587045L, "Usage: .friend remove <player name>");
                  return;
               } else {
                  String name = params[1];
                  Cherish.instance.P().l(name);
                  ClientUtils.P(125527250587045L, "Removed friend: " + name);
               }
            case 5:
            case 6:
               Set<String> friends = Cherish.instance.P().v();
               if (friends.isEmpty()) {
                  ClientUtils.P(125527250587045L, "Friend list is empty");
               }

               StringBuilder sb = new StringBuilder("Friend list: ");
               Iterator var13 = friends.iterator();
               if (var13.hasNext()) {
                  String friend = (String)var13.next();
                  sb.append(friend);
               }

               ClientUtils.P(125527250587045L, sb.toString());
            case 7:
            case 8:
               Cherish.instance.P().B();
               ClientUtils.P(125527250587045L, "");
            default:
               ClientUtils.P(125527250587045L, "Friend list cleared");
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'b' && var8 != 232 && var8 != 244 && var8 != 203) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'Q') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 242) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'b') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 232) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 244) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      h[0] = "#\u0012'5\fE,Rj>\u0006X)\u000fax桲使压厷栘桇厨叡伕桭";
      h[1] = "hq_s\u000fkc~N<srld@\u007fDBzsLbUnm~";
      h[2] = "k\u001dv\u000byMd];\u0000sPa\u00000F叝栳參厸伍桹佃佷栙桢";
      h[3] = "xoq}rHLL~=?CFQ{`4\u0005NLvf0N\rn}w)GF\u0018";
      h[4] = "m@jRC\u0005fO{\u001d\"\u000bmD\u007fG";
      h[5] = "BF\u0010\ra\u000f\u0012\u0000\u0000j1wF\u0005\u0012\u0014 I\u0003SSRXNCA\u0014\u0012f\u000b\u0015\u0000Rj";
      h[6] = "?R#nGJ7\u00157\u007fva\u0006\u00165g\u0004Ml\\|o\u0019+";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/树何友友树树友友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25143;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/树何友友树树友友何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/树何友友树树友友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String HE_SHU_YOU() {
      return "何炜霖黑水";
   }
}
