package cn.cool.cherish;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class 友树树友树树友友何何 implements 何树友 {
   private final String[] 友友友何友友何友何何;
   private static int 树树树何何友友树何友;
   private static final long a;
   private static final Object[] f = new Object[8];
   private static final String[] g = new String[8];
   private static String HE_DA_WEI;

   public 友树树友树树友友何何(String... name) {
      this.友友友何友友何友何何 = name;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7508176086844470908L, 9139809221408580759L, MethodHandles.lookup().lookupClass()).a(217654649592112L);
      // $VF: monitorexit
      a = var10000;
      long var0 = a ^ 27853217717696L;
      a();
      if (b<"p">(-194870947098587443L, var0) == 0) {
         b<"p">(47, -194791401412349982L, var0);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友树树友树树友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int d() {
      return 树树树何何友友树何友;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'o' && var8 != 202 && var8 != 'n' && var8 != 229) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 210) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'p') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'o') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      f[0] = "6.X#8\u00079n\u0015(2\u001a<3\u001en厜桹桄压桧桑厜厣伀伕";
      f[1] = int.class;
      g[1] = "java/lang/Integer";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = "\u0004kVri(qK]}xg\fSNzq.d";
      f[4] = "\nU9Tr\u001b\u0001Z(\u001b\u0013\u0015\nQ,A";
      f[5] = "Up\u0019>Q(\u001ba\u001fF号叕厩佁去厅佩叕伷佁x|\b+R\"\u0018 E(\u0016";
      f[6] = "\u00054~\u0000QjK%xx}T@hr\u0004O,\u0006%ox";
      f[7] = "\"\u001e:{|\"l\u000f<\u0003V\u001cgB6\u007fbd!\u000f+\u0003 nl\u00194ftd \u0014[";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 6;
               case 2 -> 52;
               case 3 -> 55;
               case 4 -> 8;
               case 5 -> 42;
               case 6 -> 16;
               case 7 -> 56;
               case 8 -> 61;
               case 9 -> 10;
               case 10 -> 54;
               case 11 -> 46;
               case 12 -> 44;
               case 13 -> 57;
               case 14 -> 18;
               case 15 -> 0;
               case 16 -> 31;
               case 17 -> 17;
               case 18 -> 27;
               case 19 -> 62;
               case 20 -> 59;
               case 21 -> 22;
               case 22 -> 13;
               case 23 -> 34;
               case 24 -> 47;
               case 25 -> 39;
               case 26 -> 40;
               case 27 -> 21;
               case 28 -> 26;
               case 29 -> 60;
               case 30 -> 7;
               case 31 -> 53;
               case 32 -> 11;
               case 33 -> 4;
               case 34 -> 63;
               case 35 -> 41;
               case 36 -> 49;
               case 37 -> 58;
               case 38 -> 23;
               case 39 -> 30;
               case 40 -> 3;
               case 41 -> 45;
               case 42 -> 25;
               case 43 -> 50;
               case 44 -> 43;
               case 45 -> 38;
               case 46 -> 36;
               case 47 -> 2;
               case 48 -> 12;
               case 49 -> 1;
               case 50 -> 14;
               case 51 -> 15;
               case 52 -> 51;
               case 53 -> 33;
               case 54 -> 5;
               case 55 -> 35;
               case 56 -> 32;
               case 57 -> 9;
               case 58 -> 20;
               case 59 -> 28;
               case 60 -> 48;
               case 61 -> 29;
               case 62 -> 24;
               default -> 19;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static int A() {
      d();

      try {
         return 75;
      } catch (RuntimeException var0) {
         throw b(var0);
      }
   }

   public abstract void W(String[] var1);

   public String[] T() {
      long a = 友树树友树树友友何何.a ^ 68942847821241L;
      return b<"o">(this, 7292020405226788975L, a);
   }

   public static void G(int var0) {
      树树树何何友友树何友 = var0;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖大狗叫";
   }
}
