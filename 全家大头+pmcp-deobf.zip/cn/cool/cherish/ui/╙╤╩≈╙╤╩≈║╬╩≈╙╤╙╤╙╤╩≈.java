package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 友树友树何树友友友树 implements IWrapper, 何树友 {
   public final HashMap<String, HashMap<String, Float>> 友树友何树树友友何何;
   public final HashMap<NumberValue, Float> 何何树树树友友何何树;
   public final HashMap<NumberValue, Float> 树友树树友树何友友何;
   public final HashMap<NumberValue, float[]> 何树友何树树何友友树;
   public final HashMap<ModeValue, Boolean> 友何友友友何何何友树;
   public final HashMap<ModeValue, Float> 何树何何友友友树何树;
   public 友树友树何树友友友树.树树树何何友友何何友 树树树友树友何树树树;
   public 树友何友何何友树树友 何树树友友树友树友树;
   public 树何何何友树树何友何<?> 何树树何何何树树何何;
   public float 树何何何树何树友树友;
   public float 友友友何树何树何树树;
   public float 友树友何友树树树友树;
   private final Module 友友树友树树友树友何;
   public Color 何何友友何友何树何树;
   public boolean 友何友友友树何树友树;
   public float 树树友何何树友何树何;
   private static final float 友何友何树友何树何何 = 16.0F;
   public 友树何树友友何树友友 何何树何友友树友何何;
   public final HashMap<树友何友何何友树树友, Float> 何友树树树友友友何友;
   public final HashMap<树友何友何何友树树友, Boolean> 友树何树树何树何树友;
   private final Map<Class<? extends 树何何何友树树何友何<?>>, 友树何树友友树树何树<?>> 何友友何树何树何树友;
   private static int 友何树何树友友友友友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[42];
   private static final String[] g = new String[42];
   private static String HE_JIAN_GUO;

   public 友树友树何树友友友树(Module module) {
      long a = 友树友树何树友友友树.a ^ 45417417749681L;
      super();
      this.友树友何树树友友何何 = new HashMap<>();
      this.何何树树树友友何何树 = new HashMap<>();
      this.树友树树友树何友友何 = new HashMap<>();
      this.何树友何树树何友友树 = new HashMap<>();
      this.友何友友友何何何友树 = new HashMap<>();
      this.何树何何友友友树何树 = new HashMap<>();
      b<"ì">(this, null, -3517053593995370858L, a);
      b<"ì">(this, null, -3516745355907459603L, a);
      b<"ì">(this, null, -3516216762960795135L, a);
      int var10000 = b<"C">(-3516272247803261554L, a);
      this.何友树树树友友友何友 = new HashMap<>();
      this.友树何树树何树何树友 = new HashMap<>();
      this.何友友何树何树何树友 = new HashMap<>();
      this.友友树友树树友树友何 = module;
      b<"Z">(this, -3516372537255532020L, a).put(BooleanValue.class, new 树何何何何树何树何树());
      int var4 = var10000;
      b<"Z">(this, -3516372537255532020L, a).put(NumberValue.class, new 树何友树友友树树何友());
      b<"Z">(this, -3516372537255532020L, a).put(ModeValue.class, new 友树树友友树友何树友());
      b<"Z">(this, -3516372537255532020L, a).put(友树何树友友何树友友.class, new 何何树何树何树友树友());
      b<"Z">(this, -3516372537255532020L, a).put(树友何友何何友树树友.class, new 友何何友树何树树树何());
      if (!b<"C">(-3513922612849186729L, a)) {
         b<"C">(++var4, -3513308663933711269L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(3726923521458402176L, -7519164127954917020L, MethodHandles.lookup().lookupClass()).a(9130634568641L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 62446301994526L;
      a();
      b<"C">(55, 2706990925611345652L, var9);
      Cipher var0;
      Cipher var12 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[2];
      int var5 = 0;
      char var3 = '@';
      int var2 = -1;

      while (true) {
         String var14 = b(
               var0.doFinal(
                  "Æ!Ö\u008eÝÜy\u0082ËZ½)¬g\u0001\u009aÆ¤n\u0015a<w\u001fö\u0098á\u0083IÞy´/9\fâÈ\u0098\u0005×\u0017\"k\u0014\rÙm´Xnvi\u000bÝà\u0001%\u000e¡\u009f;\u0082`c(Á\u008a\u0016Ú`à\u007fÚ?Sô¦k¸Ó'\u0088ª\u001fôÄû¯+\u0002'\u0092ª¹D+´ëa»\u001eÑ\u008fTU"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var14;
         if ((var2 += var3) >= 105) {
            b = var7;
            c = new String[2];
            return;
         }

         var3 = "Æ!Ö\u008eÝÜy\u0082ËZ½)¬g\u0001\u009aÆ¤n\u0015a<w\u001fö\u0098á\u0083IÞy´/9\fâÈ\u0098\u0005×\u0017\"k\u0014\rÙm´Xnvi\u000bÝà\u0001%\u000e¡\u009f;\u0082`c(Á\u008a\u0016Ú`à\u007fÚ?Sô¦k¸Ó'\u0088ª\u001fôÄû¯+\u0002'\u0092ª¹D+´ëa»\u001eÑ\u008fTU"
            .charAt(var2);
      }
   }

   public void D(char chr, int modifiers) {
      long a = 友树友树何树友友友树.a ^ 1879211751400L;
      b<"C">(5506382811968163543L, a);
      if (b<"Z">(this, 5506437248297478488L, a) != null && b<"Z">(this, 5504738245486019056L, a)) {
         友树何树友友树树何树<友树何树友友何树友友> renderer = this.i(b<"Z">(this, 5506437248297478488L, a));
         if (renderer != null) {
            renderer.Q(b<"Z">(this, 5506437248297478488L, a), chr, modifiers, this);
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 21;
               case 1 -> 24;
               case 2 -> 19;
               case 3 -> 10;
               case 4 -> 9;
               case 5 -> 16;
               case 6 -> 59;
               case 7 -> 62;
               case 8 -> 47;
               case 9 -> 57;
               case 10 -> 38;
               case 11 -> 49;
               case 12 -> 17;
               case 13 -> 33;
               case 14 -> 40;
               case 15 -> 63;
               case 16 -> 8;
               case 17 -> 41;
               case 18 -> 60;
               case 19 -> 39;
               case 20 -> 55;
               case 21 -> 35;
               case 22 -> 3;
               case 23 -> 30;
               case 24 -> 45;
               case 25 -> 13;
               case 26 -> 27;
               case 27 -> 6;
               case 28 -> 46;
               case 29 -> 4;
               case 30 -> 5;
               case 31 -> 56;
               case 32 -> 25;
               case 33 -> 61;
               case 34 -> 22;
               case 35 -> 12;
               case 36 -> 29;
               case 37 -> 26;
               case 38 -> 1;
               case 39 -> 48;
               case 40 -> 20;
               case 41 -> 43;
               case 42 -> 32;
               case 43 -> 52;
               case 44 -> 7;
               case 45 -> 18;
               case 46 -> 54;
               case 47 -> 53;
               case 48 -> 11;
               case 49 -> 36;
               case 50 -> 37;
               case 51 -> 2;
               case 52 -> 23;
               case 53 -> 58;
               case 54 -> 42;
               case 55 -> 51;
               case 56 -> 31;
               case 57 -> 50;
               case 58 -> 28;
               case 59 -> 0;
               case 60 -> 34;
               case 61 -> 44;
               case 62 -> 15;
               default -> 14;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private <T extends 树何何何友树树何友何<?>> 友树何树友友树树何树<T> i(T value) {
      long a = 友树友树何树友友友树.a ^ 69139305968885L;
      b<"C">(5725572013358771605L, a);
      if (value == null) {
         return null;
      } else {
         Class<?> valueClass = value.getClass();
         return 树何何何友树树何友何.class.isAssignableFrom(valueClass) ? (友树何树友友树树何树)b<"Z">(this, 5726118439835757128L, a).get(valueClass) : null;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Z' && var8 != 236 && var8 != 224 && var8 != 253) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'b') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'C') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Z') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 224) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树友树何树友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public float l() {
      long a = 友树友树何树友友友树.a ^ 74652227837333L;
      b<"C">(7355834416337962229L, a);
      float totalHeight = 0.0F;

      for (树何何何友树树何友何<?> value : b<"Z">(this, 7356059931796140729L, a).q()) {
         if (!value.n()) {
            友树何树友友树树何树<树何何何友树树何友何<?>> renderer = this.i(value);
            totalHeight = 16.0F + renderer.h(value, this);
            break;
         }
      }

      return totalHeight;
   }

   public void l(double mouseX, double mouseY, int button) {
      long a = 友树友树何树友友友树.a ^ 2074046566885L;
      b<"C">(-1556716692743108475L, a);
      if (b<"Z">(this, -1557112480915797923L, a) instanceof NumberValue ns) {
         友树何树友友树树何树<NumberValue> renderer = this.i(ns);
         renderer.N(ns, mouseX, mouseY, button, this);
      }

      if (b<"Z">(this, -1556510341857038151L, a) != null && button == 0) {
         友树何树友友树树何树<树友何友何何友树树友> renderer = this.i(b<"Z">(this, -1556510341857038151L, a));
         if (renderer != null) {
            renderer.N(b<"Z">(this, -1556510341857038151L, a), mouseX, mouseY, button, this);
         }
      }

      if (button == 0) {
         if (b<"Z">(this, -1557112480915797923L, a) != null) {
            b<"ì">(this, null, -1557112480915797923L, a);
         }

         if (b<"Z">(this, -1556510341857038151L, a) != null) {
            b<"ì">(this, null, -1556510341857038151L, a);
         }

         if (b<"Z">(this, -1556905374598612030L, a) != null) {
            b<"ì">(this, null, -1556905374598612030L, a);
         }
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   public void d() {
      long a = 友树友树何树友友友树.a ^ 70523508400273L;
      b<"ì">(this, null, 6562740888766070305L, a);
      b<"ì">(this, false, 6565548784081081993L, a);
      b<"ì">(this, null, 6562426155344200141L, a);
      b<"ì">(this, null, 6561888733505948342L, a);
      b<"ì">(this, null, 6561823496535177513L, a);
      b<"C">(6562078550508567025L, a);
      b<"Z">(this, 6565145849668714720L, a).clear();
      b<"Z">(this, 6561745702400205357L, a).clear();
      b<"Z">(this, 6562216303509373653L, a).clear();
      b<"Z">(this, 6565380349675937326L, a).clear();
      b<"Z">(this, 6562535239842722703L, a).clear();
      b<"Z">(this, 6562700504084865118L, a).clear();
      b<"Z">(this, 6565498846067043825L, a).clear();
      b<"Z">(this, 6562160869070349582L, a).clear();
      Iterator var4 = b<"Z">(this, 6562301327624261565L, a).q().iterator();
      if (var4.hasNext()) {
         树何何何友树树何友何<?> value = (树何何何友树树何友何<?>)var4.next();
         友树何树友友树树何树<树何何何友树树何友何<?>> renderer = this.i(value);
         if (renderer != null) {
            renderer.g(value, this);
         }

         null.println(a<"n">(25322, 8709029747497882621L ^ a) + value.getClass().getName());
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "L)i~*\rCi$u \u0010F4/30\u000b\u0001厌桖取桔伷栾厌厌取桔";
      f[1] = "\u0013EACat\u0018JP\f\u001dm\u0017P^O*]\u0001GRR;q\u0016J";
      f[2] = "t\u0007(z{5{Geqq(~\u001an7b;{\u001cc7}7g\u0005(叒栅伏栆厢反佌栅厑叜";
      f[3] = int.class;
      g[3] = "java/lang/Integer";
      f[4] = float.class;
      g[4] = "java/lang/Float";
      f[5] = "\u0007\u0004\u0000fY!\u001a\u0011XD\u0018,\u0002\u0017";
      f[6] = boolean.class;
      g[6] = "java/lang/Boolean";
      f[7] = "\u001c\u000f1\u0005H;\u0013O|\u000eB&\u0016\u0012wHJ;\u001b\u0014s\u0003\t\u0019\u0010\u0005j\nB";
      f[8] = "Lj\u0000:x@C*M1r]FwFwaNCqKw栆佺佺佑句案栆佺古佑";
      f[9] = "\u007f(/\u001f\u0005:phb\u0014\u000f'u5iR\u001f<2厍栐厷桻伀栍厍及厷桻q栍桗栐伩伿厞受伓佔厷";
      f[10] = "9q\u0014!\u0003u61Y*\th3lRl\u001a{6j_l\u0005w*s\u0014桓厧住厑佊佯厉桽栋厑";
      f[11] = "Zy&\b\f[Dq<GoO@";
      f[12] = void.class;
      g[12] = "java/lang/Void";
      f[13] = "\u0003\u0010G\u0012\u0017]\u001d\u0018]]qI\u001a\u0019|\u0012I";
      f[14] = "hZ*\nUqcU;E4\u007fh^?\u001f";
      f[15] = "I iHQ\u0019O)%q\u0002{\u0019}`\u000f\f\u001fMw%HkB\u001b\u007f'\u0016\u000f\u0016\u0011:`q";
      f[16] = "zx|nx{|q0W桛叚栊标厏桎伟叚叐佃Lfyd#o1).(|";
      f[17] = "\u0012}b]>o\u0014t.d余栔桢但伏伹栝栔伦但RY}b\u0006ih\nkj\u001c";
      f[18] = "g\u00060`_\u0006a\u000f|Y桼桽栗厣栙厚伸桽栗桹\u0000g\t\u0016s\u0011=#]\u00026";
      f[19] = "\u0005\u000f%JEB[Q!\t,!s'CHH\u001d\u0007\u0002z\u0016\u0016\u0019D";
      f[20] = "y_N;\u0007?\u007fV\u0002\u0002m]*\u0005@fV%(G\u00192=";
      f[21] = "ep\u0003\u0014FxcyO-伡叙栕栏株叮县叙佑叕3\u001cGg<gNS\u0010+c";
      f[22] = "HWAr+MN^\rK佌栶叢佬桨桒佌召叢栨qz*R\u0011@\f5}\u001eN";
      f[23] = "hbyX,tnk5a叕叕栘叇桐桸叕栏参余I]d\u007fp<)_qgl";
      f[24] = "9o\u0005)\u0000$?fI\u0010栣桟厓佔佨栉叹伛桉佔5+\n6+h\u0005}By+";
      f[25] = "\u00115moLH\u0017<!V伫栳桡厐厞桏厵栳去桊]i\u0012\u0012\u0016:,=\fOG";
      f[26] = "DkKj\u00100Bb\u0007S佷伏叮収伦厐佷桋佰栔{hN4\u0014dB6\u00100W";
      f[27] = "p$\u0016;\u0017\u0005v-Z\u0002佰桾佄伟句叁叮桾佄桛&3\u0016\u001a)3[|AVv";
      f[28] = "PZ6\r\u0000JVSz4佧叫叺佡栟佩栣併栠叿\u0006\u000bCJTDo\u000eWHW";
      f[29] = "8? [jF>6lb厓栽厒伄栉桻厓叧伌伄\u0010SkYa(m\u001c<\u0015>";
      f[30] = "y{ccqD\u007fr/Z伖佻栉佀厐厙桒句位佀Sc+E{g\"9{Jk";
      f[31] = "P8j~TqV1&G\r\u0013\u0003bd#\u0005k\u0001 =wn";
      f[32] = "$JTb4)\"C\u0018[体伖桔栵桽厘反伖伐栵dj56}]\u0019%bz\"";
      f[33] = "\u0019X2J{\b\u001bM*VC\u0005%\u0016<P.YF\u0016\"X&h";
      f[34] = "8\u000f\u001bn\u0017i>\u0006WW栴佖伌伴栲伊栴又案厪+l\u001d{*\b\u001b:U4*";
      f[35] = "\u0013E\u0003]AI\u0015LOd厸佶厹叠台伹伦佶厹栺3U@VJRN\u001a\u0017\u001a\u0015";
      f[36] = "|{\u00128~\u001fzr^\u0001厇厾取佀栻作桝传栌栄\":t\rn|\u0012l<Bn";
      f[37] = "kK6vU5mBzO厬桎佟栴栟伒桶伊栛叮\u0006~T*2\\{1\u0003fm";
      f[38] = "\u0010I+PW\r\u0016@gi厮伲厺召变桰估桶厺栶\u001bU\n\u0004\u0014\u001exU\u0014\f\u001c";
      f[39] = "<\u001fmr@zbAi1)\u001cG:W\u0006)xc\u001d2\"\u0010&=\u0019q";
      f[40] = ")\u001e\r*e\u0007/\u0017A\u0013厜桼厃伥叾栊框桼厃桡=(o\u0015;\u0019\r~'Z;";
      f[41] = "\u0000\u0002k8Y>\u0006\u000b'\u0001:\\SXee\b$Q\u001a<1cl\u001b^\"x\f6\f]`\u0001";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27139;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友树友树何树友友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树友树何树友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void k(int keyCode, int scanCode, int modifiers) {
      long a = 友树友树何树友友友树.a ^ 81219026896756L;
      b<"C">(-4830443109774180789L, a);
      if (b<"Z">(this, -4830528504762148412L, a) != null) {
         友树何树友友树树何树<友树何树友友何树友友> renderer = this.i(b<"Z">(this, -4830528504762148412L, a));
         if (renderer != null) {
            renderer.E(b<"Z">(this, -4830528504762148412L, a), keyCode, scanCode, modifiers, this);
         }
      }
   }

   public static int k() {
      X();

      try {
         return 13;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void j(double mouseX, double mouseY, int button) {
      long a = 友树友树何树友友友树.a ^ 119115155045832L;
      b<"C">(453443124095780087L, a);

      for (树何何何友树树何友何<?> value : b<"Z">(this, 452847300003500772L, a).q()) {
         if (!value.n()) {
            float valueRowY = b<"Z">(this, 451535009785150544L, a) + 0.0F;
            float middleValueRowY = valueRowY + 8.0F;
            友树何树友友树树何树<树何何何友树树何友何<?>> renderer = this.i(value);
            float extraHeight = 0.0F;
            if (renderer != null) {
               extraHeight = renderer.h(value, this);
            }

            float totalValueHeight = 16.0F + extraHeight;
            if (mouseY >= valueRowY && mouseY <= valueRowY + totalValueHeight && renderer != null) {
               renderer.r(
                  value,
                  mouseX,
                  mouseY,
                  button,
                  b<"Z">(this, 451931227267995985L, a),
                  valueRowY,
                  b<"Z">(this, 452379871429655000L, a),
                  16.0F,
                  middleValueRowY,
                  this
               );
            }

            float var10000 = 0.0F + totalValueHeight;
            break;
         }
      }
   }

   public static int X() {
      return 友何树何树友友友友友;
   }

   public void T(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      long a = 友树友树何树友友友树.a ^ 65682969761979L;
      long ax = a ^ 88721219090955L;
      b<"C">(7149926164059316612L, a);
      b<"ì">(this, b<"Z">(this, 7150011451076969995L, a) != null, 7149455940320276131L, a);
      float yOffset = 0.0F;
      ClientUtils.o(new Object[]{ax});
      友何何树友何何何何树 valueNameFont = Cherish.instance.h().n(16);
      友何何树友何何何何树 defaultValueFont = Cherish.instance.h().n(14);
      Color accentC = b<"Z">(this, 7149741116820623150L, a) != null ? b<"Z">(this, 7149741116820623150L, a) : HUD.instance.getColor(0);
      Color disabledC = new Color(60, 60, 60, 200);
      Color darkBgC = new Color(45, 45, 45, 235);

      for (树何何何友树树何友何<?> value : b<"Z">(this, 7150451567972349847L, a).q()) {
         if (!value.n()) {
            float valueRowY = b<"Z">(this, 7149318561552472355L, a) + 0.0F;
            float middleValueRowY = valueRowY + 8.0F;
            友树何树友友树树何树<树何何何友树树何友何<?>> renderer = this.i(value);
            valueNameFont.c(
               guiGraphics.pose(),
               value.v(),
               b<"Z">(this, 7149115752176647202L, a) + 5.0F,
               middleValueRowY - valueNameFont.K() / 2.0F,
               b<"à">(7149391400835560679L, a).getRGB()
            );
            renderer.Y(
               guiGraphics,
               value,
               b<"Z">(this, 7149115752176647202L, a),
               valueRowY,
               b<"Z">(this, 7148473679998721195L, a),
               16.0F,
               middleValueRowY,
               mouseX,
               mouseY,
               partialTicks,
               valueNameFont,
               defaultValueFont,
               accentC,
               disabledC,
               darkBgC,
               this
            );
            yOffset = 0.0F + (16.0F + renderer.h(value, this));
            defaultValueFont.c(
               guiGraphics.pose(),
               a<"n">(361, 775046081159891029L ^ a),
               b<"Z">(this, 7149115752176647202L, a) + b<"Z">(this, 7148473679998721195L, a) - 70.0F,
               middleValueRowY - defaultValueFont.K() / 2.0F,
               b<"à">(7150210087159990299L, a).getRGB()
            );
            yOffset += 16.0F;
            break;
         }
      }

      b<"ì">(this, yOffset, 7149559175236239968L, a);
   }

   public static void Q(int var0) {
      友何树何树友友友友友 = var0;
   }

   public float K(NumberValue value, float targetPosition, float partialTicks) {
      long a = 友树友树何树友友友树.a ^ 71741047258452L;
      b<"C">(-4118865715422739349L, a);
      if (!b<"Z">(this, -4118238091910849243L, a).containsKey(value)) {
         b<"Z">(this, -4118238091910849243L, a).put(value, targetPosition);
      }

      if (!b<"Z">(this, -4119384184306581528L, a).containsKey(value)) {
         b<"Z">(this, -4119384184306581528L, a).put(value, targetPosition);
      }

      if (!b<"Z">(this, -4119476520500748528L, a).containsKey(value)) {
         b<"Z">(this, -4119476520500748528L, a).put(value, new float[]{0.0F});
      }

      b<"Z">(this, -4119384184306581528L, a).put(value, targetPosition);
      float currentPosition = (Float)b<"Z">(this, -4118238091910849243L, a).get(value);
      float[] velocity = (float[])b<"Z">(this, -4119476520500748528L, a).get(value);
      if (b<"Z">(this, -4119308563660938004L, a) == value) {
         b<"Z">(this, -4118238091910849243L, a).put(value, targetPosition);
         velocity[0] = 0.0F;
         return targetPosition;
      } else {
         float deltaTime = partialTicks * 0.05F;
         float distance = targetPosition - currentPosition;
         float springForce = distance * 8.0F;
         velocity[0] += springForce * deltaTime;
         velocity[0] *= (float)Math.pow(0.75, deltaTime * 60.0);
         float newPosition = currentPosition + velocity[0] * deltaTime * 5.0F;
         if (Math.abs(distance) < 0.001F && Math.abs(velocity[0]) < 0.001F) {
            newPosition = targetPosition;
            velocity[0] = 0.0F;
         }

         b<"Z">(this, -4118238091910849243L, a).put(value, newPosition);
         return newPosition;
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖诈骗";
   }

   public static enum 树树树何何友友何何友 implements  {
      树友何何树友友何友友,
      树友何树友友树何友何,
      友树树树何友何何何友;

      private static final long a;
      private static final Object[] b = new Object[7];
      private static final String[] c = new String[7];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(5902427640160127952L, 7931033149232800175L, MethodHandles.lookup().lookupClass()).a(176283601316147L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 100662925643982L;
         a();
         Cipher var1;
         Cipher var12 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[3];
         int var6 = 0;
         char var4 = '\b';
         int var3 = -1;

         while (true) {
            String var14 = a(
                  var1.doFinal(
                     "\bÿ\u0099~«¯op\u0010\u0085k\u00998;\u009b|\u0082ùá\u00ade1]\u0016\u0014\b\u0013F\f\u008e\u000e\u008fÅÌ"
                        .substring(++var3, var3 + var4)
                        .getBytes("ISO-8859-1")
                  )
               )
               .intern();
            byte var10001 = -1;
            var0[var6++] = var14;
            if ((var3 += var4) >= 34) {
               树友何何树友友何友友 = new 友树友树何树友友友树.树树树何何友友何何友();
               树友何树友友树何友何 = new 友树友树何树友友友树.树树树何何友友何何友();
               友树树树何友何何何友 = new 友树友树何树友友友树.树树树何何友友何何友();
               return;
            }

            var4 = "\bÿ\u0099~«¯op\u0010\u0085k\u00998;\u009b|\u0082ùá\u00ade1]\u0016\u0014\b\u0013F\f\u008e\u000e\u008fÅÌ".charAt(var3);
         }
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public static 友树友树何树友友友树.树树树何何友友何何友 l(String name) {
         return Enum.valueOf(友树友树何树友友友树.树树树何何友友何何友.class, name);
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 205 && var8 != 204 && var8 != 195 && var8 != 233) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'p') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 237) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 205) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 204) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 195) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 11;
                  case 1 -> 14;
                  case 2 -> 13;
                  case 3 -> 23;
                  case 4 -> 54;
                  case 5 -> 10;
                  case 6 -> 51;
                  case 7 -> 29;
                  case 8 -> 12;
                  case 9 -> 45;
                  case 10 -> 20;
                  case 11 -> 37;
                  case 12 -> 6;
                  case 13 -> 27;
                  case 14 -> 5;
                  case 15 -> 33;
                  case 16 -> 1;
                  case 17 -> 21;
                  case 18 -> 41;
                  case 19 -> 42;
                  case 20 -> 30;
                  case 21 -> 24;
                  case 22 -> 50;
                  case 23 -> 46;
                  case 24 -> 52;
                  case 25 -> 0;
                  case 26 -> 58;
                  case 27 -> 55;
                  case 28 -> 4;
                  case 29 -> 62;
                  case 30 -> 38;
                  case 31 -> 19;
                  case 32 -> 53;
                  case 33 -> 60;
                  case 34 -> 25;
                  case 35 -> 28;
                  case 36 -> 15;
                  case 37 -> 31;
                  case 38 -> 44;
                  case 39 -> 8;
                  case 40 -> 34;
                  case 41 -> 43;
                  case 42 -> 3;
                  case 43 -> 63;
                  case 44 -> 35;
                  case 45 -> 49;
                  case 46 -> 7;
                  case 47 -> 18;
                  case 48 -> 26;
                  case 49 -> 61;
                  case 50 -> 22;
                  case 51 -> 57;
                  case 52 -> 39;
                  case 53 -> 16;
                  case 54 -> 32;
                  case 55 -> 17;
                  case 56 -> 47;
                  case 57 -> 2;
                  case 58 -> 36;
                  case 59 -> 56;
                  case 60 -> 9;
                  case 61 -> 48;
                  case 62 -> 40;
                  default -> 59;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "J\u0004J:O\u0001ED\u00071E\u001c@\u0019\fwU\u0007\u0007厡桵厒栱伻核厡厯厒栱J核桻桵伌併厥叢伿伱厒";
         b[1] = "C\t%Ip=w**\t=6}7/T6pm,h召桏厕栉伐桗召厕厕栉a桗栶桏伋位厎厍佲伋厕#";
         b[2] = "w\u0002\u0019zi{|\r\b5\buw\u0006\fo";
         b[3] = "\u000e9\rt\u00006\u00079\u0006L桳厕伱伍桴厏厩伋厯厓m.\u00036T:\r'\u0003=";
         b[4] = "rb&6\u001aH{b-\u000e桩併位栒厅体桩栱叓栒F7HP`4=t\u000fN\u007f";
         b[5] = "0CH{g=9CCC栔厞伏栳叫厀栔伀厑佷(!d=j@H(d6";
         b[6] = "\u0018,I\r_1\u0011,B5叶案档桜佴叶佨伌伧历)W\\1B/I^\\:";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/友树友树何树友友友树$树树树何何友友何何友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      public static 友树友树何树友友友树.树树树何何友友何何友[] H() {
         long var0 = a ^ 2572604633703L;
         return (友树友树何树友友友树.树树树何何友友何何友[])a<"Ã">(3986908951612622963L, var0).clone();
      }

      private static String HE_DA_WEI() {
         return "何大伟230622198107200054";
      }
   }
}
