package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 友友友何友友何何树树 implements IWrapper, 何树友 {
   private final 树何友何树树何何树树 何友何树何何何友友友;
   public float 树友何友树何何何友友;
   public float 友友树树树树树何何友;
   public float 何何树友何友友何何何;
   public float 树树树树友友友何何何;
   public float 何树友树树树友友友树;
   public float 树友友友何友友树树友;
   public boolean 友树何友何树友友树树;
   public Module 树何友友何友何友何友;
   private boolean 何友树友树友友何何树;
   private float 树友树树友友何何友友;
   private long 友何树何何何树何友树;
   private boolean 树树友友友何何友何友;
   private static final long a;
   private static final long b;
   private static final Object[] c = new Object[33];
   private static final String[] e = new String[33];
   private static int _我是何树友 _;

   public 友友友何友友何何树树(Module module) {
      树何友何树树何何树树.X();
      super();
      this.何友树友树友友何何树 = false;
      this.树友树树友友何何友友 = 0.0F;
      this.友何树何何何树何友树 = 0L;
      this.树何友友何友何友何友 = module;
      this.何友何树何何何友友友 = new 树何友何树树何何树树(module);
      this.树树友友友何何友何友 = module.isEnabled();
      this.友友树树树树树何何友 = 0.0F;
      if (module.isEnabled()) {
         this.树友树树友友何何友友 = 1.0F;
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3298136584976389390L, -8186745460120853756L, MethodHandles.lookup().lookupClass()).a(219518892769261L);
      // $VF: monitorexit
      a = var10000;
      b();
      Cipher var2;
      Cipher var7 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(52537457806836L << var3 * 8 >>> 56);
      }

      var7.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var6 = var2.doFinal(new byte[]{100, -126, -104, 2, -86, 121, 118, -43});
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      byte var10001 = -1;
      b = var8;
   }

   public void B(int keyCode, int scanCode, int modifiers) {
      this.何友何树何何何友友友.z(keyCode, scanCode, modifiers);
   }

   private boolean D(float x, float y, float width, float height, double mouseX, double mouseY) {
      树何友何树树何何树树.X();
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + 20.0F;
   }

   public void F(char chr, int modifiers) {
      this.何友何树何何何友友友.L(chr, modifiers);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 16;
               case 1 -> 1;
               case 2 -> 26;
               case 3 -> 62;
               case 4 -> 44;
               case 5 -> 61;
               case 6 -> 2;
               case 7 -> 52;
               case 8 -> 40;
               case 9 -> 10;
               case 10 -> 8;
               case 11 -> 60;
               case 12 -> 27;
               case 13 -> 35;
               case 14 -> 54;
               case 15 -> 5;
               case 16 -> 24;
               case 17 -> 3;
               case 18 -> 25;
               case 19 -> 19;
               case 20 -> 20;
               case 21 -> 47;
               case 22 -> 41;
               case 23 -> 6;
               case 24 -> 59;
               case 25 -> 39;
               case 26 -> 49;
               case 27 -> 48;
               case 28 -> 17;
               case 29 -> 42;
               case 30 -> 63;
               case 31 -> 14;
               case 32 -> 31;
               case 33 -> 15;
               case 34 -> 57;
               case 35 -> 34;
               case 36 -> 22;
               case 37 -> 0;
               case 38 -> 30;
               case 39 -> 21;
               case 40 -> 13;
               case 41 -> 51;
               case 42 -> 53;
               case 43 -> 50;
               case 44 -> 43;
               case 45 -> 28;
               case 46 -> 7;
               case 47 -> 55;
               case 48 -> 33;
               case 49 -> 58;
               case 50 -> 12;
               case 51 -> 36;
               case 52 -> 32;
               case 53 -> 4;
               case 54 -> 56;
               case 55 -> 37;
               case 56 -> 9;
               case 57 -> 11;
               case 58 -> 18;
               case 59 -> 45;
               case 60 -> 29;
               case 61 -> 38;
               case 62 -> 46;
               default -> 23;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void b() {
      c[0] = "_\u000b|4\n\u001dPK1?\u0000\u0000U\u0016:y\u0010\u001b\u0012厮厙厜估厹号估伇框桴";
      c[1] = "-4\"D\u007f\b\"toOu\u0015')d\te\u000e`桋余召佅桶桟伏余栶栁";
      c[2] = "'B_KQR(\u0002\u0012@[O-_\u0019\u0006SR Y\u001dM\u0010p+H\u0004D[";
      c[3] = boolean.class;
      e[3] = "java/lang/Boolean";
      c[4] = "VS\u0006\u00062_]\\\u0017INFRF\u0019\nyvDQ\u0015\u0017hZS\\";
      c[5] = long.class;
      e[5] = "java/lang/Long";
      c[6] = float.class;
      e[6] = "java/lang/Float";
      c[7] = "GEt\ri?ZP,/(2BV";
      c[8] = "7a<1F,BA7>Wc?Y$9^*W";
      c[9] = "X\u001b]NT_l8R\u000e\u0019Tf%WS\u0012\u0012n8ZU\u0016Y-\u001aQD\u000fPfl";
      c[10] = "C}HhIOw^G(\u0004D}CBu\u000f\u0002u^Os\u000bI6|Db\u0012@}\n";
      c[11] = void.class;
      e[11] = "java/lang/Void";
      c[12] = "Hn\u00011jfCa\u0010~\u000bhHj\u0014$";
      c[13] = "ok\r\u0014\u0015\r8s\u000fS\u007f栨桏叁厩栲厼史厕栛桳+CZ0x\u0000\u0017DI4}";
      c[14] = "S\u007f!$\u001deUq9Z桩栄栬桙厙厙厳佀佨伝Zf\u001b{O*fa\b\u007fJ";
      c[15] = "\u0000\u0011 ]^N\u0006\u001f8#台叵桿样桂栺株佫伻叭[\u001fXP\u001cDg\u0018KT\u0019";
      c[16] = "Iv\u000f5x\u0000Ox\u0017K佈去佲桐伩伖佈去召厊tr|\u001f\u0010#H%d\u001dW";
      c[17] = "JK.\b'1LE6v桓厊佱厷桌伫众伔可厷UJ!/V\u001eiM2+S";
      c[18] = "&8\u0001[(\nq \u0003\u001cB栯栆案厥伹厁叵叜伌伻d\u007f\u0007u4\r\n)\b =";
      c[19] = "h\bLWO2n\u0006T)使厉栗叴栮只叡众体栮7\u0013[+`\u000e\u000fWY%g";
      c[20] = ">fYhRR8hA\u0016栦叩桁桀叡叕佢佷厛厚\"*TL\"3\u001e-GH'";
      c[21] = "7UJ\u0015\u001df1[Rk伭佃案厩佬厨厳佃伌伷1W\u001bx+\u0000\rP\b|.";
      c[22] = "\u0018\r\b\u0011m\u000eO\u0015\nV\u0007b!Y\u000b\u0014lQ\u0019\u000f\u0016Ek2";
      c[23] = "RKAYVuTEY'司栔佩厷佧栾司収栭桭:\u001dBlZM\u0002Y@b]";
      c[24] = "\u001fMR%[)\u0019CJ[_QBB\u0016gM>\u0003\u000fC56jIM\u0015 Y+\u0004\u0018G[";
      c[25] = "` \u0018>m\u000078\u001ay\u0007栥伄伔厼作栞栥厚厊桦\u0001;W?3\u0015=<D;6";
      c[26] = "wpu04\u007fq~mN桀栞叒厌反伓伄叄佌厌\u000et f\u007fv60\"hx";
      c[27] = "\u001c\u0005$n\"X\u0016F~'\u0012{&\u0002}'w\u0016\u001bY,oo)";
      c[28] = "W\u0001D\u0000VD\u0000\u0019FG<桡厭伵叠叼栥伥桷伵叠?\u0006\u0001\u000f\u0006\u001a\u0007B\u0003\u0001\u0001";
      c[29] = "9\u001c@q\u000eV?\u0012X\u000f厠佳框佾佦佒桺佳厜栺;4\fU1\u0012Cv^R9";
      c[30] = "\u000b`to\u007f\u0006\u0001#.&O)1g-&*H\f<|n2w\u000e=vv!\u0019L;rfO";
      c[31] = "\u0003\u0006\"7S\u0006\u0005\b:I栧伣厦叺伄厊佣厽伸叺Ys\u0006\u001b\u001c\t(yEAU";
      c[32] = "m~\u007f`;\u0017:f}'Q叨厗佊叛厜案叨厗佊叛_m@2mrcjS6h";
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 230 && var8 != 'd' && var8 != 253 && var8 != 206) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'C') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 226) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 230) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'd') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 253) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private void h(float partialTicks, boolean enabled) {
      树何友何树树何何树树.X();
      float animSpeed = partialTicks / 0.15F;
      if (this.树友树树友友何何友友 < 1.0F) {
         this.树友树树友友何何友友 = Math.min(this.树友树树友友何何友友 + animSpeed, 1.0F);
      }

      if (this.树友树树友友何何友友 > 1.0F) {
         this.树友树树友友何何友友 = Math.max(this.树友树树友友何何友友 - animSpeed, 0.0F);
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public Module d() {
      return this.树何友友何友何友何友;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友友何友友何何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void a() {
   }

   public void a(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      this.友树何友何树友友树树 = false;
      树何友何树树何何树树.X();
      boolean currentEnabled = this.树何友友何友何友何友.isEnabled();
      if (currentEnabled != this.树树友友友何何友何友) {
         this.树树友友友何何友何友 = currentEnabled;
         this.友何树何何何树何友树 = System.currentTimeMillis();
         this.何友树友树友友何何树 = true;
      }

      this.h(partialTicks, currentEnabled);
      this.X();
      float valuesHeight = 0.0F;
      if (!this.树何友友何友何友何友.P().isEmpty()) {
         this.何友何树何何何友友友.树树树友何友友友何何 = HUD.instance.getColor(0);
         valuesHeight = this.何友何树何何何友友友.g();
      }

      this.友友树树树树树何何友 = 20.0F + valuesHeight;
      RenderUtils.q(
         guiGraphics.pose(),
         (int)this.何何树友何友友何何何,
         (int)this.树树树树友友友何何何,
         (int)(this.何何树友何友友何何何 + this.树友何友树何何何友友),
         (int)(this.树树树树友友友何何何 + this.友友树树树树树何何友),
         137876390830295L,
         new Color(35, 35, 35).getRGB()
      );
      ClientUtils.D(131325480669526L);
      何何友友树何树何友树 titleFont = Cherish.instance.t().H(20);
      String moduleName = this.树何友友何友何友何友.A();
      titleFont.q(guiGraphics.pose(), moduleName, this.何何树友何友友何何何 + 5.0F, this.树树树树友友友何何何 + 10.0F - titleFont.x() / 2.0F, -1);
      Color accentColor = HUD.instance.getColor(0);
      Color disabledColor = new Color(100, 100, 100);
      Color toggleColor = 何树友友树树友何树何.p(disabledColor, accentColor, this.树友树树友友何何友友);
      float toggleIndicatorX = this.何何树友何友友何何何 + this.树友何友树何何何友友 - 10.0F - 10.0F;
      float toggleIndicatorY = this.树树树树友友友何何何 + 10.0F - 5.0F;
      RenderUtils.q(
         guiGraphics.pose(),
         (int)toggleIndicatorX,
         (int)toggleIndicatorY,
         (int)(toggleIndicatorX + 10.0F),
         (int)(toggleIndicatorY + 10.0F),
         137876390830295L,
         toggleColor.getRGB()
      );
      if (valuesHeight > 0.0F) {
         this.何友何树何何何友友友.友友何友友树友友何友 = this.何何树友何友友何何何;
         this.何友何树何何何友友友.树何何友何树树友友树 = this.树树树树友友友何何何 + 20.0F;
         this.何友何树何何何友友友.树树友友树友友友树树 = this.树友何友树何何何友友;
         this.何友何树何何何友友友.h(guiGraphics, mouseX, mouseY, partialTicks);
         this.友树何友何树友友树树 = this.友树何友何树友友树树 || this.何友何树何何何友友友.树友何友友树何树何友;
      }

      Module.V(new Module[5]);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public void o(double mouseX, double mouseY, int button) {
      树何友何树树何何树树.X();
      if (this.D(this.何何树友何友友何何何, this.树树树树友友友何何何, this.树友何友树何何何友友, 20.0F, mouseX, mouseY) && button == 0) {
         this.树何友友何友何友何友.n();
      } else {
         if (mouseY > this.树树树树友友友何何何 + 20.0F && mouseY < this.树树树树友友友何何何 + this.友友树树树树树何何友) {
            this.何友何树何何何友友友.W(mouseX, mouseY, button);
         }
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void r(double mouseX, double mouseY, int button) {
      this.何友何树何何何友友友.d(mouseX, mouseY, button);
   }

   private void X() {
      if (this.何友树友树友友何何树) {
         long currentTime = System.currentTimeMillis();
         long elapsedTime = currentTime - this.友何树何何何树何友树;
         if (elapsedTime >= 300L) {
            this.何友树友树友友何何树 = false;
         }
      }
   }

   public void K() {
      this.何友何树何何何友友友.c();
      this.树友树树友友何何友友 = this.树何友友何友何友何友.isEnabled() ? 1.0F : 0.0F;
      this.树树友友友何何友何友 = this.树何友友何友何友何友.isEnabled();
   }

   private static String HE_DA_WEI() {
      return "何炜霖大狗叫";
   }
}
