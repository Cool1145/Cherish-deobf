package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 友友何友树友树树何树 implements 友友何何何树友友何树, 何树友 {
   private float 何友友树何树树友树树 = -1.0F;
   private final float 友何树何友何树友树何 = 16.0F;
   private final float 何树树树何树友友何友 = 10.0F;
   private long 何何树树何树何何何何 = 0L;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[27];
   private static final String[] f = new String[27];
   private static int _何树友为什么濒天了 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-637444467151885224L, -8174074790980964659L, MethodHandles.lookup().lookupClass()).a(253904145217080L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(35958165795897L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 16;
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal("·\u0088\u0089ò£~B]ì\u007f~¹2\\?õ\u0010\\¯6¼\\7\u0099ÑY\u0099NW°ÚË\u0094".substring(++var4, var4 + var5).getBytes("ISO-8859-1"))
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 33) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "·\u0088\u0089ò£~B]ì\u007f~¹2\\?õ\u0010\\¯6¼\\7\u0099ÑY\u0099NW°ÚË\u0094".charAt(var4);
      }
   }

   @Override
   public float Z(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value) {
      return 16.0F;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友何友树友树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void d() {
      this.何友友树何树树友树树 = 0.0F;
      this.何何树树何树何何何何 = System.currentTimeMillis();
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      e[0] = "b36A\u0019<ms{J\u0013!h.p\f\u0003:/厖叓佷厽桂及桌栉佷桧";
      e[1] = float.class;
      f[1] = "java/lang/Float";
      e[2] = long.class;
      f[2] = "java/lang/Long";
      e[3] = "sk%pt5|+h{~(yvc=n3>栔叀栂栊伏叛佐佞栂叐";
      e[4] = int.class;
      f[4] = "java/lang/Integer";
      e[5] = "\u0013\u0003LW\u0014P\u0018\f]\u0018hI\u0017\u0016S[_y\u0001\u0001_FNU\u0016\f";
      e[6] = "sq>;\\\u0006|1s0V\u001bylxvF\u0000>栎栁桉司似佅栎佅厓佦";
      e[7] = "\u0006>\fpUL\t~A{_Q\f#J=OJK伅栳但叱叨估伅叩变栫";
      e[8] = "AM\u007fP6MN\r2[<PKP9\u001d/CNV4\u001d0ORO\u007f},O@F#e8NWF";
      e[9] = boolean.class;
      f[9] = "java/lang/Boolean";
      e[10] = "H-g) 4U8?\u000ba9M>";
      e[11] = "\u000eo9\u0014\u0018U\u0001/t\u001f\u0012H\u0004r\u007fY\u0002SC佔佂厼厼栫伸栐佂厼桦";
      e[12] = "E?\u0019\u0019d\u0003N*\u0007V\u0018\u0001Z0\u000b\u0011$\tb1\u000b\u001d";
      e[13] = "\u001f+\u001c\r\fg\u0014$\rBmi\u001f/\t\u0018";
      e[14] = "Um{42-\u0012f.mB框桱伀栎双桛伂桱厞栎\u000f|=\u0005<xk\"?T?";
      e[15] = "\"\u0007Ul`fe\f\u00005\u0010受栆栮叺伊栉受叜栮叺W/%~O\tk`qaQ";
      e[16] = "rMT>f\u00004\u0019O?Z叺厍伮叵佒桃佤伓桪栯\u000fg\t\"HF} \u0002w\u0011";
      e[17] = "6Dcq\u0015\u0011qO6(e厠佖伩佒众桼厠栒伩栖JU[lI7!Y^aJ";
      e[18] = "&n,^\u0001zf7>\u00009S\u001ci6T@zm,4SW\u001e";
      e[19] = "\u0015\r\r\u0007\u00136R\u0006X^c伙栱你厢佡伾桝栱栤厢<\\uIEQ\u0000\u0013!V[";
      e[20] = ":\u0001\u0014(&m2\u001fP\u0012-P8\u0012\u0006jtn\u007f\f\u0007hDk`\u001b\u0014\"z,~\u001a\u0016\u0012";
      e[21] = "lqm:kQ*%v;W桱桉厌栖佖桎伵厓厌佒\u000bj\u001a,56zh\u0011?(";
      e[22] = "\u000f!\u0004T*9H*Q\rZ厈佯栈厫厬伇厈佯叒伵ofuP TV !K!";
      e[23] = "icCNbqa}\u0007t佝厏厓栊佦桭栙厏桉栊;\u000ekpmrBHe(";
      e[24] = "zn\u007fU\"$:7m\u000b\u001a\u0011@ie_c$1,gXt@";
      e[25] = "?a`\u001d)-7\u007f$'伖位栟栈佅栾伖位佛佌\u0018\u001droyx}\u001d5yj";
      e[26] = "O\u0003&^-!\u0018A9\t_]6:\u00139\u0002E\u007fN \u0015ooC\u0019b\n8";
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'u' && var8 != 204 && var8 != 250 && var8 != 192) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'F') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 249) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'u') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 204) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 250) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2624;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友友何友树友树树何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   @Override
   public void a(GuiGraphics g, 树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      b<"ù">(2572996832096251619L, 53303731626931L);
      NumberValue nv = (NumberValue)value;
      this.P(nv);
      float sliderBarY = valy + 3.0F;
      RenderUtils.drawRectangle(
         g.pose(),
         valx,
         sliderBarY,
         valw,
         10.0F,
         b<"u">(panel, 2573569661944815080L, 53303731626931L)
            .o(b<"u">(b<"u">(panel, 2573569661944815080L, 53303731626931L), 2573787945266325087L, 53303731626931L), alpha)
            .getRGB()
      );
      RenderUtils.drawRectangle(
         g.pose(),
         valx,
         sliderBarY,
         valw * b<"u">(this, 2573472448680146137L, 53303731626931L),
         10.0F,
         b<"u">(panel, 2573569661944815080L, 53303731626931L).o(HUD.instance.getColor(4), alpha).getRGB()
      );
      String valueText = String.format(nv.X().doubleValue() % 1.0 == 0.0 ? "" : "%.1f", nv.getValue().doubleValue());
      String text = (b<"u">(b<"u">(panel, 2573569661944815080L, 53303731626931L), 2571739581098792773L, 53303731626931L) ? nv.r() : nv.V()) + " " + valueText;
      b<"u">(b<"u">(panel, 2573569661944815080L, 53303731626931L), 2573636298242400310L, 53303731626931L)
         .s(
            g.pose(),
            text,
            valx + 2.0F,
            sliderBarY + 5.0F - b<"u">(b<"u">(panel, 2573569661944815080L, 53303731626931L), 2573636298242400310L, 53303731626931L).x() / 2.0F,
            b<"u">(panel, 2573569661944815080L, 53303731626931L)
               .o(b<"u">(b<"u">(panel, 2573569661944815080L, 53303731626931L), 2571808435986875875L, 53303731626931L), alpha)
               .getRGB()
         );
      if (b<"u">(panel, 2573339577796006866L, 53303731626931L) == nv
         && b<"u">(b<"u">(panel, 2573569661944815080L, 53303731626931L), 2573442113733306185L, 53303731626931L) == panel) {
         this.E(mousex, valx, valw, nv);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 41;
               case 1 -> 29;
               case 2 -> 15;
               case 3 -> 20;
               case 4 -> 46;
               case 5 -> 42;
               case 6 -> 13;
               case 7 -> 7;
               case 8 -> 17;
               case 9 -> 6;
               case 10 -> 22;
               case 11 -> 8;
               case 12 -> 14;
               case 13 -> 45;
               case 14 -> 23;
               case 15 -> 56;
               case 16 -> 30;
               case 17 -> 59;
               case 18 -> 47;
               case 19 -> 57;
               case 20 -> 24;
               case 21 -> 26;
               case 22 -> 5;
               case 23 -> 12;
               case 24 -> 18;
               case 25 -> 1;
               case 26 -> 21;
               case 27 -> 58;
               case 28 -> 48;
               case 29 -> 63;
               case 30 -> 9;
               case 31 -> 43;
               case 32 -> 55;
               case 33 -> 51;
               case 34 -> 37;
               case 35 -> 10;
               case 36 -> 11;
               case 37 -> 31;
               case 38 -> 49;
               case 39 -> 62;
               case 40 -> 53;
               case 41 -> 16;
               case 42 -> 28;
               case 43 -> 3;
               case 44 -> 36;
               case 45 -> 33;
               case 46 -> 54;
               case 47 -> 2;
               case 48 -> 39;
               case 49 -> 60;
               case 50 -> 25;
               case 51 -> 61;
               case 52 -> 27;
               case 53 -> 52;
               case 54 -> 34;
               case 55 -> 32;
               case 56 -> 4;
               case 57 -> 40;
               case 58 -> 0;
               case 59 -> 35;
               case 60 -> 44;
               case 61 -> 50;
               case 62 -> 19;
               default -> 38;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友何友树友树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public void E(double mouseX, float valueX, float valueWidth, NumberValue numberValue) {
      树友树树何友何何树友.E();
      double minVal = numberValue.o().doubleValue();
      double maxVal = numberValue.A().doubleValue();
      BigDecimal stepBigDecimal = BigDecimal.valueOf(numberValue.X().doubleValue());
      BigDecimal rawValueBigDecimal = BigDecimal.valueOf(minVal + (maxVal - minVal) * Mth.clamp((mouseX - valueX) / 106.0, 0.0, 1.0));
      BigDecimal roundedValueBigDecimal = rawValueBigDecimal.divide(stepBigDecimal, 0, RoundingMode.HALF_UP).multiply(stepBigDecimal);
      if (numberValue.getValue() instanceof Double) {
         numberValue.S(roundedValueBigDecimal.doubleValue());
      }

      if (numberValue.getValue() instanceof Float) {
         numberValue.S(roundedValueBigDecimal.floatValue());
      }
   }

   private void P(NumberValue nv) {
      树友树树何友何何树友.E();
      float min = nv.o().floatValue();
      float max = nv.A().floatValue();
      float curr = nv.getValue().floatValue();
      float progress = max - min == 0.0F ? 0.0F : (curr - min) / (max - min);
      if (this.何友友树何树树友树树 == -1.0F) {
         this.何友友树何树树友树树 = progress;
         this.何何树树何树何何何何 = System.currentTimeMillis();
      } else {
         long currentTime = System.currentTimeMillis();
         long deltaTime = currentTime - this.何何树树何树何何何何;
         this.何何树树何树何何何何 = currentTime;
         if (Math.abs(this.何友友树何树树友树树 - progress) > 0.001F) {
            float diff = progress - this.何友友树何树树友树树;
            float interpolationFactor = (float)deltaTime / 150.0F * 2.0F;
            if (interpolationFactor >= 1.0F) {
               this.何友友树何树树友树树 = progress;
            }

            this.何友友树何树树友树树 += diff * interpolationFactor;
            this.何友友树何树树友树树 = Mth.clamp(this.何友友树何树树友树树, 0.0F, 1.0F);
         }
      }
   }

   @Override
   public 何何何友友何树何何何 K(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      树友树树何友何何树友.E();
      NumberValue nv = (NumberValue)value;
      float sliderClickY = vy + 3.0F;
      if (mx >= vx && mx <= vx + vw && my >= sliderClickY && my <= sliderClickY + 10.0F) {
         panel.树树友树何树何友友何 = nv;
         panel.友友何友何树何何树树.友何树友友何友何友何 = panel;
         this.E(mx, vx, vw, nv);
      }

      return null;
   }

   private static String HE_SHU_YOU() {
      return "何树友被何大伟克制了";
   }
}
