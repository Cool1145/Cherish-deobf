package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import com.mojang.blaze3d.platform.InputConstants;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 何何树何树何树友树友 implements 友树何树友友树树何树<友树何树友友何树友友>, IWrapper,  {
   private static final float 树何树树友何友友何树 = 7.0F;
   private static final float 何友何何树友树何友友 = 10.0F;
   private static final float 树树树树友树树何友树 = 70.0F;
   private long 友树友树何友树树友友;
   private static final int 何树友何何何友树树树;
   private static final long a;
   private static final String b;
   private static final long[] c;
   private static final Long[] e;
   private static final Map f;
   private static final Object[] g = new Object[16];
   private static final String[] h = new String[16];
   private static String HE_JIAN_GUO;

   public 何何树何树何树友树友() {
      long a = 何何树何树何树友树友.a ^ 9355166687239L;
      super();
      b<"ç">(this, 0L, 8051418209497686914L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-6291625225974656523L, 5060422894866223015L, MethodHandles.lookup().lookupClass()).a(59905870891737L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var18 = a ^ 9292637945650L;
      Cipher var20;
      Cipher var22 = var20 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var18 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var21 = 1; var21 < 8; var21++) {
         var10003[var21] = (byte)(var18 << var21 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var28 = b(var20.doFinal("±Æ\u0098À;Ø1\u009b".getBytes("ISO-8859-1"))).intern();
      int var10001 = -1;
      b = var28;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)(var18 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var18 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var17 = var13.doFinal(new byte[]{-42, 62, 59, -95, -46, -9, 105, 84});
      long var30 = (var17[0] & 255L) << 56
         | (var17[1] & 255L) << 48
         | (var17[2] & 255L) << 40
         | (var17[3] & 255L) << 32
         | (var17[4] & 255L) << 24
         | (var17[5] & 255L) << 16
         | (var17[6] & 255L) << 8
         | var17[7] & 255L;
      var10001 = (byte)-1;
      何树友何何何友树树树 = (int)var30;
      f = new HashMap(13);
      Cipher var0;
      Cipher var24 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)(var18 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var18 << var1 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[3];
      int var3 = 0;
      byte var2 = 0;

      do {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = "A\u009e!ì\"c1\u0084¸\u0007¹³Îð\u008c>\u0015â¦/\"d\u0011ë".substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         byte var34 = -1;
         var6[var10001] = var10004;
      } while (var2 < 24);

      c = var6;
      e = new Long[3];
   }

   public boolean D(
      友树何树友友何树友友 value, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 友树友树何树友友友树 componentsInstance
   ) {
      long a = 何何树何树何树友树友.a ^ 96213055141834L;
      float boxX = x + width - 77.0F;
      b<"ñ">(4066833390012128125L, a);
      float boxY = middleY - 5.0F;
      if (button == 0) {
         if (mouseX >= boxX && mouseX <= boxX + 70.0F && mouseY >= boxY && mouseY <= boxY + 10.0F) {
            if (b<"g">(componentsInstance, 4067210913986558887L, a) != value) {
               b<"ç">(componentsInstance, value, 4067210913986558887L, a);
               b<"ç">(componentsInstance, true, 4066781171484229471L, a);
            }

            return true;
         }

         if (b<"g">(componentsInstance, 4067210913986558887L, a) == value) {
            b<"ç">(componentsInstance, null, 4067210913986558887L, a);
            b<"ç">(componentsInstance, false, 4066781171484229471L, a);
         }
      }

      return false;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 28;
               case 1 -> 29;
               case 2 -> 63;
               case 3 -> 12;
               case 4 -> 53;
               case 5 -> 52;
               case 6 -> 23;
               case 7 -> 35;
               case 8 -> 5;
               case 9 -> 6;
               case 10 -> 39;
               case 11 -> 37;
               case 12 -> 7;
               case 13 -> 21;
               case 14 -> 44;
               case 15 -> 16;
               case 16 -> 59;
               case 17 -> 24;
               case 18 -> 11;
               case 19 -> 14;
               case 20 -> 8;
               case 21 -> 47;
               case 22 -> 61;
               case 23 -> 13;
               case 24 -> 0;
               case 25 -> 49;
               case 26 -> 43;
               case 27 -> 56;
               case 28 -> 32;
               case 29 -> 1;
               case 30 -> 36;
               case 31 -> 31;
               case 32 -> 60;
               case 33 -> 22;
               case 34 -> 20;
               case 35 -> 26;
               case 36 -> 17;
               case 37 -> 48;
               case 38 -> 62;
               case 39 -> 45;
               case 40 -> 41;
               case 41 -> 51;
               case 42 -> 50;
               case 43 -> 57;
               case 44 -> 34;
               case 45 -> 27;
               case 46 -> 15;
               case 47 -> 46;
               case 48 -> 42;
               case 49 -> 9;
               case 50 -> 10;
               case 51 -> 54;
               case 52 -> 55;
               case 53 -> 38;
               case 54 -> 18;
               case 55 -> 2;
               case 56 -> 3;
               case 57 -> 4;
               case 58 -> 19;
               case 59 -> 40;
               case 60 -> 25;
               case 61 -> 58;
               case 62 -> 30;
               default -> 33;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'g' && var8 != 231 && var8 != 193 && var8 != 181) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'c') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 241) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'g') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 231) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 193) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何树何树何树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public boolean s(友树何树友友何树友友 value, char chr, int modifiers, 友树友树何树友友友树 componentsInstance) {
      long a = 何何树何树何树友树友.a ^ 117782281920062L;
      b<"ñ">(5873951711901823625L, a);
      if (b<"g">(componentsInstance, 5874275393814975059L, a) == value && chr >= ' ' && chr != 167) {
         String currentText = value.getValue();
         value.g(currentText + chr);
         return true;
      } else {
         return false;
      }
   }

   public boolean s(友树何树友友何树友友 value, int keyCode, int scanCode, int modifiers, 友树友树何树友友友树 componentsInstance) {
      long a = 何何树何树何树友树友.a ^ 65076705573371L;
      b<"ñ">(8521346871069086146L, a);
      if (b<"g">(componentsInstance, 8521037443134190998L, a) == value) {
         String currentText = value.getValue();
         if (keyCode == 256 || keyCode == 257 || keyCode == 335) {
            b<"ç">(componentsInstance, null, 8521037443134190998L, a);
            b<"ç">(componentsInstance, false, 8521223100690477422L, a);
            return true;
         } else if (keyCode == 259) {
            if (!currentText.isEmpty()) {
               value.g(currentText.substring(0, currentText.length() - 1));
               b<"ç">(this, System.currentTimeMillis(), 8520900216745933438L, a);
            }

            return true;
         } else if (InputConstants.isKeyDown(mc.getWindow().getWindow(), 259) && !currentText.isEmpty()) {
            if (System.currentTimeMillis() - b<"g">(this, 8520900216745933438L, a) > a<"l">(6755, 8256223542635233321L ^ a)) {
               value.g(currentText.substring(0, currentText.length() - 1));
               b<"ç">(this, System.currentTimeMillis(), 8520900216745933438L, a);
            }

            return true;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何树何树何树友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      g[0] = "*\u000f%?\u0012*%Oh4\u00187 \u0012cr\b,g伴佞桍伨桔伜桰叀桍厶";
      g[1] = long.class;
      h[1] = "java/lang/Long";
      g[2] = "\u001c\u0006\u0006\rB\u0010\u0013FK\u0006H\r\u0016\u001b@@X\u0016Q厣根厥格伪桮厣口厥格";
      g[3] = "rv\u0014CMQ}6YHGLxkR\u000eT_}m_\u000eKSat\u0014叫栳佫栀叓叱併栳叵叚";
      g[4] = "\b\u000en\u001bCP\u0007N#\u0010IM\u0002\u0013(VYVE厫伕伭叧栮伾桱桑桩佹";
      g[5] = boolean.class;
      h[5] = "java/lang/Boolean";
      g[6] = "X<F4\u0002>S3W{~'\\)Y8I\u0017J>U%X;]3";
      g[7] = "`x\u001b=T^}mC\u001f\u0015Sek";
      g[8] = "\u0010<\u0003,\"(\u001b3\u0012cC&\u00108\u00169";
      g[9] = "?\u0007U \u0017s>\u001f\\O厳栍叁桧估厌桩栍叁厽mvL%s\u0019Uw\u0015ta";
      g[10] = "d`zy\u000f]exs\u0016\u0001:ev.l\u000e[e$2mh\u00066u8p\t\u0006di9\u0016";
      g[11] = "\u001d\u0017\u001bW&\u001fZ\u0015ZQW佹佹桷伻叵厔栽叧伳伻6m\u0015U^\u0017\bi\u0019\u001dW";
      g[12] = "w[3\u000bC\u0010r\f&\u0018!>L\f/\u0013\u001b\b.Y0M_y";
      g[13] = "s\u007fh\u0017&N4})\u0011W厶众叅取厵桎伨桓叅栌vl\u0017+<d\u00149\bux";
      g[14] = "d\u007f~r|4c\u007f-+\f[\u0019\u0001\u0012\\\f9fp-a<>f#t";
      g[15] = "iX\b\u001b,\u0016l\u000f\u001d\bN4R\u000f\u0014\u0003t\u000e0Z\u000b]0\u007f";
   }

   public void a(友树何树友友何树友友 value, double mouseX, double mouseY, int button, 友树友树何树友友友树 componentsInstance) {
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 27657;
      if (e[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])f.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            f.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/何何树何树何树友树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         e[var3] = var15;
      }

      return e[var3];
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void u(友树何树友友何树友友 value, 友树友树何树友友友树 componentsInstance) {
   }

   public float H(友树何树友友何树友友 value, 友树友树何树友友友树 componentsInstance) {
      return 0.0F;
   }

   public void Q(
      GuiGraphics guiGraphics,
      友树何树友友何树友友 value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      友何何树友何何何何树 valueNameFont,
      友何何树友何何何何树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      友树友树何树友友友树 componentsInstance
   ) {
      long a = 何何树何树何树友树友.a ^ 71907886292742L;
      b<"ñ">(-8017359937714096321L, a);
      float boxX = x + width - 77.0F;
      float boxY = middleY - 5.0F;
      RenderUtils.drawRoundedRect(guiGraphics.pose(), boxX, boxY, 70.0, 10.0, 2.0, darkBgColor);
      String displayValue = value.getValue();
      if (displayValue.isEmpty() && b<"g">(componentsInstance, -8017053703557147797L, a) != value) {
         displayValue = b;
      }

      String visibleText = displayValue;
      float textWidth = valueDisplayFont.A(displayValue);
      if (textWidth > 62.0F && !displayValue.isEmpty()) {
         visibleText = displayValue.substring(1);
         float var10000 = valueDisplayFont.A(visibleText);
      }

      float textX = boxX + 4.0F;
      float textY = boxY + (10.0F - valueDisplayFont.K()) / 2.0F + 0.5F;
      valueDisplayFont.c(guiGraphics.pose(), visibleText, textX, textY, b<"Á">(-8017253244959618304L, a).getRGB());
      if (b<"g">(componentsInstance, -8017053703557147797L, a) == value
         && System.currentTimeMillis() % a<"l">(19956, 4866244759600476480L ^ a) < a<"l">(262, 6357970205921574320L ^ a)) {
         float cursorX = textX + valueDisplayFont.A(visibleText);
         RenderUtils.drawRectangle(guiGraphics.pose(), cursorX, textY - 1.0F, 1.0F, valueDisplayFont.K() + 1, b<"Á">(-8017253244959618304L, a).getRGB());
      }

      if (b<"g">(componentsInstance, -8017053703557147797L, a) == value) {
         int borderColor = accentColor.getRGB();
         RenderUtils.drawRectangle(guiGraphics.pose(), boxX - 1.0F, boxY - 1.0F, 72.0F, 1.0F, borderColor);
         RenderUtils.drawRectangle(guiGraphics.pose(), boxX - 1.0F, boxY + 10.0F, 72.0F, 1.0F, borderColor);
         RenderUtils.drawRectangle(guiGraphics.pose(), boxX - 1.0F, boxY, 1.0F, 10.0F, borderColor);
         RenderUtils.drawRectangle(guiGraphics.pose(), boxX + 70.0F, boxY, 1.0F, 10.0F, borderColor);
      }
   }

   private static String HE_DA_WEI() {
      return "何炜霖国企变私企";
   }
}
