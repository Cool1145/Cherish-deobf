package cn.cool.cherish.ui;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

public class 树树何树何何树何友友 extends Screen implements 何树友 {
   private static final int 友树何友何友何何何何;
   private static final int 树树友何何何何友树树;
   private static final int 友何树友何友树树树友;
   private static final int 友树何何友树何树友树;
   private static final Color 树何友何友友友树友友;
   private static final Color 何何友友友友友何友树;
   private static final Color 友树友何友友何树树树;
   private int 树何何树友树何树树树 = 0;
   private final int 树树友何树何何何何树;
   private LinkedList<树树何树何何树何友友.何何何树友友友何树友> 何友友何何友何何树何;
   private 树树何树何何树何友友.何何何树友友友何树友 树树何树树何友友树树;
   private 树树何树何何树何友友.友树何树树何何友友树 何树树友树树树树树何;
   private boolean 友何友何友树树友树树;
   private int 树友何树友何友友树友;
   private final Random 何树何何友树树友何友;
   private int 何友友何友友何何何友;
   private int 何友何友何友友友何何;
   private int 何何友友树何何何友树;
   private int 友何何树友友友何树友;
   private static int 友何何树树友友何友友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[59];
   private static final String[] i = new String[59];
   private static int _何大伟230622198107200054 _;

   public 树树何树何何树何友友() {
      super(Component.literal("Snake Game"));
      int var10000 = A();
      this.树树友何树何何何何树 = 20;
      int var3 = var10000;
      this.何树何何友树树友何友 = new Random();
      this.何友友何友友何何何友 = 0;
      this.何友何友何友友友何何 = 5;
      this.何何友友树何何何友树 = this.何友何友何友友友何何;
      this.友何何树友友友何树友 = 0;
      this.V();
      if (Module.Z() == null) {
         K(++var3);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(4191798745143856807L, -8685306102967153891L, MethodHandles.lookup().lookupClass()).a(41509122210053L);
      // $VF: monitorexit
      a = var10000;
      a();
      K(0);
      Cipher var11;
      Cipher var22 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(104353242311214L << var12 * 8 >>> 56);
      }

      var22.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[5];
      int var16 = 0;
      String var15 = "TKXÓ:\u0018³Æñ\u0012=('-C<\u0091\u0086\u009dñQ\u0095Å\u0085\u0006±Å\u001d8¯F\u0099\u0018\u0095\u001eÈ\u001fpú½ü¿q\u0080@ÿÇy\u001b¤bULåÄ\u008a/@¸Ù£¡¦ª\b\u000b\u0085\u001f\u001d~Ä\t'\u0006\u0090{¦\u0002¦À\u0084\u0086T\u0082%#dj\u0018\u000bd\u0098x\u0083\u0003«¼\u001b\"Þ÷ðVÇá,Å¾\u008aÊäi\u0016Ý3ZsòOD\u000f)";
      byte var17 = 122;
      char var14 = ' ';
      int var21 = -1;

      label54:
      while (true) {
         String var23 = var15.substring(++var21, var21 + var14);
         int var10001 = -1;

         while (true) {
            String var34 = a(var11.doFinal(var23.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var34;
                  if ((var21 += var14) >= var17) {
                     b = var18;
                     c = new String[5];
                     g = new HashMap(13);
                     Cipher var0;
                     Cipher var25 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(104353242311214L << var1 * 8 >>> 56);
                     }

                     var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[7];
                     int var3 = 0;
                     String var4 = "\r\u0083ª\u0098\u001e)µ^\u0095\u0092:\u008eâoH\u0001 ¢äA'ËQÆã°õïÞ½ýÃy}\u0081ùÊ\u009c\u0084\u0085";
                     byte var5 = 40;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        var10001 = var3++;
                        long var38 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var41 = -1;

                        while (true) {
                           long var8 = var38;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var43 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var41) {
                              case 0:
                                 var26[var10001] = var43;
                                 if (var2 >= var5) {
                                    e = var6;
                                    f = new Integer[7];
                                    友树何友何友何何何何 = 20;
                                    友何树友何友树树树友 = 300;
                                    树树友何何何何友树树 = 15;
                                    友树何何友树何树友树 = 300;
                                    树何友何友友友树友友 = new Color(20, 20, 40);
                                    何何友友友友友何友树 = new Color(65, 105, 225);
                                    友树友何友友何树树树 = new Color(50, 205, 50);
                                    return;
                                 }
                                 break;
                              default:
                                 var26[var10001] = var43;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = ",Ý\u008céV\u0093\u0014Ö;v \u009b\u0011\u000by$";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var32 = var2;
                           var2 += 8;
                           var7 = var4.substring(var32, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var10001 = var3++;
                           var38 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var41 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var21);
                  break;
               default:
                  var18[var16++] = var34;
                  if ((var21 += var14) < var17) {
                     var14 = var15.charAt(var21);
                     continue label54;
                  }

                  var15 = "&>ZÄµ\u0012x\u0003Ú¬í\u0090è\u0019Ã©ì\u0099r\u0002ô~Ge\u0014v÷×Q¤Gù\u0010\"ËHñ¬h\u001c\u0092\u0018iSÝ\u0097UÕH";
                  var17 = 49;
                  var14 = ' ';
                  var21 = -1;
            }

            var23 = var15.substring(++var21, var21 + var14);
            var10001 = 0;
         }
      }
   }

   private void V() {
      this.何友友何何友何何树何 = new LinkedList<>();
      this.何友友何何友何何树何.add(new 树树何树何何树何友友.何何何树友友友何树友(10, 10));
      this.何友友何何友何何树何.add(new 树树何树何何树何友友.何何何树友友友何树友(9, 10));
      this.何树树友树树树树树何 = 树树何树何何树何友友.友树何树树何何友友树.友何何友友友树何树何;
      this.k();
      this.友何友何友树树友树树 = false;
      this.树友何树友何友友树友 = 0;
      this.何友友何友友何何何友 = 0;
      this.何友何友何友友友何何 = 5;
      this.何何友友树何何何友树 = this.何友何友何友友友何何;
      this.友何何树友友友何树友 = 0;
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19929;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树何何树何友友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树何树何何树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树何树何何树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 11;
               case 2 -> 55;
               case 3 -> 38;
               case 4 -> 47;
               case 5 -> 54;
               case 6 -> 36;
               case 7 -> 62;
               case 8 -> 58;
               case 9 -> 57;
               case 10 -> 10;
               case 11 -> 51;
               case 12 -> 63;
               case 13 -> 12;
               case 14 -> 61;
               case 15 -> 2;
               case 16 -> 31;
               case 17 -> 5;
               case 18 -> 23;
               case 19 -> 45;
               case 20 -> 21;
               case 21 -> 17;
               case 22 -> 60;
               case 23 -> 4;
               case 24 -> 34;
               case 25 -> 39;
               case 26 -> 48;
               case 27 -> 41;
               case 28 -> 25;
               case 29 -> 7;
               case 30 -> 13;
               case 31 -> 1;
               case 32 -> 43;
               case 33 -> 33;
               case 34 -> 26;
               case 35 -> 15;
               case 36 -> 20;
               case 37 -> 22;
               case 38 -> 14;
               case 39 -> 18;
               case 40 -> 46;
               case 41 -> 50;
               case 42 -> 8;
               case 43 -> 32;
               case 44 -> 35;
               case 45 -> 42;
               case 46 -> 29;
               case 47 -> 40;
               case 48 -> 44;
               case 49 -> 30;
               case 50 -> 3;
               case 51 -> 16;
               case 52 -> 27;
               case 53 -> 52;
               case 54 -> 24;
               case 55 -> 59;
               case 56 -> 0;
               case 57 -> 49;
               case 58 -> 53;
               case 59 -> 9;
               case 60 -> 19;
               case 61 -> 28;
               case 62 -> 6;
               default -> 56;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static void a() {
      h[0] = "\\\u0016eT}0SV(_w-V\u000b#\u0019g6\u0011桩桚佢栃伊佪桩伞叼叙{佪伭伞栦叙厔叴伭桚叼";
      h[1] = int.class;
      i[1] = "java/lang/Integer";
      h[2] = "\u0006x1v.Y\t8|}$D\few;4_K标栎佀桐佣估标佊叞厊";
      h[3] = "kM\u0013g($`B\u0002(T=oX\fkc\ryO\u0000vr!nB";
      h[4] = "\u0011k';#'\u001e+j0):\u001bvav!'\u0016pe=b\u0005\u001da|4)";
      h[5] = "db?P6:PA0\u0010{1Z\\5MpwRA8Kt<\u0011c3Zm5Z\u0015";
      h[6] = void.class;
      i[6] = "java/lang/Void";
      h[7] = boolean.class;
      i[7] = "java/lang/Boolean";
      h[8] = "1 ~y\u001b)1 i%\u0017&+ki;\u001f%11$\u001a\u001f.:&x6\u00104";
      h[9] = "\u0016O6\u001b\u0016.\u0019\u000f{\u0010\u001c3\u001cRpV\f([栰栉伭桨伔传栰位厳厲e厾栰位桩桨伔传只叓桩";
      h[10] = "myh$\u001a\u001asqrkx\u0006is{!x\u0006tl";
      h[11] = "u8N\u007fzDk0T0\u0006Pq=Ws";
      h[12] = "K2y\u0000J\u0013Dr4\u000b@\u000eA/?MP\u0015\u0006桍框伶栴伩佽桍伂厨叮X口伉厜厨佰桭佽桍厜桲";
      h[13] = "\u0010|\u0006\u0017\u001a+\ri^5[&\u0015o";
      h[14] = "\u0000\u001e\u0015\u0011*)\u0000\u001e\u0002M&&\u001aU\u0002S.%\u0000\u000fOX2)@=\u000eQ3";
      h[15] = "\\h>G`\bhK1\u0007-\u0003bV4Z&EjK9\\\"\u000e)i2M;\u0007b\u001f";
      h[16] = "#}vkz\u0006,=;`p\u001b)`0&`\u0000n栂桉佝栄似伕栂伍參叞M桑栂桉參栄似压但伍栙";
      h[17] = "J`";
      h[18] = "\u0016DPNLC\u001dKA\u0001-M\u0016@E[";
      h[19] = "[Dp9\u000fjZB%c0W'b\u000b\u001bo\u0006[Dp9\u000fjZB%c";
      h[20] = "A=N}$m\u0001aLuXc/h\u0014%d2/YCrf=E(Fx*}";
      h[21] = "\u0005|\u0003\"^\u001aE \u0001*\"\u0014k)Yz\u001eCk\u0018Yz\u001e\u0019\r(\u0016?L\u0005";
      h[22] = "M27Z\u001fX\u001d~ ]o厠伮伟厞号厬桺伮桛伀4Q\u0013\u0019,-\u000f\u0001_\u000e+";
      h[23] = "bT(TS0\"\b*\\/伍伆右厏栨佲伍伆右桕1^7c\r/K\u0015j#";
      h[24] = "lS\u0005F\u0014v<\u001f\u0012Ad桔厑栺厬併桽桔伏栺厬(Z=8M\u001f\u0013\nq/J";
      h[25] = "Y%y}\u000e\u0012Wtt\f厡厲栯优桐佑伿伬佫桜I<\t@Xyx7\u001f\u0018N";
      h[26] = "q;A\t\u001eu1gC\u0001b佈桑伂佸厯桻栌压伂另l]d%e\\\u000b\u001d+\"g";
      h[27] = "A\u0005j\b\u007fs\u0001Yh\u0000\u0003叐伥似栗厮叀叐伥桸反mrt@\\m\u00179)\u0000";
      h[28] = "B:r\u0003GU\u0014!$\u00047>x\"eCN\u0010\u001b\"wGQl";
      h[29] = ".Muc-\u001fn\u0011wkQ伢叔只佌叅厒伢佊佴叒\u0006 \u0018/\u0014r|kEo";
      h[30] = "j\u0001\u0007g`_a\u0017_q\\桷厙伷叵及企伳伇桳叵\tl\u0005k\u0004\n8g\u00133\u0012";
      h[31] = "\u0013rf\u001d\t\u0003S.d\u0015u伾佷叕叁去厶厠佷叕栛xD\u0001\u0015s=\u0014E\u0007@)";
      h[32] = "\u0004+\rIT{Tg\u001aN$厃栣伆桾古叧伝栣厘厤'\u001a0P5\u0017\u001cJ|G2";
      h[33] = "\u001eA'?^\u0018HZq8.\u007f$Y0\u007fW]GY\"{H!\u0018^.jB\u001a\u001e\u000f#g.";
      h[34] = "\u000bZ\u001dY-`K\u0006\u001fQQI2O\u001e\u0004lcH\u0004CDQ";
      h[35] = "&\u001c\u0013\u0005\u0013if@\u0011\ro栐栆伥桮桹伲及叜桡桮`\u0000i/\t\u001b\u0003\u000e8\"";
      h[36] = "\u0010G-\u0018\u0017K\u001eMv[.叹伧佱桟佸佳栣伧可桟%E\n\u0014N GNB\u001aB";
      h[37] = "X'\u0005\u0016Xv\u0018{\u0007\u001e$叕似厀似厰栽栏厢桚桸s\u0019zZ2\u001cIC(\u0013 ";
      h[38] = "P\u000fo}aj\u0010Smu\u001d佗桰桲又栁栄栓桰桲佖\u0018#z\u0003\u0005{#s6\u0014\u0002";
      h[39] = "K\u001f]&,\u0003@\t\u00050\u0010佯厸伩厯压叓佯桢桭伱HaUCI\u000f2*\b\u0003";
      h[40] = "\u001bPF\"$[[\fD*X栢叡佩栻厄伅司叡栭叡G)\\\u001a\tA=b\u0001Z";
      h[41] = "`\f@KE\u0017 PBC9厴桀厫佹叭叺伪桀桱栽.\b\u0015f\r\u001bB\t\u00133W";
      h[42] = "9\u000e\u007fX\b\nyR}Pt\u0004W[%\u0000HQWjjZLWc\u0010!\u0007\f";
      h[43] = "@\r\u000eDsxN\\\u00035佂变佲厮佣栬佂栂召桴>Dx#\u0012\u000eD\u000f%c";
      h[44] = "oag{\u0017\u000ea0j\n桢厮參栘伊佗厸桴佝作W{\u001cU=b-0A\u0015";
      h[45] = "\u0007\u00020\u0011k}G^2\u0019\u0017栄佣伻桍厷栎佀栧桿桍tfz\u0006[7\u000e-'F";
      h[46] = "\u0001 bd[`A|`l'栙佥厇佛参古參校厇叅\u0001\u0016b\u0007!9m\u0017dR{";
      h[47] = "-qeW\u00135m-g_o伈受取作佯厬伈佉栌作2PoxhpN\u001dnpl";
      h[48] = "?\u0004y5|T4\u0012!#@伸双伲桑伆伝桼双厬压[q\u00070\nw7p\u0001eP";
      h[49] = "Y\n+JI5\u0019V)B5<`TtCDl\u0001\u000b2BNUZU#^\f4\u0005\u0013\"T5";
      h[50] = "rn80%\u0015shmj\u001a2\u0012EAU+\u001b|i89*\u001d)3";
      h[51] = "(];:\u0016`h\u000192j佝叒佤厜伂厩參叒佤伂_\u001bg)\u0004<%P:i";
      h[52] = "6D\u0016\u0007Ar=RN\u0011}桚佛佲佺伴传桚佛栶佺iM(7A\u001bXF>oW";
      h[53] = "\u00028V%vGBdT-\nU;-Ux7DAf\b8\n";
      h[54] = "j\u000eYyEha\u0018\u0001oy桀桃伸伵佊厺桀桃伸厫\u0017I2k\u000bT&B$3\u001d";
      h[55] = "a7wx\"I!kup^jX\"t%cJ\"i)e^\u001564~qe\u0013g9s\u001d";
      h[56] = "y\u0018K\u00169U)T\\\u0011I厭厄桱核伥桐伳桞厫叢xw\u001e-\u0006QC'R:\u0001";
      h[57] = "_qgBhA\u001f-eJ\u0014O1$=\u001a(\u001d1\u0015r@,\u001c\u0005o9\u001dl";
      h[58] = "\u001a}b\\\u0003\"\u001b{7\u0006<\u0011k^\u0001t<\u007fI 8\u0006P~Oub";
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'd' && var8 != 'F' && var8 != 227 && var8 != 241) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 230) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 248) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'd') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'F') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 227) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7596;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树何何树何友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[-Ê\u0003 s!òBæâv\u0005\u0081Åæ\u0015, Ä9:}\u0085\u009dÍª´Y<gg?\u009f!, h\\Ö\u0010Á)åX\u009eñFÍÍ\u00ad@åò\u0080Y\u009fM³qjÌ¡H\u0018¿\u001cD")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树何树何何树何友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void k() {
      z();

      do {
         树树何树何何树何友友.友何友友何树何树友树 type = 树树何树何何树何友友.友何友友何树何树友树.树何何何何何树何树何;
         int rand = this.何树何何友树树友何友.nextInt(100);
         if (rand < 5) {
            type = 树树何树何何树何友友.友何友友何树何树友树.树友何友友何何何树友;
         }

         if (rand < 10) {
            type = 树树何树何何树何友友.友何友友何树何树友树.树树何何何友树树何友;
         }

         this.树树何树树何友友树树 = new 树树何树何何树何友友.何何何树友友友何树友(this.何树何何友树树友何友.nextInt(20), this.何树何何友树树友何友.nextInt(20), type);
      } while (this.E(this.何友友何何友何何树何, this.树树何树树何友友树树));
   }

   public static int z() {
      return 友何何树树友友何友友;
   }

   private boolean E(LinkedList<树树何树何何树何友友.何何何树友友友何树友> list, 树树何树何何树何友友.何何何树友友友何树友 point) {
      z();
      Iterator var6 = list.iterator();
      if (var6.hasNext()) {
         树树何树何何树何友友.何何何树友友友何树友 p = (树树何树何何树何友友.何何何树友友友何树友)var6.next();
         if (p.树友友树何何友树何何 == point.树友友树何何友树何何 && p.何友何友何树何树友树 == point.何友何友何树何树友树) {
            return true;
         }
      }

      return false;
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private void E() {
      z();
      if (!this.何友友何何友何何树何.isEmpty()) {
         树树何树何何树何友友.何何何树友友友何树友 head = this.何友友何何友何何树何.getFirst();
         switch (树树何树何何树何友友$树树树友树何友何何树.友何何树何何树何友树[this.何树树友树树树树树何.ordinal()]) {
            case 1:
               new 树树何树何何树何友友.何何何树友友友何树友(head.树友友树何何友树何何, head.何友何友何树何树友树 - 1);
            case 2:
               new 树树何树何何树何友友.何何何树友友友何树友(head.树友友树何何友树何何, head.何友何友何树何树友树 + 1);
            case 3:
               new 树树何树何何树何友友.何何何树友友友何树友(head.树友友树何何友树何何 - 1, head.何友何友何树何树友树);
            case 4:
               new 树树何树何何树何友友.何何何树友友友何树友(head.树友友树何何友树何何 + 1, head.何友何友何树何树友树);
         }
      }
   }

   public static int A() {
      z();

      try {
         return 4;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public static void K(int var0) {
      友何何树树友友何友友 = var0;
   }

   private static String HE_DA_WEI() {
      return "何炜霖黑水";
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      c<"ø">(4579401340119673686L, 47924016594816L);
      super.render(guiGraphics, mouseX, mouseY, partialTicks);
      int gameAreaX = (c<"d">(this, 4578678066406914038L, 47924016594816L) - 300) / 2;
      int gameAreaY = (c<"d">(this, 4579699285724081712L, 47924016594816L) - 300) / 2;
      guiGraphics.fill(gameAreaX - 1, gameAreaY - 1, gameAreaX + 300 + 1, gameAreaY + 300 + 1, c<"ã">(4577867502819538942L, 47924016594816L).getRGB());
      guiGraphics.fill(gameAreaX, gameAreaY, gameAreaX + 300, gameAreaY + 300, c<"ã">(4578899753814087720L, 47924016594816L).getRGB());
      int i = 0;
      Iterator pulse = c<"d">(this, 4579023013959265944L, 47924016594816L).iterator();
      if (pulse.hasNext()) {
         树树何树何何树何友友.何何何树友友友何树友 p = (树树何树何何树何友友.何何何树友友友何树友)pulse.next();
         float hue = 0.0F / c<"d">(this, 4579023013959265944L, 47924016594816L).size() * 0.3F + 0.3F;
         Color segmentColor = Color.getHSBColor(hue, 0.8F, 0.9F);
         if (p.equals(c<"d">(this, 4579023013959265944L, 47924016594816L).getFirst())) {
            segmentColor = c<"ã">(4578586396965296030L, 47924016594816L);
         }

         guiGraphics.fill(
            gameAreaX + c<"d">(p, 4578787769125404785L, 47924016594816L) * 15,
            gameAreaY + c<"d">(p, 4578740819548313294L, 47924016594816L) * 15,
            gameAreaX + c<"d">(p, 4578787769125404785L, 47924016594816L) * 15 + 15 - 1,
            gameAreaY + c<"d">(p, 4578740819548313294L, 47924016594816L) * 15 + 15 - 1,
            segmentColor.getRGB()
         );
         i++;
         c<"ø">(new Module[1], 4578016270161912128L, 47924016594816L);
      }

      float pulsex = Math.abs(c<"d">(this, 4578848179545665430L, 47924016594816L) / 20.0F * 2.0F - 1.0F);
      Color currentFoodColor = c<"d">(
         c<"d">(c<"d">(this, 4578141539163146503L, 47924016594816L), 4577484522890281482L, 47924016594816L), 4579086602546681464L, 47924016594816L
      );
      Color foodColor = new Color(Math.min(255, currentFoodColor.getRed() + (int)(pulsex * 50.0F)), currentFoodColor.getGreen(), currentFoodColor.getBlue());
      guiGraphics.fill(
         gameAreaX + c<"d">(c<"d">(this, 4578141539163146503L, 47924016594816L), 4578787769125404785L, 47924016594816L) * 15,
         gameAreaY + c<"d">(c<"d">(this, 4578141539163146503L, 47924016594816L), 4578740819548313294L, 47924016594816L) * 15,
         gameAreaX + c<"d">(c<"d">(this, 4578141539163146503L, 47924016594816L), 4578787769125404785L, 47924016594816L) * 15 + 15 - 1,
         gameAreaY + c<"d">(c<"d">(this, 4578141539163146503L, 47924016594816L), 4578740819548313294L, 47924016594816L) * 15 + 15 - 1,
         foodColor.getRGB()
      );
      String scoreText = "Score: " + c<"d">(this, 4578477987726147174L, 47924016594816L);
      guiGraphics.drawString(
         c<"d">(this, 4577133480435891387L, 47924016594816L), scoreText, gameAreaX, gameAreaY - 9 - 5, c<"ã">(4579757941890979683L, 47924016594816L).getRGB()
      );
      if (c<"d">(this, 4577573255897522636L, 47924016594816L) > 0) {
         String speedText = "SPEED BOOST: " + (c<"d">(this, 4577573255897522636L, 47924016594816L) / 20 + 1) + "s";
         guiGraphics.drawString(
            c<"d">(this, 4577133480435891387L, 47924016594816L),
            speedText,
            gameAreaX + 300 - c<"d">(this, 4577133480435891387L, 47924016594816L).width(speedText),
            gameAreaY - 9 - 5,
            c<"ã">(4579211666696300939L, 47924016594816L).getRGB()
         );
      }

      if (c<"d">(this, 4578277430899545669L, 47924016594816L)) {
         MutableComponent var22 = Component.literal("GAME OVER");
         Component restartComponent = Component.literal(a<"c">(12400, 4216335368710729182L));
         guiGraphics.drawCenteredString(
            c<"d">(this, 4577133480435891387L, 47924016594816L),
            var22,
            c<"d">(this, 4578678066406914038L, 47924016594816L) / 2,
            c<"d">(this, 4579699285724081712L, 47924016594816L) / 2 - 9,
            c<"ã">(4577012736244490388L, 47924016594816L).getRGB()
         );
         guiGraphics.drawCenteredString(
            c<"d">(this, 4577133480435891387L, 47924016594816L),
            restartComponent,
            c<"d">(this, 4578678066406914038L, 47924016594816L) / 2,
            c<"d">(this, 4579699285724081712L, 47924016594816L) / 2 + 5,
            c<"ã">(4579757941890979683L, 47924016594816L).getRGB()
         );
      }
   }

   public boolean isPauseScreen() {
      return false;
   }

   public void tick() {
      z();
      if (!this.友何友何友树树友树树) {
         this.树何何树友树何树树树 = (this.树何何树友树何树树树 + 1) % 20;
         if (this.友何何树友友友何树友 > 0) {
            this.友何何树友友友何树友--;
            this.何何友友树何何何友树 = Math.max(1, this.何友何友何友友友何何 / 2);
         }

         this.何何友友树何何何友树 = this.何友何友何友友友何何;
         this.何友友何友友何何何友++;
         if (this.何友友何友友何何何友 >= this.何何友友树何何何友树) {
            this.何友友何友友何何何友 = 0;
            this.E();
         }
      }
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      A();
      if (this.友何友何友树树友树树) {
         if (keyCode == 82) {
            this.V();
            return true;
         }
      } else {
         if (keyCode == 265 && this.何树树友树树树树树何 != 树树何树何何树何友友.友树何树树何何友友树.树友树友何树树何树友) {
            this.何树树友树树树树树何 = 树树何树何何树何友友.友树何树树何何友友树.友树何树友友何树友友;
            return true;
         }

         if (keyCode == 264 && this.何树树友树树树树树何 != 树树何树何何树何友友.友树何树树何何友友树.友树何树友友何树友友) {
            this.何树树友树树树树树何 = 树树何树何何树何友友.友树何树树何何友友树.树友树友何树树何树友;
            return true;
         }

         if (keyCode == 263 && this.何树树友树树树树树何 != 树树何树何何树何友友.友树何树树何何友友树.友何何友友友树何树何) {
            this.何树树友树树树树树何 = 树树何树何何树何友友.友树何树树何何友友树.友友树树何树何树友友;
            return true;
         }

         if (keyCode == 262 && this.何树树友树树树树树何 != 树树何树何何树何友友.友树何树树何何友友树.友友树树何树何树友友) {
            this.何树树友树树树树树何 = 树树何树何何树何友友.友树何树树何何友友树.友何何友友友树何树何;
            return true;
         }
      }

      if (keyCode == 256) {
         super.minecraft.setScreen(null);
         return true;
      } else {
         return super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   private static class 何何何树友友友何树友 implements 何树友 {
      int 树友友树何何友树何何;
      int 何友何友何树何树友树;
      树树何树何何树何友友.友何友友何树何树友树 友友树何树何何何何树 = 树树何树何何树何友友.友何友友何树何树友树.树何何何何何树何树何;
      private static final long a;
      private static final Object[] b = new Object[12];
      private static final String[] c = new String[12];
      private static String HE_DA_WEI;

      何何何树友友友何树友(int x, int y) {
         this.树友友树何何友树何何 = x;
         this.何友何友何树何树友树 = 10;
      }

      何何何树友友友何树友(int x, int y, 树树何树何何树何友友.友何友友何树何树友树 type) {
         this.树友友树何何友树何何 = x;
         this.何友何友何树何树友树 = y;
         this.友友树何树何何何何树 = type;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(5930052247127574487L, 6302441994054342699L, MethodHandles.lookup().lookupClass()).a(63266066949622L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      @Override
      public boolean equals(Object obj) {
         树树何树何何树何友友.A();
         if (this == obj) {
            return true;
         } else if (obj != null && this.getClass() == obj.getClass()) {
            树树何树何何树何友友.何何何树友友友何树友 point = (树树何树何何树何友友.何何何树友友友何树友)obj;
            return this.树友友树何何友树何何 == point.树友友树何何友树何何 && this.何友何友何树何树友树 == point.何友何友何树何树友树;
         } else {
            return false;
         }
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树何何树何友友$何何何树友友友何树友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 181 && var8 != 209 && var8 != 214 && var8 != 'W') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 206) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'R') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 181) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 209) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 214) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static void a() {
         b[0] = "-Y&\u0004n\f\"\u0019k\u000fd\u0011'D`It\n`栦栙伲栐伶伛栦佝厬及G伛佢佝桶及厨厅佢栙厬";
         b[1] = int.class;
         c[1] = "java/lang/Integer";
         b[2] = "ksIH\u0007kd3\u0004C\rvan\u000f\u0005\u001dm&栌桶佾桹佑佝栌伲叠厣 參佈厬叠伽栕佝栌厬栺";
         b[3] = "\f\u0017\u001c6Wp\u0007\u0018\ry+i\b\u0002\u0003:\u001cY\u001e\u0015\u000f'\ru\t\u0018";
         b[4] = "i\u0013\u0001u'lfSL~-qc\u000eG8=j$桬栾佃桙佖佟桬佺叝厃";
         b[5] = "PBC\f\"?[MRCC1PFV\u0019";
         b[6] = ")8\u0016m>\u0002s5H\tn|r3Rny\u0007,=V4\u0007F$!Kw|\u0018*%\u0011\t";
         b[7] = "\u0011\bR-9\u001cK\u0005\fI佝厡伭厬伵桐佝桻厳桶hp?\u0013\u001b\b\f,\u007f\u001bK";
         b[8] = "5#\u0005K\u000fjo.[/栯受厗桝佢佲叵栍伉伙?\u0016\te?#[JImo";
         b[9] = "%u\n_4\u0003zs\n\u0005\f{\u001e%D\u0012gUzy\u0004\u001a72";
         b[10] = "Q)W\r5\u000b\u000b$\ti叏厶栩伓桴伴佑伨佭桗mPj\u0005P<PPe\u001aS";
         b[11] = "#\u000e\u0016~6l#\u0001\t}D案佇伵伻佃伙案佇桱伻\u001e}7j\b\u0014#}8u\u000b";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 32;
                  case 1 -> 57;
                  case 2 -> 62;
                  case 3 -> 47;
                  case 4 -> 33;
                  case 5 -> 49;
                  case 6 -> 34;
                  case 7 -> 23;
                  case 8 -> 21;
                  case 9 -> 42;
                  case 10 -> 51;
                  case 11 -> 46;
                  case 12 -> 28;
                  case 13 -> 17;
                  case 14 -> 27;
                  case 15 -> 11;
                  case 16 -> 0;
                  case 17 -> 45;
                  case 18 -> 55;
                  case 19 -> 36;
                  case 20 -> 8;
                  case 21 -> 7;
                  case 22 -> 1;
                  case 23 -> 41;
                  case 24 -> 6;
                  case 25 -> 24;
                  case 26 -> 43;
                  case 27 -> 58;
                  case 28 -> 63;
                  case 29 -> 30;
                  case 30 -> 4;
                  case 31 -> 39;
                  case 32 -> 31;
                  case 33 -> 25;
                  case 34 -> 59;
                  case 35 -> 15;
                  case 36 -> 50;
                  case 37 -> 5;
                  case 38 -> 48;
                  case 39 -> 60;
                  case 40 -> 54;
                  case 41 -> 19;
                  case 42 -> 3;
                  case 43 -> 22;
                  case 44 -> 2;
                  case 45 -> 40;
                  case 46 -> 9;
                  case 47 -> 12;
                  case 48 -> 53;
                  case 49 -> 16;
                  case 50 -> 61;
                  case 51 -> 56;
                  case 52 -> 14;
                  case 53 -> 10;
                  case 54 -> 18;
                  case 55 -> 37;
                  case 56 -> 44;
                  case 57 -> 38;
                  case 58 -> 29;
                  case 59 -> 35;
                  case 60 -> 26;
                  case 61 -> 20;
                  case 62 -> 13;
                  default -> 52;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String HE_JIAN_GUO() {
         return "何树友，和树做朋友";
      }
   }

   private static enum 友何友友何树何树友树 implements  {
      树何何何何何树何树何,
      树友何友友何何何树友,
      树树何何何友树树何友;

      final int 何友何友友友何树树何;
      final Color 何友何树何何树友友友;
      private static final long a;
      private static final Object[] b = new Object[7];
      private static final String[] c = new String[7];
      private static int _我是何树友 _;

      private 友何友友何树何树友树(int points, Color color) {
         this.何友何友友友何树树何 = points;
         this.何友何树何何树友友友 = color;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-396779488148973579L, -5057657869753450574L, MethodHandles.lookup().lookupClass()).a(94732810244849L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var8 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(113542112142495L << var2 * 8 >>> 56);
         }

         var8.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[3];
         int var6 = 0;
         char var4 = '\b';
         int var3 = -1;

         while (true) {
            String var10 = a(var1.doFinal("\rbÓtóI½Ï\b)Y\u0091X\u0006ìÙº\b»u\u0085¥+\u0086,Û".substring(++var3, var3 + var4).getBytes("ISO-8859-1"))).intern();
            byte var10001 = -1;
            var0[var6++] = var10;
            if ((var3 += var4) >= 26) {
               树何何何何何树何树何 = new 树树何树何何树何友友.友何友友何树何树友树(1, new Color(220, 20, 60));
               树友何友友何何何树友 = new 树树何树何何树何友友.友何友友何树何树友树(3, new Color(255, 215, 0));
               树树何何何友树树何友 = new 树树何树何何树何友友.友何友友何树何树友树(1, new Color(0, 191, 255));
               return;
            }

            var4 = "\rbÓtóI½Ï\b)Y\u0091X\u0006ìÙº\b»u\u0085¥+\u0086,Û".charAt(var3);
         }
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public static 树树何树何何树何友友.友何友友何树何树友树[] c() {
         return (树树何树何何树何友友.友何友友何树何树友树[])树何何友树友友何友树.clone();
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 218 && var8 != 238 && var8 != 'v' && var8 != 'D') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 223) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'm') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 218) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 238) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'v') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树何何树何友友$友何友友何树何树友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 32;
                  case 1 -> 29;
                  case 2 -> 40;
                  case 3 -> 8;
                  case 4 -> 20;
                  case 5 -> 4;
                  case 6 -> 39;
                  case 7 -> 56;
                  case 8 -> 6;
                  case 9 -> 10;
                  case 10 -> 59;
                  case 11 -> 61;
                  case 12 -> 41;
                  case 13 -> 5;
                  case 14 -> 43;
                  case 15 -> 26;
                  case 16 -> 11;
                  case 17 -> 21;
                  case 18 -> 23;
                  case 19 -> 1;
                  case 20 -> 36;
                  case 21 -> 42;
                  case 22 -> 17;
                  case 23 -> 58;
                  case 24 -> 30;
                  case 25 -> 50;
                  case 26 -> 55;
                  case 27 -> 13;
                  case 28 -> 63;
                  case 29 -> 57;
                  case 30 -> 7;
                  case 31 -> 37;
                  case 32 -> 52;
                  case 33 -> 27;
                  case 34 -> 31;
                  case 35 -> 47;
                  case 36 -> 53;
                  case 37 -> 28;
                  case 38 -> 54;
                  case 39 -> 33;
                  case 40 -> 19;
                  case 41 -> 3;
                  case 42 -> 14;
                  case 43 -> 46;
                  case 44 -> 12;
                  case 45 -> 16;
                  case 46 -> 60;
                  case 47 -> 48;
                  case 48 -> 49;
                  case 49 -> 34;
                  case 50 -> 24;
                  case 51 -> 44;
                  case 52 -> 2;
                  case 53 -> 18;
                  case 54 -> 38;
                  case 55 -> 25;
                  case 56 -> 45;
                  case 57 -> 9;
                  case 58 -> 62;
                  case 59 -> 22;
                  case 60 -> 35;
                  case 61 -> 15;
                  case 62 -> 0;
                  default -> 51;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\n\u0016\u0017\u001b#A\u0005VZ\u0010)\\\u0000\u000bQV9GG桩栨伭桝佻似桩佬厳厇\n厢伭史厳伙栿似桩史桩";
         b[1] = "'X\u001cft,\u0013{\u0013&9'\u0019f\u0016{2a\t}Q栙桋会桭佁伪栙伏厄厷0厴佝厑厄伩栅伪栙厑桞G";
         b[2] = "n'\f\u0001oje(\u001dN\u000edn#\u0019\u0014";
         b[3] = "BA)7{S\u0018Md\u0007栒伿使叧栏叄又伿叡栽\u0016w4\rGCknv\u0012";
         b[4] = "?e\u0010\")vei]\u0012桀厄伂參召住伄会框參/r<xop\u001e(05";
         b[5] = ".[z\"g0tW7\u0012栎栘伓佣优发栎栘伓叽Err>~Nt(~s";
         b[6] = "^ 9\u0003\u0011s\u0004,t3桸伟佣优佛佮桸伟栧优\u0006S\u0004}\u000e57\t\b0";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public static 树树何树何何树何友友.友何友友何树何树友树 U(String name) {
         return Enum.valueOf(树树何树何何树何友友.友何友友何树何树友树.class, name);
      }

      private static String HE_DA_WEI() {
         return "何树友为什么濒天了";
      }
   }

   private static enum 友树何树树何何友友树 implements  {
      友树何树友友何树友友,
      树友树友何树树何树友,
      友友树树何树何树友友,
      友何何友友友树何树何;

      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_DA_WEI;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(4632186888208474765L, 5032103498494579789L, MethodHandles.lookup().lookupClass()).a(161731001808631L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(94514965139837L << var2 * 8 >>> 56);
         }

         var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[4];
         int var6 = 0;
         String var5 = "Ê?Þ²_ú\u001fâ\b\u0016\u0095²QÉ4\u0095Ú";
         byte var7 = 17;
         char var4 = '\b';
         int var9 = -1;

         label28:
         while (true) {
            String var11 = var5.substring(++var9, var9 + var4);
            byte var10001 = -1;

            while (true) {
               String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var17;
                     if ((var9 += var4) >= var7) {
                        友树何树友友何树友友 = new 树树何树何何树何友友.友树何树树何何友友树();
                        树友树友何树树何树友 = new 树树何树何何树何友友.友树何树树何何友友树();
                        友友树树何树何树友友 = new 树树何树何何树何友友.友树何树树何何友友树();
                        友何何友友友树何树何 = new 树树何树何何树何友友.友树何树树何何友友树();
                        return;
                     }

                     var4 = var5.charAt(var9);
                     break;
                  default:
                     var0[var6++] = var17;
                     if ((var9 += var4) < var7) {
                        var4 = var5.charAt(var9);
                        continue label28;
                     }

                     var5 = "·~ù¦L8\u0091\u009d\b§\t\u0012\u0017N6\u000b×";
                     var7 = 17;
                     var4 = '\b';
                     var9 = -1;
               }

               var11 = var5.substring(++var9, var9 + var4);
               var10001 = 0;
            }
         }
      }

      public static 树树何树何何树何友友.友树何树树何何友友树 Z(String name) {
         return Enum.valueOf(树树何树何何树何友友.友树何树树何何友友树.class, name);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 204 && var8 != 210 && var8 != 'O' && var8 != 'J') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 232) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'W') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 204) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 210) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'O') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 22;
                  case 1 -> 40;
                  case 2 -> 25;
                  case 3 -> 43;
                  case 4 -> 28;
                  case 5 -> 55;
                  case 6 -> 35;
                  case 7 -> 7;
                  case 8 -> 18;
                  case 9 -> 3;
                  case 10 -> 23;
                  case 11 -> 20;
                  case 12 -> 52;
                  case 13 -> 21;
                  case 14 -> 50;
                  case 15 -> 14;
                  case 16 -> 19;
                  case 17 -> 36;
                  case 18 -> 56;
                  case 19 -> 31;
                  case 20 -> 17;
                  case 21 -> 48;
                  case 22 -> 8;
                  case 23 -> 27;
                  case 24 -> 29;
                  case 25 -> 38;
                  case 26 -> 58;
                  case 27 -> 5;
                  case 28 -> 12;
                  case 29 -> 4;
                  case 30 -> 61;
                  case 31 -> 30;
                  case 32 -> 6;
                  case 33 -> 57;
                  case 34 -> 37;
                  case 35 -> 42;
                  case 36 -> 26;
                  case 37 -> 1;
                  case 38 -> 51;
                  case 39 -> 16;
                  case 40 -> 59;
                  case 41 -> 60;
                  case 42 -> 15;
                  case 43 -> 13;
                  case 44 -> 54;
                  case 45 -> 9;
                  case 46 -> 63;
                  case 47 -> 47;
                  case 48 -> 2;
                  case 49 -> 32;
                  case 50 -> 44;
                  case 51 -> 33;
                  case 52 -> 46;
                  case 53 -> 49;
                  case 54 -> 24;
                  case 55 -> 41;
                  case 56 -> 11;
                  case 57 -> 62;
                  case 58 -> 39;
                  case 59 -> 45;
                  case 60 -> 34;
                  case 61 -> 10;
                  case 62 -> 0;
                  default -> 53;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "I_Gi\u001fYF\u001f\nb\u0015DCB\u0001$\u0005_\u0004栠桸佟桡佣使栠似叁去\u0012叡栠似栛桡佣使叺厢栛";
         b[1] = "Y\u001ez\u001c\u0007am=u\\Jjg p\u0001A,w;7档核佗栓伇佌档佼叉叉v叒档佼栓栓伇佌厹叢栓9";
         b[2] = "F8\t?'oM7\u0018pFaF<\u001c*";
         b[3] = "P#4&b\u0004^>9\u001b厘厷桹案伈栂伆桭厣厒U+)\u0015]h%%4\u0018";
         b[4] = "d0`wV\u0003j-mJ厬伮桍桛参厉伲桪厗桛\u00011\u0015\u00142r:0^M";
         b[5] = "i'e\u0014M+g:h)厷伆伄厖叇只桭伆桀伈\u0004\u0019\u0006:dlt\u0017\u001b7";
         b[6] = "\\do,]*Ryb\u0011厧桃伱栏反叒伹桃厯叕\u000e!\u0016;Q/~/\u000b6";
         b[7] = "9$ZE*`79Wx栊叓栐厕佦桡栊位栐厕;Haq4oKF||";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树何何树何友友$友树何树树何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      public static 树树何树何何树何友友.友树何树树何何友友树[] U() {
         return (树树何树何何树何友友.友树何树树何何友友树[])友何树树友友何树友树.clone();
      }

      private static String LIU_YA_FENG() {
         return "何大伟为什么要诈骗何炜霖";
      }
   }
}
