package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import net.minecraft.client.gui.GuiGraphics;

public class 树友何友友友树友何树 implements 友友何何何树友友何树, 何树友 {
   private float 友何友友何友树友何何 = 0.0F;
   private boolean 友树友友友友友何何何 = false;
   private long 何何何树树树何友何友 = 0L;
   private static final long a;
   private static final Object[] b = new Object[24];
   private static final String[] c = new String[24];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2487458438130551164L, 6534723743240169238L, MethodHandles.lookup().lookupClass()).a(81398142631420L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   @Override
   public float Z(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value) {
      树友树树何友何何树友.Y();
      String valueName = panel.友友何友何树何何树树.树树何树友树何树友树 ? value.r() : value.V();
      float nameWidth = panel.友友何友何树何何树树.友何何何何树友树何树.D(valueName);
      Objects.requireNonNull(panel.友友何友何树何何树树);
      float availableWidthForControl = 106.0F - nameWidth - 4.0F;
      if (!(nameWidth > 58.300003F) && availableWidthForControl < 26.5F) {
      }

      return 28.8F;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 's' && var8 != 'K' && var8 != 'c' && var8 != 216) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 224) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 's') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'K') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'c') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何友友友树友何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   public void a(GuiGraphics g, 树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      BooleanValue bv = (BooleanValue)value;
      树友树树何友何何树友.Y();
      this.v(bv.getValue());
      String valueName = panel.友友何友何树何何树树.树树何树友树何树友树 ? value.r() : value.V();
      float nameWidth = panel.友友何友何树何何树树.友何何何何树友树何树.D(valueName);
      boolean dsj = nameWidth > valw * 0.55F || valw - nameWidth - 4.0F < valw * 0.25F;
      float currentYOffset = valy;
      float textRenderX = valx + 2.0F;
      panel.友友何友何树何何树树
         .友何何何何树友树何树
         .s(
            g.pose(),
            valueName,
            textRenderX,
            valy + 8.0F - panel.友友何友何树何何树树.友何何何何树友树何树.x() / 2.0F,
            panel.友友何友何树何何树树.o(panel.友友何友何树何何树树.树友何何友树友友何树, alpha).getRGB()
         );
      if (dsj) {
         currentYOffset = valy + 12.8F;
      }

      float checkMarkSize = panel.友友何友何树何何树树.树友何何何树何友树树.x();
      float squareSize = checkMarkSize + 4.0F;
      float squareX = valx + valw - squareSize - 2.0F;
      float squareY = currentYOffset + 8.0F - squareSize / 2.0F;
      RenderUtils.drawRectangle(
         g.pose(), squareX, squareY, squareSize, squareSize, panel.友友何友何树何何树树.o(panel.友友何友何树何何树树.树何何树何树何树何友, (int)(alpha * 0.7F)).getRGB()
      );
      if (this.友何友友何友树友何何 > 0.01F) {
         float iconX = squareX + squareSize / 2.0F - panel.友友何友何树何何树树.友何友树树友何友树友.D("\ueb53") / 2.0F;
         float iconY = squareY + squareSize / 2.0F - panel.友友何友何树何何树树.友何友树树友何友树友.x() / 2.0F;
         int animatedCheckMarkAlpha = (int)(alpha * this.友何友友何友树友何何);
         panel.友友何友何树何何树树.友何友树树友何友树友.s(g.pose(), "\ueb53", iconX, iconY, panel.友友何友何树何何树树.o(HUD.instance.getColor(1), animatedCheckMarkAlpha).getRGB());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 40;
               case 1 -> 35;
               case 2 -> 39;
               case 3 -> 20;
               case 4 -> 57;
               case 5 -> 50;
               case 6 -> 56;
               case 7 -> 31;
               case 8 -> 63;
               case 9 -> 54;
               case 10 -> 45;
               case 11 -> 59;
               case 12 -> 58;
               case 13 -> 8;
               case 14 -> 18;
               case 15 -> 44;
               case 16 -> 29;
               case 17 -> 23;
               case 18 -> 15;
               case 19 -> 48;
               case 20 -> 34;
               case 21 -> 0;
               case 22 -> 24;
               case 23 -> 26;
               case 24 -> 14;
               case 25 -> 41;
               case 26 -> 25;
               case 27 -> 27;
               case 28 -> 51;
               case 29 -> 1;
               case 30 -> 49;
               case 31 -> 55;
               case 32 -> 61;
               case 33 -> 3;
               case 34 -> 21;
               case 35 -> 42;
               case 36 -> 10;
               case 37 -> 37;
               case 38 -> 4;
               case 39 -> 19;
               case 40 -> 28;
               case 41 -> 12;
               case 42 -> 43;
               case 43 -> 30;
               case 44 -> 46;
               case 45 -> 2;
               case 46 -> 60;
               case 47 -> 38;
               case 48 -> 6;
               case 49 -> 16;
               case 50 -> 5;
               case 51 -> 33;
               case 52 -> 7;
               case 53 -> 47;
               case 54 -> 9;
               case 55 -> 11;
               case 56 -> 62;
               case 57 -> 53;
               case 58 -> 36;
               case 59 -> 17;
               case 60 -> 13;
               case 61 -> 32;
               case 62 -> 52;
               default -> 22;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "Jy~LDWE93GNJ@d8\u0001^Q\u0007栆厛佺叠右叢栆厛佺栺";
      b[1] = ">dME\u001dy5k\\\na`:qRIVP,f^TG|;k";
      b[2] = "qOXn\u0015\u0010~\u000f\u0015e\u001f\r{R\u001e#\u000f\u0016<栰厽栜桫伪叙佴伣栜厱";
      b[3] = int.class;
      c[3] = "java/lang/Integer";
      b[4] = "MPxy;EB\u00105r1XGM>4!C\u0000佫桇住原叡佻佫厝发桅";
      b[5] = boolean.class;
      c[5] = "java/lang/Boolean";
      b[6] = "G@O\u001aF\u0002H\u0000\u0002\u0011L\u001fM]\tW\\\u0004\n栿桰桨叢伸佱栿伴厲佼";
      b[7] = "\u000e2E \u0004M\u0001r\b+\u000eP\u0004/\u0003m\u001eKC伉伾厈厠栳伸桍伾厈桺";
      b[8] = float.class;
      c[8] = "java/lang/Float";
      b[9] = long.class;
      c[9] = "java/lang/Long";
      b[10] = "p\u0000#2\u001f<m\u0015{\u0010^1u\u0013";
      b[11] = "%6uQ\u0018\f.9d\u001ey\u0002%2`D";
      b[12] = "VP)gRsQ\\(jn栊厯佽佅叄桷叐厯佽栁\u0007Q)\u001cP\u007f}_s\u0010R";
      b[13] = "y/\u0007/&z> \u0011`EO@w\u0004`8$,5\u0015!t\u001e";
      b[14] = "c\u0013\u000b{oAd\u001f\nvS核桀伾栣变桊佼桀厠栣\u001bhQ:RV~0H:\b";
      b[15] = "8/\u0012n.\u0015ho\u001d\u0007伃伶伏桍桮栞伃厨伏厗w9#\b.m\rm.\u00123";
      b[16] = "$y\u0018F= #u\u0019K\u0001桙佃佔栰佻栘伝标佔只&>znyN\\0 b{";
      b[17] = "uj\u001djq\u001drf\u001cgM桤厌佇佱佗桔传厌栃栵\npG~zVa?\u00021v";
      b[18] = "f.Ltw:6nC\u001d叄桝叏厖只叞叄伙佑伈)&w'=9L~n'g";
      b[19] = "7\u0014@\u007fZ)gTO\u0016CW$\u0005@i@24P@\u0016S=8\u0010OsCh8o";
      b[20] = "g\u0016\t^?|%\u001e\n\u000bM叞厘伥厫伲桔佀伆桡桱owmj\u0018T\u000fpak\u0015";
      b[21] = "w\u001cv$ulp\u0010w)I叏伐伱会伙桐叏桔伱桞Dt6|\f=/;s3\u0000";
      b[22] = "E}.~7\u001d\u0015=!\u0017厄伾召叅伖叔桞厠佲佛K*\"Y\u001f9!u}\nR";
      b[23] = "/ yQAX(,x\\}叻佈厓桑栨厾佥取桉压1@\u0002$02Z\u000fGk<";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private void v(boolean currentValue) {
      树友树树何友何何树友.Y();
      if (currentValue != this.友树友友友友友何何何) {
         this.何何何树树树何友何友 = System.currentTimeMillis();
         this.友树友友友友友何何何 = currentValue;
      }

      long elapsed = System.currentTimeMillis() - this.何何何树树树何友何友;
      if (currentValue) {
         if ((float)elapsed < 200.0F) {
            this.友何友友何友树友何何 = (float)elapsed / 200.0F;
         }

         this.友何友友何友树友何何 = 1.0F;
      }

      if ((float)elapsed < 200.0F) {
         this.友何友友何友树友何何 = 1.0F - (float)elapsed / 200.0F;
      }

      this.友何友友何友树友何何 = 0.0F;
      this.友何友友何友树友何何 = Math.max(0.0F, Math.min(1.0F, this.友何友友何友树友何何));
   }

   @Override
   public 何何何友友何树何何何 K(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      树友树树何友何何树友.Y();
      BooleanValue bv = (BooleanValue)value;
      bv.G(!bv.getValue());
      return null;
   }

   private static String LIU_YA_FENG() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
