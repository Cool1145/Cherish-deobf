package cn.cool.cherish.ui;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import heilongjiang.zhaoyuan.何树友;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraft.client.User.Type;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class 何何友友何友友友何友 extends Screen implements 何树友 {
   public static final 何何友友何友友友何友 友友友友友树友友树树;
   private EditBox 树何何何友友何何树友;
   private EditBox 何树树友何何树何友友;
   private Button 树友何友何树友树何树;
   private static boolean 何树树友何何友友友友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[28];
   private static final String[] i = new String[28];
   private static String HE_SHU_YOU;

   public 何何友友何友友友何友() {
      super(Component.literal("Token Login"));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-2755754195003319659L, 832550397156049986L, MethodHandles.lookup().lookupClass()).a(214096083385821L);
      // $VF: monitorexit
      a = var10000;
      b();
      i(false);
      Cipher var11;
      Cipher var21 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(107883904092993L << var12 * 8 >>> 56);
      }

      var21.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[12];
      int var16 = 0;
      String var15 = "KÌ-go\u001eeÔ\u0000\u0012\u0084\u0096\u0090R;¼\u0080rí\u0016k(§\u0012\u0010ó\u0097Q£\u0081¤¬)_¦\u0018q\u0007¾½ö\u00102\u009có\u0092\u0006xæö\u000e\u0097ew\u0018\r\u0002L(E¸ÐtDY\u009a)\u0018Úø\n^ìa5C?qaÈz\u0006ã\u0016¢wÂ³\u008dì\u009dã\\1\b\u0085¤£\u008c\u0010#8\"£§s\u00ad'¢\u0087U&IqjÓ Òq c\u0092C&\u0096²\u0016\u009d|\u0097yÃM³5\u0097Û¼¥)\u0085\u0016A>Ìw,\u0099f\u0010|70[\nÄgp\u0010<\u0093l±üwÂ\u0010QÕLöHPgaã\u00134ù\u009f\u0004Ï\u001b\u0010³xY\u009a\u00990\u008b¤´Ö´\u008dû\u0087[-\u0010\u0080\u009fÑ±úx_ø\u0018\u0094®¶\u0017Â05";
      short var17 = 217;
      char var14 = 24;
      int var20 = -1;

      label45:
      while (true) {
         String var22 = var15.substring(++var20, var20 + var14);
         int var10001 = -1;

         while (true) {
            String var31 = a(var11.doFinal(var22.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var31;
                  if ((var20 += var14) >= var17) {
                     b = var18;
                     c = new String[12];
                     g = new HashMap(13);
                     Cipher var0;
                     Cipher var24 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(107883904092993L << var1 * 8 >>> 56);
                     }

                     var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0012\u0097\u0081ByÁ\u008c`·9\\]1M~\u0093Û{+=\u0088}>«".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var36 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     e = var6;
                     f = new Integer[3];
                     友友友友友树友友树树 = new 何何友友何友友友何友();
                     return;
                  }

                  var14 = var15.charAt(var20);
                  break;
               default:
                  var18[var16++] = var31;
                  if ((var20 += var14) < var17) {
                     var14 = var15.charAt(var20);
                     continue label45;
                  }

                  var15 = "\u0085c+\t.ïms{8\u000f£Å\u00055·ë_¶ÅV£§<Ùì\u0001\u0093|îÜØb\u0016T{Æ\u0096\u0087¸ñ¹\u008f\u008a¸b\u0013²¼&l\u001dÎP\u0007\u001a1bHwWA(\u0099o\u0090Oh¨î#\u0086\u001dçXöX\"êæ \u0010O F\u009f\u009e\n\u0010z¬Ì\u0019ë±dß{\u0089Ò,\u0085nçb";
                  var17 = 105;
                  var14 = 'X';
                  var20 = -1;
            }

            var22 = var15.substring(++var20, var20 + var14);
            var10001 = 0;
         }
      }
   }

   public static void i(boolean var0) {
      何树树友何何友友友友 = var0;
   }

   private void i(Button button) {
      String ign = this.树何何何友友何何树友.getValue();
      String token = this.何树树友何何树何友友.getValue();
      String uuid = u(ign);

      try {
         User newUser = new User(ign, UUID.fromString(this.a(uuid)).toString(), token, Optional.empty(), Optional.empty(), Type.MOJANG);
         this.U(newUser);
         null.println("Login successful:" + newUser.getName());
      } catch (Exception var8) {
         var8.printStackTrace();
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 31433;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/何何友友何友友友何友", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何友友何友友友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void b() {
      h[0] = "\tX<DF\u001e\u0006\u0018qOL\u0003\u0003Ez\t\\\u0018D佣佇召叢伤厡叽叙佲叢";
      h[1] = "\u00031P\u0004's\u00031GX+|\u0019zGF#\u007f\u0003 \nM?sC7KG:u\u00031J^94(0M^\bu\u0015";
      h[2] = boolean.class;
      i[2] = "java/lang/Boolean";
      h[3] = "q<9=#*z3(r_3u)&1h\u0003c>*,y/t3";
      h[4] = void.class;
      i[4] = "java/lang/Void";
      h[5] = int.class;
      i[5] = "java/lang/Integer";
      h[6] = "8D\u0019>\f\u00027\u0004T5\u0006\u001f2Y_s\u000e\u0002?_[8M 4NB1\u0006";
      h[7] = ").PWTJ\u001d\r_\u0017\u0019A\u0017\u0010ZJ\u0012\u0007\u001f\rWL\u0016L\\/\\]\u000fE\u0017Y";
      h[8] = "i3/TKui38\bGzsx8\u0016Oyi\"u\u001dSu)\u00104\u0014R";
      h[9] = "\u0019rsb?\u0017\u0019rd>3\u0018\u00039d ;\u001b\u0019c)\u0019!\u001b\u00053S5\"\u001b";
      h[10] = "\u0002\u001fg\u001bWH\u0002\u001fpG[G\u0018TpYSD\u0002\u000e=xSO\t\u0019aT\\U";
      h[11] = "Vp ;\u0007-Vp7g\u000b\"L;7y\u0003!Vazr\u001f-\u0016v;x\u001a+Vp:a\u0019jz` a\u0005*";
      h[12] = " feA\u0003k\u0014Ej\u0001N`\u001eXo\\E&\u0016EbZAmUgiKXd\u001e\u0011";
      h[13] = "Pv<k\"6[y-$C8Pr)~";
      h[14] = "\b\u0004]^v#SS_3~X\u0001D\u000bAo*W\u0005VQ\u001fbIJZHy9\t\u0005\\3";
      h[15] = "pU\u001d\u00175J+\u0002\u001fz桅史伝厦伫档原栨伝桼vE%[-\u0017\u001c\u00013K{";
      h[16] = "6\"\u001bZjxmu\u00197栚佞佛住厳叴佞佞栟发pExaoh\u0014T:8";
      h[17] = "\u0019\u001brLX8BLp!_\u0014\u0018\u0015$\u001d\r\u0014)\u0010cZ\b.W\u0012 [L";
      h[18] = "<-r}N#h-g{2VE\u0000GT}\u0013<-r}N#h-g{";
      h[19] = "0F1\u0002C\u0012k\u00113o佷桰栙厵伇伲栳伴參厵Z\u001dQ\u000bi\f>\f\u0013R";
      h[20] = "\u0018NVi{wN\u0019Vi\u0001L$\u0014Mm:aKE[v:\u001e";
      h[21] = "5\u000b/iITn\\-\u0004Nx4\u0005y8\u001bx\u0005\u0000>\u007f\u0019B{\u0002}~]";
      h[22] = "E|!o\f0\u001e+#\u0002\u000b\u001cDrw>\\\u001cus*b\u0018'\u00055ug\u001f";
      h[23] = "6kR\u0007[*m<Pj[Q?+\u0004\u0018B#ijY\b2";
      h[24] = "Po.\"|!\u000b8,O{\rQaxs*\r`b50sb_54>*";
      h[25] = "\u000bFe\u0002Z7]\u0011e\u0002 \u00007\u001c~\u0006\u001b!XMh\u001d\u001b^\r]x\b[8V\u001d7\u000e ";
      h[26] = ",[w\u000bSAw\fufJ:%\u001b!\u0014JHsZ|\u0004:";
      h[27] = "R\u0012^E|M\tE\\(|6XZ\u000fG)J\u0013\u001bS\u0010\u0015\f\u001a\u0018Z\u0014iG[D\r(";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public static boolean x() {
      return 何树树友何何友友友友;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何友友何友友友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 7;
               case 1 -> 29;
               case 2 -> 61;
               case 3 -> 63;
               case 4 -> 48;
               case 5 -> 57;
               case 6 -> 30;
               case 7 -> 27;
               case 8 -> 45;
               case 9 -> 19;
               case 10 -> 0;
               case 11 -> 46;
               case 12 -> 42;
               case 13 -> 56;
               case 14 -> 20;
               case 15 -> 9;
               case 16 -> 49;
               case 17 -> 3;
               case 18 -> 8;
               case 19 -> 4;
               case 20 -> 58;
               case 21 -> 52;
               case 22 -> 13;
               case 23 -> 39;
               case 24 -> 47;
               case 25 -> 40;
               case 26 -> 15;
               case 27 -> 53;
               case 28 -> 31;
               case 29 -> 5;
               case 30 -> 17;
               case 31 -> 43;
               case 32 -> 21;
               case 33 -> 60;
               case 34 -> 1;
               case 35 -> 10;
               case 36 -> 62;
               case 37 -> 44;
               case 38 -> 36;
               case 39 -> 32;
               case 40 -> 59;
               case 41 -> 37;
               case 42 -> 54;
               case 43 -> 23;
               case 44 -> 2;
               case 45 -> 14;
               case 46 -> 12;
               case 47 -> 26;
               case 48 -> 18;
               case 49 -> 50;
               case 50 -> 11;
               case 51 -> 51;
               case 52 -> 22;
               case 53 -> 33;
               case 54 -> 16;
               case 55 -> 24;
               case 56 -> 28;
               case 57 -> 55;
               case 58 -> 38;
               case 59 -> 25;
               case 60 -> 41;
               case 61 -> 35;
               case 62 -> 6;
               default -> 34;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 232 && var8 != 203 && var8 != 228 && var8 != 252) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 235) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 230) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 232) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 203) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 228) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public static boolean a() {
      x();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private String a(String uuid) {
      x();
      return uuid.length() != 32
         ? uuid
         : uuid.substring(0, 8) + "-" + uuid.substring(8, 12) + "-" + uuid.substring(12, 16) + "-" + uuid.substring(16, 20) + "-" + uuid.substring(20, 32);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何友友何友友友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19457;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何何友友何友友友何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u001f.#Tjpj'%ô¯Àr«ýÕ, |¯0\u009dq\u0007G\u008f, ´\u000eí¨7)xã, ÞÂ*åÍ+_IÀ\u009e©\u0001\u0011\u0098MÄ\u0089I.)âÆ\u00adz, Ê\u0090>ô\u008f\u008bEÉ, ¡î\u0002î]°Å\u0006ÒVû8ù8ep, Tq\u001aÃÌ5Ã{, ¨E\u0080â\u0088A\u0093¥, n¶S\u0091")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private void U(User user) {
      try {
         Field userField = Minecraft.class.getDeclaredField("user");
         userField.setAccessible(true);
         userField.set(super.minecraft, user);
      } catch (Exception var5) {
         var5.printStackTrace();
      }
   }

   public static String u(String name) {
      try {
         URL url = new URL("https://api.mojang.com/users/profiles/minecraft/" + name);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod("GET");
         connection.setConnectTimeout(5000);
         connection.setReadTimeout(5000);
         int status = connection.getResponseCode();
         if (status != 200) {
            return null;
         } else {
            Reader reader = new InputStreamReader(connection.getInputStream());
            JsonObject json = (JsonObject)new Gson().fromJson(reader, JsonObject.class);
            return json.get("id").getAsString();
         }
      } catch (Exception var8) {
         var8.printStackTrace();
         return null;
      }
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      this.renderBackground(guiGraphics);
      guiGraphics.drawCenteredString(super.font, "Token Login", super.width / 2, super.height / 2 - 60, 16777215);
      x();
      guiGraphics.drawString(super.font, "IGN:", super.width / 2 - 100, super.height / 2 - 47, 10526880);
      guiGraphics.drawString(super.font, "Token:", super.width / 2 - 100, super.height / 2 - 12, 10526880);
      super.render(guiGraphics, mouseX, mouseY, partialTick);
      if (Module.Z() == null) {
         i(false);
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖黑水";
   }

   public void tick() {
      this.树何何何友友何何树友.tick();
      this.何树树友何何树何友友.tick();
      super.tick();
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      x();
      if (keyCode == 256) {
         super.minecraft.setScreen(null);
         return true;
      } else if (keyCode == 258) {
         if (this.树何何何友友何何树友.isFocused()) {
            this.树何何何友友何何树友.setFocused(false);
            this.何树树友何何树何友友.setFocused(true);
         }

         this.何树树友何何树何友友.setFocused(false);
         this.树何何何友友何何树友.setFocused(true);
         return true;
      } else if (this.树何何何友友何何树友.isFocused() && this.树何何何友友何何树友.keyPressed(keyCode, scanCode, modifiers)) {
         return true;
      } else {
         return this.何树树友何何树何友友.isFocused() && this.何树树友何何树何友友.keyPressed(keyCode, scanCode, modifiers) ? true : super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   protected void init() {
      super.init();
      int centerX = super.width / 2;
      int centerY = super.height / 2;
      this.树何何何友友何何树友 = new EditBox(super.font, centerX - 100, centerY - 35, 200, 20, Component.literal("IGN"));
      boolean var10000 = x();
      this.树何何何友友何何树友.setMaxLength(50);
      this.树何何何友友何何树友.setFocused(true);
      this.addRenderableWidget(this.树何何何友友何何树友);
      this.何树树友何何树何友友 = new EditBox(super.font, centerX - 100, centerY, 200, 20, Component.literal("Token"));
      this.何树树友何何树何友友.setMaxLength(999);
      this.addRenderableWidget(this.何树树友何何树何友友);
      this.树友何友何树友树何树 = Button.builder(Component.literal("Login"), this::i).bounds(centerX - 50, centerY + 40, 100, 20).build();
      this.addRenderableWidget(this.树友何友何树友树何树);
      if (var10000) {
         Module.V(new Module[2]);
      }
   }

   public boolean charTyped(char codePoint, int modifiers) {
      x();
      if (this.树何何何友友何何树友.isFocused() && this.树何何何友友何何树友.charTyped(codePoint, modifiers)) {
         return true;
      } else {
         return this.何树树友何何树何友友.isFocused() && this.何树树友何何树何友友.charTyped(codePoint, modifiers) ? true : super.charTyped(codePoint, modifiers);
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      a();
      boolean ignClicked = this.树何何何友友何何树友.mouseClicked(mouseX, mouseY, button);
      boolean tokenClicked = this.何树树友何何树何友友.mouseClicked(mouseX, mouseY, button);
      if (ignClicked) {
         this.树何何何友友何何树友.setFocused(true);
         this.何树树友何何树何友友.setFocused(false);
         return true;
      } else if (tokenClicked) {
         this.何树树友何何树何友友.setFocused(true);
         this.树何何何友友何何树友.setFocused(false);
         return true;
      } else {
         this.树何何何友友何何树友.setFocused(false);
         this.何树树友何何树何友友.setFocused(false);
         return super.mouseClicked(mouseX, mouseY, button);
      }
   }
}
