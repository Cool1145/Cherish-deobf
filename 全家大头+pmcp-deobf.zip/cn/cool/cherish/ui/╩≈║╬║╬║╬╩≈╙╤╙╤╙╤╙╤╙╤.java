package cn.cool.cherish.ui;

import cn.cool.cherish.value.树何何树何友树何何树;
import java.awt.Color;
import net.minecraft.client.gui.GuiGraphics;

public interface 树何何何树友友友友友<T extends 树何何树何友树何何树<?>> {
   boolean V(T var1, char var2, int var3, 树何友何树树何何树树 var4);

   boolean x(T var1, int var2, int var3, int var4, 树何友何树树何何树树 var5);

   float h(T var1, 树何友何树树何何树树 var2);

   void o(T var1, double var2, double var4, int var6, 树何友何树树何何树树 var7);

   boolean g(T var1, double var2, double var4, int var6, float var7, float var8, float var9, float var10, float var11, 树何友何树树何何树树 var12);

   void Y(T var1, 树何友何树树何何树树 var2);

   void K(
      GuiGraphics var1,
      T var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      int var8,
      int var9,
      float var10,
      何何友友树何树何友树 var11,
      何何友友树何树何友树 var12,
      Color var13,
      Color var14,
      Color var15,
      树何友何树树何何树树 var16
   );
}
