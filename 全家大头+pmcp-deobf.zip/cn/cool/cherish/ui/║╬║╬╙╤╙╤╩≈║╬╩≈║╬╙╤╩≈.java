package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.render.树友何友友何友友何友;
import cn.lzq.injection.asm.invoked.render.ModernFontTextEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat.Mode;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;

public final class 何何友友树何树何友树 implements AutoCloseable, 何树友 {
   private static final FontRenderContext 友何何何何何何友友友;
   private final Map<Character, 何何友友树何树何友树.树友树何友树树树树何> 何树友何树何友何友友;
   private static final Map<Integer, Font> 友树树友何树何何树树;
   private static final int[] 何友树何树树树树友树;
   private final FontMetrics 树树何何友树树友树树;
   private final boolean 树树树何友友树友友友;
   private final int 友何树树树友何友何友;
   private final int 友友友何何树树何树何;
   private final Font 树树友树友何友友友友;
   private final Font 友何何友树何树树树何;
   private static int[] 树友何何树何何树何友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[79];
   private static final String[] i = new String[79];
   private static int _何树友被何大伟克制了 _;

   public 何何友友树何树何友树(Font font, boolean antiAliasing) {
      h();
      super();
      this.何树友何树何友何友友 = new ConcurrentHashMap<>();
      this.友何何友树何树树树何 = font;
      this.友何树树树友何友何友 = font.getSize();
      this.友友友何何树树何树何 = s(font.getSize() * 2 + 8);
      this.树树树何友友树友友友 = antiAliasing;
      this.树树友树友何友友友友 = this.m();
      this.树树何何友树树友树树 = new Canvas().getFontMetrics(font);
      if (Module.Z() == null) {
         Q(new int[3]);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(2727230652208859810L, -4836016591493300754L, MethodHandles.lookup().lookupClass()).a(151744624756265L);
      // $VF: monitorexit
      a = var10000;
      a();
      int[] var28 = new int[3];
      Q(var28);
      Cipher a;
      Cipher var29 = a = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int ax = 1; ax < 8; ax++) {
         var10003[ax] = (byte)(22847533676827L << ax * 8 >>> 56);
      }

      var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] ax = new String[2];
      int axx = 0;
      int axxx = 24;
      int axxxx = -1;

      while (true) {
         String var34 = a(
               a.doFinal(
                  "¯UDrL\u008fëP\u0096H«<ùËNJ}6\u0096½9&âÿ({\u0096\u0088\u0014\u0014È±á\u008cãg\u00ad(íù@ÐtSèù÷\u00927¸ÄËJ\u0093Ò)c¡g§¬\u007fO´F"
                     .substring(++axxxx, axxxx + axxx)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         int var10001 = -1;
         ax[axx++] = var34;
         if ((axxxx += axxx) >= 65) {
            b = ax;
            c = new String[2];
            g = new HashMap(13);
            Cipher axxxxx;
            Cipher var30 = axxxxx = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

            for (int axxxxxx = 1; axxxxxx < 8; axxxxxx++) {
               var10003[axxxxxx] = (byte)(22847533676827L << axxxxxx * 8 >>> 56);
            }

            var30.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] axxxxxx = new long[3];
            int axxxxxxx = 0;
            int axxxxxxxx = 0;

            do {
               var10001 = axxxxxxxx;
               axxxxxxxx += 8;
               byte[] axxxxxxxxx = "¬ù\u0093\u0088hÑaËÙt_V\u0012(ÎO\u008ef\n8å\u0087£\u009f".substring(var10001, axxxxxxxx).getBytes("ISO-8859-1");
               var10001 = axxxxxxx++;
               long axxxxxxxxxx = (axxxxxxxxx[0] & 255L) << 56
                  | (axxxxxxxxx[1] & 255L) << 48
                  | (axxxxxxxxx[2] & 255L) << 40
                  | (axxxxxxxxx[3] & 255L) << 32
                  | (axxxxxxxxx[4] & 255L) << 24
                  | (axxxxxxxxx[5] & 255L) << 16
                  | (axxxxxxxxx[6] & 255L) << 8
                  | axxxxxxxxx[7] & 255L;
               byte[] axxxxxxxxxxx = axxxxx.doFinal(
                  new byte[]{
                     (byte)(axxxxxxxxxx >>> 56),
                     (byte)(axxxxxxxxxx >>> 48),
                     (byte)(axxxxxxxxxx >>> 40),
                     (byte)(axxxxxxxxxx >>> 32),
                     (byte)(axxxxxxxxxx >>> 24),
                     (byte)(axxxxxxxxxx >>> 16),
                     (byte)(axxxxxxxxxx >>> 8),
                     (byte)axxxxxxxxxx
                  }
               );
               long var10004 = (axxxxxxxxxxx[0] & 255L) << 56
                  | (axxxxxxxxxxx[1] & 255L) << 48
                  | (axxxxxxxxxxx[2] & 255L) << 40
                  | (axxxxxxxxxxx[3] & 255L) << 32
                  | (axxxxxxxxxxx[4] & 255L) << 24
                  | (axxxxxxxxxxx[5] & 255L) << 16
                  | (axxxxxxxxxxx[6] & 255L) << 8
                  | axxxxxxxxxxx[7] & 255L;
               byte var38 = -1;
               axxxxxx[var10001] = var10004;
            } while (axxxxxxxx < 24);

            e = axxxxxx;
            f = new Integer[3];
            友何何何何何何友友友 = new FontRenderContext(new AffineTransform(), true, true);
            友树树友何树何何树树 = new HashMap<>();
            何友树何树树树树友树 = new int[32];

            for (int i = 0; i < 何友树何树树树树友树.length; i++) {
               int offset = (i >> 3 & 1) * 85;
               int red = (i >> 2 & 1) * 170 + offset;
               int green = (i >> 1 & 1) * 170 + offset;
               int blue = (i & 1) * 170 + offset;
               if (i == 6) {
                  red += 85;
               }

               if (i >= 16) {
                  red /= 4;
                  green /= 4;
                  blue /= 4;
               }

               何友树何树树树树友树[i] = (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
            }

            return;
         }

         axxx = "¯UDrL\u008fëP\u0096H«<ùËNJ}6\u0096½9&âÿ({\u0096\u0088\u0014\u0014È±á\u008cãg\u00ad(íù@ÐtSèù÷\u00927¸ÄËJ\u0093Ò)c¡g§¬\u007fO´F".charAt(axxxx);
      }
   }

   public int B(PoseStack poseStack, String s, double x, double y, int color) {
      return this.e(poseStack, s, x, y, color, false);
   }

   public int D(String s) {
      h();
      ModernFontTextEvent modernFontTextEvent = new ModernFontTextEvent(s);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(modernFontTextEvent);
      }

      if (modernFontTextEvent.isCancelled()) {
         return 0;
      } else {
         s = modernFontTextEvent.getText();
         if (s != null && !s.isEmpty()) {
            float ret = 0.0F;
            int i = 0;
            if (0 < s.length()) {
               char c = s.charAt(0);
               if (c == 167 && 1 < s.length()) {
                  i++;
               }

               ret = 0.0F + this.h(c).何树友何友何树友树友;
               i++;
            }

            return Math.round(ret * 0.5F);
         } else {
            return 0;
         }
      }
   }

   private void D(BufferBuilder builder, Matrix4f matrix, 何何友友树何树何友树.树友树何友树树树树何 glyph, double x, double y, boolean italic) {
      float invSize = 1.0F / this.友友友何何树树何树何;
      float u1 = glyph.何何树树何树树树友树 * invSize;
      float v1 = glyph.树何树友树树何树树友 * invSize;
      float u2 = (glyph.何何树树何树树树友树 + glyph.何树友何友何树友树友) * invSize;
      float v2 = (glyph.树何树友树树何树树友 + glyph.树树友树树树树何何何) * invSize;
      builder.vertex(matrix, (float)(x + 2.0), (float)y, 0.0F).uv(u1, v1).endVertex();
      builder.vertex(matrix, (float)(x - 2.0), (float)(y + glyph.树树友树树树树何何何), 0.0F).uv(u1, v2).endVertex();
      builder.vertex(matrix, (float)(x + glyph.何树友何友何树友树友 - 2.0), (float)(y + glyph.树树友树树树树何何何), 0.0F).uv(u2, v2).endVertex();
      builder.vertex(matrix, (float)(x + glyph.何树友何友何树友树友 + 2.0), (float)y, 0.0F).uv(u2, v1).endVertex();
   }

   private 何何友友树何树何友树.树友树何友树树树树何 J(char c) {
      h();
      this.W();
      String s = String.valueOf(c);
      Font renderFont = this.友何何友树何树树树何.canDisplay(c) ? this.友何何友树何树树树何 : this.树树友树友何友友友友;
      Rectangle bounds = renderFont.getStringBounds(s, 友何何何何何何友友友).getBounds();
      int charWidth = Math.max(1, bounds.width);
      int charHeight = Math.max(1, bounds.height);
      int u = (this.友友友何何树树何树何 - charWidth) / 2;
      int v = (this.友友友何何树树何树何 - charHeight) / 2;
      BufferedImage image = new BufferedImage(this.友友友何何树树何树何, this.友友友何何树树何树何, 2);
      Graphics2D g = image.createGraphics();
      x(g, this.树树树何友友树友友友);
      g.setColor(new Color(0, 0, 0, 0));
      g.fillRect(0, 0, this.友友友何何树树何树何, this.友友友何何树树何树何);
      g.setFont(renderFont);
      g.setColor(Color.WHITE);
      FontMetrics fm = g.getFontMetrics();
      g.drawString(s, u, v + fm.getAscent());
      g.dispose();
      int textureId = 树友何友友何友友何友.h(85155106533732L, image);
      RenderSystem.bindTexture(textureId);
      if (this.友何树树树友何友何友 <= 12) {
         RenderSystem.texParameter(3553, 10241, 9728);
         RenderSystem.texParameter(3553, 10240, 9728);
      }

      RenderSystem.texParameter(3553, 10241, 9729);
      RenderSystem.texParameter(3553, 10240, 9729);
      return new 何何友友树何树何友树.树友树何友树树树树何(textureId, charWidth, charHeight, u, v);
   }

   public void Z(PoseStack poseStack, String s, double x, double y, int color, boolean shadow) {
      h();
      if (shadow) {
         this.e(poseStack, s, x + 0.5, 4.5, this.q(color), true);
      }

      this.e(poseStack, s, x, y, color, false);
   }

   private void Z(PoseStack poseStack, int textureId, List<何何友友树何树何友树.树树何友友树何树友何> glyphs) {
      h();
      Matrix4f matrix = poseStack.last().pose();
      RenderSystem.setShader(GameRenderer::getPositionTexShader);
      RenderSystem.setShaderTexture(0, textureId);
      LinkedHashMap colorGroups = new LinkedHashMap();
      Iterator var9 = glyphs.iterator();
      if (var9.hasNext()) {
         何何友友树何树何友树.树树何友友树何树友何 info = (何何友友树何树何友树.树树何友友树何树友何)var9.next();
         colorGroups.computeIfAbsent(info.友树友何友树何友何友, k -> new ArrayList<>()).add(info);
      }

      var9 = colorGroups.entrySet().iterator();
      if (var9.hasNext()) {
         Entry<Integer, List<何何友友树何树何友树.树树何友友树何树友何>> entry = (Entry<Integer, List<何何友友树何树何友树.树树何友友树何树友何>>)var9.next();
         u(entry.getKey());
         BufferBuilder builder = Tesselator.getInstance().getBuilder();
         builder.begin(Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
         Iterator var12 = entry.getValue().iterator();
         if (var12.hasNext()) {
            何何友友树何树何友树.树树何友友树何树友何 info = (何何友友树何树何友树.树树何友友树何树友何)var12.next();
            if (info.树树何何友何树何树友) {
               this.D(builder, matrix, info.树友友何何友友友树友, info.树友友树友树树何友何 + 1.0, info.友树树友何何树友友友, info.友友树友何树何友友何);
            }

            this.D(builder, matrix, info.树友友何何友友友树友, info.树友友树友树树何友何, info.友树树友何何树友友友, info.友友树友何树何友友何);
         }

         BufferUploader.drawWithShader(builder.end());
      }
   }

   public int e(PoseStack poseStack, String s, double x, double y, int color, boolean shadow) {
      h();
      ModernFontTextEvent modernFontTextEvent = new ModernFontTextEvent(s);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(modernFontTextEvent);
      }

      if (modernFontTextEvent.isCancelled()) {
         return 8;
      } else {
         s = modernFontTextEvent.getText();
         if (s != null && !s.isEmpty()) {
            poseStack.pushPose();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            poseStack.scale(0.5F, 0.5F, 1.0F);

            try {
               Map<Integer, List<何何友友树何树何友树.树树何友友树何树友何>> glyphGroups = new LinkedHashMap<>();
               List<何何友友树何树何友树.友友树树友何树何树树> lines = new ArrayList<>();
               x = Math.round(x * 2.0);
               y = Math.round(12.0);
               boolean bold = false;
               boolean italic = false;
               boolean strikethrough = false;
               boolean underline = false;
               int currentColor = -1;
               int i = 0;
               if (0 < s.length()) {
                  char c = s.charAt(0);
                  if (c == 167 && 1 < s.length()) {
                     char formatCode = s.charAt(++i);
                     int colorIndex = "0123456789abcdefklmnor".indexOf(formatCode);
                     switch (colorIndex) {
                        case 16:
                        case 17:
                        case 18:
                        case 19:
                        case 20:
                        case 21:
                           bold = false;
                           italic = false;
                           underline = false;
                           strikethrough = false;
                           currentColor = color;
                        default:
                           if (colorIndex >= 0) {
                              int finalColor = 何友树何树树树树友树[colorIndex];
                              currentColor = color & 0xFF000000 | finalColor & 16777215;
                           }
                     }
                  }

                  何何友友树何树何友树.树友树何友树树树树何 glyph = this.h(c);
                  glyphGroups.computeIfAbsent(glyph.树树何树何树何树友何, k -> new ArrayList<>()).add(new 何何友友树何树何友树.树树何友友树何树友何(glyph, x, y, bold, italic, currentColor));
                  if (strikethrough) {
                     double mid = y + glyph.树树友树树树树何何何 * 0.5;
                     lines.add(new 何何友友树何树何友树.友友树树友何树何树树(x, mid - 0.5, x + glyph.何树友何友何树友树友, mid + 0.5, currentColor));
                  }

                  if (underline) {
                     lines.add(new 何何友友树何树何友树.友友树树友何树何树树(x, y + glyph.树树友树树树树何何何 - 1.0, x + glyph.何树友何友何树友树友, y + glyph.树树友树树树树何何何, currentColor));
                  }

                  double var10000 = x + glyph.何树友何友何树友树友;
                  i++;
               }

               Iterator var34 = glyphGroups.entrySet().iterator();
               if (var34.hasNext()) {
                  Entry<Integer, List<何何友友树何树何友树.树树何友友树何树友何>> entry = (Entry<Integer, List<何何友友树何树何友树.树树何友友树何树友何>>)var34.next();
                  this.Z(poseStack, entry.getKey(), entry.getValue());
               }

               this.U(poseStack, lines);
            } finally {
               poseStack.popPose();
               RenderSystem.disableBlend();
               RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            }

            return this.D(s);
         } else {
            return 0;
         }
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何友友树何树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20964;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/何何友友树何树何友树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static void x(Graphics2D g, boolean antiAliasing) {
      h();
      g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
      g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
      g.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, RenderingHints.VALUE_FRACTIONALMETRICS_ON);
      g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
      g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
      g.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
      g.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
   }

   public int x() {
      return this.树树何何友树树友树树.getAscent() / 2;
   }

   public void s(PoseStack poseStack, String s, double x, double y, int color) {
      this.e(poseStack, s, x + 0.5, y + 0.5, this.q(color), true);
      this.e(poseStack, s, x, y, color, false);
   }

   private static int s(int value) {
      h();
      byte power = 1;
      if (1 < value) {
         power = 2;
      }

      return power;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何友友树何树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public String n(String text, int width, boolean reverse) {
      h();
      StringBuilder stringbuilder = new StringBuilder();
      int j = reverse ? -1 : 1;
      if (0 < text.length() && 0.0F < width) {
         char c0 = text.charAt(0);
         if (c0 == 167) {
         }

         何何友友树何树何友树.树友树何友树树树树何 glyph = this.h(c0);
         float f1 = glyph.何树友何友何树友树友 * 0.5F;
         if (f1 < 0.0F) {
         }

         if (0.0F + f1 > width) {
         }

         if (reverse) {
            stringbuilder.insert(0, c0);
         }

         stringbuilder.append(c0);
         int var10000 = 0 + j;
      }

      return stringbuilder.toString();
   }

   public void h(PoseStack poseStack, String s, double x, double y, int color) {
      this.B(poseStack, s, x - this.D(s) / 2.0, 25.0, color);
   }

   public static int[] h() {
      return 树友何何树何何树何友;
   }

   private 何何友友树何树何友树.树友树何友树树树树何 h(char c) {
      return this.何树友何树何友何友友.computeIfAbsent(c, this::J);
   }

   public float f(float boxHeight) {
      return boxHeight / 2.0F - this.x() / 2.0F;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何友友树何树何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 3730;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何何友友树何树何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      h[0] = "/\b\u0004\u000e\u0019< HI\u0005\u0013!%\u0015BC\u0003:b伳使厦厽桂伙桷使厦桧";
      h[1] = "cIk\u001b\f#hFzTp:g\\t\u0017G\nqKx\nV&fF";
      h[2] = "ld";
      h[3] = "l\u000b<0t\u000fcKq;~\u0012f\u0016z}n\t!估佇厘叐桱佚桴佇厘栊D栞厮栃伆叐桱栞桴栃伆";
      h[4] = int.class;
      i[4] = "java/lang/Integer";
      h[5] = "P]'FC6_\u001djMI+Z@a\u000bY0\u001d佦作叮叧案佦栢作叮栽}栢栢作叮叧案佦栢参佰";
      h[6] = "^\u00106-\u0007\u001aW\u001e5dD\u0017Q\u001e!fY\u0011\u0013\t>q\u001e\u0010EQ\rf\u0018\u0001X\u0007\u001dl\u0018\u0018\\\u000b\u007fN\u0005\u0011X";
      h[7] = boolean.class;
      i[7] = "java/lang/Boolean";
      h[8] = double.class;
      i[8] = "java/lang/Double";
      h[9] = "\u0001Es{T\u0014\bKp2\u0017\u0019\u000eKd0\n\u001fL\\{'M\u001e\u001a\u0004Z0_\u001a\u0017Fj\u0003\\\t\u0016Of\u0013V\t\u000fKj";
      h[10] = "\u007f.>eIVv =,\n[p ).\u0017]2769P\\do\u0005.VMy9\u0015$VT}5";
      h[11] = "K`hI>zUhr\u0006]nQ";
      h[12] = ",i@\u001a\u0015@1|\u0018\u001dTO2&p\u0014UU\u0014mX\u001f^S\u0005gX\u000f^Y2";
      h[13] = "\u0014s\u000b5P@\tfS\u0006\u001bB\ns\u00133\u0012D";
      h[14] = ".3i;9>3&1\u001cx10";
      h[15] = "\u0018\u0010\u001fC1\u0012\u0005\u0005Gap\u001f\u001d\u0003";
      h[16] = "\u001e\u0004";
      h[17] = "F^";
      h[18] = void.class;
      i[18] = "java/lang/Void";
      h[19] = "\u0013$\u0018V \u0002\u000e1@qa\r\r\b\u000bC|\n\u001a6";
      h[20] = "$\bO8Un+H\u00023_s.\u0015\tuWn#\u0013\r>\u0014L(\u0002\u00147_";
      h[21] = "(9J\n>\u001c\u001c\u001aEJs\u0017\u0016\u0007@\u0017xQ\u001e\u001aM\u0011|\u001a]8F\u0000e\u0013\u0016N";
      h[22] = "\u0002\u001c)?d\u0019\r\\d4n\u0004\b\u0001or~\u001fO伧佒厗叀桧伴档佒厗栚R厪厹栖桍叀伣桰伧栖桍";
      h[23] = "\u0000P\t/ >\u001dEQ\u001ck1\u000eT\r'`8\"X\u0011:}";
      h[24] = "\u001a\u0019+\u007f\u0004\n\u0011\u0016:0e\u0004\u001a\u001d>j";
      h[25] = "}o\bOe@`zP|.Osk\fG%F_g\u0010Z8\u0005\\k\u0007";
      h[26] = "\u000e\u0002\u0000KXA\u001f]B\u001d9厲伽厤伤叢佤厲桹厤厺!\u0007L^\u0006\u0003J\u0003\t\u001bW";
      h[27] = "C99\u0004k+]\u007f+\u0016Z\u0005e@\u000e*\r\u0010k@\u0014=\r\u0001aB\u001f*\u0000\fuY\u001a#\u001b\u0007}\u00043\\  ]t-_1g";
      h[28] = "#^uG\u001c\u0015pZ\"-伦桫厏佻桗佰厸伯厏句N\u0012\u0000N V(SD\u0016<";
      h[29] = "e\u001b7s2b{]%a\u0003QGw\nLNBVq\u0014V_SCb\u001cYXSLi]pqv4^7*ete";
      h[30] = "I\u001aX(!fXE\u001a~@桏栾厼核伟桙伋古厼佼B~k\u0019\u001e[)z.\\O";
      h[31] = "nxa(:T|*>:Pg\u0003/e6,^s.3c<5";
      h[32] = "titWx\u001b'm#=叜县变佌伒栤栆伡栂佌O\u0006rC'st[y\u0002r";
      h[33] = "s.v &> *!J!Ywkt:y2b.v:A";
      h[34] = "\u000e\u00130-\fO[I<|~厰栬厲佑取桧伮叶伬叏\u0015E\u001e\nMn.\u0018\u0015K\u0018";
      h[35] = "?X&-(b.\u0007d{I厑厒你厜厄伔桋案你厜Gr?n\u0001=|/4/T";
      h[36] = "Y\bg\u001b/\u001a]\u0010>\u001fD&8;\u0015)DC\u001fL0\u0019!G\u0007\u00154";
      h[37] = "\bYZRFM\u0006YXNwVT\u0005\u000fR\u000b6\u0002\t_\u000e\u0015\r_\u0002\u001e[";
      h[38] = "d\tB}^AuV\u0000+?伬佗厯司佊栦桨佗伱栢\u0017\u0001L4\rA|\u0005\tq\\";
      h[39] = "\u0015S\u0016_\u0005Y\u000b\u0015\u0004M4j7?+fyo6#&}rfz\u000e\u000eX\nQ\u0010T\u001aZ[";
      h[40] = "^!\u0003\u001f3I\r%Tu=.\bb^\u00050^P%\u0004\bT\u0017\n?H\u0011$OMeEu";
      h[41] = "\u0007WS\u0018M\u0005TS\u0004r叩桻桱召伵桫佷伿桱栶hMQ^\u0004_\u000e\f\u0015\u0006\u0018";
      h[42] = "kZ\rKBX8^Z!|?o\u001f\u000fQ\u001dTzZ\rQ%TxS\tDBP8HF!";
      h[43] = "&A\u0006\u000e\\|uEQd司但伔叺栤伹栢栂桐佤=\r\u0002*t@\u0005\u001e\u0004b7";
      h[44] = "\r\u001a&s\u0002p\u000e\u00167w=栈栮佶桔佀栤佌栮叨伐\u001d\u0006|\b\u0017/&[wIB";
      h[45] = "l\u0014y\fg}}K;Z\u0006桔佟桨栙伻栟伐栛厲栙f8p<\u0010z\r<5yA";
      h[46] = "\u007fA\u0003\"\u0001ba\u0007\u001100LY84\fgSV $\u001bhUT55\u0000wTG6(\nmXQ7i!\u000bhk\r\u0019?\by,";
      h[47] = "4IU\u00196!a\u0013YHD栄双叨伴佼厇叞双栲厪!~,dEV@} uA";
      h[48] = "[\u001c\u007f\tZqEZm\u001bk_}eH'<Hr}T#/@}zB--\u0001T\u001ao\u0011\u001aqJ\u0019~V";
      h[49] = "6n\u0000\u0017!}ejW}厅佇伄佋佦传伛叙厚叕;M>!hsQ\f%~9";
      h[50] = "W\\4\nn6I\u001a&\u0018_\u0018q%\u0003$\b\u001dd;\u0019*\u0012\u0011`<\u0004$_&\u0003\u001b%\u0018/8\u0000\nb";
      h[51] = "\u0016Ea\b@9C\u001fmY2叆叮栾厞佭栫佘叮古伀0\u000f:P\u00191_BkAY";
      h[52] = "\u0016\r'<\u000bW\bK5.:y0t\u0010\u0012m{4`\u0011\bsa%q\u0004\u001b{n\"g\n\u0019:GBJ6.JYA[q";
      h[53] = "3\u0011|M\u0001X-Wn_0k\u0011}Agtp\u001ceAovt\u0011vNita\u0000mQh0H.H(VZ\u0012:Jy";
      h[54] = "y}\b\u0007 6w}\n\u001b\u00112),N\u0007\u0011v%\u007f\u000e\u0005*+.>[";
      h[55] = "6` \bWDc:,Y%桡収叁栅右格桡佐叁佁0\u001bE3cf[\u001f\u0000v2";
      h[56] = "Co 7\u0014W\u00165,ff厨桡栔叟佒伻桲去収叟\u000fXVFlfd\\\u0013\u0003=";
      h[57] = "jc%\t]\u001ft%7\u001bl,H\u000f\u0018#*3D\u0017\u000b+%4D\u0018\u0000j\f\u001da`7\u0000V\tc1";
      h[58] = "2o]mH\u001cak\n\u0007佲厸桄佊桿栞栶桢厞栎fl\u0012B-/\ryW@-";
      h[59] = "@Ac><z^\u0007q,\rTf8T\u0010ZDu5B\u0001LMi5M\u0018@Vu=B\u0006ZMi|ifwq^\fwef6";
      h[60] = "\u000b_cO\u0013vQK<\u0010ldb\u0014<AU5b$>K\u000e:YHqM\u0007d";
      h[61] = "Iy\u000fG/\u0014\u001a}X-桑桪栿作号叮桑厰句参4\u0010w\u000e\u0018m[]&\u001fX";
      h[62] = "E>2]^Z[x OotcG\u0005s8cn[\u0018w8kl_\u0015d7mnJ\u0004\u007f(l}Z\u0005w+kvRX^TPQr(@WA\u0016";
      h[63] = "\r\u001a%\"5K\u0013\\70\u0004x/v\u0018\u000f^r){\u000e\u0006Br&b\u0002\u001d^z)|O!v_\\_%{b]\r";
      h[64] = ".PL34G-\\]7\u000b佻栍厢佺厞佖栿受桸古]0K+]Efm@j\b";
      h[65] = "c4d/Zl`8u+e佐伄栜栖伜桼栔桀叆栖A^`f9mz\u0003k'l";
      h[66] = "m\\9;FQs\u001a+)wbO0\u0004\u0003+{E\"\u001e\u000f<fD=\t\u001f3!b\u00137f\u000fK8\u000757";
      h[67] = "\u001f\b('C6\u0001N:5r\u00189q\u001f\t%\u001c=s\u000e\t(\u0011)h\u000b\u00003\u001a!5\"\u007f\b=\u0001E<|\u0019z";
      h[68] = "\u001a4f\u0000!VI01j厅佬桬桕桄厩伛史伨厏]Q+\u000eI.f\f O\u001c";
      h[69] = "E\u0019U>m+\u0010CYo\u001f栎桧伦伴叅佂栎伣桢厪\u0006\"(\u0003E\u0005ioy\u0012\u0005";
      h[70] = "\u000e%kxA\u001aT14'>\bgn4v\u0007Zg^6|\\V\\2yzU\b";
      h[71] = "fYx%s x\u001fj7B\u000e@ O\u000b\u0015\fD4N\u0011\u000b\u0016U%[\u0002\u0003\u0019R3V\r\u000e\u0007I>]\fB02\u001ei72.1\u000f.";
      h[72] = "G_BB-6DSSF\u0012桎桤厭栰栵栋桎传伳佴,):BRK\u0017t1\u0003\u0007";
      h[73] = ":?lFx\u0005$y~TI6\u0018SQd\u000f)\u0018X^b\r<\tCAcI\u0015'f8]#O3di";
      h[74] = "d:UdmB7>\u0002\u000e栓格又桛厭体叉另又厁ng3\u00146;Vt5\\u";
      h[75] = "(#NAm@+/_ER核住栋另栶桋佼栋栋另/iL-.G\u00144Gl{";
      h[76] = "\u000en$\u0019\u0017.\u0010(6\u000b&\u001d,\u0002\u00191a\u001a&\t\u0019 k\u0018-\u001e\u0014;`\u0011a3<\u001e\u0018&\u000bi(\u001cI";
      h[77] = "/w)xdD~j!|\u001e\"\u0006G\u001cL\u001e\u00147o9{'E*g=";
      h[78] = "@d,f\u0010\u0005\u0013`{\f桮桻佲佁叔栕桮厡栶栅\u0017`\u001a\u000f\u0011blt\u001bZO";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 45;
               case 1 -> 5;
               case 2 -> 28;
               case 3 -> 50;
               case 4 -> 23;
               case 5 -> 10;
               case 6 -> 32;
               case 7 -> 49;
               case 8 -> 36;
               case 9 -> 20;
               case 10 -> 14;
               case 11 -> 48;
               case 12 -> 39;
               case 13 -> 0;
               case 14 -> 40;
               case 15 -> 8;
               case 16 -> 57;
               case 17 -> 17;
               case 18 -> 51;
               case 19 -> 12;
               case 20 -> 1;
               case 21 -> 29;
               case 22 -> 25;
               case 23 -> 35;
               case 24 -> 15;
               case 25 -> 47;
               case 26 -> 52;
               case 27 -> 18;
               case 28 -> 11;
               case 29 -> 42;
               case 30 -> 33;
               case 31 -> 27;
               case 32 -> 22;
               case 33 -> 53;
               case 34 -> 55;
               case 35 -> 6;
               case 36 -> 63;
               case 37 -> 9;
               case 38 -> 56;
               case 39 -> 24;
               case 40 -> 26;
               case 41 -> 4;
               case 42 -> 21;
               case 43 -> 16;
               case 44 -> 43;
               case 45 -> 41;
               case 46 -> 19;
               case 47 -> 58;
               case 48 -> 13;
               case 49 -> 2;
               case 50 -> 61;
               case 51 -> 54;
               case 52 -> 7;
               case 53 -> 62;
               case 54 -> 46;
               case 55 -> 31;
               case 56 -> 34;
               case 57 -> 30;
               case 58 -> 38;
               case 59 -> 37;
               case 60 -> 3;
               case 61 -> 60;
               case 62 -> 59;
               default -> 44;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'I' && var8 != 'A' && var8 != 253 && var8 != 225) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 's') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'M') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'I') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'A') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 253) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private Font m() {
      return 友树树友何树何何树树.computeIfAbsent(this.友何树树树友何友何友, k -> new Font("SansSerif", 0, this.友何树树树友何友何友));
   }

   public int t(PoseStack poseStack, String s, int x, int y, int color, boolean shadow) {
      return this.e(poseStack, s, x, y, color, false);
   }

   public String v(String text, int width) {
      return this.n(text, 112, false);
   }

   private int q(int color) {
      int alpha = color >> 24 & 0xFF;
      return alpha << 24 | b<"o">(7612, 8054470493328886872L);
   }

   public int q(PoseStack poseStack, String s, float x, float y, int color) {
      return this.e(poseStack, s, x, y, -1, false);
   }

   private void U(PoseStack poseStack, List<何何友友树何树何友树.友友树树友何树何树树> lines) {
      h();
      if (!lines.isEmpty()) {
         RenderSystem.setShaderTexture(0, 0);
         RenderSystem.setShader(GameRenderer::getPositionShader);
         Map<Integer, List<何何友友树何树何友树.友友树树友何树何树树>> colorGroups = new LinkedHashMap<>();
         Iterator matrix = lines.iterator();
         if (matrix.hasNext()) {
            何何友友树何树何友树.友友树树友何树何树树 line = (何何友友树何树何友树.友友树树友何树何树树)matrix.next();
            colorGroups.computeIfAbsent(line.友友何友友何树树何友, k -> new ArrayList<>()).add(line);
         }

         Matrix4f matrixx = poseStack.last().pose();
         Iterator var14 = colorGroups.entrySet().iterator();
         if (var14.hasNext()) {
            Entry<Integer, List<何何友友树何树何友树.友友树树友何树何树树>> entry = (Entry<Integer, List<何何友友树何树何友树.友友树树友何树何树树>>)var14.next();
            u(entry.getKey());
            BufferBuilder builder = Tesselator.getInstance().getBuilder();
            builder.begin(Mode.QUADS, DefaultVertexFormat.POSITION);
            Iterator var11 = entry.getValue().iterator();
            if (var11.hasNext()) {
               何何友友树何树何友树.友友树树友何树何树树 line = (何何友友树何树何友树.友友树树友何树何树树)var11.next();
               builder.vertex(matrixx, (float)line.树何树树何树何树友树, (float)line.友何友何友何友树友友, 0.0F).endVertex();
               builder.vertex(matrixx, (float)line.树树友树何树何友友何, (float)line.友何友何友何友树友友, 0.0F).endVertex();
               builder.vertex(matrixx, (float)line.树树友树何树何友友何, (float)line.何何友友何树树何何树, 0.0F).endVertex();
               builder.vertex(matrixx, (float)line.树何树树何树何树友树, (float)line.何何友友何树树何何树, 0.0F).endVertex();
            }

            BufferUploader.drawWithShader(builder.end());
         }
      }
   }

   @Override
   public void close() {
      this.何树友何树何友何友友.values().forEach(glyph -> RenderSystem.deleteTexture(glyph.树树何树何树何树友何));
      this.何树友何树何友何友友.clear();
   }

   private static void u(int color) {
      float alpha = (color >> 24 & 0xFF) / 255.0F;
      float red = (color >> 16 & 0xFF) / 255.0F;
      float green = (color >> 8 & 0xFF) / 255.0F;
      float blue = (color & 0xFF) / 255.0F;
      RenderSystem.setShaderColor(red, green, blue, alpha);
   }

   private void W() {
      h();
      if (this.何树友何树何友何友友.size() > 1024) {
         this.何树友何树何友何友友.entrySet().removeIf(entry -> {
            h();
            return Math.random() < 0.1;
         });
      }
   }

   private static String HE_DA_WEI() {
      return "何大伟：我要教育何炜霖";
   }

   public void Q(PoseStack poseStack, String s, double x, double y, int color, boolean shadow, double shadowOffSet) {
      h();
      if (shadow) {
         this.e(poseStack, "k", x + shadowOffSet, y + shadowOffSet, this.q(color), true);
      }

      this.e(poseStack, s, x, y, color, false);
   }

   public static void Q(int[] var0) {
      树友何何树何何树何友 = var0;
   }

   public int Q(PoseStack poseStack, String s, int x, int y, int color) {
      return this.t(poseStack, "P", x, y, -1, false);
   }

   private record 友友树树友何树何树树(double 树何树树何树何树友树, double 何何友友何树树何何树, double 树树友树何树何友友何, double 友何友何友何友树友友, int 友友何友友何树树何友) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[9];
      private static final String[] c = new String[9];
      private static int _何炜霖230622200409390090 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(9140574252100182282L, -5702097376457981128L, MethodHandles.lookup().lookupClass()).a(126787536548760L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public double e() {
         return this.树树友树何树何友友何;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      public double s() {
         return this.树何树树何树何树友树;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何何友友树何树何友树$友友树树友何树何树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 202 && var8 != 'W' && var8 != 206 && var8 != 194) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 199) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 243) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 202) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'W') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 206) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 62;
                  case 1 -> 63;
                  case 2 -> 43;
                  case 3 -> 49;
                  case 4 -> 24;
                  case 5 -> 44;
                  case 6 -> 57;
                  case 7 -> 6;
                  case 8 -> 58;
                  case 9 -> 0;
                  case 10 -> 36;
                  case 11 -> 42;
                  case 12 -> 9;
                  case 13 -> 12;
                  case 14 -> 33;
                  case 15 -> 7;
                  case 16 -> 53;
                  case 17 -> 39;
                  case 18 -> 40;
                  case 19 -> 5;
                  case 20 -> 1;
                  case 21 -> 28;
                  case 22 -> 23;
                  case 23 -> 20;
                  case 24 -> 15;
                  case 25 -> 21;
                  case 26 -> 35;
                  case 27 -> 3;
                  case 28 -> 17;
                  case 29 -> 46;
                  case 30 -> 27;
                  case 31 -> 16;
                  case 32 -> 55;
                  case 33 -> 37;
                  case 34 -> 2;
                  case 35 -> 59;
                  case 36 -> 30;
                  case 37 -> 50;
                  case 38 -> 38;
                  case 39 -> 11;
                  case 40 -> 19;
                  case 41 -> 51;
                  case 42 -> 48;
                  case 43 -> 13;
                  case 44 -> 32;
                  case 45 -> 8;
                  case 46 -> 18;
                  case 47 -> 31;
                  case 48 -> 34;
                  case 49 -> 10;
                  case 50 -> 47;
                  case 51 -> 56;
                  case 52 -> 52;
                  case 53 -> 61;
                  case 54 -> 41;
                  case 55 -> 60;
                  case 56 -> 22;
                  case 57 -> 29;
                  case 58 -> 45;
                  case 59 -> 25;
                  case 60 -> 14;
                  case 61 -> 4;
                  case 62 -> 54;
                  default -> 26;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "HbtsyzG\"9xsgB\u007f2>c|\u0005余伏叛叝栄佾栝伏叛标1叠叇桋栁叝佀栺余桋栁";
         b[1] = double.class;
         c[1] = "java/lang/Double";
         b[2] = int.class;
         c[2] = "java/lang/Integer";
         b[3] = "\u0017)PI\u0005|\u001c&A\u0006dr\u0017-E\\";
         b[4] = "1J\r2\u0001\b?WGL叾佤厑佧厵休叾栠厑叹vu\u0004Z#B\u00182SWi";
         b[5] = "\u0018\u0013\u001f\u001ey5\u0016\u000eU`桜栝厸桺伹桹优叇厸伾dY|g\n\u001b\n\u001e+j@";
         b[6] = "\u001a 'r\u0007c\u0014=m\f司厑伤厓原佑栢桋伤厓\\6\u0002#\u0012?%o\u0005>F";
         b[7] = "\u0015H)\u0001wO\u001bUc\u007f桒伣桯校伏桦伖桧厵校RFr\u001d\u0007@<\u0001%\u0010M";
         b[8] = "\"Dr\u0000|5,Y8~伝余厂号佔桧桙余伜栭\tGyg0Lg\u0000.jz";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public int U() {
         return this.友友何友友何树树何友;
      }

      public double T() {
         return this.何何友友何树树何何树;
      }

      public double Q() {
         return this.友何友何友何友树友友;
      }

      private static String LIU_YA_FENG() {
         return "解放村多种2队1144号";
      }
   }

   public record 树友树何友树树树树何(int 树树何树何树何树友何, int 何树友何友何树友树友, int 树树友树树树树何何何, int 何何树树何树树树友树, int 树何树友树树何树树友) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static int _刘凤楠230622109211173513 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(2451470157079402860L, 6380076325404886951L, MethodHandles.lookup().lookupClass()).a(244069922637036L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public int J() {
         return this.树树友树树树树何何何;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      public int x() {
         return this.树树何树何树何树友何;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何何友友树何树何友树$树友树何友树树树树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'a' && var8 != 'Q' && var8 != 'c' && var8 != 181) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 219) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'N') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'a') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'Q') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'c') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 58;
                  case 1 -> 52;
                  case 2 -> 54;
                  case 3 -> 30;
                  case 4 -> 24;
                  case 5 -> 37;
                  case 6 -> 51;
                  case 7 -> 53;
                  case 8 -> 32;
                  case 9 -> 14;
                  case 10 -> 38;
                  case 11 -> 22;
                  case 12 -> 49;
                  case 13 -> 31;
                  case 14 -> 0;
                  case 15 -> 44;
                  case 16 -> 39;
                  case 17 -> 3;
                  case 18 -> 9;
                  case 19 -> 16;
                  case 20 -> 43;
                  case 21 -> 59;
                  case 22 -> 35;
                  case 23 -> 8;
                  case 24 -> 42;
                  case 25 -> 56;
                  case 26 -> 7;
                  case 27 -> 5;
                  case 28 -> 20;
                  case 29 -> 63;
                  case 30 -> 11;
                  case 31 -> 36;
                  case 32 -> 15;
                  case 33 -> 28;
                  case 34 -> 40;
                  case 35 -> 62;
                  case 36 -> 29;
                  case 37 -> 6;
                  case 38 -> 34;
                  case 39 -> 45;
                  case 40 -> 26;
                  case 41 -> 48;
                  case 42 -> 25;
                  case 43 -> 21;
                  case 44 -> 27;
                  case 45 -> 1;
                  case 46 -> 10;
                  case 47 -> 46;
                  case 48 -> 19;
                  case 49 -> 2;
                  case 50 -> 17;
                  case 51 -> 57;
                  case 52 -> 55;
                  case 53 -> 23;
                  case 54 -> 60;
                  case 55 -> 4;
                  case 56 -> 13;
                  case 57 -> 61;
                  case 58 -> 41;
                  case 59 -> 50;
                  case 60 -> 12;
                  case 61 -> 33;
                  case 62 -> 18;
                  default -> 47;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "$z\u000e]T\r+:CV^\u0010.gH\u0010N\u000bi佁併叵台桳伒栅併叵株F桖叟栱佫台桳桖栅栱佫";
         b[1] = int.class;
         c[1] = "java/lang/Integer";
         b[2] = "\fK\u001e\u0012}5\u0007D\u000f]\u001c;\fO\u000b\u0007";
         b[3] = "nC\f\u007f'j5\u000b\u001c\u0000桘桍厖桠桼栙桘伉伈伤e9xo.\u0013\u0015{1*n";
         b[4] = "%,\t\u0010\u0002-~d\u0019o桽栊佃栏伽桶伹栊叝佋`V](e|\u0010\u0014\u0014m%";
         b[5] = "0\u001d@4\u001fekUPK桠伆栒古栰桒伤桂栒古)r@`pMY0\t%0";
         b[6] = "D\r*&7v\u001fE:Y伌桑厼佪厀伄案压桦叴C`hs\u0004]3\"!6D";
         b[7] = "&QxSlr}\u0019h,佗休栄桲佌栵栓桕叞桲\u0011\u00153wf\u0001aWz2&";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public int j() {
         return this.树何树友树树何树树友;
      }

      public int y() {
         return this.何何树树何树树树友树;
      }

      public int K() {
         return this.何树友何友何树友树友;
      }

      private static String LIU_YA_FENG() {
         return "我是何树友";
      }
   }

   private record 树树何友友树何树友何(何何友友树何树何友树.树友树何友树树树树何 树友友何何友友友树友, double 树友友树友树树何友何, double 友树树友何何树友友友, boolean 树树何何友何树何树友, boolean 友友树友何树何友友何, int 友树友何友树何友何友)
      implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[12];
      private static final String[] c = new String[12];
      private static int _何炜霖230622200409390090 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(2041563698759324445L, 5641132695218834402L, MethodHandles.lookup().lookupClass()).a(110193204620068L);
         // $VF: monitorexit
         a = var10000;
         b();
      }

      public double J() {
         return this.友树树友何何树友友友;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static void b() {
         b[0] = "@+?$HpOkr/BmJ6yiRv\r伐佄厌召栎佶桔佄厌栶;栲桔佄厌召栎佶桔叚伒";
         b[1] = boolean.class;
         c[1] = "java/lang/Boolean";
         b[2] = double.class;
         c[2] = "java/lang/Double";
         b[3] = "TCEs?e[\u0003\bx5x^^\u0003>%c\u0019佸伾叛厛栛佢格伾叛桁.栦另桺佅厛栛栦格桺佅";
         b[4] = int.class;
         c[4] = "java/lang/Integer";
         b[5] = "8\u007fl\u0004\f\u00153p}Km\u001b8{y\u0011";
         b[6] = "SR>1\u0018\u0005\u0000M!\f栾厢厪佡伆叏古厢桰叿[6F[\u0000^>vX_\u0015";
         b[7] = "8s?%\u0018ekl \u0018古栘叁佀厙栁佺参佟叞Z\"U=:!(\"_a?";
         b[8] = "\u000f\f\u0014Ak4\\\u0013\u000b|厗厓栬厡伬桥伉厓叶伿qE>lT\u0006\u0001@7+\u000f";
         b[9] = "0J`|C6cU\u007fA县桋栓叧佘伜桥厑叉叧\u0005x\u001195\\4&\u0015ct";
         b[10] = "\u0010g}e\u0005bCxbX栣叅叩栐叛桁栣佛叩佔\u0018aWm\u0015q)?S7T";
         b[11] = "IDy\f\u000fm\u001a[f1栩栐伮佷叟佬栩佔桪叩\u001c\bZ5\u0012Nl\rSrI";
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public boolean l() {
         return this.友友树友何树何友友何;
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 229 && var8 != 242 && var8 != 245 && var8 != 233) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'Q') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'a') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 229) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 242) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 245) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 15;
                  case 1 -> 36;
                  case 2 -> 4;
                  case 3 -> 28;
                  case 4 -> 0;
                  case 5 -> 50;
                  case 6 -> 37;
                  case 7 -> 46;
                  case 8 -> 44;
                  case 9 -> 56;
                  case 10 -> 10;
                  case 11 -> 16;
                  case 12 -> 31;
                  case 13 -> 5;
                  case 14 -> 47;
                  case 15 -> 32;
                  case 16 -> 7;
                  case 17 -> 33;
                  case 18 -> 42;
                  case 19 -> 45;
                  case 20 -> 63;
                  case 21 -> 51;
                  case 22 -> 38;
                  case 23 -> 17;
                  case 24 -> 8;
                  case 25 -> 22;
                  case 26 -> 59;
                  case 27 -> 58;
                  case 28 -> 19;
                  case 29 -> 14;
                  case 30 -> 1;
                  case 31 -> 60;
                  case 32 -> 57;
                  case 33 -> 13;
                  case 34 -> 49;
                  case 35 -> 62;
                  case 36 -> 53;
                  case 37 -> 20;
                  case 38 -> 39;
                  case 39 -> 6;
                  case 40 -> 26;
                  case 41 -> 30;
                  case 42 -> 11;
                  case 43 -> 23;
                  case 44 -> 35;
                  case 45 -> 3;
                  case 46 -> 34;
                  case 47 -> 52;
                  case 48 -> 9;
                  case 49 -> 25;
                  case 50 -> 27;
                  case 51 -> 48;
                  case 52 -> 2;
                  case 53 -> 12;
                  case 54 -> 24;
                  case 55 -> 61;
                  case 56 -> 41;
                  case 57 -> 43;
                  case 58 -> 18;
                  case 59 -> 54;
                  case 60 -> 21;
                  case 61 -> 40;
                  case 62 -> 29;
                  default -> 55;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      public boolean a() {
         return this.树树何何友何树何树友;
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/何何友友树何树何友树$树树何友友树何树友何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      public int H() {
         return this.友树友何友树何友何友;
      }

      public double T() {
         return this.树友友树友树树何友何;
      }

      private static String HE_SHU_YOU() {
         return "何大伟为什么要诈骗何炜霖";
      }

      public 何何友友树何树何友树.树友树何友树树树树何 Q() {
         return this.树友友何何友友友树友;
      }
   }
}
