package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.何树何友何何树树树树;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树何何树何何何何友何 implements IWrapper, 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[19];
   private static final String[] g = new String[19];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8442697276849496973L, -4489101622108542096L, MethodHandles.lookup().lookupClass()).a(34875666738320L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 115879550064506L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[7];
      int var7 = 0;
      String var6 = "\u008b\u00ad0\t\bG\u0083\u0097vÑ\u0016*\u009a<%¯\u0001\u0015\u0083\u0002ºÉ3\u0080\u0010Ô&\u0000iW\u0005\u0099Ý¤e·F_þ8\u0081\u0018\u0010åÉ²\u001dU¿\u0004¹ô\u009cHuH#\u0081¥=Ö½\u000eÚ¹¾ \u0019Ä=×\u008e\u0090¶¼á#SY\u00ad\u0001ð\u0000½2>\u009e\u0002ÀòßÖ\u0084xÿÌúÀË 3G«©R\u009d³\u0096²Ã¨Kx´oL¹iX\u0013A\u0084oYóOhÄäµ¶Ü";
      short var8 = 132;
      char var5 = 24;
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = b(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     b = var9;
                     c = new String[7];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ðÆ\u009fa\u009fd\u0001\u001a\u009cCFÉ\u0015µÙi\u008aà\n?*\u001cÄ\u0005\u0084)×¿G\u007fÍ\u009b ãÄh¿`\u0010\u00108\u0096ùt\u0097\u0091ßr\u007fø u\u001a1 no|ìµG<j-\u0007";
                  var8 = 65;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static String C(int state) {
      long a = 树何何树何何何何友何.a ^ 82643190854832L;

      return switch (state) {
         case 0, 1 -> a<"k">(25978, 3587239867306249954L ^ a);
         case 2 -> a<"k">(20931, 7891990498788325978L ^ a);
         case 3 -> a<"k">(23668, 7133784266978637802L ^ a);
         case 4 -> a<"k">(13575, 5708635153279770267L ^ a);
         case 5 -> a<"k">(11380, 405953285001005035L ^ a);
         default -> a<"k">(11533, 2549348788997179031L ^ a);
      };
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 61;
               case 1 -> 47;
               case 2 -> 7;
               case 3 -> 24;
               case 4 -> 26;
               case 5 -> 36;
               case 6 -> 5;
               case 7 -> 9;
               case 8 -> 1;
               case 9 -> 60;
               case 10 -> 38;
               case 11 -> 55;
               case 12 -> 0;
               case 13 -> 63;
               case 14 -> 20;
               case 15 -> 25;
               case 16 -> 33;
               case 17 -> 15;
               case 18 -> 2;
               case 19 -> 10;
               case 20 -> 52;
               case 21 -> 6;
               case 22 -> 59;
               case 23 -> 62;
               case 24 -> 27;
               case 25 -> 46;
               case 26 -> 28;
               case 27 -> 32;
               case 28 -> 50;
               case 29 -> 54;
               case 30 -> 43;
               case 31 -> 23;
               case 32 -> 31;
               case 33 -> 51;
               case 34 -> 16;
               case 35 -> 37;
               case 36 -> 40;
               case 37 -> 30;
               case 38 -> 58;
               case 39 -> 13;
               case 40 -> 34;
               case 41 -> 12;
               case 42 -> 56;
               case 43 -> 41;
               case 44 -> 11;
               case 45 -> 45;
               case 46 -> 29;
               case 47 -> 42;
               case 48 -> 3;
               case 49 -> 35;
               case 50 -> 44;
               case 51 -> 48;
               case 52 -> 17;
               case 53 -> 39;
               case 54 -> 22;
               case 55 -> 19;
               case 56 -> 18;
               case 57 -> 14;
               case 58 -> 57;
               case 59 -> 4;
               case 60 -> 21;
               case 61 -> 53;
               case 62 -> 8;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 225 && var8 != 'O' && var8 != 'w' && var8 != 199) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 213) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'N') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 225) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'O') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'w') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static void b(
      PoseStack poseStack,
      float x,
      float y,
      float width,
      float height,
      List<何树何友何何树树树树.友友何何友何树友友友> messages,
      float animationOutput,
      int fontSize,
      boolean textShadow,
      float messageSpacing,
      int backgroundAlpha,
      float cornerRadius,
      何树何友何何树树树树 instance
   ) {
      long a = 树何何树何何何何友何.a ^ 124270063709269L;
      long ax = a ^ 28503685031836L;
      友何何树友何何何何树 font = Cherish.instance.h().n(fontSize);
      b<"N">(5030922195353884663L, (long)a);
      float alphaMultiplier = Math.max(0.0F, Math.min(1.0F, animationOutput));
      Color glassColor = new Color(0, 0, 0, (int)(backgroundAlpha * alphaMultiplier));
      Color borderColor = new Color(255, 255, 255, (int)(100.0F * alphaMultiplier));
      ShaderUtils.e((PoseStack)ax, y, (long)width, height, cornerRadius, 1.0F, (float)borderColor, (float)glassColor, 10.0F);
      Iterator var25 = messages.iterator();
      if (var25.hasNext()) {
         何树何友何何树树树树.友友何何友何树友友友 message = (何树何友何何树树树树.友友何何友何树友友友)var25.next();
         String displayText = n(message);
         Color textColor = N(b<"á">(message, 5031023588825785883L, (long)a));
         float messageAlpha = Math.max(0.0F, 1.0F - (float)(System.currentTimeMillis() - b<"á">(message, 5032270661205219767L, (long)a)) / 10000.0F);
         messageAlpha *= animationOutput;
         if (messageAlpha > 0.1F) {
            Color finalTextColor = new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), (int)(textColor.getAlpha() * messageAlpha));
            font.y(poseStack, displayText, x + 8.0F, y + 4.0F, finalTextColor.getRGB(), textShadow);
         }

         float var10002 = y + (font.K() + messageSpacing);
         b<"N">(!b<"N">(5032351081489933279L, (long)a), 5032325110505980516L, (long)a);
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何树何何何何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String n(何树何友何何树树树树.友友何何友何树友友友 message) {
      long a = 树何何树何何何何友何.a ^ 33707522947056L;
      String prefix = C(b<"á">(message, -2417123611849720386L, a));
      return prefix + a<"k">(5662, 4872810851205037765L ^ a) + b<"á">(message, -2417063860559757315L, a);
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何树何何何何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      f[0] = "\u0001Y\u0004\u0010@.\u000e\u0019I\u001bJ3\u000bDB]Z(L栦使伦栾伔伷佢使厸佺";
      f[1] = "r\u000eT\u0002\u001b\u0010y\u0001EMg\tv\u001bK\u000eP9`\fG\u0013A\u0015w\u0001";
      f[2] = "zW4|Wvu\u0017yw]kpJr1Mp7史栋叔右叒叒史栋佊右";
      f[3] = "s\n";
      f[4] = "iU\")L_f\u0015o\"FBcHddN_nN`/\rYgK`dGYyK`+Z\u001e佟株余厁佶佥栛株栝桛\u0007叻叁佮余厁佶校叁台叇";
      f[5] = int.class;
      g[5] = "java/lang/Integer";
      f[6] = long.class;
      g[6] = "java/lang/Long";
      f[7] = "5\u0001\u0005X+L:AHS!Q?\u001cC\u0015)L2\u001aG^jn9\u000b^W!";
      f[8] = boolean.class;
      g[8] = "java/lang/Boolean";
      f[9] = void.class;
      g[9] = "java/lang/Void";
      f[10] = "fe\rwL[mj\u001c81C~m\u0015q";
      f[11] = "U\u0019}^4R^\u0016l\u0011U\\U\u001dhK";
      f[12] = "JC7sC!ELN*y(TT-9\u0016>KSN:\u000b4EK!,\u00143&";
      f[13] = "M  \u0017ee\f>4\u001d\u0000Xtdm\u00101o\u0014/4\u000b\u007f\u0001";
      f[14] = "\b*k !nZ*~,\u001e桌佮伙佒厏佃厖株桝佒L!9N5wrp3\u0003:";
      f[15] = "P,|\f *\u0002,i\u0000\u001f佌桲伟叛桹叜栈伶桛佅`$s\u0012sd\u000b }Qz";
      f[16] = "yK~2\u000fV+Kk>0估厁格佇伃佭桴伟格佇^\f\u0014+Ez`]\u00130X";
      f[17] = "O\u0006\u0018e\u000ed\u000bEI:gWr\u0001Gp\u001c\u007f\u001fGQ3V\u001eL[So\u0007s\fS\u0019sg";
      f[18] = "N\u0005hOx(\nF9\u0010\u0011?s\u00027Zj3\u001eD!\u0019 R";
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 30381;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树何何树何何何何友何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Color N(int state) {
      long var10000 = 树何何树何何何何友何.a ^ 118673314025189L;
      return switch (state) {
         case 0, 1 -> new Color(170, 170, 170, 255);
         case 2 -> new Color(170, 0, 0, 255);
         case 3 -> new Color(85, 255, 85, 255);
         case 4, 5 -> new Color(255, 85, 85, 255);
         default -> new Color(255, 255, 255, 255);
      };
   }

   private static String HE_SHU_YOU() {
      return "职业技术教育中心学校";
   }
}
