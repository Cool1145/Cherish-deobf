package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 树友何何友树树树树何 implements 何树树友树树友友何何, 何树友 {
   private final Map<String, Float> 何何友友友何友何友何;
   private final Map<String, Boolean> 树友友友树友友何树何;
   private final Map<String, Long> 树树树何友友友树树友;
   private boolean 友何友友友友树何何何;
   private float 友树树友树树友树树树;
   private long 树何友何何树友友何何;
   private static int 何树何何何树树树何何;
   private static final long a;
   private static final long[] b;
   private static final Long[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[41];
   private static final String[] f = new String[41];
   private static String LIU_YA_FENG;

   public 树友何何友树树树树何() {
      long a = 树友何何友树树树树何.a ^ 116321923725805L;
      super();
      this.何何友友友何友何友何 = new HashMap<>();
      this.树友友友树友友何树何 = new HashMap<>();
      this.树树树何友友友树树友 = new HashMap<>();
      b<"Ð">(this, false, 707024422909168912L, a);
      b<"Ð">(this, 0.0F, 706302835406905951L, a);
      b<"Ð">(this, 0L, 702978124376032891L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2593172006644245037L, -1915180190972974219L, MethodHandles.lookup().lookupClass()).a(212956696662642L);
      // $VF: monitorexit
      a = var10000;
      long var11 = a ^ 71404269775481L;
      a();
      b<"Z">(0, -2712396528252175550L, var11);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var11 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      int var3 = 0;
      byte var2 = 0;

      do {
         int var10001 = var2;
         var2 += 8;
         byte[] var7 = "!ÃÔÅ\u009e\u0091yo\u0001{\u0085\u0099ß2Ä\u001d".substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         byte var15 = -1;
         var6[var10001] = var10004;
      } while (var2 < 16);

      b = var6;
      c = new Long[2];
   }

   public static int i() {
      G();

      try {
         return 16;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何何友树树树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public static void s(int var0) {
      何树何何何树树树何何 = var0;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Color c(树友何树何树何友友友 panel, float hoverProgress) {
      long a = 树友何何友树树树树何.a ^ 126091254114186L;
      Color defaultColor = b<"a">(b<"a">(panel, 6317012452299444278L, a), 6317411909125935447L, a);
      Color hoverColor = b<"a">(b<"a">(panel, 6317012452299444278L, a), 6316690261857175672L, a);
      int red = (int)(defaultColor.getRed() + (hoverColor.getRed() - defaultColor.getRed()) * hoverProgress);
      int green = (int)(defaultColor.getGreen() + (hoverColor.getGreen() - defaultColor.getGreen()) * hoverProgress);
      int blue = (int)(defaultColor.getBlue() + (hoverColor.getBlue() - defaultColor.getBlue()) * hoverProgress);
      return new Color(red, green, blue);
   }

   private void h() {
      long a = 树友何何友树树树树何.a ^ 113790063165327L;
      b<"Z">(5741626587318209700L, a);
      long currentTime = System.currentTimeMillis();
      if (b<"a">(this, 5738558270213685273L, a) == 0L
         && (b<"a">(this, 5741478479526660978L, a) ? b<"a">(this, 5741882925545022525L, a) < 1.0F : b<"a">(this, 5741882925545022525L, a) > 0.0F)) {
         b<"Ð">(this, currentTime - a<"e">(2665, 5509644174286515015L ^ a), 5738558270213685273L, a);
      }

      if (b<"a">(this, 5738558270213685273L, a) != 0L) {
         long deltaTime = currentTime - b<"a">(this, 5738558270213685273L, a);
         float targetFactor = b<"a">(this, 5741478479526660978L, a) ? 1.0F : 0.0F;
         if (Math.abs(b<"a">(this, 5741882925545022525L, a) - targetFactor) > 0.001F) {
            if (deltaTime > 0L) {
               float diff = targetFactor - b<"a">(this, 5741882925545022525L, a);
               float interpolationFactorRaw = (float)deltaTime / 150.0F * 2.0F;
               if (interpolationFactorRaw >= 1.0F) {
                  b<"Ð">(this, targetFactor, 5741882925545022525L, a);
               }

               b<"Ð">(this, b<"a">(this, 5741882925545022525L, a) + diff * interpolationFactorRaw, 5741882925545022525L, a);
               b<"Ð">(this, Mth.clamp(b<"a">(this, 5741882925545022525L, a), 0.0F, 1.0F), 5741882925545022525L, a);
            }

            b<"Ð">(this, currentTime, 5738558270213685273L, a);
         }

         b<"Ð">(this, targetFactor, 5741882925545022525L, a);
         b<"Ð">(this, 0L, 5738558270213685273L, a);
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      e[0] = "{\u0004\t]Z8tDDVP%q\u0019O\u0010@>6桻召佫你厜栉桻栶栯你";
      e[1] = boolean.class;
      f[1] = "java/lang/Boolean";
      e[2] = float.class;
      f[2] = "java/lang/Float";
      e[3] = "}@qT\u007fsr\u0000<_unw]7\u0019eu0栿厔佢栁佉栏佻厔叼叛";
      e[4] = "dKR$48k\u000b\u001f/>%nV\u0014i.>)栴厷厌厐框栖栴桭桖伎";
      e[5] = "T\u0014@\u0014U8[T\r\u001f_%^\t\u0006YO>\u0019桫厥伢佯厜栦桫桿桦佯s佢伯厥厼叱伂佢厱厥伢";
      e[6] = long.class;
      f[6] = "java/lang/Long";
      e[7] = " \u000bP\u0013QT+\u0004A\\-M$\u001eO\u001f\u001a}2\tC\u0002\u000bQ%\u0004";
      e[8] = int.class;
      f[8] = "java/lang/Integer";
      e[9] = "\u0017\tR\u001eR?\u001c\u0006CQ/'\u000f\u0001J\u0018";
      e[10] = "\u001bW\u001eO5c\u0006BFmtn\u001eD";
      e[11] = "A\n%#%hNJh(/uK\u0017cn'hF\u0011g%dJM\u0000~,/";
      e[12] = "^[\nC25@S\u0010\fQ!D";
      e[13] = void.class;
      f[13] = "java/lang/Void";
      e[14] = "\u0013gqIn.\u001c'<Bd3\u0019z7\u0004t(^参伊使栐厊伥作伊使栐";
      e[15] = "Z\n5j<AQ\u0005$%]OZ\u000e \u007f";
      e[16] = "Rgz{\\\u0015\fblo%厩厪佚叝佉格伷厪叄标\u0014\u001c\u0004\u0016uxeHT\u0015y";
      e[17] = "3A\tcnkf@\u0002\u0000取桍桃厸桶栙取桍桃桢o9{+(\u001d\u001em+($";
      e[18] = "'G\u0002~hid\u001eSw\u000e叄叞桮栧叓反栞佀桮栧\u00104x{\t\u000fqr>|F";
      e[19] = "a\u000fJ\t,2'IMF\u001d厐厘厳可伪栄桊桂桩栵w\"1>\u0000A\u0017#0`K";
      e[20] = "MHI[Nw\u0018IB8zH\u001aL@IH.J\t@Y5";
      e[21] = "Qt\u000b\u0010\u0016Y\u0004u\u0000s\ff\u0006p\u0002\u0002\u0010\u0000V5\u0002\u0012m";
      e[22] = "A\u0011\u0012F\u0011\u0018\u001f\u0014\u0004Rh桾厹厲伫栰厫伺档桨伫)VW\u001d\u0018\u0014U\u0015\u0018@\n";
      e[23] = "Hr)\t^:\u000e4.Fo桂厱栔厌桮厬桂伯佐伒wP9\u0017}\"\u0017Q8I6";
      e[24] = "F\u0014\r\u0010_\n\u000bNT\u001b#tv[UB]L\u0016\u0016\n\u0015#";
      e[25] = "\u0013aS&\u001d#F`XE伻佁厹厘叶优厥佁厹伆5u\u000b&E&\u000ex\\$\u0011";
      e[26] = "\\uc\u0016E$\tthuE\u001b\u000bqj\u0004C}[4j\u0014>*\u0004?oHLiS&fu";
      e[27] = "\u000e<-D\u0002v[=&'厺伔厤叅厈古桠伔伺佛KW\u001dr\u0019}+\u001aB%";
      e[28] = "2'qjMo\u007f}(a1\u001b\u0002h)8O)b%vo1c3h'>C dq.\u0003";
      e[29] = "6%\u0005*=rpc\u0002e\f栊叏桃伾桍叏栊叏桃桺T3qi*\u000e42p7a";
      e[30] = "\u0017\u0006aL\u0004pQ@f\u00035佌叮厺佚叱栬佌栴桠佚2\u0004`L\u001fe\bQxN\u0005";
      e[31] = "\u0014e\u000b<,5J`\u001d(U众佲栜桶桊伈厉召栜桶Sl$Pw\t\"8tS{";
      e[32] = "{*o`\u001ax=lh/+叚伜桌栐标栲佄伜厖佔\u001e\u001ah 3k$Op\")";
      e[33] = ":+9*\u0006?o*2I桤佝厐佌伂桐厾參伎佌_u\u001a;l}$xMo0";
      e[34] = "DDZ\u0001az\u001aAL\u0015\u0018叆伢佹佣伳栁栜厼佹叽n!k\u0000VX\u001fu;\u0003Z";
      e[35] = "w\u001b\\!#q)\u001eJ5Z反休厸校厍桃栗休桢佥Nc`3\t^?700\u0005";
      e[36] = "\u0004\u001f\u001ftZ Z\u001a\t`#框佢厼伦栂叠框叼厼伦\u001b\u001a1@\r\u001djNaC\u0001";
      e[37] = ">}Xp\u0003\u001a`xNdz伸叆叞栥栆伧伸栜栄佡\u001fC\u000bzoZn\u0017[yc";
      e[38] = "\u0013X#4){FY(W桋厇厹厡桜厔厑伙档伿Eg?~E\u001f~jh|\u0011";
      e[39] = "-\u0005z`{\nx\u0004q\u0003i5yR{m|Oy\u0007c~\u0000\b)Xr\u007fz\b|@a\u0003";
      e[40] = "q\u0002\u0004X'\u0015$\u0003\u000f;桅栳栁佥厡司原栳栁叻b\u000b1\u0010'EY\u0006f\u0012s";
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'a' && var8 != 208 && var8 != 'e' && var8 != 162) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 164) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'a') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 208) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'e') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 11909;
      if (c[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = b[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])d.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/树友何何友树树树树何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         c[var3] = var15;
      }

      return c[var3];
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何何友树树树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 30;
               case 1 -> 44;
               case 2 -> 22;
               case 3 -> 10;
               case 4 -> 2;
               case 5 -> 19;
               case 6 -> 35;
               case 7 -> 56;
               case 8 -> 54;
               case 9 -> 43;
               case 10 -> 61;
               case 11 -> 25;
               case 12 -> 29;
               case 13 -> 31;
               case 14 -> 46;
               case 15 -> 57;
               case 16 -> 17;
               case 17 -> 36;
               case 18 -> 33;
               case 19 -> 37;
               case 20 -> 14;
               case 21 -> 58;
               case 22 -> 52;
               case 23 -> 3;
               case 24 -> 59;
               case 25 -> 42;
               case 26 -> 15;
               case 27 -> 18;
               case 28 -> 63;
               case 29 -> 8;
               case 30 -> 51;
               case 31 -> 11;
               case 32 -> 62;
               case 33 -> 6;
               case 34 -> 53;
               case 35 -> 9;
               case 36 -> 7;
               case 37 -> 12;
               case 38 -> 47;
               case 39 -> 48;
               case 40 -> 1;
               case 41 -> 0;
               case 42 -> 13;
               case 43 -> 55;
               case 44 -> 27;
               case 45 -> 40;
               case 46 -> 45;
               case 47 -> 41;
               case 48 -> 60;
               case 49 -> 24;
               case 50 -> 21;
               case 51 -> 20;
               case 52 -> 32;
               case 53 -> 50;
               case 54 -> 39;
               case 55 -> 28;
               case 56 -> 26;
               case 57 -> 23;
               case 58 -> 5;
               case 59 -> 49;
               case 60 -> 38;
               case 61 -> 4;
               case 62 -> 16;
               default -> 34;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   @Override
   public 友树何树友友何树友友 o(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      long a = 树友何何友树树树树何.a ^ 73414137963993L;
      b<"Z">(1583019232298859426L, a);
      树友何何友树树树树何.何何友友友何何友友何 layout = 树友何何友树树树树何.友树树树友何树友何树.r(panel, value, vx, vy, vw);
      ModeValue mv = (ModeValue)value;
      Objects.requireNonNull(b<"a">(panel, 1583500376365290085L, a));
      float mainModeBoxActualRenderY = b<"a">(layout, 1582375078557964651L, a) + 8.0F - 6.4F;
      if (b<"a">(panel, 1583500376365290085L, a)
         .w(mx, my, b<"a">(layout, 1583803045544846127L, a), mainModeBoxActualRenderY, b<"a">(layout, 1582005104993480461L, a), 12.8F)) {
         if (btn == 0) {
            List<String> modes = Arrays.asList(mv.s());
            int currentIndex = modes.indexOf(mv.getValue());
            int nextIndex = (currentIndex + 1) % modes.size();
            mv.g(modes.get(nextIndex));
            if (b<"a">(this, 1584125746612982052L, a)) {
               b<"Ð">(this, false, 1584125746612982052L, a);
               if (b<"a">(this, 1582260932860566095L, a) == 0L) {
                  b<"Ð">(this, System.currentTimeMillis() - a<"e">(17592, 6555411881988652993L ^ a), 1582260932860566095L, a);
               }
            }

            return null;
         }

         if (btn == 1) {
            b<"Ð">(this, !b<"a">(this, 1584125746612982052L, a), 1584125746612982052L, a);
            if (b<"a">(this, 1582260932860566095L, a) == 0L) {
               b<"Ð">(this, System.currentTimeMillis() - a<"e">(2665, 5509614935521603857L ^ a), 1582260932860566095L, a);
            }

            return null;
         }
      }

      if (b<"a">(this, 1584125746612982052L, a) && b<"a">(this, 1583404090416414315L, a) > 0.8F) {
         float optionVisualY = mainModeBoxActualRenderY + 12.8F + 2.0F;
         String[] currentIndex = mv.s();
         int nextIndex = currentIndex.length;
         int var21 = 0;
         if (0 < nextIndex) {
            String mode = currentIndex[0];
            if (optionVisualY < mainModeBoxActualRenderY + 12.8F + this.N(panel, mv) * b<"a">(this, 1583404090416414315L, a)
               && optionVisualY + 12.8F > mainModeBoxActualRenderY + 12.8F
               && b<"a">(panel, 1583500376365290085L, a)
                  .w(mx, my, b<"a">(layout, 1583803045544846127L, a), optionVisualY, b<"a">(layout, 1582005104993480461L, a), 12.8F)
               && btn == 0) {
               mv.g(mode);
               b<"Ð">(this, false, 1584125746612982052L, a);
               if (b<"a">(this, 1582260932860566095L, a) == 0L) {
                  b<"Ð">(this, System.currentTimeMillis() - a<"e">(2665, 5509614935521603857L ^ a), 1582260932860566095L, a);
               }

               return null;
            }

            float var10000 = optionVisualY + 14.8F;
            var21++;
         }
      }

      return null;
   }

   @Override
   public float t(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value) {
      long a = 树友何何友树树树树何.a ^ 77325669790177L;
      Objects.requireNonNull(b<"a">(panel, 126590781388113501L, a));
      Objects.requireNonNull(b<"a">(panel, 126590781388113501L, a));
      树友何何友树树树树何.何何友友友何何友友何 layout = 树友何何友树树树树何.友树树树友何树友何树.r(panel, value, 0.0F, 0.0F, 106.0F);
      b<"Z">(126108537742028698L, a);
      float baseHeight = 16.0F + b<"a">(layout, 126405587081883080L, a);
      float naturalDropdownHeight = 0.0F;
      if (value instanceof ModeValue mv && mv.s().length > 0) {
         float var10001 = mv.s().length;
         Objects.requireNonNull(b<"a">(panel, 126590781388113501L, a));
         naturalDropdownHeight = 2.0F + var10001 * 14.8F;
      }

      return baseHeight + naturalDropdownHeight * b<"a">(this, 126493552776751699L, a);
   }

   @Override
   public void v(GuiGraphics g, 树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      long a = 树友何何友树树树树何.a ^ 5144078631835L;
      b<"Z">(-5496017561747476304L, a);
      this.h();
      树友何何友树树树树何.何何友友友何何友友何 layout = 树友何何友树树树树何.友树树树友何树友何树.r(panel, value, valx, valy, valw);
      ModeValue mv = (ModeValue)value;
      b<"a">(b<"a">(panel, -5495518152230636505L, a), -5496407478728774362L, a)
         .m(
            g.pose(),
            b<"a">(layout, -5495804894473799397L, a),
            b<"a">(layout, -5496770224006461033L, a),
            b<"a">(layout, -5497094165362299691L, a),
            b<"a">(panel, -5495518152230636505L, a).Z(b<"a">(b<"a">(panel, -5495518152230636505L, a), -5495591580067141808L, a), alpha).getRGB()
         );
      Objects.requireNonNull(b<"a">(panel, -5495518152230636505L, a));
      float boxY = b<"a">(layout, -5496643720083701975L, a) + 8.0F - 6.4F;
      RenderUtils.drawRectangle(
         g.pose(),
         b<"a">(layout, -5496491534242658963L, a),
         boxY,
         b<"a">(layout, -5497154436002608817L, a),
         12.8F,
         b<"a">(panel, -5495518152230636505L, a).Z(b<"a">(b<"a">(panel, -5495518152230636505L, a), -5495936731316882106L, a), alpha).getRGB()
      );
      b<"a">(b<"a">(panel, -5495518152230636505L, a), -5496787151161613020L, a)
         .m(
            g.pose(),
            mv.getValue(),
            b<"a">(layout, -5496491534242658963L, a) + 2.0F,
            boxY + 6.4F - b<"a">(b<"a">(panel, -5495518152230636505L, a), -5496787151161613020L, a).K() / 2.0F,
            b<"a">(panel, -5495518152230636505L, a).Z(b<"a">(b<"a">(panel, -5495518152230636505L, a), -5495591580067141808L, a), alpha).getRGB()
         );
      String arrowString = (!(b<"a">(this, -5495755175156246487L, a) > 0.5F) || !b<"a">(this, -5496160034497923226L, a))
            && (!(b<"a">(this, -5495755175156246487L, a) > 0.01F) || !b<"a">(this, -5496160034497923226L, a) || b<"a">(this, -5496898948100097011L, a) == 0L)
         ? "v"
         : "^";
      b<"a">(b<"a">(panel, -5495518152230636505L, a), -5496787151161613020L, a)
         .m(
            g.pose(),
            arrowString,
            b<"a">(layout, -5496491534242658963L, a)
               + b<"a">(layout, -5497154436002608817L, a)
               - 2.0F
               - b<"a">(b<"a">(panel, -5495518152230636505L, a), -5496787151161613020L, a).A(arrowString),
            boxY + 6.4F - b<"a">(b<"a">(panel, -5495518152230636505L, a), -5496787151161613020L, a).K() / 2.0F,
            b<"a">(panel, -5495518152230636505L, a).Z(b<"a">(b<"a">(panel, -5495518152230636505L, a), -5495591580067141808L, a), alpha).getRGB()
         );
      float dropdownContentStartY = boxY + 12.8F + 2.0F;
      this.G(
         panel,
         mv,
         mousex,
         mousey,
         b<"a">(layout, -5496491534242658963L, a),
         b<"a">(layout, -5497154436002608817L, a),
         12.8F,
         dropdownContentStartY,
         boxY,
         12.8F
      );
      if (b<"a">(this, -5495755175156246487L, a) > 0.001F) {
         float naturalDropdownTotalHeight = this.N(panel, mv);
         float animatedDropdownRenderHeight = naturalDropdownTotalHeight * b<"a">(this, -5495755175156246487L, a);
         g.pose().pushPose();
         g.enableScissor(
            (int)b<"a">(layout, -5496491534242658963L, a),
            (int)(boxY + 12.8F),
            (int)(b<"a">(layout, -5496491534242658963L, a) + b<"a">(layout, -5497154436002608817L, a)),
            (int)(boxY + 12.8F + animatedDropdownRenderHeight + 1.0F)
         );
         int optionContainerAlpha = (int)(alpha * Mth.clamp(b<"a">(this, -5495755175156246487L, a) * 1.5F, 0.0F, 1.0F));
         String[] var23 = mv.s();
         int var24 = var23.length;
         int var25 = 0;
         if (0 < var24) {
            String mode = var23[0];
            if (dropdownContentStartY < boxY + 12.8F + animatedDropdownRenderHeight && dropdownContentStartY + 12.8F > boxY + 12.8F) {
               float hoverProgress = b<"a">(this, -5496327176665205863L, a).getOrDefault(mode, 0.0F);
               Color blendedColor = c(panel, hoverProgress);
               RenderUtils.drawRectangle(
                  g.pose(),
                  b<"a">(layout, -5496491534242658963L, a),
                  dropdownContentStartY,
                  b<"a">(layout, -5497154436002608817L, a),
                  12.8F,
                  b<"a">(panel, -5495518152230636505L, a).Z(blendedColor, optionContainerAlpha).getRGB()
               );
               b<"a">(b<"a">(panel, -5495518152230636505L, a), -5496787151161613020L, a)
                  .m(
                     g.pose(),
                     mode,
                     b<"a">(layout, -5496491534242658963L, a) + 2.0F,
                     dropdownContentStartY + 6.4F - b<"a">(b<"a">(panel, -5495518152230636505L, a), -5496787151161613020L, a).K() / 2.0F,
                     b<"a">(panel, -5495518152230636505L, a)
                        .Z(b<"a">(b<"a">(panel, -5495518152230636505L, a), -5495591580067141808L, a), optionContainerAlpha)
                        .getRGB()
                  );
            }

            float optionY = dropdownContentStartY + 14.8F;
            if (!(optionY > boxY + 12.8F + animatedDropdownRenderHeight + 12.8F)) {
               var25++;
               b<"Z">(!b<"Z">(-5496279617367220398L, a), -5496548785621237318L, a);
            }
         }

         g.disableScissor();
         g.pose().popPose();
      }
   }

   private float N(树友何树何树何友友友 panel, ModeValue mv) {
      long a = 树友何何友树树树树何.a ^ 125852428803348L;
      b<"Z">(7869283878103510591L, a);
      float naturalDropdownHeight = 0.0F;
      if (mv.s().length > 0) {
         float var10001 = mv.s().length;
         Objects.requireNonNull(b<"a">(panel, 7869065634326129320L, a));
         naturalDropdownHeight = 2.0F + var10001 * 14.8F;
      }

      return naturalDropdownHeight;
   }

   public static int G() {
      return 何树何何何树树树何何;
   }

   private void G(
      树友何树何树何友友友 panel,
      ModeValue mv,
      int mousex,
      int mousey,
      float controlx,
      float controlw,
      float boxh,
      float dropdownContentStartY,
      float mainBoxVy,
      float mainBoxH
   ) {
      long a = 树友何何友树树树树何.a ^ 66434709057623L;
      long currentTime = System.currentTimeMillis();
      String[] var17 = mv.s();
      b<"Z">(-9190020328327320020L, a);
      int var18 = var17.length;
      int var19 = 0;
      if (0 < var18) {
         String mode = var17[0];
         boolean isMouseOverThisOption = false;
         if (b<"a">(this, -9189842392997614619L, a) > 0.1F) {
            isMouseOverThisOption = b<"a">(panel, -9189657046690707477L, a).w(mousex, mousey, controlx, dropdownContentStartY, controlw, 12.8F)
               && dropdownContentStartY + boxh > mainBoxVy + 12.8F
               && dropdownContentStartY < mainBoxVy + mainBoxH + this.N(panel, mv) * b<"a">(this, -9189842392997614619L, a);
         }

         b<"a">(this, -9188807044922806239L, a).put(mode, isMouseOverThisOption);
         float currentProgress = b<"a">(this, -9190396257170210731L, a).getOrDefault(mode, 0.0F);
         b<"a">(this, -9188807044922806239L, a).getOrDefault(mode, false);
         long lastUpdate = b<"a">(this, -9189209702095113274L, a).getOrDefault(mode, 0L);
         if (lastUpdate == 0L && Math.abs(currentProgress - 1.0F) > 0.001F) {
            lastUpdate = currentTime - a<"e">(2665, 5509709111359775903L ^ a);
         }

         if (lastUpdate != 0L) {
            long deltaTime = currentTime - lastUpdate;
            if (Math.abs(currentProgress - 1.0F) > 0.001F) {
               if (deltaTime > 0L) {
                  float diff = 1.0F - currentProgress;
                  float interpolationFactorRaw = (float)deltaTime / 120.0F * 2.0F;
                  if (interpolationFactorRaw >= 1.0F) {
                     currentProgress = 1.0F;
                  }

                  Mth.clamp(currentProgress + diff * interpolationFactorRaw, 0.0F, 1.0F);
               }

               b<"a">(this, -9189209702095113274L, a).put(mode, currentTime);
            }

            currentProgress = 1.0F;
            b<"a">(this, -9189209702095113274L, a).remove(mode);
         }

         b<"a">(this, -9190396257170210731L, a).put(mode, currentProgress);
         float var10000 = dropdownContentStartY + (boxh + 2.0F);
         var19++;
      }
   }

   private static String HE_JIAN_GUO() {
      return "何树友被何大伟克制了";
   }

   public record 何何友友友何何友友何(
      boolean 何树友树友友树何友树, String 树友友何树友何树树何, float 友何友树友树树何树何, float 树何友何树友树友友何, float 何何树树树何友友树树, float 友何何何何树树友何友, float 何友友树树何何树树何, float 友友何友何树何友友树
   ) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[13];
      private static final String[] c = new String[13];
      private static int _刘凤楠230622109211173513 _;

      public 何何友友友何何友友何(
         boolean 何树友树友友树何友树, String 树友友何树友何树树何, float 友何友树友树树何树何, float 树何友何树友树友友何, float 何何树树树何友友树树, float 友何何何何树树友何友, float 何友友树树何何树树何, float 友友何友何树何友友树
      ) {
         this.何树友树友友树何友树 = 何树友树友友树何友树;
         this.树友友何树友何树树何 = 树友友何树友何树树何;
         this.友何友树友树树何树何 = 友何友树友树树何树何;
         this.树何友何树友树友友何 = 树何友何树友树友友何;
         this.何何树树树何友友树树 = 何何树树树何友友树树;
         this.友何何何何树树友何友 = 友何何何何树树友何友;
         this.何友友树树何何树树何 = 何友友树树何何树树何;
         this.友友何友何树何友友树 = 12.8F;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-288850890519560522L, 1826395130515162076L, MethodHandles.lookup().lookupClass()).a(225919148575463L);
         // $VF: monitorexit
         a = var10000;
         b();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static void b() {
         b[0] = "Y)^)\"YVi\u0013\"(DS4\u0018d8_\u0014桖去伟优叽栫桖桡桛优\u0012佯伒去厁历佣佯厌去伟";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = boolean.class;
         c[2] = "java/lang/Boolean";
         b[3] = "\u0007dmZ\u0018L\fk|\u0015eT\u001flu\\";
         b[4] = "$^\u0001\u001fjX/Q\u0010P\u000bV$Z\u0014\n";
         b[5] = "i9\u001f\rmy|+\u001f}叄伜佞伕佺桤栞厂佞压'D7~c#@\u0011e*s";
         b[6] = "\u001afYo)p\u000ftY\u001f厀伕厳栎厢栆桚伕桩佊a&sw\u0010|\u0006s!#\u0000";
         b[7] = "d\u001ejZ7(q\fj*桄叓反伲桋叩伀栉栗伲R\u0010c+l\tbH8,`";
         b[8] = "W!=K4\u001dB3=;桇佸叾伍栜司桇另叾伍\u0005\u0002n\u001a];bW<NM";
         b[9] = "0\u00044XJz%\u00164(口厁伇厶佑栱佽厁厙桬\f\u0011\u0010}:\u001ekDB)*";
         b[10] = "Y,+!\u001cwL>+Q伫厌台桄栊伌伫桖株伀\u0013hFpS6t=\u0014$C";
         b[11] = "\u0007:)I.E\u0012()9伙桤厮桒叒叺桝传厮桒\u0011\u0003~G\u00119v\u0006 \u0002\n";
         b[12] = "3e7lo\u0013&w7\u001c佘佶桀栍栖佁叆叨桀栍\u000f%5\u00149\u007fhpg@)";
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      public boolean x() {
         long a = 树友何何友树树树树何.何何友友友何何友友何.a ^ 76355753191428L;
         return a<"ñ">(this, -156544387775939080L, a);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友何何友树树树树何$何何友友友何何友友何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 241 && var8 != 209 && var8 != 'R' && var8 != 204) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 207) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 193) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 241) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 209) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'R') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      public float a() {
         long a = 树友何何友树树树树何.何何友友友何何友友何.a ^ 96756321788605L;
         return a<"ñ">(this, -618371217643953068L, a);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 10;
                  case 1 -> 6;
                  case 2 -> 62;
                  case 3 -> 23;
                  case 4 -> 1;
                  case 5 -> 58;
                  case 6 -> 29;
                  case 7 -> 26;
                  case 8 -> 47;
                  case 9 -> 24;
                  case 10 -> 18;
                  case 11 -> 43;
                  case 12 -> 0;
                  case 13 -> 14;
                  case 14 -> 59;
                  case 15 -> 25;
                  case 16 -> 51;
                  case 17 -> 28;
                  case 18 -> 12;
                  case 19 -> 5;
                  case 20 -> 20;
                  case 21 -> 2;
                  case 22 -> 8;
                  case 23 -> 30;
                  case 24 -> 55;
                  case 25 -> 21;
                  case 26 -> 60;
                  case 27 -> 4;
                  case 28 -> 46;
                  case 29 -> 63;
                  case 30 -> 33;
                  case 31 -> 54;
                  case 32 -> 22;
                  case 33 -> 40;
                  case 34 -> 17;
                  case 35 -> 42;
                  case 36 -> 61;
                  case 37 -> 53;
                  case 38 -> 50;
                  case 39 -> 37;
                  case 40 -> 44;
                  case 41 -> 9;
                  case 42 -> 41;
                  case 43 -> 15;
                  case 44 -> 49;
                  case 45 -> 27;
                  case 46 -> 7;
                  case 47 -> 32;
                  case 48 -> 57;
                  case 49 -> 35;
                  case 50 -> 31;
                  case 51 -> 13;
                  case 52 -> 56;
                  case 53 -> 39;
                  case 54 -> 45;
                  case 55 -> 48;
                  case 56 -> 52;
                  case 57 -> 36;
                  case 58 -> 3;
                  case 59 -> 19;
                  case 60 -> 11;
                  case 61 -> 16;
                  case 62 -> 34;
                  default -> 38;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      public float p() {
         long a = 树友何何友树树树树何.何何友友友何何友友何.a ^ 75935769545800L;
         return a<"ñ">(this, -7377035085495233153L, a);
      }

      public String p() {
         long a = 树友何何友树树树树何.何何友友友何何友友何.a ^ 18697399740938L;
         return a<"ñ">(this, -9365004657148262L, a);
      }

      public float w() {
         long a = 树友何何友树树树树何.何何友友友何何友友何.a ^ 22377228343880L;
         return a<"ñ">(this, 5737380804311240001L, a);
      }

      public float u() {
         long a = 树友何何友树树树树何.何何友友友何何友友何.a ^ 11900282265706L;
         return a<"ñ">(this, -5350614721220442396L, a);
      }

      public float y() {
         long a = 树友何何友树树树树何.何何友友友何何友友何.a ^ 30448196901971L;
         return a<"ñ">(this, -8537688059108760057L, a);
      }

      public float G() {
         long a = 树友何何友树树树树何.何何友友友何何友友何.a ^ 30946323867327L;
         return a<"ñ">(this, 8316797638409889165L, a);
      }

      private static String HE_WEI_LIN() {
         return "何建国230622195906030014";
      }
   }

   public static class 友树树树友何树友何树 implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[14];
      private static final String[] c = new String[14];
      private static String HE_JIAN_GUO;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-7242232493029936610L, -8726541456760564641L, MethodHandles.lookup().lookupClass()).a(190844278771588L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友何何友树树树树何$友树树树友何树友何树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 163 && var8 != 225 && var8 != 211 && var8 != 231) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 218) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'L') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 163) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 225) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 211) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static void a() {
         b[0] = "/\u0014$\u001aOq Ti\u0011El%\tbWUwb桫叁伬併叕桝桫栛桨併:厇桫栛桨叫佋桝厱佟桨";
         b[1] = ">=|+\u0007J52md{S:(c'Lc,?o:]O;2";
         b[2] = "\u001e\u0001\u0015r>m\u0011AXy4p\u0014\u001cS?$kS桾台叚厚栓桬桾株栀伄";
         b[3] = boolean.class;
         c[3] = "java/lang/Boolean";
         b[4] = "\riZ\u0003ea\u0002)\u0017\bo|\u0007t\u001cN\u007fg@栖县伵栛佛桿佒县厫叁";
         b[5] = "\u001dB\u0001\u0017br\u0012\u0002L\u001cho\u0017_GZxtP叧佺伡栜取伫佹佺伡栜";
         b[6] = "TcKa\u0000\u0004[#\u0006j\n\u0019^~\r,\u001a\u0002\u0019栜厮佗伺厠栦栜桴栓伺";
         b[7] = int.class;
         c[7] = "java/lang/Integer";
         b[8] = "#3O\u0018S/(<^W2!#7Z\r";
         b[9] = "w\u000bo\u0016\u0015\u001c1\u001cyd\u0003-7\u000eu^\fT6\u0010ld\u0015S8Jc\u001d\u0014M!p";
         b[10] = ")$\f!\u000bDs~_j2栺低叟伿叓叱佾栊佁桻\u0010\bC*'\u001bv\n\u0013u{";
         b[11] = "si\u0002F\u001bYr-\u0018[r叡厊栏档叠厱栻伔栏档#H\u001a''CD\u0012@tl";
         b[12] = "eJ<|\u0012\u0003?\u0010o7+伹厜厱伏厎栲伹框桫伏M\u0017]eC6.G\u0016f\u0012";
         b[13] = "RVSI\u001dT\u0010\rUSqNn\u000e\u0000]\u0001O\u0012R\tQA/";
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 38;
                  case 1 -> 58;
                  case 2 -> 46;
                  case 3 -> 39;
                  case 4 -> 51;
                  case 5 -> 21;
                  case 6 -> 27;
                  case 7 -> 44;
                  case 8 -> 24;
                  case 9 -> 62;
                  case 10 -> 3;
                  case 11 -> 11;
                  case 12 -> 57;
                  case 13 -> 5;
                  case 14 -> 43;
                  case 15 -> 40;
                  case 16 -> 63;
                  case 17 -> 54;
                  case 18 -> 16;
                  case 19 -> 52;
                  case 20 -> 19;
                  case 21 -> 56;
                  case 22 -> 59;
                  case 23 -> 7;
                  case 24 -> 53;
                  case 25 -> 26;
                  case 26 -> 15;
                  case 27 -> 32;
                  case 28 -> 0;
                  case 29 -> 8;
                  case 30 -> 2;
                  case 31 -> 35;
                  case 32 -> 42;
                  case 33 -> 31;
                  case 34 -> 10;
                  case 35 -> 55;
                  case 36 -> 14;
                  case 37 -> 47;
                  case 38 -> 18;
                  case 39 -> 13;
                  case 40 -> 29;
                  case 41 -> 12;
                  case 42 -> 17;
                  case 43 -> 50;
                  case 44 -> 36;
                  case 45 -> 9;
                  case 46 -> 61;
                  case 47 -> 48;
                  case 48 -> 28;
                  case 49 -> 49;
                  case 50 -> 45;
                  case 51 -> 34;
                  case 52 -> 23;
                  case 53 -> 6;
                  case 54 -> 4;
                  case 55 -> 1;
                  case 56 -> 37;
                  case 57 -> 60;
                  case 58 -> 30;
                  case 59 -> 41;
                  case 60 -> 25;
                  case 61 -> 22;
                  case 62 -> 20;
                  default -> 33;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      public static 树友何何友树树树树何.何何友友友何何友友何 r(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, float itemX, float itemY, float itemW) {
         long a = 树友何何友树树树树何.友树树树友何树友何树.a ^ 132807996573767L;
         a<"L">(2263451433963102149L, a);
         String valueNameStr = a<"£">(a<"£">(panel, 2263270611876353963L, a), 2263217459732983103L, a) ? value.v() : value.W();
         float nameStringWidth = a<"£">(a<"£">(panel, 2263270611876353963L, a), 2263365478801469900L, a).A(valueNameStr);
         Objects.requireNonNull(a<"£">(panel, 2263270611876353963L, a));
         float nameWidthUsedForCondition = nameStringWidth + 2.0F;
         float potentialControlWidthIfSideBySide = 106.0F - nameStringWidth - 6.0F;
         boolean isControlBelowName = nameWidthUsedForCondition > itemW * 0.55F || potentialControlWidthIfSideBySide < itemW * 0.25F;
         float nameDrawY = 8.0F - a<"£">(a<"£">(panel, 2263270611876353963L, a), 2263365478801469900L, a).K() / 2.0F;
         Objects.requireNonNull(a<"£">(panel, 2263270611876353963L, a));
         float var10000 = itemY + 12.8F;
         var10000 = itemX + 2.0F;
         var10000 = itemW - 4.0F;
         float ctrlX = itemX + nameStringWidth + 4.0F;
         return new 树友何何友树树树树何.何何友友友何何友友何(isControlBelowName, valueNameStr, 2.0F, nameDrawY, ctrlX, itemY, potentialControlWidthIfSideBySide, 12.8F);
      }

      private static String HE_SHU_YOU() {
         return "何大伟：我要教育何炜霖";
      }
   }
}
