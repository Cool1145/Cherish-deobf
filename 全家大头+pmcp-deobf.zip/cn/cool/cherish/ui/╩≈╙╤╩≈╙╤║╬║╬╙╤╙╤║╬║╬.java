package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.config.友何友树树树友树何友;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何何友何何友何何树树;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.友树树何何树树何何树;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

public class 树友树友何何友友何何 extends Screen implements IWrapper, 何树友 {
   public static final 树友树友何何友友何何 友树树友何树友友树友;
   private final float 友友树树友友何树树何;
   private final float 何树树树何何树何友树;
   public float 何树树友何友树树何何;
   public float 友友友友树何树树何友;
   private 树友树友何何友友何何.树树友友树何友树友树 何何何树友友友何友树;
   private static final float 何树何树友友友友友树 = 0.1F;
   private static final float 何何树友何树友何树何 = 0.3F;
   private float 何树何树友树友树何树;
   private long 何树友何树树树友友友;
   private float 何友树树何友友何树友;
   private boolean 何何何何友友树树树友;
   private boolean 友友友友友友友何树友;
   private long 何何友树何何树友友何;
   private static final float 何何何何树树友何树何 = 0.2F;
   private boolean 树何友友树树树何友树;
   private float 友何友友友友友何树友;
   private float 树何何树树何友友树友;
   private final HashMap<何何友何何友何何树树, List<树何何树树树友友友友>> 何树友何何树友树何树;
   private final 树友树树友友树树树友 树友友何树树友树何友;
   public boolean 何何友树树树树何树何;
   private 何何友何何友何何树树 树何树何树何树树友树;
   private 何何友何何友何何树树 友树友友树树何何友树;
   private float 何友何何何友友何何友;
   private static final float 友何树友何友友友何何 = 0.5F;
   private boolean 友树友友何友树树树树;
   private long 何何何友何树何树何树;
   private boolean 何何何友树树何树何何;
   private boolean 友友友树友何友树友树;
   private final float 何友友友友树友树友何;
   private final float 树何友树友友树树何友;
   private float 友树友树友何友树何何;
   private float 何树树友树树友树友树;
   private float 友友何何何树何何树友;
   private boolean 何树友何友友友友何友;
   private float 友何树友树友何友友树;
   private float 友友友何友友何何树树;
   private boolean 树何友友友树树何何树;
   private long 树树树何友何友树树树;
   private static final float 友何何树友友友何树友 = 0.4F;
   private final List<树友树友何何友友何何.友何树树树树何树何友> 何何何树友树何友何友;
   private boolean 何何何友友何树何何何;
   private float 何树树树友树树树树树;
   private float 树何树友树友何友树何;
   private 树友树友何何友友何何.友何树树树树何树何友 友树友友何何树树友何;
   private List<Module> 友树树友何树友何树何;
   private float 何树友友树友友友友友;
   private String 友树友何树友何友何树;
   private boolean 树何友树友友何树友树;
   private final float 友友友树友友友友何友;
   private final float 何友树友何何何树友树;
   private final float 何友友何友何何树树树;
   private float 树何何何树树何友树树;
   private float 树树树何树友树树何树;
   private float 友树友何树友何何何友;
   private final float 树友何友友何友何树友;
   private final float 树树树树友友树树树何;
   private boolean 何树何友友何树友何何;
   private float 何树何何何何友友友何;
   private float 何友树友何友友树友树;
   private float 友何树友树友树友何友;
   private float 树树何何树何树何树树;
   private float 何友何何树何何何何何;
   private float 友何友树树何友树树友;
   private static final float 友友何树树树友树树树 = 10.0F;
   private final float 友何何友树何树何友友;
   private final float 何何何何树树何树树友;
   private float 何友何树树友何树友友;
   private float 树友何何友树友友何树;
   private float 何树树友友何何友何友;
   private boolean 友树友树友树树何友友;
   private float 树友何友树何友友友友;
   private final float 树友友何友何何树树友;
   private final float 友树何树树友何友友友;
   private float 何何何友何树树树何何;
   private float 何何何何树树友树树友;
   private float 友何友友何何树树树友;
   private boolean 何树友树友何友友树树;
   private float 友友树树友何树友何树;
   private boolean 何友友树何树友树何友;
   private float 友友何友友树友友何友;
   private float 友树友树树友何何何树;
   private final float 树树树何何何何何何何;
   private final float 友树友友友树树树何何;
   private String 何树何友友何树树友树;
   private boolean 友友树树友友友友友何;
   private List<String> 何何何树树友树何何树;
   private float 树友树友何何友友友何;
   private float 何友树何何树树何友何;
   private boolean 树友友友树树树树树何;
   private boolean 何树树友何何树何友友;
   private long 友何树何友树树树何何;
   private static final float 友友友友何何友树友树 = 0.2F;
   private final float 友友友何树树何友树友;
   private float 友树何何友树树树树何;
   private boolean 友何何何何友友树何树;
   private boolean 友何友友何友何何友树;
   private String 友友友友何树何何友树;
   private boolean 友何何友何何何友何何;
   private final float 何何友友友友何友树树;
   private final float 友友何友树树何何树友;
   private float 树何何何树树友何树何;
   private float 友何树何树友树树何何;
   private float 树何友树友树树何树何;
   private static Module[] 友友树树树何树树何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[131];
   private static final String[] j = new String[131];
   private static int _何大伟：我要教育何炜霖 _;

   protected 树友树友何何友友何何() {
      long a = 树友树友何何友友何何.a ^ 121532390660129L;
      super(Component.nullToEmpty(a<"o">(1954, 4398628970352061618L ^ a)));
      this.友友树树友友何树树何 = 550.0F;
      this.何树树树何何树何友树 = 350.0F;
      c<"Å">(this, 40.0F, -4264532739546889048L, a);
      c<"Å">(this, 40.0F, -4269176706057678201L, a);
      c<"Å">(this, c<"í">(-4268988906366491746L, a), -4264933794880064467L, a);
      c<"Å">(this, 0.0F, -4264114726669687899L, a);
      c<"Å">(this, 0.0F, -4263322238808429358L, a);
      c<"Å">(this, false, -4267592615121655452L, a);
      c<"Å">(this, false, -4265332899382717360L, a);
      c<"Å">(this, false, -4267493083642496126L, a);
      c<"Å">(this, null, -4262274960905366905L, a);
      c<"Å">(this, 1.0F, -4267927681496083790L, a);
      c<"Å">(this, false, -4262725364406568657L, a);
      c<"Å">(this, false, -4260596077030482866L, a);
      c<"Å">(this, false, -4262615682214817949L, a);
      this.何友友友友树友树友何 = 80.0F;
      this.树何友树友友树树何友 = 20.0F;
      c<"Å">(this, false, -4263122189550605754L, a);
      c<"Å">(this, 0.0F, -4260986595961373643L, a);
      c<"Å">(this, 0.0F, -4269010679518453009L, a);
      c<"Å">(this, false, -4260447020562592969L, a);
      this.何何何树友树何友何友 = new ArrayList<>();
      c<"Å">(this, false, -4261223344832982941L, a);
      c<"Å">(this, null, -4257971900700082447L, a);
      c<"Å">(this, 0.0F, -4261974423353654374L, a);
      c<"Å">(this, "", -4268814895680515775L, a);
      c<"Å">(this, false, -4264480211936769619L, a);
      this.友友友树友友友友何友 = 20.0F;
      this.何友树友何何何树友树 = 150.0F;
      this.何友友何友何何树树树 = 150.0F;
      this.树友何友友何友何树友 = 80.0F;
      this.树树树树友友树树树何 = 30.0F;
      c<"Å">(this, false, -4268621441748270499L, a);
      c<"Å">(this, 0.0F, -4260834436147766473L, a);
      this.友何何友树何树何友友 = 80.0F;
      this.何何何何树树何树树友 = 20.0F;
      c<"Å">(this, false, -4264881510135383613L, a);
      c<"Å">(this, 0.0F, -4268257622287778456L, a);
      this.树友友何友何何树树友 = 80.0F;
      this.友树何树树友何友友友 = 20.0F;
      c<"Å">(this, false, -4263155377201031514L, a);
      c<"Å">(this, 0.0F, -4263250211863950260L, a);
      c<"Å">(this, false, -4268003607280585425L, a);
      this.树树树何何何何何何何 = 180.0F;
      this.友树友友友树树树何何 = 200.0F;
      c<"Å">(this, "", -4264823489087216368L, a);
      c<"Å">(this, false, -4262083234685042434L, a);
      c<"Å">(this, new ArrayList(), -4258129501387772927L, a);
      c<"Å">(this, 0.0F, -4262572713877063480L, a);
      c<"Å">(this, 0.0F, -4265249695608265765L, a);
      c<"Å">(this, false, -4262733665598173328L, a);
      c<"Å">(this, false, -4268875362837839944L, a);
      this.友友友何树树何友树友 = 20.0F;
      c<"Å">(this, 20.0F, -4267527442524488912L, a);
      c<"Å">(this, false, -4261609733352916935L, a);
      c<"Å">(this, false, -4264361589739263564L, a);
      c<"Å">(this, "", -4265407369428132138L, a);
      c<"Å">(this, false, -4262207865152758900L, a);
      this.何何友友友友何友树树 = 120.0F;
      this.友友何友树树何何树友 = 20.0F;
      this.树友友何树树友树何友 = new 树友树树友友树树树友();
      this.何树友何何树友树何树 = new HashMap<>();
      c<"Å">(this, System.currentTimeMillis(), -4262817018240218252L, a);
      c<"Å">(this, System.currentTimeMillis(), -4268521243324907397L, a);
      c<"Å">(this, System.currentTimeMillis(), -4263961300404411162L, a);
      c<"Å">(this, System.currentTimeMillis(), -4267175095462905041L, a);
      c<"Å">(this, System.currentTimeMillis(), -4261495261417807268L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(4157009220643328531L, 3835496272656014415L, MethodHandles.lookup().lookupClass()).a(240826087563484L);
      // $VF: monitorexit
      a = var10000;
      long var20 = a ^ 25505392961065L;
      a();
      c<"ý">(null, -4985659300443236628L, var20);
      Cipher var11;
      Cipher var25 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(var20 << var12 * 8 >>> 56);
      }

      var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[156];
      int var16 = 0;
      String var15 = "p\u001cA|u\u0010/½@ÃmÝ»\u0083\u0011©\u0012ö?ýVýÚ\u007f>¾È\u0083¿\u0097IÀâ¿\u0085eËZ¨¬\u0018\u0006óëïßñ¡.Ã~i\u0088<\u00147\u0098\u0001\u0086ýÆ\u009c>éº Ù\u000eÛ\"R\n£ß²0Ó\u0097ª¯*\u001aÏ\rã\u008dW¥5J¥¹Ok¤\u0002A\u0007\u0010q\u0006P\u0082È+æ|\u0094Hì&â]tL :\u0019þÿ÷\u0014tD%*Ï~ý\u009a\u0099óöüïþF\u008dd\u001d/þ¯\u009eQ\u0002\u0084ï\u0010Å0$îç\u008aø=\u008cË½«\u0095Î\u0091#\u0010\u008f\u008c\u0084?K\u0085\u009dÉ&Ü°!\r\u0001\u0015\r\u0010\u001d\"¦éü\u00197«\u001aË\nm¢\u001d\u008f5\u0010çK Ç7Ö)Únû¢±laé?(\u0018pD{\u009d3èjsüagk»\u0082\u009cÍ^\u008a\u0095Á±¶øl\u00ads|\u0003Æ\u001bî¨FK¬cAi.\u0010n\u0091auÜ\u000fä©\u0092Ð\u0006\u001cñô\u0091õ\u0010\u0019´L\u0012¡\u0010SW7\u0093rÐ\u0097O8g\u0010ÓÚ\u000béÕÇ¯Cpj£ÜãËEH\u0010Ã\u0003Y\u0019\u0015Âjáö\u000f\u0018'Ì-C\u0018 \u009eã×¡\u0099è7r®hÉ11\u0094Q©¼ï(ï+á\u0002@\u008b HàJq2ô\u0010é#rÂ@©~\u0012J\"\u0010+ÜC ¡ ð5Nt\u0006NþÏñªZë\rH\u0084Ì;\b\u000e\u009br\u009b\u0007\u009bÉ²µg}ÊmQ\u0010qhgÆÛ]{v\u0000õ\u007f·^÷\u0093Ò\u0018³\u000bD/\u009a9oCóUÂ\tíçlR\u0085y\u0000\u008bª¥\u0001d\u0010Ýª+àÀÞS\u0004 G\u0015\u009dö\u0081ÿâ(eÈ\u0082A×þ\u00120\u008bËzW\u0096\u008aÛADab#6Výà¿USíûß\u009f\u0094;µô\u0094ïGgæ\u0010\u009c\u0014|\u001cã\u0097\u0013\u0084v8¹ïÊÔ+\"\u0018\u009bþèÒ\u0000æ6üåg,Í\u000f»\b8mÖ\u0092\u000fgAªX \u0086\u0005\n3)å¥U3vÊ\u008eËöS\u00141\u00871-Véòy}É!D¬§OÔ\u0010ÎÌê\u009d\\bâ»ï£\u0005\u008e¥\u007fg\u001f\u0010\u008f\u001c«]J#\u0097w|\u001c=÷\u0083¼Än\u0018g¨º\u0087\u0096~\u0015\u0081O+yJ\u0005}\u0006Ê3,ø\u008f\u008eÆ\u0006\b\u0010\u001b\u0012\u0015Ãç\u0087\u0001ÙÍ:$÷X\bF¹\u0010\u001c\u0004Ogë!u¬\u009a\\;¶L××Z \u008dÞuÁADÇ÷\u008f\b\u000f\u0018?÷Ò?Í\u009cL\u0084&\u0007\u0087\u007f\u0096ÿ¯\u008by\u00804\u0017\u0010Ëf\u009eÍ¥\u0002Oô\u00022AR®\u00964¸\u0010\u0005¨ \u0097Ð\u0005Äo4Hmáã»Ò48\u0099Ac\nvÿ è_1\u008b\u009b\u008eæZÿÄ\u0086Käo\t~fØ>\u0092»Ñ»iö\\0Õ\u008d\u001f9|ÊLçk\t§r\u0007yh°\f\u0088\u009cI|F(\u0087±I\u009aV\u0005\u000e¬Ç\u0000f{BJÊÃão\u007f\u001e§!k3zè\u008bR\u009eqÍo8O\fcÙ%`Õ\u0010Ô.»\u008d\u0000°+²'},\u0089pÿFª x[R>o\u009cÜ¶øMdd\bÇº\u0087òW\u0013¸w¹üe|\u0091ØÂ!]\u008aõ\u0010\u000eU¸¤*e7]¬¹\u0002$\u0089Ð]ö\u0010OWØ\u0019[\u000f\u0099\u001f\\%0\t~ÙÓÂ\u0018eâ¿Ã2S\u008c\u0082ÙËB%¾¤\u0081Îe~þ\u008dB\u001fÎz 0Kõ!¯+·«¯¦WD\u0005þänW\u008dÉ³/Ç\u009d°cfÈ\u0015¡£.Ä \u001a$7µv_.%\u0017Ò¤TÖ\u0017-#ÃÞ\u0019\u0017_¿Ëf\u0005¡\u008c\u000b\u001c\u0087ÞX\u0010Ìyv®[\u0083ü\u0089j\u0086}Að7Us\u0010×ö)DW+sölIqýd®ë0\u0010\u0086·\u0017\u001f:\u0013ËEà\u0096\u008b'§¬GF \u001d\u0090ÖÐ¥÷cý\u0089ª®IîIek7¢o\u0096l!N\u008e·ù½£H~úu\u0010\u0083N :u&\u008d{\u0084\u0095t{ÅY\u0084\u007f(Ò°xd³4u.^Y\u008d\u007f\u0015\u0087ó\u007fB]9Ô\u008b5N\u000b1öÁ\\O\tóiHÿðõå³]Ð -\u0002\u0094]Î8ºlä½³\u0019&§\u00ad\u0088)ö\u0084\u009cvþÀì°\u001f`\u0018~Ç¾$\u00109Ô\u0012\u0019M\u00ad¿B÷S>Ü¾~èù\u0010Ðb/\u0014Opq/Ã\u0086÷-N\u001c\u009a\u0014 ¿ç´\u0082$ÙeÍ°\u00029Ü\u001fcß¤\u0088Ö¦ó\u0090¡/\u0011\u0002wÉøl\u0089ÖÞ\u0010ôÏD°òòÇ\u008b[ìúÎ/\u0085\u000f\u0012\u0010où#E~õ\u0005\u0085{ ¬M\u001bOÙ$\u0010\u0086Éÿ\u0091\u0018°1\\|c\u0083Ã\u0086$\u008aä \u001b\u008e¦\u0084q\u0012ÏÜ\u008fO\u001bÃÀðáõ\u000f÷\u008cP¥\u0012ú\u007fÑ\u0092\\\u008e\u009eÎH\u0010\u0010°32á´Ø,\u001fjÕÉ\u0094º\f¯²\u0018d\u001db\f\u009b·\u0011ÓÙ\u0096#/©\u0017»\u008e\u0001\u007fMa\u009c/Râ\u0010Z!^½Ç¢ZÐ¹r\u0096\u0000\u0011\u008eFi(°kuùÚ°çÙ\u001aYír\u008ay\u001b×\u0085NäAÆÖ\u0004°ÂóçdÏ}hõT\u00106x\u009f\u001d °\u0010\u0019\u009c\u0091cBå\u0016¦Õf¾e\u0088B¦J\u00104UL\u0007Õ»Èâ4×ø\u0011=\u000exú8lº-ü\u001e\u009aêì:ø\u0089\u008e\u001cß¬\u0091>\\¥§Y7»Ú,UÑ%ø\u0004iÃ\u009eêÒzíáI\b¹¨+÷\u000e\u008c¬µÀg\u0095ix\u0004íÍ \u008be]ý\u00adê\u0017u Lö\u001b±\u0091\u000b\u0085¥¯\u008f\tÆ\u008c>7AX?~Zj\u0017\u0089\u0010\u0087Óècæú¡\u000b$ËMäSj\u0005Æ\u0010C¬,4=IÀÆå\u009bì\u0001Í$®\u008b\u0010ä\u000fw·Â5\u0082¤>£\u0015óì½m5\u0018F\u001cv\u000b{\u0017îæ\u009eÄ\u0010DÚ¸O¬seè\\ ÈÓ\u0087\u0010XN\\\u0088CìºÚ\u0098qµÛ`£û\u008e\u00183\u0095\u000fÿ[.ñpÂNÝ\u008fj'{#iQp\bÈ<\u00adÛ\u0010\u0092\n\u0088ø\u0091\u008eþÇ¨é{·E\u007fºQ\u0010\u0011®5lqÃ\u000b±æsG&\u0005FHÓ\u0010FÿñDëbôÇ±ÑÊ7\u0015²¨@\u0010ÍH\u0093¤\u0092Ñ\u000fæPoi\u0002g\u0004÷^\u0010\u0000ØØ\u0014VÓ\u008c¥û\u0095!|dA÷µ\u0010ZìlÒR\u0096Ø9%\rR®L\u001a\f½ bÀú¥Ë3ìRÛßGzx\u0014A7ú\u0004òÿ)b\u0081PIû¤\u0000Áa\u000f©\u0010åW\u009cÉí ¯DÙcXmFØað(÷ÃpÂ±\u0092²\u000b¡\u0014Uû\u007f*ð\u008eß$\u0087±ô\u001f-\u0099\u008fQ¼eðT·ó\u0080\u0096\u0097|Á\u0002l¯\u0010ý%\u008fÇè«#ì:»Ð#¥ö\u0098¥(ak\\è\u0000ÛöéÌn\u001b¥£\u001c\u008f\u001f\u0005Y¬5w§F\u0090ÀÝ\u0007Ë\u00adÑmîoòÕ#W¶Lª\u0010}á)1\u009eÅ\\v\u0087IQ\u0016®Ûú©\u0010IÆ\u008e½ï\u000e¼(Z\u0099\u001f¿Ä)\u0011¦\u0010\u0002±\u0017\bå$\u0096½\u0010N½¥\u0017¨JÔ\u0010QÊ·\f×\n$\u008f\u000f_°º\u0097>?ß ·PÆ\u0081\u0007VÐT+Ú\f(\f\u0011÷Y#ÌÕZä!æ\u009eæñ[eÈR\u0005\u0097 ¤zÎ#hm\u0090g¡¨»¨r|N\u001déD Ô¤Ì\u009a\u0089W\u0010.·\n©\u009b,\u0010`\u008ad\noGÛfOþ\u0004ÍL\u0011'¦\u00100\u009d\u0010\u0007(ÌöÖn\u0000ç\u0014\u0094¾\u0011\u0005\u0018´êÝÊ\u00ad<ä\u0085\u008e5W\nmA¢íáÛz\u001dÖÊuý \u00ad|\u0090\u009bW\u008e&µ\r@a|%é\u0003½\u0085µ9\u0096¹¨-ò\u009dîòZ\u0090\u0014>é\u0010\u001c\u009e±YS\u000eY¯Ì\u0086oe\u008d¤E\u0004\u0010\u0095iLøl\f\u00adÛeøª°÷\u0017Z*\u0010G²[¶Î\u0094]I¾í|¯5?ût\u0010>t;®S\u0010àÏ\u0090\u001dÌy\u0096\u008c;½\u0010ç\f\u0001Ë»\u007f:Á3Vø\u0096\u0014\u0011Ïñ \u0096\u008e\u007f¢\r\u0004³U§1¿\fÿKüÏAóY®RÝH\u000b]?©ßhØo\u008b\u0010\u0080\u0088\f¨®1\u0003\u0018\u001c\u0005õõ2çÊ- n(Äô¿¥Ð6\u0010\u0012¡Ã¦6\u008cq^\u001fª6\"\u009aþ\u0006>à\f\u009b°Ààá \u001c£ë\u008a\u008cª D\b\u0097Ë\u0082\u000bAã7\u0091\u0014O!uþ¤¼T:\u009cãNeä\u008e\u0010T ¯ÁQaw\u0096¥¿\u0093Ú\u008bÿ_;\u0010üÐF\u001bY\u009aøþrB\u008d[Ûrt.\u0010Ê\u000e\u0082©Á\u0000Dº&¢ ³`Il[\u0010\u0003}Íp Ö+åIub/¬8ëF\u0010F·Ô]Ð\bFÅ;ù[8OHI\u00ad\u0010¥\u0002\u0002äÇ-à\u0005c&ËUF\u0016\u008d¨ \u000b-\u0092È[hómûkH,ÔiË<\u0007\u000f÷$äb\ný\u0018\u0019\u0017a\u008f<>¿\u0010/\u0093ô^\u001fa7à\u008a¾ªÿ·c\u008bÏ\u0010ªúS I\u008f\u0004Hó{Q\u0004e¹bÿ ÿ\u0012î2Eÿt\u0017\u009fá>ã!äßÎÉ&Îù÷C×dñæ\u0095[ \u0087\fÜ\u0010È%\nµ\u008aÀkCe$\u0006ÑC©\u0010,\u0010½Ð³ jWÈ6\u009cFÉã%Jd\u00ad Öô\u008d\u0010Æ\u001fXjû²Ó\n#m-\u001d$\u00886\u009eôW\u0002¦ÿ¦²gFR\u0019Z\u00188ÿp)Ù´#É !\r[\u0080\u0003\u0000.n¯ä\u0003\u0096ß(\u008e\u0010Dzv+±'ÁàU\u000fiØJ_Ív\u0010¥ÒpñÈDÓ\u0098\u0094Í8-\u008alúÌ\u0010tVÆ éÓ\u0095M\u009f\u000b?è¸\rhÙ\u0010\u00ad¦\u0098Þ'ª9§r.îRR»ä\u008d\u0010ø\u0004\u001fÙ\u0080\u0083\u0092¢=G\u0083²\u0089ìÊ\u001f\u0010ÖFÈà\u0002\u0002ä\u001fæ\t\u008fP Ã\u008f\u0083\u0010(gì\u001c®\u0004Ï\u0011NR¾\u0003ÒÍv{\u00102]\u0007´\u0000_\u0014\u001f\u0014\u0000X\u0013¿yyR\u0010\u0002m/\u009b\\À\u0099ó\u0001óH\u009a/÷l¯\u00109\u0081Ö¹{yÒ\u0089Þ¬@\u00809(\u0083\u0013 h¡ý\u0015»ß«$E\u0018¨ðÇ6ÓÑ`0\u0016}¦Fr\u0012¾½\u0096\u0089\u0085 À©\u0010\u009c\tnó§\u0018\u0016ï\u0002D,\u0093vÈ\u000fº\u0010Î\u0096õ¸vÛBX×È¤z>ÚBÐ\u0010ê«\u0006´òwÜ\u0005Ü\u0003¸vÍã¬¥\u0010è-¨\\éë#é*6I«æõÑµ\u0018#É±k`HJ\u008e\u0093\u0081áÿÂÕ\u009fäH7\u0085Á1Û\u0011ù\u00109\"LÕ32\nGêu¸\u009e\u009c?\u0098Å\u00106\u0012f~ô;;ï¹)\u0003\u0087eàÍ\u001f8\u0011Z\u0016YT9Oà\u0082\u0080\u0014ù\u009d\u008aÅ|\u009eE2Ñ:ñ\u001bÑ\u001còñ\u0013\u0002<,9æà\u0083ô \u0083\u001bÍ?f\u0005+\u0002ë\u0090ÊûÄÍ\u009bQyñ$ sèËCi\u0004;ÿBoô\u0096g(\u007fî1àKLôT\u0085\u0012ñ ÔIñ¤ó5\u0010\t\u0090d7ÛîO²\u0001>\u008d¨\u0092|\u0096ý\u0010ôwånéØ!yïoKLëÖ,ð\u0010\u001aéô\u0096Ó®\nE\u0003\u0092pc\u009cß²\u001b\u0018Í\u0007u\bñ\u0000iv¸£\u00825/\u0019£8õ)¥}Â|@\u009d ñ\u009aUÏw\u0019ù]È\u0002IÄ¹v×¡¶Ioâbkuï÷É¾~µ¯\rÉ\u0010_B¡*n\u008f±\u0086À\u00814òÕ¥Qa wf\u001dÕ4\u0093\u0080Õmÿ1õ×\u008açxÂ½}q\u0004¤+\u0088òÂò\u000b\u00ad\nÓ´\u0010sî\u0092Ò|¨ÊÈ-\u001e\u008aixÞsh ´aéÂÏujÙ[\u0095\u0013R¨P\u008b\u000eÑ©\u001eÃ\u0097\u001b\u009by±\u008e+X:I\u0086\u009a\u0018\u001aÆ°±\u0011&Wæä7eYÙ\u0097¯o\u00adïHm¨xñt\u0010[+¢¾ÌL[ñlÕ=\u0089«[nß\u0010SåÇÙ@Ú\u008cÂ©\u0081¢de\u000f\u0006'8f\u008c©çSD\u0004\n\u000b\u0089\u0099$\u000f\\fS÷Ñ½ëAª\u0004Õs\u0006'²<&Ê^+¾\u007fLn52½(n\u000b¢/ÕÇ\u0014\u009fCr\u009c\u0091\u000b=ß ë\u0002\u0011¥\"\u0088\u0003V9\u001c\u008c{ÓÐ\u0086\bÝ*ï¥»í+µíU¯Ð¼ñCÃ\u0018¤ª\u0091²\u008b,$ º;dè\u0090ÑÆ1Aæï\n¾\u001aßÁ\u0010\u0085\u0003\u0097£°þ<&LLµ'®µ[M 8\u0006\u009c¦\u0084IO\u008cÜß®\u000b\u0093_YP|jJÕ8î\u0096ú}3ã\u000282ôÈ\u0010³5À\u0016Ï;è¼Ü\u000e\u0080ê¾Û\u001d?\u0018Ø\u0016`Z9$Ó\u0011êÎÚ\u0004Ä~mðî\u001d-¹=\u0006/Ú PJª\u001a ´.\u009c\u007f²ÞéL²=\u0004µ¡]µ¤,¸0J9²¤\u0099\u0091Yi\u0010Z\u008b*Ê_Ð\u0094\u0006½\u0010ìÙ¼å_i";
      short var17 = 3601;
      char var14 = '(';
      int var24 = -1;

      label54:
      while (true) {
         String var26 = var15.substring(++var24, var24 + var14);
         int var10001 = -1;

         while (true) {
            String var37 = b(var11.doFinal(var26.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var37;
                  if ((var24 += var14) >= var17) {
                     b = var18;
                     c = new String[156];
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var28 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var20 << var1 * 8 >>> 56);
                     }

                     var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[4];
                     int var3 = 0;
                     String var4 = "´Ä&(\u001b{mJS\u009f\u0004Í2ònh";
                     byte var5 = 16;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var29 = var6;
                        var10001 = var3++;
                        long var41 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var44 = -1;

                        while (true) {
                           long var8 = var41;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var46 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var44) {
                              case 0:
                                 var29[var10001] = var46;
                                 if (var2 >= var5) {
                                    f = var6;
                                    g = new Long[4];
                                    友树树友何树友友树友 = new 树友树友何何友友何何();
                                    return;
                                 }
                                 break;
                              default:
                                 var29[var10001] = var46;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "¬\u008d@n`\u0005M\u00ad\u008f\u009b¥«\u0013\u0097ñX";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var35 = var2;
                           var2 += 8;
                           var7 = var4.substring(var35, var2).getBytes("ISO-8859-1");
                           var29 = var6;
                           var10001 = var3++;
                           var41 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var44 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var24);
                  break;
               default:
                  var18[var16++] = var37;
                  if ((var24 += var14) < var17) {
                     var14 = var15.charAt(var24);
                     continue label54;
                  }

                  var15 = "2 s¡\u0000ùJçÐê£\u0014v\u0095ouM\u0095\u001b.?G\tz\u0010\u008e\u0087rÒ`b)m\u0012²õ\u0000t\u0005rÙ";
                  var17 = 41;
                  var14 = 24;
                  var24 = -1;
            }

            var26 = var15.substring(++var24, var24 + var14);
            var10001 = 0;
         }
      }
   }

   private void B() {
      long a = 树友树友何何友友何何.a ^ 51273675342562L;
      c<"ý">(2161787665439855204L, a);
      if (c<"X">(this, 2163488683040813036L, a) || c<"X">(this, 2167632724882478515L, a)) {
         c<"Å">(this, false, 2167632724882478515L, a);
         c<"Å">(this, true, 2162475849627985275L, a);
         c<"Å">(this, System.currentTimeMillis(), 2170559687897102495L, a);
         c<"Å">(this, false, 2168845833036798525L, a);
      }

      c<"Å">(this, false, 2163488683040813036L, a);
      c<"Å">(this, 0.0F, 2165538910524995864L, a);
   }

   private void C() {
      long a = 树友树友何何友友何何.a ^ 120855853423281L;
      c<"ý">(-4155849227456493001L, a);
      if (mc != null && mc.getWindow() != null) {
         int screenWidth = mc.getWindow().getGuiScaledWidth();
         if (c<"X">(this, -4159536505405101866L, a)) {
            c<"Å">(this, Math.min(1.0F, c<"X">(this, -4157407229688250715L, a) + 0.1F), -4157407229688250715L, a);
         }

         c<"Å">(this, Math.max(0.0F, c<"X">(this, -4157407229688250715L, a) - 0.1F), -4157407229688250715L, a);
         if (c<"X">(this, -4161295551088772269L, a)) {
            c<"Å">(this, Math.min(1.0F, c<"X">(this, -4155668879363670024L, a) + 0.1F), -4155668879363670024L, a);
         }

         c<"Å">(this, Math.max(0.0F, c<"X">(this, -4155668879363670024L, a) - 0.1F), -4155668879363670024L, a);
         if (c<"X">(this, -4159573816350223306L, a)) {
            c<"Å">(this, Math.min(1.0F, c<"X">(this, -4159663698900513060L, a) + 0.1F), -4159663698900513060L, a);
         }

         c<"Å">(this, Math.max(0.0F, c<"X">(this, -4159663698900513060L, a) - 0.1F), -4159663698900513060L, a);
         float targetKeyBindX = c<"X">(this, -4158135415434786794L, a);
         float targetSnakeGameX = c<"X">(this, -4155778831306115040L, a);
         float targetConfigButtonX = c<"X">(this, -4156627221435555547L, a);
         float targetSearchBarX = c<"X">(this, -4157751588137099969L, a);
         float startX = screenWidth + 10;
         if (c<"X">(this, -4159031385469973005L, a)
            || c<"X">(this, -4152342848637602115L, a) == c<"í">(-4159321509786749907L, a) && c<"X">(this, -4156864909831714393L, a)) {
            c<"X">(this, -4156420012321857409L, a);
            if (c<"X">(this, -4156864909831714393L, a) && c<"X">(this, -4152342848637602115L, a) == c<"í">(-4159321509786749907L, a)) {
               c<"X">(this, -4156420012321857409L, a);
            }

            c<"Å">(this, 友树树何何树树何何树.s(targetKeyBindX, startX, this.n(1.0F)), -4155415908468334545L, a);
            c<"Å">(this, 友树树何何树树何何树.s(targetSnakeGameX, startX, this.n(1.0F)), -4157548548276541782L, a);
            c<"Å">(this, 友树树何何树树何何树.s(targetConfigButtonX, startX, this.n(1.0F)), -4160128332837618138L, a);
            c<"Å">(this, 友树树何何树树何何树.s(targetSearchBarX, startX, this.n(1.0F)), -4152562734255179026L, a);
         }

         if (c<"X">(this, -4157014786612928802L, a)) {
            float progress = 1.0F - c<"X">(this, -4160532907978890955L, a);
            c<"Å">(this, 友树树何何树树何何树.s(targetKeyBindX, startX, this.n(progress)), -4155415908468334545L, a);
            c<"Å">(this, 友树树何何树树何何树.s(targetSnakeGameX, startX, this.n(progress)), -4157548548276541782L, a);
            c<"Å">(this, 友树树何何树树何何树.s(targetConfigButtonX, startX, this.n(progress)), -4160128332837618138L, a);
            c<"Å">(this, 友树树何何树树何何树.s(targetSearchBarX, startX, this.n(progress)), -4152562734255179026L, a);
         }

         c<"Å">(this, 友树树何何树树何何树.s(startX, targetKeyBindX, this.n(c<"X">(this, -4160532907978890955L, a))), -4155415908468334545L, a);
         c<"Å">(this, 友树树何何树树何何树.s(startX, targetSnakeGameX, this.n(c<"X">(this, -4160532907978890955L, a))), -4157548548276541782L, a);
         c<"Å">(this, 友树树何何树树何何树.s(startX, targetConfigButtonX, this.n(c<"X">(this, -4160532907978890955L, a))), -4160128332837618138L, a);
         c<"Å">(this, 友树树何何树树何何树.s(startX, targetSearchBarX, this.n(c<"X">(this, -4160532907978890955L, a))), -4152562734255179026L, a);
      }
   }

   private void D() {
      long a = 树友树友何何友友何何.a ^ 71654104093868L;
      c<"ý">(5210200658023695402L, a);
      if (c<"X">(this, 5216728294187053692L, a) == null) {
         c<"Å">(this, new ArrayList(), 5214027965925778161L, a);
      } else {
         List<Module> allModules = Cherish.instance
            .getModuleManager()
            .k()
            .stream()
            .filter(
               m -> {
                  long ax = 树友树友何何友友何何.a ^ 86557559923544L;
                  c<"ý">(4592077838151398366L, ax);
                  return c<"X">(this, 4592333827891063352L, ax).isEmpty()
                     || m.i().toLowerCase().contains(c<"X">(this, 4592333827891063352L, ax).toLowerCase())
                     || m.Q().toLowerCase().contains(c<"X">(this, 4592333827891063352L, ax).toLowerCase());
               }
            )
            .collect(Collectors.toList());
         int selectedKeyCode = c<"X">(c<"X">(this, 5216728294187053692L, a), 5211217224948431252L, a);
         allModules.sort((m1, m2) -> {
            long ax = 树友树友何何友友何何.a ^ 23173348225567L;
            c<"ý">(-1225808280931409255L, ax);
            boolean m1BoundToKey = m1.W() == selectedKeyCode;
            boolean m2BoundToKey = m2.W() == selectedKeyCode;
            if (m1BoundToKey && !m2BoundToKey) {
               return -1;
            } else {
               return !m1BoundToKey && m2BoundToKey ? 1 : m1.i().compareToIgnoreCase(m2.i());
            }
         });
         c<"Å">(this, allModules, 5214027965925778161L, a);
      }
   }

   private void F(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      long a = 树友树友何何友友何何.a ^ 22593574011896L;
      long ax = a ^ 119825750459940L;
      ClientUtils.o(new Object[]{ax});
      友何何树友何何何何树 buttonFont = Cherish.instance.h().n(16);
      String buttonTextString = a<"o">(32726, 2525323640955965269L ^ a);
      boolean hoveringKeyBind = this.b(c<"X">(this, -6981276126610015898L, a), c<"X">(this, -6985740111717545359L, a), 80.0F, 20.0F, mouseX, mouseY);
      if (hoveringKeyBind != c<"X">(this, -6985326079908154977L, a)) {
         c<"Å">(this, hoveringKeyBind, -6985326079908154977L, a);
      }

      Color baseColor = new Color(60, 60, 60, 255);
      Color hoverColor = new Color(80, 80, 80, 255);
      int r = (int)友树树何何树树何何树.s(baseColor.getRed(), hoverColor.getRed(), c<"X">(this, -6988296618386118676L, a));
      int g = (int)友树树何何树树何何树.s(baseColor.getGreen(), hoverColor.getGreen(), c<"X">(this, -6988296618386118676L, a));
      int b = (int)友树树何何树树何何树.s(baseColor.getBlue(), hoverColor.getBlue(), c<"X">(this, -6988296618386118676L, a));
      Color keyBindBgColor = new Color(r, g, b, 255);
      RenderUtils.drawRectangle(
         guiGraphics.pose(), c<"X">(this, -6981276126610015898L, a), c<"X">(this, -6985740111717545359L, a), 80.0F, 20.0F, keyBindBgColor.getRGB()
      );
      Color accentColor = new Color(100, 100, 100, 255);
      RenderUtils.drawRectangle(
         guiGraphics.pose(), c<"X">(this, -6981276126610015898L, a), c<"X">(this, -6985740111717545359L, a) + 20.0F - 2.0F, 80.0F, 2.0F, accentColor.getRGB()
      );
      buttonFont.L(
         guiGraphics.pose(),
         buttonTextString,
         c<"X">(this, -6981276126610015898L, a) + 40.0F,
         c<"X">(this, -6985740111717545359L, a) + 10.0F - buttonFont.K() / 2,
         new Color(220, 220, 220).getRGB()
      );
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 63;
               case 1 -> 40;
               case 2 -> 3;
               case 3 -> 16;
               case 4 -> 60;
               case 5 -> 14;
               case 6 -> 4;
               case 7 -> 19;
               case 8 -> 54;
               case 9 -> 10;
               case 10 -> 22;
               case 11 -> 13;
               case 12 -> 11;
               case 13 -> 53;
               case 14 -> 56;
               case 15 -> 0;
               case 16 -> 32;
               case 17 -> 41;
               case 18 -> 51;
               case 19 -> 43;
               case 20 -> 17;
               case 21 -> 55;
               case 22 -> 61;
               case 23 -> 28;
               case 24 -> 9;
               case 25 -> 8;
               case 26 -> 18;
               case 27 -> 46;
               case 28 -> 59;
               case 29 -> 52;
               case 30 -> 48;
               case 31 -> 20;
               case 32 -> 25;
               case 33 -> 45;
               case 34 -> 12;
               case 35 -> 39;
               case 36 -> 42;
               case 37 -> 5;
               case 38 -> 24;
               case 39 -> 23;
               case 40 -> 29;
               case 41 -> 1;
               case 42 -> 35;
               case 43 -> 58;
               case 44 -> 57;
               case 45 -> 7;
               case 46 -> 49;
               case 47 -> 15;
               case 48 -> 36;
               case 49 -> 21;
               case 50 -> 26;
               case 51 -> 44;
               case 52 -> 34;
               case 53 -> 38;
               case 54 -> 33;
               case 55 -> 2;
               case 56 -> 50;
               case 57 -> 6;
               case 58 -> 47;
               case 59 -> 62;
               case 60 -> 37;
               case 61 -> 31;
               case 62 -> 30;
               default -> 27;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private void i() {
      long a = 树友树友何何友友何何.a ^ 136313019687310L;
      c<"ý">(9037707637322707208L, a);
      if (c<"X">(this, 9041168809390028511L, a)) {
         long elapsedTime = System.currentTimeMillis() - c<"X">(this, 9039628057229057011L, a);
         c<"Å">(this, Math.min(1.0F, (float)elapsedTime / 200.0F), 9034748006742202996L, a);
         if (c<"X">(this, 9034748006742202996L, a) >= 1.0F) {
            c<"Å">(this, false, 9041168809390028511L, a);
         }
      }

      if (c<"X">(this, 9038439713924875799L, a)) {
         long elapsedTime = System.currentTimeMillis() - c<"X">(this, 9039628057229057011L, a);
         c<"Å">(this, Math.max(0.0F, 1.0F - (float)elapsedTime / 200.0F), 9034748006742202996L, a);
         if (c<"X">(this, 9034748006742202996L, a) <= 0.0F) {
            c<"Å">(this, false, 9038439713924875799L, a);
            c<"Å">(this, false, 9037057752761945216L, a);
            c<"Å">(this, false, 9040163234075113809L, a);
         }
      }

      if (c<"X">(this, 9037057752761945216L, a)) {
         c<"Å">(this, 1.0F, 9034748006742202996L, a);
      }

      c<"Å">(this, 0.0F, 9034748006742202996L, a);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友树友何何友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void b() {
      long a = 树友树友何何友友何何.a ^ 43093286572731L;
      c<"Å">(this, c<"í">(5641002919437167590L, a), 5644594688069336759L, a);
      c<"Å">(this, true, 5640076530929254829L, a);
      c<"Å">(this, System.currentTimeMillis(), 5645652676191029985L, a);
      c<"Å">(this, false, 5639188594043323897L, a);
      this.w();
      c<"Å">(this, false, 5641827732659831607L, a);
   }

   private boolean b(float x, float y, float width, float height, double mouseX, double mouseY) {
      long a = 树友树友何何友友何何.a ^ 27798707056512L;
      c<"ý">(-5520848509988323578L, a);
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'X' && var8 != 197 && var8 != 237 && var8 != 'q') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 196) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 253) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'X') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 197) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 237) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 16684;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树友何何友友何何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private void b(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      long a = 树友树友何何友友何何.a ^ 49723228226431L;
      long ax = a ^ 93795473786531L;
      c<"ý">(-6945335717170867207L, a);
      if (c<"X">(this, -6945884446317465999L, a) || c<"X">(this, -6944643220772985626L, a)) {
         if (!(c<"X">(this, -6948902829997197179L, a) <= 0.01F)) {
            ClientUtils.o(new Object[]{ax});
            友何何树友何何何何树 textFont = Cherish.instance.h().n(14);
            友何何树友何何何何树 placeholderAndListFont = Cherish.instance.h().n(14);
            String inputPlaceholderString = a<"o">(9592, 4537663238439654690L ^ a);
            String saveTextString = a<"o">(9303, 8399861018917983324L ^ a);
            String loadTextString = a<"o">(8679, 4005718121952301540L ^ a);
            String availableText = a<"o">(22475, 2734487246925506475L ^ a);
            c<"Å">(this, c<"X">(this, -6950741419447179288L, a) + 40.0F - 90.0F, -6949236374894850038L, a);
            c<"Å">(this, c<"X">(this, -6949427859250734475L, a) - 200.0F - 5.0F, -6950168111133617122L, a);
            if (c<"X">(this, -6949236374894850038L, a) < 5.0F) {
               c<"Å">(this, 5.0F, -6949236374894850038L, a);
            }

            if (c<"X">(this, -6949236374894850038L, a) + 180.0F > c<"X">(this, -6945794102389066323L, a) - 5) {
               c<"Å">(this, c<"X">(this, -6945794102389066323L, a) - 5 - 180.0F, -6949236374894850038L, a);
            }

            if (c<"X">(this, -6950168111133617122L, a) < 5.0F) {
               c<"Å">(this, 5.0F, -6950168111133617122L, a);
            }

            int animatedAlpha = (int)(230.0F * c<"X">(this, -6948902829997197179L, a));
            if (animatedAlpha >= 4) {
               RenderUtils.drawRoundedRect(
                  guiGraphics.pose(),
                  c<"X">(this, -6949236374894850038L, a),
                  c<"X">(this, -6950168111133617122L, a),
                  180.0,
                  200.0,
                  5.0,
                  new Color(30, 30, 30, animatedAlpha)
               );
               float currentY = c<"X">(this, -6950168111133617122L, a) + 5.0F;
               RenderUtils.drawRoundedRect(
                  guiGraphics.pose(), c<"X">(this, -6949236374894850038L, a) + 5.0F, currentY, 170.0, 20.0, 3.0, new Color(45, 45, 45, animatedAlpha)
               );
               String inputText = c<"X">(this, -6949601710577500594L, a)
                  + (
                     c<"X">(this, -6952350216073700448L, a)
                           && System.currentTimeMillis() / b<"u">(27098, 5020798829653964642L ^ a) % b<"u">(6189, 2472654691193505431L ^ a) == 0L
                        ? "_"
                        : ""
                  );
               if (c<"X">(this, -6949601710577500594L, a).isEmpty() && !c<"X">(this, -6952350216073700448L, a)) {
                  placeholderAndListFont.c(
                     guiGraphics.pose(),
                     inputPlaceholderString,
                     c<"X">(this, -6949236374894850038L, a) + 5.0F + 4.0F,
                     currentY + (20.0F - placeholderAndListFont.K()) / 2.0F,
                     new Color(150, 150, 150, animatedAlpha).getRGB()
                  );
               }

               textFont.c(
                  guiGraphics.pose(),
                  inputText,
                  c<"X">(this, -6949236374894850038L, a) + 5.0F + 4.0F,
                  currentY + (20.0F - textFont.K()) / 2.0F,
                  new Color(220, 220, 220, animatedAlpha).getRGB()
               );
               currentY += 25.0F;
               c<"Å">(this, 20.0F, -6946536515761938322L, a);
               float configPopupSaveButtonX = c<"X">(this, -6949236374894850038L, a) + 5.0F;
               float configPopupLoadButtonX = c<"X">(this, -6949236374894850038L, a) + 5.0F + 82.5F + 5.0F;
               c<"Å">(
                  this,
                  this.b(configPopupSaveButtonX, currentY, 82.5F, c<"X">(this, -6946536515761938322L, a), mouseX, mouseY)
                     && c<"X">(this, -6948902829997197179L, a) > 0.9F,
                  -6949139939017149718L,
                  a
               );
               c<"Å">(
                  this,
                  this.b(configPopupLoadButtonX, currentY, 82.5F, 20.0F, mouseX, mouseY) && c<"X">(this, -6948902829997197179L, a) > 0.9F,
                  -6951874233290677401L,
                  a
               );
               Color saveBtnColor = c<"X">(this, -6949139939017149718L, a) ? new Color(70, 100, 70, animatedAlpha) : new Color(50, 80, 50, animatedAlpha);
               RenderUtils.drawRoundedRect(
                  guiGraphics.pose(), configPopupSaveButtonX, currentY, 82.5, c<"X">(this, -6946536515761938322L, a), 3.0, saveBtnColor
               );
               textFont.L(
                  guiGraphics.pose(),
                  saveTextString,
                  configPopupSaveButtonX + 41.25F,
                  currentY + (c<"X">(this, -6946536515761938322L, a) - textFont.K()) / 2.0F,
                  new Color(220, 220, 220, animatedAlpha).getRGB()
               );
               Color loadBtnColor = c<"X">(this, -6951874233290677401L, a) ? new Color(70, 70, 100, animatedAlpha) : new Color(50, 50, 80, animatedAlpha);
               RenderUtils.drawRoundedRect(guiGraphics.pose(), configPopupLoadButtonX, currentY, 82.5, 20.0, 3.0, loadBtnColor);
               textFont.L(
                  guiGraphics.pose(),
                  loadTextString,
                  configPopupLoadButtonX + 41.25F,
                  currentY + (20.0F - textFont.K()) / 2.0F,
                  new Color(220, 220, 220, animatedAlpha).getRGB()
               );
               currentY += c<"X">(this, -6946536515761938322L, a) + 5.0F;
               placeholderAndListFont.c(
                  guiGraphics.pose(), availableText, c<"X">(this, -6949236374894850038L, a) + 5.0F, currentY, new Color(180, 180, 180, animatedAlpha).getRGB()
               );
               float listStartY = currentY + (placeholderAndListFont.K() + 2);
               float listHeight = c<"X">(this, -6950168111133617122L, a) + 200.0F - 5.0F - listStartY;
               float listRenderY = listStartY - c<"X">(this, -6951852473372384362L, a);
               guiGraphics.enableScissor(
                  (int)(c<"X">(this, -6949236374894850038L, a) + 5.0F),
                  (int)listStartY,
                  (int)(c<"X">(this, -6949236374894850038L, a) + 180.0F - 5.0F),
                  (int)(listStartY + listHeight)
               );
               Iterator totalContentHeight = c<"X">(this, -6938263110850840737L, a).iterator();
               if (totalContentHeight.hasNext()) {
                  String configName = (String)totalContentHeight.next();
                  if (listRenderY + 20.0F > listStartY && listRenderY < listStartY + listHeight) {
                     boolean hoveringItem = this.b(c<"X">(this, -6949236374894850038L, a) + 5.0F, listRenderY, 170.0F, 20.0F, mouseX, mouseY)
                        && mouseY >= listStartY
                        && mouseY <= listStartY + listHeight
                        && c<"X">(this, -6948902829997197179L, a) > 0.9F;
                     if (hoveringItem) {
                        RenderUtils.drawRoundedRect(
                           guiGraphics.pose(),
                           c<"X">(this, -6949236374894850038L, a) + 5.0F,
                           listRenderY,
                           170.0,
                           20.0,
                           2.0,
                           new Color(60, 60, 60, animatedAlpha)
                        );
                     }

                     placeholderAndListFont.c(
                        guiGraphics.pose(),
                        configName,
                        c<"X">(this, -6949236374894850038L, a) + 5.0F + 4.0F,
                        listRenderY + (20.0F - placeholderAndListFont.K()) / 2.0F,
                        new Color(200, 200, 200, animatedAlpha).getRGB()
                     );
                  }

                  float var10000 = listRenderY + 20.0F;
               }

               guiGraphics.disableScissor();
               float totalContentHeightx = c<"X">(this, -6938263110850840737L, a).size() * 20.0F;
               if (totalContentHeightx > listHeight) {
                  float scrollBarHeightRatio = listHeight / totalContentHeightx;
                  float scrollBarActualHeight = Math.max(10.0F, scrollBarHeightRatio * listHeight);
                  float scrollBarYPosRatio = totalContentHeightx - listHeight == 0.0F
                     ? 0.0F
                     : c<"X">(this, -6951852473372384362L, a) / (totalContentHeightx - listHeight);
                  float scrollBarY = listStartY + scrollBarYPosRatio * (listHeight - scrollBarActualHeight);
                  RenderUtils.drawRectangle(
                     guiGraphics.pose(),
                     c<"X">(this, -6949236374894850038L, a) + 180.0F - 5.0F - 3.0F,
                     scrollBarY,
                     2.0F,
                     scrollBarActualHeight,
                     new Color(100, 100, 100, animatedAlpha).getRGB()
                  );
               }
            }
         }
      }
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友树友何何友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private float n(float progress) {
      long a = 树友树友何何友友何何.a ^ 9518000383656L;
      c<"ý">(-5023184397287705042L, a);
      return 1.0F;
   }

   private void h(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      long a = 树友树友何何友友何何.a ^ 130822434735488L;
      long ax = a ^ 15994902724700L;
      c<"ý">(-2782540445921979130L, a);
      ClientUtils.o(new Object[]{ax});
      友何何树友何何何何树 closeButtonFont = Cherish.instance.h().z(20);
      友何何树友何何何何树 virtualKeyFont = Cherish.instance.h().n(14);
      友何何树友何何何何树 contextMenuModuleFont = Cherish.instance.h().n(16);
      友何何树友何何何何树 contextMenuSearchFont = Cherish.instance.h().n(14);
      String closeTextString = a<"o">(32701, 5070896676971923838L ^ a);
      float keyboardAlpha = Mth.clamp(c<"X">(this, -2783095837888266418L, a) * 1.5F, 0.0F, 1.0F);
      if (c<"X">(this, -2778255839246586347L, a) > 0.0F
         && c<"X">(this, -2777465433616754317L, a) > 0.0F
         && c<"X">(this, -2774983843898784289L, a) + c<"X">(this, -2777465433616754317L, a) > -20.0F
         && c<"X">(this, -2774983843898784289L, a) < c<"X">(this, -2781622156001815435L, a) + 20.0F) {
         RenderUtils.drawRoundedRect(
            guiGraphics.pose(),
            c<"X">(this, -2777974011486376328L, a),
            c<"X">(this, -2774983843898784289L, a),
            c<"X">(this, -2778255839246586347L, a),
            c<"X">(this, -2777465433616754317L, a),
            5.0,
            new Color(30, 30, 30, (int)(220.0F * keyboardAlpha))
         );
         if (keyboardAlpha >= 0.1F) {
            Iterator closeButtonOpacity = c<"X">(this, -2781427107980573672L, a).iterator();
            if (closeButtonOpacity.hasNext()) {
               树友树友何何友友何何.友何树树树树何树何友 key = (树友树友何何友友何何.友何树树树树何树何友)closeButtonOpacity.next();
               key.m(guiGraphics, mouseX, mouseY, virtualKeyFont, c<"X">(this, -2774983843898784289L, a), keyboardAlpha);
            }
         }
      }

      if (c<"X">(this, -2779018678234748532L, a) == c<"í">(-2777718702471643939L, a)
         || c<"X">(this, -2779018678234748532L, a) == c<"í">(-2777027661037114596L, a)) {
         float maxY = c<"X">(this, -2782291849896669591L, a);
         float relativePos = (c<"X">(this, -2776204339814962692L, a) - -40.0F) / (maxY - -40.0F);
         this.n(relativePos);
      }

      float closeButtonOpacity = c<"X">(this, -2776119611447668030L, a) ? 1.0F : 0.0F;
      boolean hoveringClose = this.b(c<"X">(this, -2774463001120723025L, a), c<"X">(this, -2776204339814962692L, a), 80.0F, 30.0F, mouseX, mouseY);
      if (hoveringClose != c<"X">(this, -2782143641374449668L, a)) {
         c<"Å">(this, hoveringClose, -2782143641374449668L, a);
      }

      Color closeBaseColor = new Color(60, 60, 60, 255);
      Color closeHoverColor = new Color(80, 80, 80, 255);
      int closeR = (int)友树树何何树树何何树.s(closeBaseColor.getRed(), closeHoverColor.getRed(), c<"X">(this, -2774391279246637418L, a));
      int closeG = (int)友树树何何树树何何树.s(closeBaseColor.getGreen(), closeHoverColor.getGreen(), c<"X">(this, -2774391279246637418L, a));
      int closeB = (int)友树树何何树树何何树.s(closeBaseColor.getBlue(), closeHoverColor.getBlue(), c<"X">(this, -2774391279246637418L, a));
      Color closeBgColor = new Color(closeR, closeG, closeB, (int)(255.0F * closeButtonOpacity));
      RenderUtils.drawRoundedRect(
         guiGraphics.pose(), c<"X">(this, -2774463001120723025L, a), c<"X">(this, -2776204339814962692L, a), 80.0, 30.0, 3.0, closeBgColor
      );
      closeButtonFont.L(
         guiGraphics.pose(),
         closeTextString,
         c<"X">(this, -2774463001120723025L, a) + 40.0F,
         c<"X">(this, -2776204339814962692L, a) + 15.0F - closeButtonFont.K() / 2,
         new Color(220, 220, 220, (int)(255.0F * closeButtonOpacity)).getRGB()
      );
      if ((c<"X">(this, -2775326215847162430L, a) || c<"X">(this, -2778890154524767759L, a))
         && c<"X">(this, -2789490210863045808L, a) != null
         && c<"X">(this, -2776533906564910115L, a) != null
         && c<"X">(this, -2777388980353240717L, a) > 0.01F) {
         float menuX = c<"X">(this, -2774305757190261565L, a);
         float menuY = c<"X">(this, -2775886201953770037L, a);
         if (menuX + 150.0F > c<"X">(this, -2781871268008037550L, a)) {
            menuX = c<"X">(this, -2781871268008037550L, a) - 150.0F;
         }

         if (menuY + 150.0F + 20.0F > c<"X">(this, -2781622156001815435L, a)) {
            menuY = c<"X">(this, -2781622156001815435L, a) - 150.0F - 20.0F;
         }

         if (menuX < 0.0F) {
            menuX = 0.0F;
         }

         if (menuY < 0.0F) {
            menuY = 0.0F;
         }

         int animatedAlpha = (int)(230.0F * c<"X">(this, -2777388980353240717L, a));
         float listY = menuY + 20.0F;
         RenderUtils.drawRoundedRect(guiGraphics.pose(), menuX, menuY, 150.0, 20.0, 3.0, new Color(25, 25, 25, animatedAlpha));
         contextMenuSearchFont.c(
            guiGraphics.pose(),
            c<"X">(this, -2782372399932764960L, a)
               + (
                  c<"X">(this, -2778547640610417652L, a)
                        && System.currentTimeMillis() / b<"u">(5339, 8374343037535718557L ^ a) % b<"u">(15352, 6994954562994742204L ^ a) == 0L
                     ? "_"
                     : ""
               ),
            menuX + 4.0F,
            menuY + (20.0F - contextMenuSearchFont.K()) / 2.0F,
            new Color(200, 200, 200, animatedAlpha).getRGB()
         );
         RenderUtils.drawRoundedRect(guiGraphics.pose(), menuX, listY, 150.0, 150.0, 3.0, new Color(30, 30, 30, animatedAlpha));
         guiGraphics.enableScissor((int)menuX + 1, (int)listY + 1, (int)(menuX + 150.0F - 2.0F), (int)(listY + 150.0F - 2.0F));
         float itemHeight = contextMenuModuleFont.K() + 4;
         float currentItemY = listY + 2.0F - c<"X">(this, -2775496494263984581L, a);
         if (c<"X">(this, -2776533906564910115L, a) != null) {
            Iterator totalContentHeight = c<"X">(this, -2776533906564910115L, a).iterator();
            if (totalContentHeight.hasNext()) {
               Module module = (Module)totalContentHeight.next();
               if (currentItemY + itemHeight > listY && currentItemY < listY + 150.0F) {
                  boolean isHoveringItem = mouseX >= menuX
                     && mouseX <= menuX + 150.0F
                     && mouseY >= currentItemY
                     && mouseY <= currentItemY + itemHeight
                     && mouseY >= listY + 1.0F
                     && mouseY <= listY + 150.0F - 1.0F;
                  if (isHoveringItem) {
                     RenderUtils.drawRoundedRect(
                        guiGraphics.pose(),
                        menuX + 1.0F,
                        currentItemY,
                        148.0,
                        itemHeight,
                        2.0,
                        new Color(80, 80, 80, (int)(180.0F * c<"X">(this, -2777388980353240717L, a)))
                     );
                  }

                  Color textColor = module.W() == c<"X">(c<"X">(this, -2789490210863045808L, a), -2774848882958849864L, a)
                     ? c<"í">(-2775643728307561455L, a)
                     : c<"í">(-2774591319356831319L, a);
                  String moduleDisplayName = module.i();
                  contextMenuModuleFont.c(
                     guiGraphics.pose(),
                     moduleDisplayName,
                     menuX + 5.0F,
                     currentItemY + 2.0F,
                     new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), (int)(255.0F * c<"X">(this, -2777388980353240717L, a))).getRGB()
                  );
               }

               float var10000 = currentItemY + itemHeight;
            }
         }

         guiGraphics.disableScissor();
         float totalContentHeight = c<"X">(this, -2776533906564910115L, a).size() * itemHeight;
         if (totalContentHeight > 150.0F) {
            float scrollBarHeight = Math.max(10.0F, 150.0F / totalContentHeight * 150.0F);
            float scrollBarY = listY
               + (totalContentHeight - 150.0F == 0.0F ? 0.0F : c<"X">(this, -2775496494263984581L, a) / (totalContentHeight - 150.0F))
                  * (150.0F - scrollBarHeight);
            RenderUtils.drawRectangle(
               guiGraphics.pose(),
               menuX + 150.0F - 5.0F,
               scrollBarY,
               3.0F,
               scrollBarHeight,
               new Color(100, 100, 100, (int)(200.0F * c<"X">(this, -2777388980353240717L, a))).getRGB()
            );
         }
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static Module[] l() {
      return 友友树树树何树树何何;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private void d() {
      long a = 树友树友何何友友何何.a ^ 135762562845016L;
      c<"Å">(this, true, -7657222566891215786L, a);
      c<"Å">(this, true, -7660992809276514807L, a);
      c<"Å">(this, false, -7658092404476580159L, a);
      c<"Å">(this, 0.0F, -7658406411394518366L, a);
      c<"Å">(this, System.currentTimeMillis(), -7663660562407869659L, a);
      c<"Å">(this, 0.0F, -7664746947823408719L, a);
      this.H();
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28642;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树友何何友友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static void a() {
      i[0] = "VU\u0017P9\"Y\u0015Z[3?\\HQ\u001d#$\u001b株史栢厝优你台史佦伃";
      i[1] = "hvS1>ccyB~DgpxR1rcg";
      i[2] = "L>U;]oG1Dt wT6M=";
      i[3] = float.class;
      j[3] = "java/lang/Float";
      i[4] = "\u0001qlty\u001c\u001fyv;\u001b\u0000\u0018d";
      i[5] = boolean.class;
      j[5] = "java/lang/Boolean";
      i[6] = long.class;
      j[6] = "java/lang/Long";
      i[7] = "D\u000f\u001av>&p,\u00156s-z1\u0010kxkr,\u001dm| 1\u000e\u0016|e)zx";
      i[8] = int.class;
      j[8] = "java/lang/Integer";
      i[9] = "\u001b\t\u00021Ma\u0014IO:G|\u0011\u0014D|WgV桶叧桃叩佛伭厬叧伇佷*桩桶叧厙栳佛厳桶叧桃";
      i[10] = "c0@Evf}8Z\n\u001b|d!WV9gf#";
      i[11] = "{#_\u00044'f6\u0007&u*~0";
      i[12] = "_d\u0005n_TP$HeUIUyC#ER\u0012栛叠栜叻佮佩叁叠佘佥\u001f号佟栺栜校株佩栛佾叆";
      i[13] = "'Ny\u0006x_(\u000e4\rrB-S?Kz_ U;\u00009佥休叫伂估叜佥休栱框";
      i[14] = "{\u001a~zAwtZ3qKjq\u000787[q6桥厛栈栿叓叓桥桁栈句";
      i[15] = "#)h59\f\u0017\ngut\u0007\u001d\u0017b(\u007fA\u0015\no.{\nV(d?b\u0003\u001d^";
      i[16] = void.class;
      j[16] = "java/lang/Void";
      i[17] = "}=\u007f]\u0017+c5e\u0012q?d4D]I";
      i[18] = "V!z~v\u0002Ya7u|\u001f\\<<3l\u0004\u001b桞原栌叒伸你厄原佈佌I你桞桅栌栈桼叾厄企栌";
      i[19] = "\u0003#fZ\u001b\u0012\fc+Q\u0011\u000f\t> \u0017\u0001\u0014N桜桙史伡伨伵历厃栨伡";
      i[20] = "=\n7}\u0011b6\u0005&2pl=\u000e\"h";
      i[21] = "X};2g\rWx(\u0003bu\u000e\"1gy\u0011K%,s\u000bL\t{2qo\t\u000ef&\u0003";
      i[22] = "i~H3\u001cHf{[\u0002厳佭栟叜格叁桩右佛叜%8N\bv!]z\u001a\\b";
      i[23] = "\u0014O/\u001cAgAV(\u0017/伂伢佬伕桧栶框伢佬压~\u00162\u0019CwC]2\u0018J";
      i[24] = "S\u001b\u001c2Pn\\\u001e\u000f\u0003叿叕叿厹伬栚佡佋叿档q:QpNELqQqG";
      i[25] = "\u001azgX\u0015\u0018\u0015\u007fti厺厣厶变叉厪厺伽桬变\nR\u0005\u0000\u0014f1\f\u0012[\u000e";
      i[26] = "9W(\u000bPJ6R;:佡佯厕栯桜栣栥佯桏佫E\u0001@R7K~_W\t-";
      i[27] = "\u001c$\bNF\u0017\u0013!\u001b\u007f佷厬桪优伸桦栳伲厰优eE\u0014W\u0003{\u001d\u0007@\u0003\u0017";
      i[28] = "$*r[\u000b\\+/aj桾佹厈桒叜桳桾佹桒伖\u001fPY\u001c;ug\u0012\rH/";
      i[29] = "\u0015uRiN\\\u001apAX叡佹厹受叼厛叡佹档受?b\u001c\u001c\n*G HH\u001e";
      i[30] = "\u001fh3H<cJq4CR厘伩叕桍佷桋伆厷佋伉*heLfjR*1\u0018r";
      i[31] = "w8!\u001dGWx=2,佶佲佅桀厏可叨佲叛桀L\u0012\u001bTq5u\u0010B\u0014i";
      i[32] = "~>f\"~Zq;u\u0013栋使栈伂栒低栋栻叒框\u000b\"q@*>mz/Cs";
      i[33] = "Rf`&E6U)7y{及栢桀栕佁厸佔司桀叏\u001cA7\u0003)2d\u0003cW=";
      i[34] = "U80n#\u0006Z=#_伒伣佧厚伀框桖桧佧伄]eqFJg%'%\u0012^";
      i[35] = "n\b)1n]a\r:\u0000叁另参厪桝佝栛格作厪D:<\u001dqW<xhIe";
      i[36] = "zA\nB}f}\u000e]\u001dC厚低桧桿桡桚桀叐桧桿xr:qE\u0007\u001e*dr\u001c";
      i[37] = "^\u00192\f^eQ\u001c!=叱叞史伥厜叾佯佀栨桡_\u0007\f%AF'EXqU";
      i[38] = "\"FgGE\u0018 \u001f'_)佼叟伫佁样只佼叟厵佁.\u0017\u0011g\u001fp\u0017\u0015H'\u0007";
      i[39] = "MK0X\\BBN#i佭栣栻叩伀伴栩佧叡叩]RLZCWf\f[\u0001Y";
      i[40] = "c\u001fWvCul\u001aDG召栔叏伣栣厄佲収佑桧:~Bk~A\u00075Bjw";
      i[41] = "R\u0003L0g%]\u0006_\u0001栒桄栤伿核参栒桄你桻!;5eM\\Yya1Y";
      i[42] = "s\u001eh\u000fN8&\u0007o\u0004 參栁伽栖估根佝栁厣栖m\u001a> \u00101\u0015Xjt\u0004";
      i[43] = "\u0017)rZ\u0017\u000b\u0018,ak伦桪伥压叜伶桢厰伥伕\u001fP\u0007\u0013\u00195$\u000e\u0010H\u0003";
      i[44] = "N(m\u001f\u0018VA-~.桭样核伔參佳厷样核桐\u0000\u0012EG\u0010+{\u0015\u0015TK";
      i[45] = "\u0013\"\" 9D\u001c'1\u00111<\u0015:, )\u0005G!=uU";
      i[46] = "\u0012Z\u0003o'O\u001d_\u0010^伖叴传栢桷厝伖栮厾司ndu\u000f\r\u0005\u0016&![\u0019";
      i[47] = "}M\u000eiWe\u007fUY%.Y\u0003dw\u0004yR\u0018bfX\u0011{{\u001aN \u0013c,V";
      i[48] = "|\u0017\u0015 \u0004}s\u0012\u0006\u0011桱叆低厵桡佌厫叆叐厵x+V=cH\u0000i\u0002iw";
      i[49] = "w },lbuy=4\u0000伆伔栉栟优參桂伔栉佛E>k2yj|<2ra";
      i[50] = "lV!\u000b\u0004\u0012cS2:\u0006=2\tq\u0006T=\u0003\trG\u0010\u00159H5]\t";
      i[51] = ")`\u0002\u0003J)&e\u00112句厒伛作伲栫佻伌桟参o\b\u0018i6?\u0017JL=\"";
      i[52] = "BgL'_OMb_\u0016佮叴叮栟佼栏台栮佰叅!-OWL{\u001asX\fV";
      i[53] = "l]!th*cX2E余厑佞佡休历叇伏佞叿L\u007f:js\u00024=n>g";
      i[54] = "Q\u0019nu}MVV9*C桫叻句叁伒伞厱叻佻栛OyL\u0000V<7;\u0018TB";
      i[55] = "v/\u0004cViy*\u0017RTF(pTn\u0001F\u0019pW/Bn#1\u00105[";
      i[56] = "\u0001\u0012Nar\u0005\u000e\u0017]P叝传桷伮栺厓标桤伳伮#j E\u001eM[(t\u0011\n";
      i[57] = "/\\\u00024D\u0001 Y\u0011\u0005併伤伝你厬叆栱桠桙叾o>T\u0019!@T`CB;";
      i[58] = "Cb*W\u001c\u0001Lg9f厳桠佱佞厄桿桩桠栵佞G\\NA\\=?\u001e\u001a\u0015H";
      i[59] = "J\u0002ME<TE\u0007^t桉佱另厠根桭桉佱另桺 O,LD\u001e\u001b\u0011;\u0017^";
      i[60] = "\u0001,s!!i\u000e)`\u0010\u0011\u0011\u00074}!1(U/ltM{\u0007(&j v\u0005\"~\u0010";
      i[61] = "{^O\nB-t[\\;佳伈佉栦叡栢佳厖佉叼\"\u0001^$}ZNYW*l";
      i[62] = "]O^<_^\u0005\u0011]e>叻伱佱栥栞栧叻厯佱佡\u0007\u0007U\n^\u0003:LU\u000bW";
      i[63] = "zNn\u0019\u00048uK}(伵伝取栶佞併桱厃取佲\u0003\u0014Y)$Mx\u0013\t:\u007f";
      i[64] = "y:y\u001a\u0005\u0005v?j+厪厾叕桂受佶厪桤叕桂\u0014\u0010\u0015\u001dw&/N\u0002Fm";
      i[65] = "Yu^7!=VpM\u0006桔历栯受佮佛厎历叵佉3<s}F*K~')R";
      i[66] = "\u0003B@\u0004s9\fGS5栆厂伱佾叮栬叜厂伱栺-\u000f!y\u001c\u001dUMu-\b";
      i[67] = "/\u001e\")m1(QuvS反厅叢厍低桊反桟叢桗\u0013i0~Qpk+d*E";
      i[68] = "\"\t\u0016p]7zW\u0015)<案叐桳伩桒栥案栊厩厷K\u0005<u\u0018KvN<t\u0011";
      i[69] = "\u001c:V\ftC\u0013?E=叛栢厰厘栢栤佅佦厰桂;\f{YH:]T%Z\u0011";
      i[70] = "\u0007\u001c!\u0003C]\b\u001922召佸伵厾休佯佲另伵传L\tSE\t\u0000wWD\u001e\u0013";
      i[71] = "S,S5G'\\)@\u0004叨框叿伐栧叇佶伂佡厎>>\u0015gLsF|A3X";
      i[72] = ",20s\u001cV#7#B厳叭桚桊厞厁厳叭厀伎]y\fN\".f'\u001b\u00158";
      i[73] = "\f\u001ah\n\u00180\u0003\u001f{;伩桑厠厸栜司厷压厠厸\u0005\u0001Jp\u0013E}C\u001e$\u0007";
      i[74] = "N\u0019\u0018W\u0016\u001aA\u001c\u000bf伧桻叢伥伨桿厹桻佼桡u\r@\f\u001c\u0007\u001b\u0018\u001eZK";
      i[75] = "\f,\u0011/aTY5\u0016$\u000f桵桾伏伫伐双桵伺桋厵M5R_\"H5w\u0006\u000b6";
      i[76] = "x\u001eWV\rbw\u001bDg桸佇栎厼栣厤似叙栎伢:]_\"gAB\u001f\u000bvs";
      i[77] = "xB\u001aBoMwG\ts叀栬叔栺厴伮叀栬佊佾wI=\rg\u001d\u000f\u000biYs";
      i[78] = "\u000fo\u0005D\u000e\u0012\u0000j\u0016u厡伷伽体伵厶厡桳伽栗hN\u001e\n\u0001sS\u0010\tQ\u001b";
      i[79] = ".\b0\u001e\u0014#,\u0010gRm\u0010@'O/R=(_pWP%\u007f\u0013";
      i[80] = "\u000e+\b\u001d'z\u0001.\u001b,厈佟桸众厦栵桒栛似众e\u0010zkP(\u001e\u0017*x\u000b";
      i[81] = "\u001f\b\u000eK\u0018\t\u0010\r\u001dz厷伬厳桰桺伧厷桨桩厪c@JI\u0000W\u001b\u0002\u001e\u001d\u0014";
      i[82] = ")hB\u000fK\u0010&mQ>栾伵伛佔栶栧古伵桟佔/\u0004\u0019P67WFM\u0004\"";
      i[83] = "c\u00198~\u0004!4\u000bkdi会厐厴栞佀伴厄伎桮栞\u001dWy.\u000fx'\u0016>4\u0016";
      i[84] = ":Aza\t\u001f5DiP伸伺伈口叔伍桼伺伈佽\u0017k\u0019\u00074],5\u000e\\.";
      i[85] = "-\u0011CXw4\"\u0014Pi但桕桛厳叭伴但厏伟厳.S%t2NV\u0011q &";
      i[86] = ")(\u007fN\u000eR|1xE`伷桛桏佅栵伽厩伟桏叛,Y\u0007$$'\u0011\u0012\u0007%-";
      i[87] = "\u0007gbj&>\bbq[厉伛桱叅栖厘众厅厫栟\u000fat~\u00188w# *\f";
      i[88] = "\u001d:\u0007:\t6\u0012?\u0014\u000b桼伓伯伆桳栒伸厍桫桂j1[v\u0002e\u0012s\u000f\"\u0016";
      i[89] = "X\u0007\u0002&O\u001bW\u0002\u0011\u0017佾桺佪伻伲佊叠厠叴伻o-\u001d[GX\u0017oI\u000fS";
      i[90] = "\u0006\"aXF\u0001\t'ri佷桠桰桚叏桰栳桠桰桚\fS\u0014A\u0019}t\u0011@\u0015\r";
      i[91] = "\u001c?p#=QI&w(S桰桮伜栎伜桊桰伪桘佊AiWO1)9+\u0003\u001b%";
      i[92] = "`\u00028\nESo\u0007+;栰叨双伾桌栢只栲佒厠UR\u0016G5]jUY\u0010j";
      i[93] = "\u0015[UT\u001e?\u001a^Fe伯会伧叹校桼伯桞伧佧8^\u000e'\u001bG\u0003\u0000\u0019|\u0001";
      i[94] = "9}\u0003+kI;eTg\u0012nFZfW\u0012\u000e`\"\u000bcj\fxuG";
      i[95] = "B\rRSy\rM\bAb栌伨叮厯叼桻栌伨佰桵?Yi\u0015L\u0011\u0004\u0007~NV";
      i[96] = "\u000eMAo\u0003\b\u0001HR^厬桩厢栵可桇桶伭厢可,e\u0013\u0010\u0000Q\u0017;\u0004K\u001a";
      i[97] = "GZ\u0001 tUH_\u0012\u0011佅栴併司厯佌栁栴叫栢l(uKZ\u0004QcuJS";
      i[98] = "0x_,Y;?}L\u001d栬桚伂佄栫佀栬伞框栀2'\u000b{/'Je_/;";
      i[99] = "\u00021\u001e68D\r4\r\u0007伉佡估伍桪栞厗栥桴厓s=j\u0004\u001dn\u000b\u007f>P\t";
      i[100] = "/wZ\u0019hy rI(叇参伝叕叴栱叇参伝叕7\u0012:90(OPnm$";
      i[101] = "s2.\u001a\u000b?|7=+伺桞栅厐伞叨桾桞佁伎C\u0011Y\u007flm;S\r+x";
      i[102] = "#\u001f\u0012ye<,\u001a\u0001H栐伙厏桧厼压佔桝厏桧\u007fsu$-\u0003D-b\u007f7";
      i[103] = "VW$Z_-YR7k台伈叺叵伔厨佮伈叺栯IPO5XKr\u000eXnB";
      i[104] = "`mL\u0002Ukg\"\u001b]k伉及伏佽叻伶厗栐厑根8P(i3]\u0003\u000e?2)";
      i[105] = "F{NR\b-I~]c厧桌只栃栺厠伹伈佴栃#YZmY$[\u001b\u000e9M";
      i[106] = "XN\u007fcE;Z\u0017?{)佟厥伣余栓佴叁伻伣余\n\u00172\u001d\u0017h3\u0015k]\u000f";
      i[107] = "\u001d3k\u001dL7\u00126x,佽桖伯桋叅栵口桖伯桋\u0006\u0016\u001ew\u0002l~TJ#\u0016";
      i[108] = "!*4\"\u0014L./'\u0013桡佩伓桒桀低去号桗厈Y)F\f>u!k\u0012X*";
      i[109] = "FCMjg\u0001IF^[佖伤佴叡佽桂佖桠佴栻 g:\u0010\u0018@[`j\u0003C";
      i[110] = "6Z;@Y\u00109_(q佨厫桀司伋厲叶桱厚栢VK\u000bP)\u0005.\t_\u0004=";
      i[111] = "v\u001akg\u0015\u0017jF*k{桼佇传栊栟桢桼叙传叐\u0006\u0017\u0002b\u001c}t\u000b^#\u0010";
      i[112] = "z*Q\u000e|+fv\u0010\u0002\u0012伄佋桔只桶栋桀叕桔只o~>n,G\u001dbb/ ";
      i[113] = "\u001f&\u001dV#%\u0010#\u000eg厌伀厳厄伭伺桖桄桩厄p]qe\u0000y\b\u001f%1\u0014";
      i[114] = "bJP~g^5X\u0003d\n佥厑栽伲佀佗叻厑叧伲\u001d3U4VP xU5_";
      i[115] = "\"`FB`J-eUs佑栫桔参栲桪叏栫厎栘+I2\n=?S\u000bf^)";
      i[116] = "* q\t\bAa p\u000077Z\u0016Z,v:H\u0000Q v R\u0013Z,p&_\u0000M{\b\u001eb3w\u001e\u0007\u001fku";
      i[117] = "$CFG\nx+FUv伻參伖使栲伫伻佝伖使+LX8;\u001cS\u000e\fl/";
      i[118] = "a!\u0002\u001a+in$\u0011+会叒栗桙伲叨厄佌栗厃o\u0011y)~~\u0017S-}j";
      i[119] = "\"\u001fp\u0016;\"-\u001ac'厔厙桔桧叞佺桎厙伐桧\u001d\u001dib=@e_=6)";
      i[120] = "XHv%@\u001eWMe\u0014佱桿叴栰变佉可厥栮栰\u001b/P\u0006VT qG]L";
      i[121] = ":~aB%\u00025{rs伔档厖佂叏厰厊厹伈叜\fH5\u001a4b7\u0016\"A.";
      i[122] = "\naoL.\u000b\u0016=.@@厺桿叅叔栴厃伤厥栟叔-,\u001e\u001egy_0B_k";
      i[123] = "Nw\u0019^PcAr\no叿栂核叕伩桶叿但核佋tULjHs\u0018\rEdY";
      i[124] = "R\u001eKU\u0004@PG\u000bMh厺伱佳佭叿伵伤伱佳右<VI\u0017G\\\u0005T\u0010W_";
      i[125] = "B;W)iZM>D\u0018佘栻叮伇栣栁栜叡叮厙:$4K\u001c8A#dXG";
      i[126] = "y\u00017!lYv\u0004$\u0010栙叢叕厣桃栉栙核栏伽Z+|Aw\u001dauk\u001am";
      i[127] = " g%m\u0002\"/b6\\厭桃厌叅伕原桷桃桖栟Hg\u0012:.{s9\u0005a4";
      i[128] = "D:FDq}K?Uu佀佘佶桂栲厶栄佘佶桂+OmtB>G\u0017dzS";
      i[129] = "\u0006\u001c*W4\u0006\u0001S}\b\n栠伲叠桟厮叉栠伲栺桟m0\u0007WSx\u0015rS\u0003G";
      i[130] = "@l\u007f?3lOil\u000e厜栍召収住体框栍召佐\u0012>1+L`ti#xV";
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友树友何何友友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void p() {
      long a = 树友树友何何友友何何.a ^ 43462047332347L;
      c<"ý">(-1506103018543782019L, a);
      c<"X">(this, -1504989851764050333L, a).clear();
      if (mc != null && mc.getWindow() != null && c<"X">(this, -1504308180163247831L, a) != 0 && c<"X">(this, -1504518800823556594L, a) != 0) {
         Map<String, Integer> glfwKeyMap = this.O();
         if (!glfwKeyMap.isEmpty()) {
            String[][] keyLayout = new String[][]{
               {
                     a<"o">(26705, 7062251714456054999L ^ a),
                     a<"o">(14087, 5867239279411213234L ^ a),
                     a<"o">(22125, 5335277697313067671L ^ a),
                     a<"o">(17239, 6751923373585778626L ^ a),
                     a<"o">(17971, 4762865124298867346L ^ a),
                     a<"o">(27764, 8515802189520136358L ^ a),
                     a<"o">(21027, 592873765982099033L ^ a),
                     a<"o">(14026, 1720504784354685522L ^ a),
                     a<"o">(11301, 3934472589049833670L ^ a),
                     a<"o">(15447, 6009841853131110550L ^ a),
                     a<"o">(16958, 7534575483261503190L ^ a),
                     a<"o">(13598, 2275240257273639413L ^ a),
                     a<"o">(30812, 1935123814620396697L ^ a),
                     a<"o">(3688, 5038935122358733326L ^ a),
                     a<"o">(18762, 5144049543207439791L ^ a),
                     a<"o">(32609, 4456523256612256658L ^ a),
                     a<"o">(29585, 215982919313848157L ^ a),
                     a<"o">(5279, 6430019057330884631L ^ a),
                     a<"o">(27733, 8644584079155259635L ^ a),
                     a<"o">(32499, 2843202715977448017L ^ a),
                     a<"o">(31575, 7363552563871809312L ^ a),
                     a<"o">(2606, 3585192130449805047L ^ a),
                     a<"o">(11002, 343553942525259317L ^ a),
                     a<"o">(7514, 8270286421208865211L ^ a),
                     a<"o">(29923, 8246628933520060440L ^ a),
                     a<"o">(29970, 5435712825576223189L ^ a)
               },
               {
                     "`",
                     a<"o">(26760, 8064868787511454954L ^ a),
                     "1",
                     "1",
                     "2",
                     "2",
                     "3",
                     "3",
                     "4",
                     "4",
                     "5",
                     "5",
                     "6",
                     "6",
                     "7",
                     "7",
                     "8",
                     "8",
                     "9",
                     "9",
                     "0",
                     "0",
                     "-",
                     a<"o">(22171, 502836588437099023L ^ a),
                     "=",
                     a<"o">(15900, 114208472644336245L ^ a),
                     a<"o">(19291, 8800553522983358383L ^ a),
                     a<"o">(23934, 6669646025605536202L ^ a)
               },
               {
                     a<"o">(582, 8507037807316174549L ^ a),
                     a<"o">(30639, 7123400639824556821L ^ a),
                     "Q",
                     "q",
                     "W",
                     "w",
                     "E",
                     "e",
                     "R",
                     "r",
                     "T",
                     "t",
                     "Y",
                     "y",
                     "U",
                     "u",
                     "I",
                     "i",
                     "O",
                     "o",
                     "P",
                     "p",
                     "[",
                     a<"o">(7612, 700125708865968607L ^ a),
                     "]",
                     a<"o">(29139, 3748524507080750509L ^ a),
                     "\\",
                     a<"o">(18894, 2576379463735987464L ^ a)
               },
               {
                     a<"o">(20384, 2206968995979283244L ^ a),
                     a<"o">(25825, 1979211425220517966L ^ a),
                     "A",
                     "a",
                     "S",
                     "s",
                     "D",
                     "d",
                     "F",
                     "f",
                     "G",
                     "g",
                     "H",
                     "h",
                     "J",
                     "j",
                     "K",
                     "k",
                     "L",
                     "l",
                     ";",
                     a<"o">(30350, 5514684690612023850L ^ a),
                     "'",
                     a<"o">(23885, 8320015964567591347L ^ a),
                     a<"o">(1459, 8847482715670905088L ^ a),
                     a<"o">(466, 8666017771466687861L ^ a)
               },
               {
                     a<"o">(9687, 6290611221849940386L ^ a),
                     a<"o">(1011, 3184880117275690858L ^ a),
                     "Z",
                     "z",
                     "X",
                     "x",
                     "C",
                     "c",
                     "V",
                     "v",
                     "B",
                     "b",
                     "N",
                     "n",
                     "M",
                     "m",
                     ",",
                     a<"o">(8798, 4108604005410448943L ^ a),
                     ".",
                     a<"o">(29460, 6722791285609428863L ^ a),
                     "/",
                     a<"o">(16939, 5639191903801624192L ^ a),
                     a<"o">(4608, 98571111789598463L ^ a),
                     a<"o">(26579, 453942702931534762L ^ a)
               },
               {
                     a<"o">(18315, 5060011000570790731L ^ a),
                     a<"o">(18115, 6384708673192477221L ^ a),
                     a<"o">(7290, 2020337967869827297L ^ a),
                     a<"o">(30125, 6256790692689965361L ^ a),
                     a<"o">(23034, 3310616917036293425L ^ a),
                     a<"o">(12710, 713316461145470312L ^ a),
                     a<"o">(30974, 2934683920805198884L ^ a),
                     a<"o">(32054, 1062431463030978999L ^ a),
                     a<"o">(31086, 1230284399847505318L ^ a),
                     a<"o">(18994, 8206351638696513252L ^ a),
                     a<"o">(8314, 1727792568272069863L ^ a),
                     a<"o">(19816, 5686272920039508356L ^ a),
                     a<"o">(11543, 2829269836818295294L ^ a),
                     a<"o">(23544, 3762665098764509008L ^ a)
               }
            };
            List<List<树友树友何何友友何何.何树树树树树友友何树>> tempKeyLayoutDefinitions = new ArrayList<>();
            float currentRelativeY = 0.0F;
            float mainBlockMaxRowWidth = 0.0F;
            int i = 0;
            if (0 < keyLayout.length) {
               List<树友树友何何友友何何.何树树树树树友友何树> currentRowDefinitions = new ArrayList<>();
               float currentRelativeX = 0.0F;
               String[] row = keyLayout[0];
               int j = 0;
               if (0 < row.length) {
                  String displayName = row[0];
                  String internalName = row[1];
                  float w = 22.0F;
                  if (internalName.equals(a<"o">(7382, 8429378351456229381L ^ a))) {
                     w = 44.0F;
                  }

                  if (internalName.equals(a<"o">(10405, 4425434274135780357L ^ a))) {
                     w = 33.0F;
                  }

                  if (internalName.equals(a<"o">(23005, 8682129373987069239L ^ a))) {
                     w = 33.0F;
                  }

                  if (internalName.equals(a<"o">(11908, 7470500699917953641L ^ a))) {
                     w = 38.5F;
                  }

                  if (internalName.equals(a<"o">(29512, 4473143489971582867L ^ a))) {
                     w = 49.5F;
                  }

                  if (internalName.equals(a<"o">(25460, 855831904557983656L ^ a))) {
                     w = 49.5F;
                  }

                  if (internalName.equals(a<"o">(4140, 6182110024724714734L ^ a))) {
                     w = 60.5F;
                  }

                  if (internalName.equals(a<"o">(5537, 196589645839602140L ^ a))
                     || internalName.equals(a<"o">(6961, 8477617672847073155L ^ a))
                     || internalName.equals(a<"o">(24629, 8833517934330995938L ^ a))
                     || internalName.equals(a<"o">(5475, 7562861180536984057L ^ a))) {
                     w = 27.5F;
                  }

                  if (internalName.equals(a<"o">(9398, 8080996284316459079L ^ a)) || internalName.equals(a<"o">(22511, 5898838634932982664L ^ a))) {
                     w = 27.5F;
                  }

                  if (internalName.equals(a<"o">(10175, 5093274139314496448L ^ a))) {
                     w = 132.0F;
                  }

                  if (displayName.equals(a<"o">(18323, 8858043046162187043L ^ a))) {
                     w = 33.0F;
                  }

                  if (displayName.startsWith("F")) {
                     w = 22.0F;
                     if (displayName.equals(a<"o">(2511, 4270203250607263075L ^ a)) || displayName.equals(a<"o">(30141, 6162521328446435614L ^ a))) {
                        currentRelativeX = 11.0F;
                     }
                  }

                  currentRowDefinitions.add(new 树友树友何何友友何何.何树树树树树友友何树(displayName, internalName, currentRelativeX, 0.0F, w, 22.0F));
                  currentRelativeX += w + 3.0F;
                  j += 2;
               }

               if (currentRelativeX - 3.0F > 0.0F) {
                  mainBlockMaxRowWidth = currentRelativeX - 3.0F;
               }

               tempKeyLayoutDefinitions.add(currentRowDefinitions);
               currentRelativeY = 31.0F;
               i++;
            }

            float keysBlockHeight = currentRelativeY - 3.0F;
            float navigationBlockStartX = mainBlockMaxRowWidth + 12.0F;
            树友树友何何友友何何.何树树树树树友友何树 keyInsert = new 树友树友何何友友何何.何树树树树树友友何树(
               a<"o">(11102, 958856228264980381L ^ a), a<"o">(9007, 1927013863674652651L ^ a), navigationBlockStartX, 0.0F, 22.0F, 22.0F
            );
            树友树友何何友友何何.何树树树树树友友何树 keyHome = new 树友树友何何友友何何.何树树树树树友友何树(
               a<"o">(31236, 2463712862834228978L ^ a), a<"o">(12039, 7979581743252941701L ^ a), navigationBlockStartX + 22.0F + 3.0F, 0.0F, 22.0F, 22.0F
            );
            树友树友何何友友何何.何树树树树树友友何树 keyPgUp = new 树友树友何何友友何何.何树树树树树友友何树(
               a<"o">(2061, 7819179123049434259L ^ a), a<"o">(13153, 7772111910517356469L ^ a), navigationBlockStartX + 50.0F, 0.0F, 22.0F, 22.0F
            );
            树友树友何何友友何何.何树树树树树友友何树 keyDel = new 树友树友何何友友何何.何树树树树树友友何树(
               a<"o">(9970, 1716585507871597154L ^ a), a<"o">(862, 5024385303016409064L ^ a), navigationBlockStartX, 25.0F, 22.0F, 22.0F
            );
            树友树友何何友友何何.何树树树树树友友何树 keyEnd = new 树友树友何何友友何何.何树树树树树友友何树(
               a<"o">(13797, 5218001970728317228L ^ a), a<"o">(9114, 3347237768582604582L ^ a), navigationBlockStartX + 22.0F + 3.0F, 25.0F, 22.0F, 22.0F
            );
            树友树友何何友友何何.何树树树树树友友何树 keyPgDn = new 树友树友何何友友何何.何树树树树树友友何树(
               a<"o">(26088, 3730622082361450853L ^ a), a<"o">(13511, 3958774760463380504L ^ a), navigationBlockStartX + 50.0F, 25.0F, 22.0F, 22.0F
            );
            float arrowBlockStartY = c<"X">(keyDel, -1506178586069697379L, a) + c<"X">(keyDel, -1513034929795940460L, a) + 57.0F + 2.0F;
            树友树友何何友友何何.何树树树树树友友何树 keyUp = new 树友树友何何友友何何.何树树树树树友友何树(
               "↑", a<"o">(16700, 6396516307346638213L ^ a), navigationBlockStartX + 22.0F + 3.0F, arrowBlockStartY, 22.0F, 22.0F
            );
            树友树友何何友友何何.何树树树树树友友何树 keyLeft = new 树友树友何何友友何何.何树树树树树友友何树(
               "←", a<"o">(21917, 6327460681982890475L ^ a), navigationBlockStartX, arrowBlockStartY + 22.0F + 3.0F, 22.0F, 22.0F
            );
            树友树友何何友友何何.何树树树树树友友何树 keyDown = new 树友树友何何友友何何.何树树树树树友友何树(
               "↓", a<"o">(28461, 2922502288645450659L ^ a), navigationBlockStartX + 22.0F + 3.0F, arrowBlockStartY + 22.0F + 3.0F, 22.0F, 22.0F
            );
            树友树友何何友友何何.何树树树树树友友何树 keyRight = new 树友树友何何友友何何.何树树树树树友友何树(
               "→", a<"o">(13471, 1815787104883060789L ^ a), navigationBlockStartX + 50.0F, arrowBlockStartY + 22.0F + 3.0F, 22.0F, 22.0F
            );
            float totalKeysWidth = navigationBlockStartX + 72.0F;
            float var36 = Math.max(keysBlockHeight, c<"X">(keyDown, -1506178586069697379L, a) + c<"X">(keyDown, -1513034929795940460L, a));
            c<"Å">(this, totalKeysWidth + 20.0F, -1510123744710271890L, a);
            c<"Å">(this, var36 + 20.0F, -1508947100153615608L, a);
            c<"Å">(this, (c<"X">(this, -1504308180163247831L, a) - c<"X">(this, -1510123744710271890L, a)) / 2.0F, -1510405553024508925L, a);
            c<"Å">(this, (c<"X">(this, -1504518800823556594L, a) - c<"X">(this, -1508947100153615608L, a)) / 2.0F, -1506480759939815735L, a);
            float var10000;
            if (c<"X">(this, -1506452761324684270L, a) > 0.0F) {
               Objects.requireNonNull(this);
               var10000 = c<"X">(this, -1506452761324684270L, a) + 30.0F + 20.0F;
            } else {
               var10000 = 40.0F;
            }

            float topLimitY = var10000;
            if (c<"X">(this, -1506480759939815735L, a) < topLimitY) {
               c<"Å">(this, topLimitY, -1506480759939815735L, a);
            }

            Iterator var30 = tempKeyLayoutDefinitions.iterator();
            if (var30.hasNext()) {
               List<树友树友何何友友何何.何树树树树树友友何树> rowDefs = (List<树友树友何何友友何何.何树树树树树友友何树>)var30.next();
               Iterator var32 = rowDefs.iterator();
               if (var32.hasNext()) {
                  树友树友何何友友何何.何树树树树树友友何树 def = (树友树友何何友友何何.何树树树树树友友何树)var32.next();
                  c<"X">(this, -1504989851764050333L, a)
                     .add(
                        new 树友树友何何友友何何.友何树树树树何树何友(
                           c<"X">(def, -1506542594252683365L, a),
                           c<"X">(def, -1510959694390248567L, a),
                           c<"X">(def, -1511917316692880112L, a),
                           c<"X">(def, -1506178586069697379L, a),
                           c<"X">(def, -1507083902367650840L, a),
                           c<"X">(def, -1513034929795940460L, a),
                           glfwKeyMap
                        )
                     );
               }
            }

            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyInsert, -1506542594252683365L, a),
                     c<"X">(keyInsert, -1510959694390248567L, a),
                     c<"X">(keyInsert, -1511917316692880112L, a),
                     c<"X">(keyInsert, -1506178586069697379L, a),
                     c<"X">(keyInsert, -1507083902367650840L, a),
                     c<"X">(keyInsert, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyHome, -1506542594252683365L, a),
                     c<"X">(keyHome, -1510959694390248567L, a),
                     c<"X">(keyHome, -1511917316692880112L, a),
                     c<"X">(keyHome, -1506178586069697379L, a),
                     c<"X">(keyHome, -1507083902367650840L, a),
                     c<"X">(keyHome, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyPgUp, -1506542594252683365L, a),
                     c<"X">(keyPgUp, -1510959694390248567L, a),
                     c<"X">(keyPgUp, -1511917316692880112L, a),
                     c<"X">(keyPgUp, -1506178586069697379L, a),
                     c<"X">(keyPgUp, -1507083902367650840L, a),
                     c<"X">(keyPgUp, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyDel, -1506542594252683365L, a),
                     c<"X">(keyDel, -1510959694390248567L, a),
                     c<"X">(keyDel, -1511917316692880112L, a),
                     c<"X">(keyDel, -1506178586069697379L, a),
                     c<"X">(keyDel, -1507083902367650840L, a),
                     c<"X">(keyDel, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyEnd, -1506542594252683365L, a),
                     c<"X">(keyEnd, -1510959694390248567L, a),
                     c<"X">(keyEnd, -1511917316692880112L, a),
                     c<"X">(keyEnd, -1506178586069697379L, a),
                     c<"X">(keyEnd, -1507083902367650840L, a),
                     c<"X">(keyEnd, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyPgDn, -1506542594252683365L, a),
                     c<"X">(keyPgDn, -1510959694390248567L, a),
                     c<"X">(keyPgDn, -1511917316692880112L, a),
                     c<"X">(keyPgDn, -1506178586069697379L, a),
                     c<"X">(keyPgDn, -1507083902367650840L, a),
                     c<"X">(keyPgDn, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyUp, -1506542594252683365L, a),
                     c<"X">(keyUp, -1510959694390248567L, a),
                     c<"X">(keyUp, -1511917316692880112L, a),
                     c<"X">(keyUp, -1506178586069697379L, a),
                     c<"X">(keyUp, -1507083902367650840L, a),
                     c<"X">(keyUp, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyLeft, -1506542594252683365L, a),
                     c<"X">(keyLeft, -1510959694390248567L, a),
                     c<"X">(keyLeft, -1511917316692880112L, a),
                     c<"X">(keyLeft, -1506178586069697379L, a),
                     c<"X">(keyLeft, -1507083902367650840L, a),
                     c<"X">(keyLeft, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyDown, -1506542594252683365L, a),
                     c<"X">(keyDown, -1510959694390248567L, a),
                     c<"X">(keyDown, -1511917316692880112L, a),
                     c<"X">(keyDown, -1506178586069697379L, a),
                     c<"X">(keyDown, -1507083902367650840L, a),
                     c<"X">(keyDown, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
            c<"X">(this, -1504989851764050333L, a)
               .add(
                  new 树友树友何何友友何何.友何树树树树何树何友(
                     c<"X">(keyRight, -1506542594252683365L, a),
                     c<"X">(keyRight, -1510959694390248567L, a),
                     c<"X">(keyRight, -1511917316692880112L, a),
                     c<"X">(keyRight, -1506178586069697379L, a),
                     c<"X">(keyRight, -1507083902367650840L, a),
                     c<"X">(keyRight, -1513034929795940460L, a),
                     glfwKeyMap
                  )
               );
         }
      }
   }

   private void t() {
      long a = 树友树友何何友友何何.a ^ 97076911923255L;
      c<"ý">(8995166774906351793L, a);
      long elapsedTime = System.currentTimeMillis() - c<"X">(this, 8989563379507917666L, a);
      if (c<"X">(this, 8991828851068527704L, a)) {
         c<"Å">(this, Math.max(0.0F, 1.0F - (float)elapsedTime / 300.0F), 8990562534091643827L, a);
      }

      c<"Å">(this, Math.min(1.0F, (float)elapsedTime / 300.0F), 8990562534091643827L, a);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void j() {
      long a = 树友树友何何友友何何.a ^ 42862391802320L;
      c<"ý">(-6543098914771654314L, a);
      if (c<"X">(this, -6541690306762536811L, a)) {
         long elapsedTime = System.currentTimeMillis() - c<"X">(this, -6541836177256719650L, a);
         c<"Å">(this, Math.min(1.0F, (float)elapsedTime / 200.0F), -6546849088471134941L, a);
         if (c<"X">(this, -6546849088471134941L, a) >= 1.0F) {
            c<"Å">(this, false, -6541690306762536811L, a);
         }
      }

      if (c<"X">(this, -6539448620824136287L, a)) {
         long elapsedTime = System.currentTimeMillis() - c<"X">(this, -6541836177256719650L, a);
         c<"Å">(this, Math.max(0.0F, 1.0F - (float)elapsedTime / 200.0F), -6546849088471134941L, a);
         if (c<"X">(this, -6546849088471134941L, a) <= 0.0F) {
            c<"Å">(this, false, -6539448620824136287L, a);
            c<"Å">(this, false, -6544751146425470574L, a);
         }
      }

      if (c<"X">(this, -6544751146425470574L, a)) {
         c<"Å">(this, 1.0F, -6546849088471134941L, a);
      }

      c<"Å">(this, 0.0F, -6546849088471134941L, a);
   }

   private void z() {
      long a = 树友树友何何友友何何.a ^ 52496853878317L;
      c<"ý">(6543509743728219819L, a);
      c<"Å">(this, true, 6544966838059077999L, a);
      c<"Å">(this, c<"í">(6546929062783314097L, a), 6540256325597129249L, a);
      c<"Å">(this, true, 6544745345708217659L, a);
      c<"Å">(this, 0.0F, 6542934560821132515L, a);
      c<"Å">(this, System.currentTimeMillis(), 6543567246873304695L, a);
      c<"Å">(this, false, 6543323837177535569L, a);
      c<"Å">(this, 0.0F, 6544355404682593595L, a);
      c<"Å">(this, -40.0F, 6545324109088025169L, a);
      if (c<"X">(this, 6541926610727104767L, a) > 0 && c<"X">(this, 6541733711291111384L, a) > 0 && c<"X">(this, 6542388363494590389L, a).isEmpty()) {
         this.p();
      }

      if (c<"X">(this, 6546312610974489310L, a) > 0.0F) {
         c<"Å">(this, -c<"X">(this, 6546312610974489310L, a) - 10.0F, 6543765034489906802L, a);
      }

      c<"Å">(this, -500.0F, 6543765034489906802L, a);
      c<"Å">(this, false, 6544107147453156975L, a);
      c<"Å">(this, 0.0F, 6546512253278384862L, a);
      c<"Å">(this, false, 6542100876947715944L, a);
      c<"Å">(this, false, 6539859312811641436L, a);
      c<"Å">(this, "", 6543271000496901965L, a);
      c<"Å">(this, false, 6547605907964499873L, a);
      c<"Å">(this, 0.0F, 6545469554173025686L, a);
   }

   private void w() {
      long a = 树友树友何何友友何何.a ^ 140482162509321L;
      c<"ý">(6551443380118574735L, a);
      if (c<"X">(this, 6554152242150985291L, a) || c<"X">(this, 6552287123692222284L, a)) {
         c<"Å">(this, false, 6552287123692222284L, a);
         c<"Å">(this, true, 6550044888469867128L, a);
         c<"Å">(this, System.currentTimeMillis(), 6552706220713026823L, a);
         c<"Å">(this, false, 6555434128677672837L, a);
      }

      c<"Å">(this, false, 6554152242150985291L, a);
      c<"Å">(this, 0.0F, 6556592688975672058L, a);
   }

   private List<树何何树树树友友友友> w(何何友何何友何何树树 category) {
      long a = 树友树友何何友友何何.a ^ 52503358153038L;
      c<"ý">(-4779384563100372536L, a);
      if (category == null) {
         return new ArrayList<>();
      } else {
         List<树何何树树树友友友友> allRects = c<"X">(this, -4776695882726868956L, a).computeIfAbsent(category, k -> {
            List<树何何树树树友友友友> newRects = new ArrayList<>();
            Cherish.instance.getModuleManager().o(k).forEach(m -> {
               树何何树树树友友友友 rect = new 树何何树树树友友友友(m);
               newRects.add(rect);
            });
            newRects.forEach(树何何树树树友友友友::m);
            return newRects;
         });
         if (c<"X">(this, -4782405193186842695L, a) != null && !c<"X">(this, -4782405193186842695L, a).isEmpty()) {
            String searchLower = c<"X">(this, -4782405193186842695L, a).toLowerCase();
            return allRects.stream().filter(rect -> {
               long ax = 树友树友何何友友何何.a ^ 43930427683845L;
               c<"ý">(-1664292010982316925L, ax);
               return rect.K().i().toLowerCase().contains(searchLower) || rect.K().Q().toLowerCase().contains(searchLower);
            }).collect(Collectors.toList());
         } else {
            return allRects;
         }
      }
   }

   private void u(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      long a = 树友树友何何友友何何.a ^ 25001568400383L;
      long ax = a ^ 121814988944931L;
      ClientUtils.o(new Object[]{ax});
      友何何树友何何何何树 buttonFont = Cherish.instance.h().n(16);
      String buttonTextString = a<"o">(10139, 8291900092938823470L ^ a);
      boolean hoveringSnakeGame = this.b(c<"X">(this, -1224116219714138140L, a), c<"X">(this, -1223026917437927451L, a), 80.0F, 20.0F, mouseX, mouseY);
      if (hoveringSnakeGame != c<"X">(this, -1220931892101213667L, a)) {
         c<"Å">(this, hoveringSnakeGame, -1220931892101213667L, a);
      }

      Color baseColor = new Color(60, 60, 60, 255);
      Color hoverColor = new Color(80, 80, 80, 255);
      int r = (int)友树树何何树树何何树.s(baseColor.getRed(), hoverColor.getRed(), c<"X">(this, -1217552465293093194L, a));
      int g = (int)友树树何何树树何何树.s(baseColor.getGreen(), hoverColor.getGreen(), c<"X">(this, -1217552465293093194L, a));
      int b = (int)友树树何何树树何何树.s(baseColor.getBlue(), hoverColor.getBlue(), c<"X">(this, -1217552465293093194L, a));
      Color snakeGameBgColor = new Color(r, g, b, 255);
      RenderUtils.drawRectangle(
         guiGraphics.pose(), c<"X">(this, -1224116219714138140L, a), c<"X">(this, -1223026917437927451L, a), 80.0F, 20.0F, snakeGameBgColor.getRGB()
      );
      Color accentColor = new Color(100, 100, 100, 255);
      RenderUtils.drawRectangle(
         guiGraphics.pose(), c<"X">(this, -1224116219714138140L, a), c<"X">(this, -1223026917437927451L, a) + 20.0F - 2.0F, 80.0F, 2.0F, accentColor.getRGB()
      );
      buttonFont.L(
         guiGraphics.pose(),
         buttonTextString,
         c<"X">(this, -1224116219714138140L, a) + 40.0F,
         c<"X">(this, -1223026917437927451L, a) + 10.0F - buttonFont.K() / 2,
         new Color(220, 220, 220).getRGB()
      );
   }

   private float E(float x) {
      return 1.0F - (1.0F - x) * (1.0F - x);
   }

   private void E() {
      long a = 树友树友何何友友何何.a ^ 134185509515637L;
      c<"ý">(7896889074106589683L, a);
      if (c<"X">(this, 7896740787103410953L, a)) {
         c<"Å">(this, Math.min(1.0F, c<"X">(this, 7893241305620329059L, a) + 0.1F), 7893241305620329059L, a);
      }

      c<"Å">(this, Math.max(0.0F, c<"X">(this, 7893241305620329059L, a) - 0.1F), 7893241305620329059L, a);
      if (c<"X">(this, 7893629838155014755L, a)) {
         long elapsedTime = System.currentTimeMillis() - c<"X">(this, 7896848682110200111L, a);
         if (c<"X">(this, 7898185430259260793L, a) == c<"í">(7891160864383983593L, a)) {
            c<"Å">(this, Math.min(1.0F, (float)elapsedTime / 400.0F), 7896351549099445179L, a);
            float progress = this.n(c<"X">(this, 7896351549099445179L, a));
            c<"Å">(this, 友树树何何树树何何树.s(-40.0F, c<"X">(this, 7896600962487384732L, a), progress), 7894242994772958473L, a);
            float startYKeyboard = -c<"X">(this, 7890721159039708550L, a) - 10.0F;
            c<"Å">(this, 友树树何何树树何何树.s(startYKeyboard, c<"X">(this, 7897548163577749575L, a), progress), 7892639798766580010L, a);
            if (c<"X">(this, 7896351549099445179L, a) >= 1.0F) {
               c<"Å">(this, 1.0F, 7896351549099445179L, a);
               c<"Å">(this, false, 7893629838155014755L, a);
               c<"Å">(this, c<"í">(7896382135490611914L, a), 7898185430259260793L, a);
            }
         }

         if (c<"X">(this, 7898185430259260793L, a) == c<"í">(7892139981086869544L, a)) {
            c<"Å">(this, Math.max(0.0F, 1.0F - (float)elapsedTime / 400.0F), 7896351549099445179L, a);
            float progress = this.n(1.0F - c<"X">(this, 7896351549099445179L, a));
            c<"Å">(this, 友树树何何树树何何树.s(c<"X">(this, 7896600962487384732L, a), -40.0F, progress), 7894242994772958473L, a);
            float endYKeyboard = -c<"X">(this, 7890721159039708550L, a) - 10.0F;
            c<"Å">(this, 友树树何何树树何何树.s(c<"X">(this, 7897548163577749575L, a), endYKeyboard, progress), 7892639798766580010L, a);
            if (c<"X">(this, 7896351549099445179L, a) <= 0.0F) {
               c<"Å">(this, 0.0F, 7896351549099445179L, a);
               c<"Å">(this, false, 7893629838155014755L, a);
               c<"Å">(this, c<"í">(7894916080634579986L, a), 7898185430259260793L, a);
               c<"Å">(this, 0.0F, 7892213914649152241L, a);
               c<"Å">(this, System.currentTimeMillis(), 7891285128944869920L, a);
            }
         }
      }

      if (c<"X">(this, 7893738247611360823L, a)) {
         c<"Å">(this, c<"X">(this, 7896600962487384732L, a), 7894242994772958473L, a);
         c<"Å">(this, c<"X">(this, 7897548163577749575L, a), 7892639798766580010L, a);
      }

      c<"Å">(this, -40.0F, 7894242994772958473L, a);
      if (c<"X">(this, 7895018581598363776L, a) > 0 && c<"X">(this, 7890721159039708550L, a) > 0.0F) {
         c<"Å">(this, -c<"X">(this, 7890721159039708550L, a) - 10.0F, 7892639798766580010L, a);
      }

      c<"Å">(this, -500.0F, 7892639798766580010L, a);
   }

   private void X(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      long a = 树友树友何何友友何何.a ^ 78280159584921L;
      long ax = a ^ 69567324120901L;
      ClientUtils.o(new Object[]{ax});
      友何何树友何何何何树 buttonFont = Cherish.instance.h().n(16);
      String buttonTextString = a<"o">(11174, 1610120357103614489L ^ a);
      boolean hoveringConfig = this.b(c<"X">(this, 9109774388357514766L, a), c<"X">(this, 9108748111046114195L, a), 80.0F, 20.0F, mouseX, mouseY);
      if (hoveringConfig != c<"X">(this, 9110240536496794654L, a)) {
         c<"Å">(this, hoveringConfig, 9110240536496794654L, a);
      }

      Color baseColor = new Color(60, 60, 60, 255);
      Color hoverColor = new Color(80, 80, 80, 255);
      int r = (int)友树树何何树树何何树.s(baseColor.getRed(), hoverColor.getRed(), c<"X">(this, 9110163293567071988L, a));
      int g = (int)友树树何何树树何何树.s(baseColor.getGreen(), hoverColor.getGreen(), c<"X">(this, 9110163293567071988L, a));
      int b = (int)友树树何何树树何何树.s(baseColor.getBlue(), hoverColor.getBlue(), c<"X">(this, 9110163293567071988L, a));
      Color configBgColor = new Color(r, g, b, 255);
      RenderUtils.drawRectangle(
         guiGraphics.pose(), c<"X">(this, 9109774388357514766L, a), c<"X">(this, 9108748111046114195L, a), 80.0F, 20.0F, configBgColor.getRGB()
      );
      Color accentColor = new Color(100, 100, 100, 255);
      RenderUtils.drawRectangle(
         guiGraphics.pose(), c<"X">(this, 9109774388357514766L, a), c<"X">(this, 9108748111046114195L, a) + 20.0F - 2.0F, 80.0F, 2.0F, accentColor.getRGB()
      );
      buttonFont.L(
         guiGraphics.pose(),
         buttonTextString,
         c<"X">(this, 9109774388357514766L, a) + 40.0F,
         c<"X">(this, 9108748111046114195L, a) + 10.0F - buttonFont.K() / 2,
         new Color(220, 220, 220).getRGB()
      );
   }

   private void X(GuiGraphics guiGraphics, float alpha) {
      long a = 树友树友何何友友何何.a ^ 98784910706922L;
      int alphaValue = (int)(Mth.clamp(alpha, 0.0F, 0.4F) * 255.0F);
      guiGraphics.fill(0, 0, c<"X">(this, -7778031080065417672L, a), c<"X">(this, -7777824032197142241L, a), alphaValue << 24);
   }

   private String L() {
      long a = 树友树友何何友友何何.a ^ 60134962112949L;
      return DateTimeFormatter.ofPattern(a<"o">(31623, 7380323388702499235L ^ a)).format(LocalDateTime.now());
   }

   private void L() {
      long a = 树友树友何何友友何何.a ^ 72181347560932L;
      c<"ý">(3532609267456359778L, a);
      if (mc != null && mc.getWindow() != null) {
         int screenWidth = mc.getWindow().getGuiScaledWidth();
         int screenHeight = mc.getWindow().getGuiScaledHeight();
         c<"Å">(this, screenWidth - 80.0F - 10.0F, 3539400025780731715L, a);
         c<"Å">(this, screenHeight - 20.0F - 10.0F, 3535887880545133677L, a);
         c<"Å">(this, c<"X">(this, 3539400025780731715L, a) - 80.0F - 5.0F, 3532679626038693749L, a);
         c<"Å">(this, c<"X">(this, 3535887880545133677L, a), 3539187624995574270L, a);
         c<"Å">(this, c<"X">(this, 3532679626038693749L, a) - 80.0F - 5.0F, 3532403052826826352L, a);
         c<"Å">(this, c<"X">(this, 3539187624995574270L, a), 3536944951259018478L, a);
         c<"Å">(this, c<"X">(this, 3532403052826826352L, a) - 120.0F - 5.0F, 3538033501316541034L, a);
         c<"Å">(this, c<"X">(this, 3536944951259018478L, a), 3531722908820782196L, a);
         c<"Å">(this, screenWidth / 2 - 40.0F, 3538448066449819595L, a);
         c<"Å">(this, 10.0F, 3532905754302686733L, a);
      }
   }

   private boolean M() {
      long a = 树友树友何何友友何何.a ^ 36978734967188L;
      c<"ý">(3852329677133003026L, a);
      return c<"X">(this, 3848921098415058427L, a) ? c<"X">(this, 3848217125197091344L, a) <= 0.0F : c<"X">(this, 3848217125197091344L, a) >= 1.0F;
   }

   private void N(GuiGraphics guiGraphics, int mouseX, int mouseY) {
      long a = 树友树友何何友友何何.a ^ 42003353424470L;
      long ax = a ^ 103649511167882L;
      ClientUtils.o(new Object[]{ax});
      友何何树友何何何何树 regularFont = Cherish.instance.h().n(14);
      c<"ý">(5671227083517084368L, a);
      友何何树友何何何何树 placeholderFont = Cherish.instance.h().n(14);
      String placeholderTextString = a<"o">(31912, 1731512366855151100L ^ a);
      Color bgColor = new Color(60, 60, 60, 255);
      Color borderColor = new Color(100, 100, 100, 255);
      RenderUtils.drawRectangle(
         guiGraphics.pose(), c<"X">(this, 5672400178476380681L, a), c<"X">(this, 5670406674209194950L, a), 120.0F, 20.0F, bgColor.getRGB()
      );
      RenderUtils.drawRectangle(
         guiGraphics.pose(), c<"X">(this, 5672400178476380681L, a), c<"X">(this, 5670406674209194950L, a) + 20.0F - 1.0F, 120.0F, 1.0F, borderColor.getRGB()
      );
      String displaySearchText = c<"X">(this, 5672690702025987233L, a);
      if (c<"X">(this, 5669697939216077307L, a)) {
         displaySearchText = displaySearchText
            + (System.currentTimeMillis() / b<"u">(5339, 8374430687853321035L ^ a) % b<"u">(15352, 6995008132749014122L ^ a) == 0L ? "_" : "");
      }

      float textX = c<"X">(this, 5672400178476380681L, a) + 4.0F;
      float textY = c<"X">(this, 5670406674209194950L, a) + (20.0F - regularFont.K()) / 2.0F;
      if (c<"X">(this, 5672690702025987233L, a).isEmpty() && !c<"X">(this, 5669697939216077307L, a)) {
         placeholderFont.c(
            guiGraphics.pose(),
            placeholderTextString,
            textX,
            c<"X">(this, 5670406674209194950L, a) + (20.0F - placeholderFont.K()) / 2.0F,
            new Color(150, 150, 150).getRGB()
         );
      }

      String clippedText = regularFont.D(displaySearchText, 112);
      if (!clippedText.equals(displaySearchText) && clippedText.endsWith(a<"o">(30041, 1873773194721154174L ^ a)) && displaySearchText.endsWith("_")) {
         clippedText = regularFont.D(displaySearchText.substring(0, displaySearchText.length() - 1), 112 - regularFont.A("_")) + "_";
      }

      regularFont.c(guiGraphics.pose(), clippedText, textX, textY, c<"í">(5668056305746517631L, a).getRGB());
   }

   private void N() {
      long a = 树友树友何何友友何何.a ^ 123221185971051L;
      c<"Å">(this, true, 6887984497424157481L, a);
      c<"Å">(this, true, 6884994174914556462L, a);
      c<"Å">(this, false, 6882732553350680346L, a);
      c<"Å">(this, 0.0F, 6890434427599550360L, a);
      c<"Å">(this, System.currentTimeMillis(), 6885419174294167653L, a);
      c<"Å">(this, 0.0F, 6886129510048667856L, a);
      this.D();
   }

   private void H() {
      long a = 树友树友何何友友何何.a ^ 64777528422131L;
      c<"ý">(-5615669715042320779L, a);
      c<"X">(this, -5604094608691635501L, a).clear();
      File configDir = Cherish.getConfigManager().G();
      if (configDir.exists() && configDir.isDirectory()) {
         File[] files = configDir.listFiles((dir, name) -> {
            long ax = 树友树友何何友友何何.a ^ 129894947534025L;
            return name.toLowerCase().endsWith(a<"o">(29441, 330953805564032198L ^ ax));
         });
         int var7 = files.length;
         int var8 = 0;
         if (0 < var7) {
            File file = files[0];
            c<"X">(this, -5604094608691635501L, a).add(file.getName().replaceAll(a<"o">(984, 963403724712238677L ^ a), ""));
            var8++;
         }
      }

      c<"X">(this, -5604094608691635501L, a).sort(c<"í">(-5618449554932936790L, a));
   }

   public static void T(Module[] var0) {
      友友树树树何树树何何 = var0;
   }

   private void Q() {
      long a = 树友树友何何友友何何.a ^ 110140109490562L;
      c<"ý">(-7683003643494950652L, a);
      if (c<"X">(this, -7677287722068940660L, a)) {
         long elapsedTime = System.currentTimeMillis() - c<"X">(this, -7678541250252589755L, a);
         c<"Å">(this, Math.min(1.0F, (float)elapsedTime / 500.0F), -7681367721250012399L, a);
         if (c<"X">(this, -7681367721250012399L, a) >= 1.0F) {
            c<"Å">(this, 1.0F, -7681367721250012399L, a);
            c<"Å">(this, false, -7677287722068940660L, a);
            c<"Å">(this, null, -7675733404589833436L, a);
         }
      }
   }

   public boolean isPauseScreen() {
      return false;
   }

   private Map<String, Integer> O() {
      long a = 树友树友何何友友何何.a ^ 23786304596002L;
      Map<String, Integer> map = new HashMap<>();
      map.put(a<"o">(32328, 5710633176603223523L ^ a), 0);
      Field[] var5 = GLFW.class.getFields();
      c<"ý">(-810633168216000348L, a);
      int var6 = var5.length;
      int var7 = 0;
      if (0 < var6) {
         Field field = var5[0];
         if (Modifier.isStatic(field.getModifiers()) && field.getName().startsWith(a<"o">(4897, 7701427322345228381L ^ a))) {
            field.setAccessible(true);

            try {
               map.put(field.getName().substring(9).toLowerCase(), (Integer)field.get(null));
            } catch (IllegalAccessException var10) {
               var10.printStackTrace();
            }
         }

         var7++;
      }

      return map;
   }

   private void K(何何友何何友何何树树 newCategory) {
      long a = 树友树友何何友友何何.a ^ 90211554310113L;
      c<"ý">(-6123968864753571993L, a);
      if (c<"X">(this, -6124880327030698793L, a) != newCategory) {
         c<"Å">(this, c<"X">(this, -6124880327030698793L, a), -6117745347206906553L, a);
         c<"Å">(this, newCategory, -6124880327030698793L, a);
         c<"Å">(this, true, -6118143006406027537L, a);
         c<"Å">(this, 0.0F, -6123352987193442958L, a);
         c<"Å">(this, System.currentTimeMillis(), -6119440482704651482L, a);
      }
   }

   private static String HE_DA_WEI() {
      return "何炜霖诈骗";
   }

   public void onClose() {
      long a = 树友树友何何友友何何.a ^ 78539922782797L;
      c<"ý">(2787551839516306123L, a);
      if (c<"X">(this, 2789330577222433248L, a)) {
         c<"Å">(this, false, 2789330577222433248L, a);
         c<"Å">(this, "", 2783808952833211578L, a);
      }

      if (c<"X">(this, 2789452237392880274L, a)) {
         c<"Å">(this, false, 2789452237392880274L, a);
      }

      if (!c<"X">(this, 2785802589629814595L, a) && !c<"X">(this, 2787096634690493908L, a)) {
         if (c<"X">(this, 2791576672927247297L, a)) {
            c<"Å">(this, false, 2791576672927247297L, a);
         }

         if (c<"X">(this, 2788077913502331407L, a) || c<"X">(this, 2783883956000028220L, a)) {
            this.w();
         } else if (c<"X">(this, 2788867787263077647L, a)) {
            this.b();
         } else {
            if (!c<"X">(this, 2788708487036091938L, a)) {
               c<"Å">(this, true, 2788708487036091938L, a);
               c<"Å">(this, System.currentTimeMillis(), 2790902902523603224L, a);
            }
         }
      } else {
         this.B();
      }
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      long a = 树友树友何何友友何何.a ^ 94404308226181L;
      c<"ý">(5505453816505974787L, a);
      if (keyCode == 256) {
         if (c<"X">(this, 5511741646125470504L, a)) {
            c<"Å">(this, false, 5511741646125470504L, a);
            c<"Å">(this, "", 5506215474316154482L, a);
            c<"X">(this, 5511004693218173111L, a).t();
            c<"Å">(
               this,
               c<"X">(c<"X">(this, 5511004693218173111L, a), 5509659820338617719L, a)
                  || c<"X">(this, 5509519189652209929L, a)
                  || c<"X">(this, 5511898748676720730L, a),
               5506424423087844031L,
               a
            );
            return true;
         } else if (c<"X">(this, 5511898748676720730L, a)) {
            c<"Å">(this, false, 5511898748676720730L, a);
            c<"Å">(
               this,
               c<"X">(c<"X">(this, 5511004693218173111L, a), 5509659820338617719L, a)
                  || c<"X">(this, 5509519189652209929L, a)
                  || c<"X">(this, 5511741646125470504L, a),
               5506424423087844031L,
               a
            );
            return true;
         } else if (c<"X">(this, 5503743994490584459L, a) || c<"X">(this, 5505038313349363484L, a)) {
            this.B();
            return true;
         } else if (c<"X">(this, 5509519189652209929L, a)) {
            c<"Å">(this, false, 5509519189652209929L, a);
            c<"Å">(
               this,
               c<"X">(c<"X">(this, 5511004693218173111L, a), 5509659820338617719L, a)
                  || c<"X">(this, 5511898748676720730L, a)
                  || c<"X">(this, 5511741646125470504L, a),
               5506424423087844031L,
               a
            );
            return true;
         } else if (c<"X">(this, 5510484708914911431L, a) || c<"X">(this, 5506289394576334068L, a)) {
            this.w();
            return true;
         } else if (c<"X">(this, 5511313902533281735L, a)) {
            this.b();
            return true;
         } else {
            c<"Å">(this, true, 5511114177870320874L, a);
            c<"Å">(this, System.currentTimeMillis(), 5508841145153995728L, a);
            return true;
         }
      } else if (c<"X">(this, 5511741646125470504L, a)) {
         if (keyCode == 257 || keyCode == 335) {
            c<"Å">(this, false, 5511741646125470504L, a);
            c<"Å">(
               this,
               c<"X">(c<"X">(this, 5511004693218173111L, a), 5509659820338617719L, a)
                  || c<"X">(this, 5509519189652209929L, a)
                  || c<"X">(this, 5511898748676720730L, a),
               5506424423087844031L,
               a
            );
            return true;
         } else if (keyCode == 259) {
            if (!c<"X">(this, 5506215474316154482L, a).isEmpty()) {
               c<"Å">(this, c<"X">(this, 5506215474316154482L, a).substring(0, c<"X">(this, 5506215474316154482L, a).length() - 1), 5506215474316154482L, a);
               c<"X">(this, 5511004693218173111L, a).t();
            }

            return true;
         } else {
            return true;
         }
      } else if (c<"X">(this, 5511898748676720730L, a)) {
         if (keyCode == 257 || keyCode == 335) {
            c<"Å">(this, false, 5511898748676720730L, a);
            c<"Å">(
               this,
               c<"X">(c<"X">(this, 5511004693218173111L, a), 5509659820338617719L, a)
                  || c<"X">(this, 5509519189652209929L, a)
                  || c<"X">(this, 5511741646125470504L, a),
               5506424423087844031L,
               a
            );
            return true;
         } else if (keyCode == 259) {
            if (!c<"X">(this, 5509159041882811828L, a).isEmpty()) {
               c<"Å">(this, c<"X">(this, 5509159041882811828L, a).substring(0, c<"X">(this, 5509159041882811828L, a).length() - 1), 5509159041882811828L, a);
            }

            return true;
         } else {
            return true;
         }
      } else if (c<"X">(this, 5511313902533281735L, a) && c<"X">(this, 5509519189652209929L, a)) {
         if (keyCode == 257 || keyCode == 335) {
            c<"Å">(this, false, 5509519189652209929L, a);
            this.D();
            c<"Å">(
               this,
               c<"X">(c<"X">(this, 5511004693218173111L, a), 5509659820338617719L, a)
                  || c<"X">(this, 5511898748676720730L, a)
                  || c<"X">(this, 5511741646125470504L, a),
               5506424423087844031L,
               a
            );
            return true;
         } else if (keyCode == 259) {
            if (!c<"X">(this, 5505127367827888613L, a).isEmpty()) {
               c<"Å">(this, c<"X">(this, 5505127367827888613L, a).substring(0, c<"X">(this, 5505127367827888613L, a).length() - 1), 5505127367827888613L, a);
               this.D();
            }

            return true;
         } else {
            return true;
         }
      } else if (c<"X">(this, 5511313902533281735L, a) && !c<"X">(this, 5509519189652209929L, a)) {
         return true;
      } else {
         if (!c<"X">(this, 5511313902533281735L, a)
            && !c<"X">(this, 5509519189652209929L, a)
            && !c<"X">(this, 5511741646125470504L, a)
            && !c<"X">(this, 5511898748676720730L, a)) {
            c<"X">(this, 5511004693218173111L, a).D(keyCode, scanCode, modifiers);
         }

         c<"Å">(
            this,
            c<"X">(c<"X">(this, 5511004693218173111L, a), 5509659820338617719L, a)
               || c<"X">(this, 5509519189652209929L, a)
               || c<"X">(this, 5511898748676720730L, a)
               || c<"X">(this, 5511741646125470504L, a),
            5506424423087844031L,
            a
         );
         return super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   protected void init() {
      long a = 树友树友何何友友何何.a ^ 64279362901203L;
      c<"ý">(590291207213417557L, a);
      if (mc != null && mc.player != null && mc.level != null) {
         super.init();
         c<"Å">(this, 0.0F, 585616118555193175L, a);
         c<"Å">(this, false, 589134338768113852L, a);
         c<"Å">(this, System.currentTimeMillis(), 586939646246881158L, a);
         c<"Å">(this, 0.0F, 590879309612903965L, a);
         c<"Å">(this, false, 589284355085436869L, a);
         c<"Å">(this, System.currentTimeMillis(), 590392068028222601L, a);
         c<"Å">(this, c<"í">(591051045843496812L, a), 593839294459918559L, a);
         c<"Å">(this, 0.0F, 589896483770970311L, a);
         c<"Å">(this, false, 586607092374103732L, a);
         c<"Å">(this, 0.0F, 588895515727878085L, a);
         c<"Å">(this, false, 590142613048544943L, a);
         c<"Å">(this, 0.0F, 591746922218271130L, a);
         c<"Å">(this, false, 586114613130655025L, a);
         c<"Å">(this, 0.0F, 587632320321896638L, a);
         c<"Å">(this, false, 586715054465620564L, a);
         c<"Å">(this, false, 592036067836344797L, a);
         c<"Å">(this, "", 586058800366627298L, a);
         c<"Å">(this, false, 587822140894317580L, a);
         if (c<"X">(this, 583850815509586163L, a) != null) {
            c<"X">(this, 583850815509586163L, a).clear();
         }

         c<"Å">(this, new ArrayList(), 583850815509586163L, a);
         c<"Å">(this, 0.0F, 588309421029553210L, a);
         c<"Å">(this, 0.0F, 593524065814441769L, a);
         c<"Å">(this, false, 587137760410911618L, a);
         c<"Å">(this, false, 591023267709252426L, a);
         c<"Å">(this, false, 588261228808778955L, a);
         c<"Å">(this, false, 586494088160453958L, a);
         c<"Å">(this, "", 593470639441564196L, a);
         c<"Å">(this, false, 588788996849489790L, a);
         this.L();
         this.p();
         int screenWidth = mc.getWindow().getGuiScaledWidth();
         c<"Å">(this, screenWidth + 10, 591845821882641997L, a);
         c<"Å">(this, screenWidth + 10, 589756062964967624L, a);
         c<"Å">(this, screenWidth + 10, 587181876839264324L, a);
         c<"Å">(this, screenWidth + 10, 593760111832347788L, a);
         c<"Å">(this, -40.0F, 588771236293228719L, a);
         if (c<"X">(this, 587501404110653472L, a) > 0.0F) {
            c<"Å">(this, -c<"X">(this, 587501404110653472L, a) - 10.0F, 589420043874391180L, a);
         }

         c<"Å">(this, -500.0F, 589420043874391180L, a);
         if (c<"X">(this, 590646312303538149L, a) == null && 何何友何何友何何树树.M().length > 0) {
            c<"Å">(this, 何何友何何友何何树树.M()[0], 590646312303538149L, a);
         }

         c<"X">(this, 589243931734172897L, a).R();
         c<"Å">(this, false, 589763810543148177L, a);
         c<"Å">(this, null, 584045063005532675L, a);
         if (c<"X">(this, 586745112227816078L, a) != null) {
            c<"X">(this, 586745112227816078L, a).clear();
         }

         c<"Å">(this, null, 586745112227816078L, a);
         c<"Å">(this, 0.0F, 587781502337175400L, a);
         c<"Å">(this, 0.0F, 587710943646064672L, a);
         c<"Å">(this, false, 591136891038410134L, a);
         c<"Å">(this, false, 593396177214331042L, a);
         c<"Å">(this, "", 590054591987441075L, a);
         c<"Å">(this, false, 586542351145321823L, a);
         c<"Å">(this, false, 593578484777479913L, a);
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      long a = 树友树友何何友友何何.a ^ 24183069486689L;
      long ax = a ^ 120439170575293L;
      long axx = a ^ 102154756922176L;
      c<"ý">(-5583604608700399897L, a);
      if (mc == null || mc.player == null || mc.level == null || !this.M()) {
         return false;
      } else if (c<"X">(this, -5575560280999215753L, a)) {
         return false;
      } else {
         boolean isEnglish = ClientUtils.o(new Object[]{ax});
         boolean clickedInsideSearch = this.b(c<"X">(this, -5580142295237030338L, a), c<"X">(this, -5582661306956136463L, a), 120.0F, 20.0F, mouseX, mouseY);
         if (clickedInsideSearch && button == 0) {
            c<"Å">(this, true, -5577176036492382772L, a);
            c<"Å">(this, false, -5577019192176134466L, a);
            c<"Å">(this, false, -5579398493234069523L, a);
            c<"X">(this, -5575661176970125741L, a).h();
            c<"Å">(this, true, -5580241464548764581L, a);
            return true;
         } else {
            if ((c<"X">(this, -5582921876502936721L, a) || c<"X">(this, -5584020368481367560L, a)) && c<"X">(this, -5580327763617753701L, a) > 0.01F) {
               boolean clickInsidePopup = mouseX >= c<"X">(this, -5579570082147435244L, a)
                  && mouseX <= c<"X">(this, -5579570082147435244L, a) + 180.0F
                  && mouseY >= c<"X">(this, -5579341829322753792L, a)
                  && mouseY <= c<"X">(this, -5579341829322753792L, a) + 200.0F;
               if (clickInsidePopup && c<"X">(this, -5580327763617753701L, a) > 0.95F) {
                  float currentListYCheck = c<"X">(this, -5579341829322753792L, a)
                     + 5.0F
                     + 20.0F
                     + 5.0F
                     + c<"X">(this, -5582553616337220240L, a)
                     + 5.0F
                     + Cherish.instance.h().n(14).K()
                     + 2.0F;
                  float listAreaHeightCheck = c<"X">(this, -5579341829322753792L, a) + 200.0F - 5.0F - currentListYCheck;
                  float inputFieldX = c<"X">(this, -5579570082147435244L, a) + 5.0F;
                  float inputFieldY = c<"X">(this, -5579341829322753792L, a) + 5.0F;
                  if (this.b(inputFieldX, inputFieldY, 170.0F, 20.0F, mouseX, mouseY) && button == 0) {
                     c<"Å">(this, true, -5577019192176134466L, a);
                     c<"Å">(this, false, -5577176036492382772L, a);
                     c<"Å">(this, false, -5579398493234069523L, a);
                     c<"X">(this, -5575661176970125741L, a).h();
                     c<"Å">(this, true, -5580241464548764581L, a);
                     return true;
                  }

                  if (c<"X">(this, -5577019192176134466L, a) && !this.b(inputFieldX, inputFieldY, 170.0F, 20.0F, mouseX, mouseY)) {
                     c<"Å">(this, false, -5577019192176134466L, a);
                  }

                  if (c<"X">(this, -5579525851596709900L, a) && button == 0) {
                     if (!c<"X">(this, -5579899641022147760L, a).isEmpty()) {
                        友何友树树树友树何友 switchModule = new 友何友树树树友树何友(
                           new File(Cherish.getConfigManager().G(), c<"X">(this, -5579899641022147760L, a) + a<"o">(23754, 167846413945110995L ^ a))
                        );

                        try {
                           if (switchModule.h()) {
                              String successMsg = a<"o">(1490, 4475848000511498291L ^ a)
                                 + c<"X">(this, -5579899641022147760L, a)
                                 + a<"o">(32470, 1036931850820395817L ^ a);
                              ClientUtils.e(new Object[]{successMsg, axx});
                              cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578019871341952383L, a), a<"o">(5863, 5781759098504563658L ^ a), successMsg, 3.0F);
                              this.H();
                           }

                           String failMsg = isEnglish
                              ? a<"o">(21001, 6210960901449453419L ^ a) + c<"X">(this, -5579899641022147760L, a) + a<"o">(20560, 6654727028638747949L ^ a)
                              : a<"o">(15689, 7309727861987532971L ^ a) + c<"X">(this, -5579899641022147760L, a) + a<"o">(19863, 4096650854906499227L ^ a);
                           ClientUtils.e(new Object[]{failMsg, axx});
                           cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578938568784705433L, a), a<"o">(11174, 1610064507325380321L ^ a), failMsg, 3.0F);
                        } catch (Throwable var31) {
                           throw new RuntimeException(var31);
                        }
                     }

                     String emptyMsg = isEnglish ? a<"o">(13358, 3878692525376498020L ^ a) : a<"o">(15153, 783740291573507800L ^ a);
                     cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578938568784705433L, a), a<"o">(11174, 1610064507325380321L ^ a), emptyMsg, 3.0F);
                     return true;
                  }

                  if (c<"X">(this, -5576648277176381831L, a) && button == 0) {
                     if (!c<"X">(this, -5579899641022147760L, a).isEmpty()) {
                        友何友树树树友树何友 switchModule = new 友何友树树树友树何友(
                           new File(Cherish.getConfigManager().G(), c<"X">(this, -5579899641022147760L, a) + a<"o">(29441, 330921554773126766L ^ a))
                        );
                        File testFile = new File(
                           Cherish.getConfigManager().G(), c<"X">(this, -5579899641022147760L, a) + a<"o">(29441, 330921554773126766L ^ a)
                        );
                        if (!testFile.exists()) {
                           String notFoundMsg = a<"o">(20019, 4211222812451115799L ^ a)
                              + c<"X">(this, -5579899641022147760L, a)
                              + a<"o">(32067, 7409584151579893933L ^ a);
                           cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578938568784705433L, a), a<"o">(11174, 1610064507325380321L ^ a), notFoundMsg, 3.0F);
                           return true;
                        }

                        try {
                           switchModule.a();
                           String successMsg = isEnglish
                              ? a<"o">(11477, 6326715718777401775L ^ a) + c<"X">(this, -5579899641022147760L, a) + a<"o">(14083, 763134793568742121L ^ a)
                              : a<"o">(11693, 5378660724527329416L ^ a) + c<"X">(this, -5579899641022147760L, a);
                           ClientUtils.e(new Object[]{successMsg, axx});
                           cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578019871341952383L, a), a<"o">(11174, 1610064507325380321L ^ a), successMsg, 3.0F);
                        } catch (Throwable var32) {
                           String errorMsg = a<"o">(21807, 4089230215822674141L ^ a) + c<"X">(this, -5579899641022147760L, a) + ".";
                           ClientUtils.e(new Object[]{errorMsg, axx});
                           cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578938568784705433L, a), a<"o">(11174, 1610064507325380321L ^ a), errorMsg, 3.0F);
                        }
                     }

                     String emptyMsg = isEnglish ? a<"o">(25154, 3693103442468421397L ^ a) : a<"o">(17261, 7849888340954750614L ^ a);
                     cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578938568784705433L, a), a<"o">(11174, 1610064507325380321L ^ a), emptyMsg, 3.0F);
                     return true;
                  }

                  float itemYCheck = currentListYCheck - c<"X">(this, -5577646816806515064L, a);
                  Iterator var49 = c<"X">(this, -5573082829839476159L, a).iterator();
                  if (var49.hasNext()) {
                     String configName = (String)var49.next();
                     if (mouseX >= c<"X">(this, -5579570082147435244L, a) + 5.0F
                        && mouseX <= c<"X">(this, -5579570082147435244L, a) + 180.0F - 5.0F
                        && mouseY >= itemYCheck
                        && mouseY <= itemYCheck + 20.0F
                        && mouseY >= currentListYCheck
                        && mouseY <= currentListYCheck + listAreaHeightCheck
                        && button == 0) {
                        c<"Å">(this, configName, -5579899641022147760L, a);
                        c<"Å">(this, false, -5577019192176134466L, a);
                        return true;
                     }

                     float var59 = itemYCheck + 20.0F;
                  }

                  return true;
               }

               if (!clickInsidePopup && button == 0) {
                  if (c<"X">(this, -5582921876502936721L, a)) {
                     this.B();
                  }

                  if (c<"X">(this, -5577019192176134466L, a)) {
                     c<"Å">(this, false, -5577019192176134466L, a);
                  }
               }
            }

            if (c<"X">(this, -5577019192176134466L, a) && button == 0) {
               c<"Å">(this, false, -5577019192176134466L, a);
            }

            if (c<"X">(this, -5577603779547694813L, a)) {
               if (this.b(c<"X">(this, -5575944949998271410L, a), c<"X">(this, -5577264101913394659L, a), 80.0F, 30.0F, mouseX, mouseY) && button == 0) {
                  this.b();
                  return true;
               } else {
                  if ((c<"X">(this, -5576181435882166749L, a) || c<"X">(this, -5580517230279597552L, a)) && c<"X">(this, -5578314562354963822L, a) > 0.01F) {
                     float menuX = c<"X">(this, -5575794330400055518L, a);
                     float menuY = c<"X">(this, -5576739257962770902L, a);
                     if (menuX + 150.0F > c<"X">(this, -5582865020166367053L, a)) {
                        menuX = c<"X">(this, -5582865020166367053L, a) - 150.0F;
                     }

                     if (menuY + 150.0F + 20.0F > c<"X">(this, -5583106298416480364L, a)) {
                        menuY = c<"X">(this, -5583106298416480364L, a) - 150.0F - 20.0F;
                     }

                     if (menuX < 0.0F) {
                        menuX = 0.0F;
                     }

                     if (menuY < 0.0F) {
                        menuY = 0.0F;
                     }

                     float searchBoxEndX = menuX + 150.0F;
                     float searchBoxEndY = menuY + 20.0F;
                     if (mouseX >= menuX && mouseX <= searchBoxEndX && mouseY >= menuY && mouseY <= searchBoxEndY && button == 0) {
                        c<"Å">(this, true, -5579398493234069523L, a);
                        c<"Å">(this, false, -5577176036492382772L, a);
                        c<"Å">(this, false, -5577019192176134466L, a);
                        c<"X">(this, -5575661176970125741L, a).h();
                        c<"Å">(this, true, -5580241464548764581L, a);
                        return true;
                     }

                     if (c<"X">(this, -5579398493234069523L, a)
                        && button == 0
                        && c<"X">(this, -5578314562354963822L, a) >= 0.95F
                        && (!(mouseX >= menuX) || !(mouseX <= searchBoxEndX) || !(mouseY >= menuY) || !(mouseY <= searchBoxEndY))) {
                        c<"Å">(this, false, -5579398493234069523L, a);
                     }

                     float listStartY = menuY + 20.0F;
                     float listEndX = menuX + 150.0F;
                     float listEndY = menuY + 20.0F + 150.0F;
                     if (mouseX >= menuX && mouseX <= listEndX && mouseY >= listStartY && mouseY <= listEndY && c<"X">(this, -5578314562354963822L, a) >= 0.95F
                        )
                      {
                        float itemHeight = Cherish.instance.h().n(16).K() + 4;
                        float currentItemY = listStartY + 2.0F - c<"X">(this, -5577119207221758502L, a);
                        if (c<"X">(this, -5578088455170516932L, a) != null) {
                           Iterator var27 = c<"X">(this, -5578088455170516932L, a).iterator();
                           if (var27.hasNext()) {
                              Module module = (Module)var27.next();
                              if (mouseY >= currentItemY && mouseY <= currentItemY + itemHeight && button == 0) {
                                 String moduleDisplayName = isEnglish ? module.i() : module.Q();
                                 if (module.W() == c<"X">(c<"X">(this, -5572959986477152079L, a), -5576403424098040999L, a)) {
                                    module.E(-1);
                                    String unbindMsg = a<"o">(13099, 5704542721686400595L ^ a)
                                       + moduleDisplayName
                                       + a<"o">(31, 7366885949522468136L ^ a)
                                       + c<"X">(c<"X">(this, -5572959986477152079L, a), -5578569861984442785L, a);
                                    cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578694807906083304L, a), a<"o">(31976, 4187160834765627662L ^ a), unbindMsg, 3.0F);
                                 }

                                 module.E(c<"X">(c<"X">(this, -5572959986477152079L, a), -5576403424098040999L, a));
                                 String bindMsg = isEnglish
                                    ? a<"o">(31005, 3085849953340793938L ^ a)
                                       + moduleDisplayName
                                       + a<"o">(1259, 4292551090378594718L ^ a)
                                       + c<"X">(c<"X">(this, -5572959986477152079L, a), -5578569861984442785L, a)
                                    : a<"o">(11392, 1126256338232046018L ^ a)
                                       + moduleDisplayName
                                       + a<"o">(28686, 2275263056996609283L ^ a)
                                       + c<"X">(c<"X">(this, -5572959986477152079L, a), -5578569861984442785L, a);
                                 cn.cool.cherish.ui.何树树友树树友树友树.S(c<"í">(-5578694807906083304L, a), a<"o">(24664, 1755507904513523019L ^ a), bindMsg, 3.0F);
                                 this.D();
                                 return true;
                              }

                              float var58 = currentItemY + itemHeight;
                           }
                        }

                        return true;
                     }

                     if (button == 0 && (mouseX < menuX || mouseX > menuX + 150.0F || mouseY < menuY || mouseY > menuY + 150.0F + 20.0F)) {
                        if (c<"X">(this, -5576181435882166749L, a)) {
                           this.w();
                        }

                        if (c<"X">(this, -5579398493234069523L, a)) {
                           c<"Å">(this, false, -5579398493234069523L, a);
                        }
                     }
                  }

                  if (c<"X">(this, -5584157799597124433L, a) >= 1.0F
                     && !c<"X">(this, -5576181435882166749L, a)
                     && !c<"X">(this, -5580517230279597552L, a)
                     && !c<"X">(this, -5582761122824806620L, a)) {
                     Iterator var35 = c<"X">(this, -5582491229437202439L, a).iterator();
                     if (var35.hasNext()) {
                        树友树友何何友友何何.友何树树树树何树何友 key = (树友树友何何友友何何.友何树树树树何树何友)var35.next();
                        if (key.d(mouseX, mouseY, c<"X">(this, -5576540592282571202L, a)) && button == 1) {
                           if (c<"X">(this, -5576181435882166749L, a) && c<"X">(this, -5572959986477152079L, a) == key) {
                              this.w();
                           }

                           c<"Å">(this, key, -5572959986477152079L, a);
                           c<"Å">(this, (float)mouseX + 5.0F, -5575794330400055518L, a);
                           c<"Å">(this, (float)mouseY + 5.0F, -5576739257962770902L, a);
                           c<"Å">(this, "", -5583790573293377791L, a);
                           c<"Å">(this, false, -5579398493234069523L, a);
                           this.N();
                           return true;
                        }
                     }
                  }

                  return true;
               }
            } else {
               if (c<"X">(this, -5577176036492382772L, a) && !clickedInsideSearch && button == 0) {
                  c<"Å">(this, false, -5577176036492382772L, a);
               }

               if (this.b(c<"X">(this, -5578771061696197898L, a), c<"X">(this, -5579796209440704661L, a), 80.0F, 20.0F, mouseX, mouseY) && button == 0) {
                  if (c<"X">(this, -5582921876502936721L, a)) {
                     this.B();
                  }

                  this.d();
                  c<"Å">(this, false, -5577176036492382772L, a);
                  return true;
               } else if (this.b(c<"X">(this, -5576279275776290182L, a), c<"X">(this, -5577448395158498693L, a), 80.0F, 20.0F, mouseX, mouseY) && button == 0) {
                  mc.setScreen(new 树树何树友树何树友树());
                  return true;
               } else if (this.b(c<"X">(this, -5583189018795928321L, a), c<"X">(this, -5578645937807366168L, a), 80.0F, 20.0F, mouseX, mouseY) && button == 0) {
                  this.z();
                  return true;
               } else if (this.b(c<"X">(this, -5579628540112555288L, a), c<"X">(this, -5584273248042736441L, a), 550.0F, 20.0F, mouseX, mouseY) && button == 0) {
                  c<"Å">(this, true, -5582586875774759486L, a);
                  c<"Å">(this, (float)(mouseX - c<"X">(this, -5579628540112555288L, a)), -5580211060024104004L, a);
                  c<"Å">(this, (float)(mouseY - c<"X">(this, -5584273248042736441L, a)), -5578996359751703312L, a);
                  return true;
               } else {
                  float catHeight = 240.0F / 何何友何何友何何树树.M().length;
                  何何友何何友何何树树[] searchBoxX = 何何友何何友何何树树.M();
                  int searchBoxY = searchBoxX.length;
                  int searchBoxEndXx = 0;
                  if (0 < searchBoxY) {
                     何何友何何友何何树树 category = searchBoxX[0];
                     float catY = c<"X">(this, -5584273248042736441L, a) + 40.0F + 0.0F;
                     if (this.b(c<"X">(this, -5579628540112555288L, a), catY, 90.0F, catHeight, mouseX, mouseY)) {
                        if (c<"X">(this, -5584381926389803689L, a) != category) {
                           this.K(category);
                        }

                        return true;
                     }

                     float var10000 = 0.0F + catHeight;
                     searchBoxEndXx++;
                  }

                  c<"X">(this, -5575661176970125741L, a).u(mouseX, mouseY, button);
                  c<"Å">(
                     this,
                     c<"X">(c<"X">(this, -5575661176970125741L, a), -5579258136620735597L, a)
                        || c<"X">(this, -5579398493234069523L, a)
                        || c<"X">(this, -5577019192176134466L, a)
                        || c<"X">(this, -5577176036492382772L, a),
                     -5580241464548764581L,
                     a
                  );
                  return super.mouseClicked(mouseX, mouseY, button);
               }
            }
         }
      }
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
      long a = 树友树友何何友友何何.a ^ 125609324985720L;
      long ax = a ^ 11316459518116L;
      c<"ý">(-6802006698763768322L, a);
      if (mc != null && mc.player != null && mc.level != null && this.M()) {
         ClientUtils.o(new Object[]{ax});
         友何何树友何何何何树 popupListFont = Cherish.instance.h().n(14);
         友何何树友何何何何树 contextMenuModuleFontLocal = Cherish.instance.h().n(16);
         if ((c<"X">(this, -6801528484054232970L, a) || c<"X">(this, -6802418078749992223L, a)) && c<"X">(this, -6802732635968354686L, a) > 0.01F) {
            float listScreenY = c<"X">(this, -6806251950296061415L, a)
               + 5.0F
               + 20.0F
               + 5.0F
               + c<"X">(this, -6800524688984121751L, a)
               + 5.0F
               + popupListFont.K()
               + 2.0F;
            float listHeight = c<"X">(this, -6806251950296061415L, a) + 200.0F - 5.0F - listScreenY;
            if (mouseX >= c<"X">(this, -6807184990074147315L, a)
               && mouseX <= c<"X">(this, -6807184990074147315L, a) + 180.0F
               && mouseY >= listScreenY
               && mouseY <= listScreenY + listHeight) {
               float totalContentH = c<"X">(this, -6795639974610810536L, a).size() * 20.0F;
               float maxScroll = Math.max(0.0F, totalContentH - listHeight);
               c<"Å">(this, c<"X">(this, -6809073171990389359L, a) - (float)delta * 20.0F * 0.8F, -6809073171990389359L, a);
               c<"Å">(this, Mth.clamp(c<"X">(this, -6809073171990389359L, a), 0.0F, maxScroll), -6809073171990389359L, a);
               return true;
            }
         }

         if (c<"X">(this, -6809098305661244870L, a)
            && (c<"X">(this, -6808304349531622086L, a) || c<"X">(this, -6802859970421657335L, a))
            && c<"X">(this, -6805854145018885749L, a) > 0.01F
            && c<"X">(this, -6805007371435472091L, a) != null) {
            float menuX = c<"X">(this, -6807283908314919877L, a);
            float menuListY = c<"X">(this, -6808854457316451021L, a) + 20.0F;
            if (mouseX >= menuX && mouseX <= menuX + 150.0F && mouseY >= menuListY && mouseY <= menuListY + 150.0F) {
               float itemHeight = contextMenuModuleFontLocal.K() + 4;
               float totalContentHeight = c<"X">(this, -6805007371435472091L, a).size() * itemHeight;
               float maxScroll = Math.max(0.0F, totalContentHeight - 150.0F);
               c<"Å">(this, c<"X">(this, -6808474645377849661L, a) - (float)delta * 12.0F, -6808474645377849661L, a);
               c<"Å">(this, Mth.clamp(c<"X">(this, -6808474645377849661L, a), 0.0F, maxScroll), -6808474645377849661L, a);
               return true;
            }
         }

         if (!c<"X">(this, -6809098305661244870L, a)) {
            boolean hoveringSearchBar = this.b(c<"X">(this, -6803182126826676953L, a), c<"X">(this, -6800715960333783832L, a), 120.0F, 20.0F, mouseX, mouseY);
            if (!hoveringSearchBar
               && !c<"X">(this, -6801528484054232970L, a)
               && !c<"X">(this, -6802418078749992223L, a)
               && !c<"X">(this, -6800491429580366117L, a)) {
               c<"X">(this, -6807715920636261046L, a).r(mouseX, mouseY, delta);
            }
         }

         return super.mouseScrolled(mouseX, mouseY, delta);
      } else {
         return false;
      }
   }

   public boolean charTyped(char typedChar, int modifiers) {
      long a = 树友树友何何友友何何.a ^ 31413343269461L;
      c<"ý">(3366164050374501075L, a);
      if (c<"X">(this, 3363602464621359608L, a)) {
         label64: {
            if (typedChar == '\b') {
               if (c<"X">(this, 3367083391126402210L, a).isEmpty()) {
                  break label64;
               }

               c<"Å">(this, c<"X">(this, 3367083391126402210L, a).substring(0, c<"X">(this, 3367083391126402210L, a).length() - 1), 3367083391126402210L, a);
            }

            if (typedChar >= ' ' && typedChar != 127 && c<"X">(this, 3367083391126402210L, a).length() < 64) {
               c<"Å">(this, c<"X">(this, 3367083391126402210L, a) + typedChar, 3367083391126402210L, a);
            }
         }

         c<"X">(this, 3362866055288242791L, a).t();
         return true;
      } else if (c<"X">(this, 3363762279502883466L, a)) {
         if (typedChar == '\b') {
            if (c<"X">(this, 3360881283527151460L, a).isEmpty()) {
               return true;
            }

            c<"Å">(this, c<"X">(this, 3360881283527151460L, a).substring(0, c<"X">(this, 3360881283527151460L, a).length() - 1), 3360881283527151460L, a);
         }

         if (typedChar >= ' ' && typedChar != 127) {
            c<"Å">(this, c<"X">(this, 3360881283527151460L, a) + typedChar, 3360881283527151460L, a);
         }

         return true;
      } else if (c<"X">(this, 3363159256994964759L, a) && c<"X">(this, 3361365164996715481L, a)) {
         if (typedChar == '\b') {
            if (!c<"X">(this, 3365998037985065781L, a).isEmpty()) {
               c<"Å">(this, c<"X">(this, 3365998037985065781L, a).substring(0, c<"X">(this, 3365998037985065781L, a).length() - 1), 3365998037985065781L, a);
            }

            this.D();
         }

         if (typedChar >= ' ' && typedChar != 127) {
            c<"Å">(this, c<"X">(this, 3365998037985065781L, a) + typedChar, 3365998037985065781L, a);
            this.D();
         }

         return true;
      } else {
         if (!c<"X">(this, 3363159256994964759L, a)
            && !c<"X">(this, 3361365164996715481L, a)
            && !c<"X">(this, 3363602464621359608L, a)
            && !c<"X">(this, 3363762279502883466L, a)) {
            c<"X">(this, 3362866055288242791L, a).h(typedChar, modifiers);
         }

         c<"Å">(
            this,
            c<"X">(c<"X">(this, 3362866055288242791L, a), 3361505183462719399L, a)
               || c<"X">(this, 3361365164996715481L, a)
               || c<"X">(this, 3363762279502883466L, a)
               || c<"X">(this, 3363602464621359608L, a),
            3367274818650294383L,
            a
         );
         return super.charTyped(typedChar, modifiers);
      }
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      long a = 树友树友何何友友何何.a ^ 77416540865648L;
      c<"ý">(-7452790360079428362L, a);
      if (mc == null || mc.player == null || mc.level == null || !this.M()) {
         return false;
      } else if (c<"X">(this, -7455412866741316814L, a)) {
         return true;
      } else {
         if (c<"X">(this, -7452285628300514946L, a)) {
            boolean clickInsidePopup = mouseX >= c<"X">(this, -7457907089539901691L, a)
               && mouseX <= c<"X">(this, -7457907089539901691L, a) + 180.0F
               && mouseY >= c<"X">(this, -7457009094548647151L, a)
               && mouseY <= c<"X">(this, -7457009094548647151L, a) + 200.0F;
            if (clickInsidePopup && c<"X">(this, -7448985804774342774L, a) > 0.9F) {
               return true;
            }
         }

         if (button == 0 && c<"X">(this, -7451212979223189549L, a)) {
            c<"Å">(this, false, -7451212979223189549L, a);
         }

         c<"X">(this, -7453995984529558462L, a).M(mouseX, mouseY, button);
         return super.mouseReleased(mouseX, mouseY, button);
      }
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      long a = 树友树友何何友友何何.a ^ 112389293877388L;
      c<"ý">(-5445275295146199030L, a);
      if (c<"X">(this, -5446020621617853649L, a) && button == 0) {
         c<"Å">(this, (float)(mouseX - c<"X">(this, -5448677897512768175L, a)), -5441370146150960123L, a);
         c<"Å">(this, (float)(mouseY - c<"X">(this, -5440876563304717795L, a)), -5445451353163423190L, a);
         return true;
      } else if (c<"X">(this, -5443394955611799602L, a)) {
         return true;
      } else {
         if (c<"X">(this, -5447092843795643006L, a) && c<"X">(this, -5448296994904452234L, a) > 0.01F) {
            boolean clickInsidePopup = mouseX >= c<"X">(this, -5441455165846553607L, a)
               && mouseX <= c<"X">(this, -5441455165846553607L, a) + 180.0F
               && mouseY >= c<"X">(this, -5440557379176808467L, a)
               && mouseY <= c<"X">(this, -5440557379176808467L, a) + 200.0F;
            if (clickInsidePopup && c<"X">(this, -5448296994904452234L, a) > 0.9F) {
               return true;
            }
         }

         if (!c<"X">(this, -5446020621617853649L, a) && button == 0) {
            c<"X">(this, -5444229099869022018L, a).y(mouseX, mouseY, button, deltaX, deltaY);
         }

         return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   private static class 何树树树树树友友何树 implements 何树友 {
      String 何何何何树树树何何友;
      String 何树树何树何友何树友;
      float 树树何树何树树何树何;
      float 友树何树何树何树友树;
      float 友何友树何树何友何何;
      float 树树何何何友树何树友;
      private static final long a;
      private static final Object[] b = new Object[10];
      private static final String[] c = new String[10];
      private static int _何树友，和树做朋友 _;

      public 何树树树树树友友何树(String displayName, String internalName, float x, float y, float width, float height) {
         long a = 树友树友何何友友何何.何树树树树树友友何树.a ^ 34698174919645L;
         super();
         a<"å">(this, displayName, -3613265373235187609L, a);
         a<"å">(this, internalName, -3613217500457789978L, a);
         a<"å">(this, x, -3613951768507040647L, a);
         a<"å">(this, y, -3613909583493032112L, a);
         a<"å">(this, 22.0F, -3614070059315337943L, a);
         a<"å">(this, 22.0F, -3614008287846626865L, a);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-7075263791824185727L, -8633043309468842453L, MethodHandles.lookup().lookupClass()).a(78487416649101L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 162 && var8 != 229 && var8 != 230 && var8 != 'v') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 254) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'c') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 162) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 229) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 230) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树友何何友友何何$何树树树树树友友何树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static void a() {
         b[0] = "Kfl-MaD&!&G|A{*`Wg\u0006栙厉桟叩佛佽參厉伛佷*佽栙桓桟栳栟口參众桟";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = "ME8\bN-FJ)G35UM \u000e";
         b[3] = "`\u0013\u001fo\u0014:k\u001c\u000e u4`\u0017\nz";
         b[4] = "Wa?3T$Y~\u0002厎佱厈栯佃栛伐可伖佫\u001e{6P'Fn\u007f.C";
         b[5] = "\u0002\"mU\u000ek\f=P栲桯余伾伀厓栲伫栝厠])P\nh\u0013--H\u0019";
         b[6] = "3oj\u0001's=pW桦框佁桋位桎桦伂栅伏\u0010.\u0004#p\"`*\u001c0";
         b[7] = "u\u0001\u0011-W\u001c{\u001e,厐栶伮栍伣栵伎栶厰栍~U(S\u001fd\u000eQ0@";
         b[8] = "?\u0006H\t\u0012B1\u0019u伪伷佰伃桠桬桮伷佰厝yL\u0014\u0017M.\b\bN\u0013Q";
         b[9] = "lx7\u000eiObg\n伭栈根佐栞佗厳佌根収\u00073\u0013l@}vwIh\\";
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 3;
                  case 1 -> 48;
                  case 2 -> 7;
                  case 3 -> 25;
                  case 4 -> 61;
                  case 5 -> 33;
                  case 6 -> 0;
                  case 7 -> 2;
                  case 8 -> 55;
                  case 9 -> 5;
                  case 10 -> 45;
                  case 11 -> 21;
                  case 12 -> 1;
                  case 13 -> 26;
                  case 14 -> 4;
                  case 15 -> 53;
                  case 16 -> 30;
                  case 17 -> 58;
                  case 18 -> 62;
                  case 19 -> 19;
                  case 20 -> 23;
                  case 21 -> 8;
                  case 22 -> 43;
                  case 23 -> 27;
                  case 24 -> 10;
                  case 25 -> 36;
                  case 26 -> 42;
                  case 27 -> 37;
                  case 28 -> 32;
                  case 29 -> 46;
                  case 30 -> 49;
                  case 31 -> 51;
                  case 32 -> 54;
                  case 33 -> 50;
                  case 34 -> 60;
                  case 35 -> 52;
                  case 36 -> 20;
                  case 37 -> 16;
                  case 38 -> 13;
                  case 39 -> 41;
                  case 40 -> 56;
                  case 41 -> 24;
                  case 42 -> 6;
                  case 43 -> 44;
                  case 44 -> 38;
                  case 45 -> 47;
                  case 46 -> 57;
                  case 47 -> 12;
                  case 48 -> 39;
                  case 49 -> 14;
                  case 50 -> 59;
                  case 51 -> 34;
                  case 52 -> 9;
                  case 53 -> 31;
                  case 54 -> 29;
                  case 55 -> 22;
                  case 56 -> 63;
                  case 57 -> 18;
                  case 58 -> 11;
                  case 59 -> 28;
                  case 60 -> 40;
                  case 61 -> 35;
                  case 62 -> 17;
                  default -> 15;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static String LIU_YA_FENG() {
         return "刘凤楠230622109211173513";
      }
   }

   private static class 友何树树树树何树何友 implements 何树友 {
      String 何友树何何何友友友何;
      String 树何友树友何友何树友;
      int 何友友树何何友何树树;
      float 友何友友何友何何友树;
      float 何何树树友友友何树友;
      float 友何树何何何何树友何;
      float 友何友树友何何何友树;
      boolean 树何何何友树友何友树;
      Map<String, Integer> 何何树树何何友友友树;
      private static final long a;
      private static final Object[] b = new Object[34];
      private static final String[] c = new String[34];
      private static int _职业技术教育中心学校 _;

      public 友何树树树树何树何友(String displayName, String internalName, float relativeX, float relativeY, float width, float height, Map<String, Integer> glfwKeyMap) {
         long a = 树友树友何何友友何何.友何树树树树何树何友.a ^ 58183492316057L;
         super();
         a<"e">(this, displayName, 7305750575912607569L, a);
         a<"Ñ">(7308784010409225800L, a);
         a<"e">(this, internalName, 7308955190838062682L, a);
         a<"e">(this, relativeX, 7308533714863189943L, a);
         a<"e">(this, relativeY, 7309213644065240503L, a);
         a<"e">(this, width, 7308650000903509822L, a);
         a<"e">(this, height, 7308258239005253419L, a);
         a<"e">(this, glfwKeyMap, 7305760617127679462L, a);
         Integer code = glfwKeyMap.get(internalName.toLowerCase());
         a<"e">(this, code != null ? code : -1, 7308442856340604191L, a);
         a<"Ñ">(!a<"Ñ">(7309183291113124691L, a), 7308849745821638255L, a);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-7611080767956175899L, -825240365763429550L, MethodHandles.lookup().lookupClass()).a(79897724548758L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public boolean d(double mx, double my, float currentKeyboardY) {
         long a = 树友树友何何友友何何.友何树树树树何树何友.a ^ 57572136188675L;
         a<"Ñ">(-5335634285243990318L, a);
         float actualX = a<"w">(a<"k">(-5335414900433839099L, a), -5334977156349815286L, a) + 10.0F + a<"w">(this, -5334760020909277395L, a);
         float actualY = currentKeyboardY + 10.0F + a<"w">(this, -5335204650529348307L, a);
         return mx >= actualX
            && mx <= actualX + a<"w">(this, -5334642652277192796L, a)
            && my >= actualY
            && my <= actualY + a<"w">(this, -5335034292845736015L, a);
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树友何何友友何何$友何树树树树何树何友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'w' && var8 != 'e' && var8 != 'k' && var8 != 'Y') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'f') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 209) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'w') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'e') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'k') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 5;
                  case 1 -> 52;
                  case 2 -> 34;
                  case 3 -> 45;
                  case 4 -> 18;
                  case 5 -> 2;
                  case 6 -> 7;
                  case 7 -> 4;
                  case 8 -> 21;
                  case 9 -> 61;
                  case 10 -> 39;
                  case 11 -> 25;
                  case 12 -> 20;
                  case 13 -> 44;
                  case 14 -> 43;
                  case 15 -> 12;
                  case 16 -> 59;
                  case 17 -> 53;
                  case 18 -> 23;
                  case 19 -> 63;
                  case 20 -> 50;
                  case 21 -> 15;
                  case 22 -> 47;
                  case 23 -> 33;
                  case 24 -> 49;
                  case 25 -> 31;
                  case 26 -> 17;
                  case 27 -> 38;
                  case 28 -> 1;
                  case 29 -> 62;
                  case 30 -> 6;
                  case 31 -> 56;
                  case 32 -> 57;
                  case 33 -> 48;
                  case 34 -> 51;
                  case 35 -> 27;
                  case 36 -> 3;
                  case 37 -> 30;
                  case 38 -> 46;
                  case 39 -> 24;
                  case 40 -> 14;
                  case 41 -> 9;
                  case 42 -> 42;
                  case 43 -> 28;
                  case 44 -> 10;
                  case 45 -> 8;
                  case 46 -> 32;
                  case 47 -> 35;
                  case 48 -> 37;
                  case 49 -> 60;
                  case 50 -> 26;
                  case 51 -> 11;
                  case 52 -> 19;
                  case 53 -> 0;
                  case 54 -> 36;
                  case 55 -> 13;
                  case 56 -> 55;
                  case 57 -> 58;
                  case 58 -> 40;
                  case 59 -> 54;
                  case 60 -> 22;
                  case 61 -> 29;
                  case 62 -> 16;
                  default -> 41;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "\u0010iftw\t\u001f)+\u007f}\u0014\u001at 9u\t\u0017r$r6+\u001cc={}";
         b[1] = boolean.class;
         c[1] = "java/lang/Boolean";
         b[2] = "\u0003!:t\u0012\t\faw\u007f\u0018\u0014\t<|9\b\u000fN桞叟栆厶伳伵厄叟佂伨B厫会栅栆桬桷伵桞佁叜";
         b[3] = float.class;
         c[3] = "java/lang/Float";
         b[4] = void.class;
         c[4] = "java/lang/Void";
         b[5] = "d^WJ-\u0018k\u001e\u001aA'\u0005nC\u0011\u00077\u001e)校厲核厉伢佒叻厲佼众";
         b[6] = ".H{TX\u0019\u001akt\u0014\u0015\u0012\u0010vqI\u001eT\u0018k|O\u001a\u001f[Iw^\u0003\u0016\u0010?";
         b[7] = "\u0010l:#?g\u001bc+lB\u007f\bd\"%";
         b[8] = "uy\u000f@t2~v\u001e\u000f\b+ql\u0010L?\u001bg{\u001cQ.7pv";
         b[9] = int.class;
         c[9] = "java/lang/Integer";
         b[10] = "=\u001a\u001aQ_ #\u0012\u0000\u001e<4'";
         b[11] = "\b\u001dt\u001fW0<>{_\u001a;6#~\u0002\u0011}>>s\u0004\u00156}\u001cx\u0015\f?6j";
         b[12] = "; \u00027tq&5Z\u00155|>3";
         b[13] = "pF\u001a>\u000e>{I\u000bqo0pB\u000f+";
         b[14] = "r^#`\u007f8sG6~@\\I\u0012lw}1,[ae.\u0000s]#$pnsD8h@";
         b[15] = "73f^\u000bJ23!I0档体伒伄台栩厹体厌桀3\t\u0016lr!\bT\u001ceq";
         b[16] = "A,B4do\u00169_PJ\u0005\u001f0Dmq>B:Mn\t";
         b[17] = "hLC'\u0003:iUV9<佟厐佭你桇佡佟伎佭你^\u0006x<\u000f\u00073\u0002hoR";
         b[18] = "d_:$\f\u0014.Q%xeb\u0005}\rHUB%X\"u\u001fL:\u0004";
         b[19] = "vu&.'wsua9\u001c会伒栐栀厀叟厄伒栐叚C&= 6#.\"-sk";
         b[20] = "\\V<g\u0011`\u000bC!\u00035\n\u0002J:>\u00041_@3=|0DXe3\u00120]C)\u0003";
         b[21] = "9.\u0016JSA87\u0003Tl\u001d\u0002bY]QHg+TO\u0002y";
         b[22] = "L\u0012!\u0007\u0012vM\u000b4\u0019-厍桮桷厜伣栴厍厴桷厜~\u00162\t\u0017`F\u0017+\u001c\t";
         b[23] = "(\u0012l\u000eJ,-\u0012+\u0019q栅佌厭桊厠伬叟佌桷厐cL- \u001fn\u001a\tx!\n";
         b[24] = "e\f\u001c/\u0006'2\u0019\u0001K\u0006M;\u0010\u001av\u0013vf\u001a\u0013uk";
         b[25] = "Sb[9d&Vb\u001c._叕伷叝厧伉厜佋伷叝桽Tel\u0005!^9a|V|";
         b[26] = "h\rc++Um\r$<\u0010\fQL# h\u00058\n1=bel\u000e:>p\f*\u001c'4\u0010";
         b[27] = "Z#wudp_#0b_厃伾框伕佅伂伝桺厜伕\u0018e:\f`rua*_=";
         b[28] = "w\u0010Ep-~v\tPn\u0012伛厏桵司佔发厅桕厯栢\t(<#S\u0001d,,p\u000e";
         b[29] = "@rT\u001c@\u0007Er\u0013\u000b{叴伤反桲厲伦佪伤反桲qAM\u00161Q\u001cE]El";
         b[30] = "xd[\u0017!~}d\u001c\u0000\u001a伓厂叛桽伧佇厍伜栁桽z$.ys\u0000\u001c{+>#";
         b[31] = "\u0013V\u0012?\u001fXYX\rcv:c|?\u001evUHL\u000f:K\u001fFSS";
         b[32] = "c\u0010\u001b~|Cf\u0010\\iG伮伇桵栽低会厰厙厯栽\u0013y\u0003?\u0013Fn)N!\u0001";
         b[33] = "67b\u001aP\u001137%\rk佼双桒伀伪伶叢双厈伀wV\u0010>:`\u000e\u0013E?/";
      }

      public void m(GuiGraphics guiGraphics, int mouseX, int mouseY, 友何何树友何何何何树 font, float currentKeyboardY, float globalAlpha) {
         long a = 树友树友何何友友何何.友何树树树树何树何友.a ^ 33929244898752L;
         a<"Ñ">(-4956441856347082735L, a);
         float actualX = a<"w">(a<"k">(-4956238955684064570L, a), -4956932611485394743L, a) + 10.0F + a<"w">(this, -4957325736943799826L, a);
         float actualY = currentKeyboardY + 10.0F + a<"w">(this, -4956597161820115986L, a);
         if (!(actualY + a<"w">(this, -4957042530982559374L, a) < currentKeyboardY + 10.0F)
            && !(actualY > currentKeyboardY + a<"w">(a<"k">(-4956238955684064570L, a), -4956721656929941490L, a) - 10.0F)) {
            int keyAlpha = (int)(255.0F * globalAlpha);
            if (keyAlpha >= 5) {
               a<"e">(
                  this,
                  mouseX >= actualX
                     && mouseX <= actualX + a<"w">(this, -4957161080985892505L, a)
                     && mouseY >= actualY
                     && mouseY <= actualY + a<"w">(this, -4957042530982559374L, a),
                  -4958037697667036247L,
                  a
               );
               Color baseBgColor = a<"w">(this, -4958037697667036247L, a) ? new Color(80, 80, 80) : new Color(50, 50, 50);
               Color shadowColor = new Color(30, 30, 30);
               RenderUtils.drawRectangle(
                  guiGraphics.pose(),
                  actualX,
                  actualY,
                  a<"w">(this, -4957161080985892505L, a),
                  a<"w">(this, -4957042530982559374L, a),
                  new Color(baseBgColor.getRed(), baseBgColor.getGreen(), baseBgColor.getBlue(), keyAlpha).getRGB()
               );
               RenderUtils.drawRectangle(
                  guiGraphics.pose(),
                  actualX,
                  actualY + a<"w">(this, -4957042530982559374L, a) - 1.0F,
                  a<"w">(this, -4957161080985892505L, a),
                  1.0F,
                  new Color(shadowColor.getRed(), shadowColor.getGreen(), shadowColor.getBlue(), keyAlpha).getRGB()
               );
               Color textColor = a<"k">(-4956873325832213981L, a);
               font.L(
                  guiGraphics.pose(),
                  a<"w">(this, -4955622868469513976L, a),
                  actualX + a<"w">(this, -4957161080985892505L, a) / 2.0F,
                  actualY + a<"w">(this, -4957042530982559374L, a) / 2.0F - font.K() / 2,
                  new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), keyAlpha).getRGB()
               );
               Iterator var16 = Cherish.instance.getModuleManager().k().iterator();
               if (var16.hasNext()) {
                  Module m = (Module)var16.next();
                  if (m.W() == a<"w">(this, -4956804853543298234L, a) && a<"w">(this, -4956804853543298234L, a) != -1) {
                     font.c(
                        guiGraphics.pose(),
                        "*",
                        actualX + a<"w">(this, -4957161080985892505L, a) - font.A("*") - 2.0F,
                        actualY + 2.0F,
                        new Color(
                              a<"k">(-4956558417563042317L, a).getRed(),
                              a<"k">(-4956558417563042317L, a).getGreen(),
                              a<"k">(-4956558417563042317L, a).getBlue(),
                              keyAlpha
                           )
                           .getRGB()
                     );
                  }
               }

               if (!a<"Ñ">(-4957202642128637749L, a)) {
                  a<"Ñ">(new Module[3], -4957908996273551606L, a);
               }
            }
         }
      }

      private static String HE_JIAN_GUO() {
         return "何建国230622195906030014";
      }
   }

   private static enum 树树友友树何友树友树 implements  {
      何友何何树友何友友何,
      何何树树何友树何树何,
      友何何何友何何何何友,
      何友何何树何友何何何;

      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_DA_WEI;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(7276004491718689102L, -5879622058227447697L, MethodHandles.lookup().lookupClass()).a(124223972141431L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 40399174476801L;
         b();
         Cipher var1;
         Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[4];
         int var6 = 0;
         String var5 = "\\|\u008aÝ¹d§³¹{¡QÄ+\u001fu\b\u0084Ë¢;\u00ad\u000b´\u0095";
         byte var7 = 25;
         char var4 = 16;
         int var12 = -1;

         label28:
         while (true) {
            String var14 = var5.substring(++var12, var12 + var4);
            byte var10001 = -1;

            while (true) {
               String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var20;
                     if ((var12 += var4) >= var7) {
                        何友何何树友何友友何 = new 树友树友何何友友何何.树树友友树何友树友树();
                        何何树树何友树何树何 = new 树友树友何何友友何何.树树友友树何友树友树();
                        友何何何友何何何何友 = new 树友树友何何友友何何.树树友友树何友树友树();
                        何友何何树何友何何何 = new 树友树友何何友友何何.树树友友树何友树友树();
                        return;
                     }

                     var4 = var5.charAt(var12);
                     break;
                  default:
                     var0[var6++] = var20;
                     if ((var12 += var4) < var7) {
                        var4 = var5.charAt(var12);
                        continue label28;
                     }

                     var5 = "\\|\u008aÝ¹d§³Q!R\rÁ\u000fÈr\u0010e<Å:\u0015T\u007fÁýÚ3&\u0013 \u008a\u001f";
                     var7 = 33;
                     var4 = 16;
                     var12 = -1;
               }

               var14 = var5.substring(++var12, var12 + var4);
               var10001 = 0;
            }
         }
      }

      public static 树友树友何何友友何何.树树友友树何友树友树 D(String name) {
         return Enum.valueOf(树友树友何何友友何何.树树友友树何友树友树.class, name);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static void b() {
         b[0] = "34Okk\u000b<t\u0002`a\u00169)\t&q\r~桋厪栙叏伱伅厑厪佝佑@桁桋厪參栕伱厛桋厪栙";
         b[1] = "n\\\n\u00036\u0003Z\u007f\u0005C{\bPb\u0000\u001epN@yG桼叓桱叾佅似厦叓伵你4桸桼叓厫栤佅厢桼叓桱\u000e";
         b[2] = "\"fz^u\u0019)ik\u0011\u0014\u0017\"boK";
         b[3] = "o5r\u001a\u0014*cayk佸佇桇栖佋厨格佇桇佒\u0016Z\u001f~/>&VKu";
         b[4] = "k'\u001e\u001a\u0000!gs\u0015k佬叒伇佀档伶史佌伇佀zZ\u000bu+,JV_~";
         b[5] = "n\u000e\u0001L\u000b\u0013bZ\n=叹佾伂佩厦你佧佾伂号e\f\u0000G.\u0005U\u0000TL";
         b[6] = "$\\.+io(\b%Z伅厜栌桿厉伇伅厜栌桿J**=*\fs&'f";
         b[7] = "xPS,$\u000ft\u0004X]佈叼伔伷栮厞佈叼厊伷7l/[8[\u0007`{P";
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public static 树友树友何何友友何何.树树友友树何友树友树[] h() {
         long var0 = a ^ 15835190304005L;
         return (树友树友何何友友何何.树树友友树何友树友树[])a<"ø">(-236175344822938785L, var0).clone();
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树友何何友友何何$树树友友树何友树友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'R' && var8 != 'k' && var8 != 248 && var8 != 203) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 205) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 244) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'R') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'k') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 248) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 10;
                  case 1 -> 14;
                  case 2 -> 21;
                  case 3 -> 50;
                  case 4 -> 5;
                  case 5 -> 24;
                  case 6 -> 12;
                  case 7 -> 2;
                  case 8 -> 16;
                  case 9 -> 43;
                  case 10 -> 11;
                  case 11 -> 23;
                  case 12 -> 29;
                  case 13 -> 27;
                  case 14 -> 17;
                  case 15 -> 55;
                  case 16 -> 20;
                  case 17 -> 40;
                  case 18 -> 35;
                  case 19 -> 51;
                  case 20 -> 59;
                  case 21 -> 49;
                  case 22 -> 56;
                  case 23 -> 30;
                  case 24 -> 26;
                  case 25 -> 34;
                  case 26 -> 58;
                  case 27 -> 7;
                  case 28 -> 62;
                  case 29 -> 19;
                  case 30 -> 8;
                  case 31 -> 6;
                  case 32 -> 54;
                  case 33 -> 57;
                  case 34 -> 60;
                  case 35 -> 36;
                  case 36 -> 22;
                  case 37 -> 25;
                  case 38 -> 53;
                  case 39 -> 28;
                  case 40 -> 13;
                  case 41 -> 37;
                  case 42 -> 45;
                  case 43 -> 4;
                  case 44 -> 9;
                  case 45 -> 32;
                  case 46 -> 42;
                  case 47 -> 15;
                  case 48 -> 41;
                  case 49 -> 18;
                  case 50 -> 0;
                  case 51 -> 38;
                  case 52 -> 31;
                  case 53 -> 39;
                  case 54 -> 52;
                  case 55 -> 46;
                  case 56 -> 33;
                  case 57 -> 1;
                  case 58 -> 63;
                  case 59 -> 61;
                  case 60 -> 3;
                  case 61 -> 48;
                  case 62 -> 47;
                  default -> 44;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String HE_SHU_YOU() {
         return "何大伟为什么要诈骗何炜霖";
      }
   }
}
