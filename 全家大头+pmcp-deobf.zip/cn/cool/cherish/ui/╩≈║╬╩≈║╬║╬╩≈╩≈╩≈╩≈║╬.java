package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.友友何何友何友树何树;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树何树何何树树树树何 implements IWrapper, 何树友 {
   private static String[] 何树树树何树友友何友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[19];
   private static final String[] g = new String[19];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8660615431503725824L, -8770471901754029928L, MethodHandles.lookup().lookupClass()).a(197453778255876L);
      // $VF: monitorexit
      a = var10000;
      a();
      M(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(54484569656902L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[7];
      int var5 = 0;
      String var4 = "®YÕMe8.q¿\u0083Æv!8Zü oI\u001c\u0006\u0011§uy\f\u009b\u0010Z\u00137\\£¿NnÛYPK\u0007\u00938/¶¨H;Þ\u0018ÌìÈ\u009aþïM\u00858ÕÆ%d{£)\u007f Ö\\K¬%ï 7\u0083LSÔ&\u0011/-à\u008e\u0080ÅÇ%m\u008aüê\u007fY\u0082\u0088l\"\u001c\u009b{Êìº\u0004\u0018@\u008e¸CÀë\u0005\u0082öX@ê1$\u008b\u0003ªíÒ\u009a\u001c\u0084\u009c[";
      short var6 = 132;
      char var3 = 16;
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[7];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "@\u0080ZÑ±³\u0097WÈ_\u0095`\u0093\u00820[Ô5\u0099µ=¨eÂÒR=¨JY\u001f\u009c \u009dâA\u000fÇ±#\u001b²\u000b~ÑK¼\u008aÂ®ëp|\u0004Kù\u0019,\u0082üô>ÀK¤";
                  var6 = 65;
                  var3 = ' ';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static String[] C() {
      return 何树树树何树友友何友;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 28;
               case 1 -> 11;
               case 2 -> 34;
               case 3 -> 29;
               case 4 -> 40;
               case 5 -> 24;
               case 6 -> 6;
               case 7 -> 3;
               case 8 -> 47;
               case 9 -> 22;
               case 10 -> 54;
               case 11 -> 14;
               case 12 -> 10;
               case 13 -> 5;
               case 14 -> 33;
               case 15 -> 37;
               case 16 -> 41;
               case 17 -> 15;
               case 18 -> 30;
               case 19 -> 48;
               case 20 -> 53;
               case 21 -> 16;
               case 22 -> 8;
               case 23 -> 39;
               case 24 -> 0;
               case 25 -> 45;
               case 26 -> 32;
               case 27 -> 49;
               case 28 -> 17;
               case 29 -> 61;
               case 30 -> 42;
               case 31 -> 55;
               case 32 -> 4;
               case 33 -> 31;
               case 34 -> 57;
               case 35 -> 63;
               case 36 -> 27;
               case 37 -> 12;
               case 38 -> 7;
               case 39 -> 62;
               case 40 -> 52;
               case 41 -> 58;
               case 42 -> 46;
               case 43 -> 35;
               case 44 -> 50;
               case 45 -> 43;
               case 46 -> 25;
               case 47 -> 23;
               case 48 -> 56;
               case 49 -> 60;
               case 50 -> 9;
               case 51 -> 20;
               case 52 -> 36;
               case 53 -> 51;
               case 54 -> 21;
               case 55 -> 44;
               case 56 -> 26;
               case 57 -> 13;
               case 58 -> 38;
               case 59 -> 19;
               case 60 -> 1;
               case 61 -> 2;
               case 62 -> 59;
               default -> 18;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何树何何树树树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 165 && var8 != 236 && var8 != 'F' && var8 != 211) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 220) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 245) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 165) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'F') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String f(友友何何友何友树何树.树何树何友友树何何友 message) {
      String prefix = E(message.树何树何树何树友何何);
      return prefix + "->" + message.何何树友友友友树何友;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      f[0] = "\u0017\u0005N&\u0004\u001f\u0018E\u0003-\u000e\u0002\u001d\u0018\bk\u001e\u0019Z桺伵桔伾伥桥桺桱桔伾";
      f[1] = "\t|v\u0010\u0007)|\\}\u001f\u0016f\u0001Dn\u0018\u001f/i";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = "Md='$FFk,hX_Iq\"+oo_f.6~CHk";
      f[4] = "c)m,4[\u0016\tf#%\u0014k\u0011u$,]\u0003";
      f[5] = "P)K$\u0003v_i\u0006/\tkZ4\ri\u0001vW2\t\"Bp^7\ti\bp@7\t&\u00157司厌估伒厧佌司桖估桖H栈佦桖估厌厧栈佦伒厮";
      f[6] = long.class;
      g[6] = "java/lang/Long";
      f[7] = "Db\u00187k~K\"U<acN\u007f^zi~CyZ1*\\HhC8a";
      f[8] = "z\u0000\u0017q#>N#\u00181n5D>\u001dlesL#\u0010ja8\u000f\u0001\u001b{x1Dw";
      f[9] = int.class;
      g[9] = "java/lang/Integer";
      f[10] = "lPSK\u0014\u0002g_B\u0004i\u001atXKM";
      f[11] = " >a8QK+1pw0E :t-";
      f[12] = "x(4+<\u001brr+<Z桺厀伖伕伇厙桺伞伖压Zf\u0003:q1<?\u0018\u007fq";
      f[13] = "0\u0000\u001a/}\u0016i\u001c\u0015c\u0003{\fL\u0017`dJ4K\r-~)";
      f[14] = "\u0000\u000f`}-T\u0019Kg\u0011\r)[\u0000}{1\u0016\u001cH<nH\u0010\u0005Q:tqL\u0011Iw\u0011";
      f[15] = "[[\u0007W6|Q\u0001\u0018@P栝伽校伦栿伍栝厣佥伦&n{\u001b\u0004\u0014A-<\u0012\u0005";
      f[16] = "\u000b\u0015:t\u0016)\u0001O%cp伌佭桯厅叆厳厒栩伫厅\u0005N#_\u001c7?H#\u0001\u000e";
      f[17] = ";Ch`6c\"\u0007o\f\u0018\u001e`Luf*!'\u00044sS";
      f[18] = "FrAM\u00008_6F!\fE\u001cwU[\u0015'Z*\u001bPe\u007f\u001d>]Q\u00079@pV!";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何树何何树树树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 3706;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树何树何何树树树树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[´a\u0096É\u008dX\u008aï, Är\u009bëÀICâ\u00adïÙÕÔ\u008f(\u0091, ñ\u0099\u0010\fGã\u0018J][Æ^\u0095")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   public static void k(
      PoseStack poseStack,
      float x,
      float y,
      float width,
      float height,
      List<友友何何友何友树何树.树何树何友友树何何友> messages,
      float animationOutput,
      int fontSize,
      boolean textShadow,
      float messageSpacing,
      int backgroundAlpha,
      float cornerRadius,
      友友何何友何友树何树 instance
   ) {
      C();
      何何友友树何树何友树 font = Cherish.instance.t().H(fontSize);
      float alphaMultiplier = Math.max(0.0F, Math.min(1.0F, animationOutput));
      int finalBackgroundAlpha = (int)(backgroundAlpha * alphaMultiplier);
      finalBackgroundAlpha = Math.max(0, Math.min(255, finalBackgroundAlpha));
      Color finalBackgroundColor = new Color(0, 0, 0, finalBackgroundAlpha);
      ShaderUtils.o(poseStack, 100739365455537L, x, y, width, height, cornerRadius, finalBackgroundColor);
      ShaderUtils.u(poseStack, x, y, 70079527892595L, width, height, cornerRadius, 6.0F, finalBackgroundColor);
      Iterator var25 = messages.iterator();
      if (var25.hasNext()) {
         友友何何友何友树何树.树何树何友友树何何友 message = (友友何何友何友树何树.树何树何友友树何何友)var25.next();
         String displayText = f(message);
         Color textColor = H(message.树何树何树何树友何何);
         float messageAlpha = Math.max(0.0F, 1.0F - (float)(System.currentTimeMillis() - message.树友何何何友树何何友) / 10000.0F);
         messageAlpha *= animationOutput;
         if (messageAlpha > 0.1F) {
            Color finalTextColor = new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), (int)(textColor.getAlpha() * messageAlpha));
            font.e(poseStack, displayText, x + 8.0F, y + 4.0F, finalTextColor.getRGB(), textShadow);
         }

         float var10000 = y + (font.x() + messageSpacing);
      }

      if (Module.Z() == null) {
         M(new String[3]);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String E(int state) {
      return switch (state) {
         case 0, 1 -> "§7通知§r";
         case 2 -> "§4警告§r";
         case 3 -> "§a成功§r";
         case 4 -> "§c失败§r";
         case 5 -> "§c错误§r";
         default -> "§7消息§r";
      };
   }

   public static void M(String[] var0) {
      何树树树何树友友何友 = var0;
   }

   private static Color H(int state) {
      return switch (state) {
         case 0, 1 -> new Color(170, 170, 170, 255);
         case 2 -> new Color(170, 0, 0, 255);
         case 3 -> new Color(85, 255, 85, 255);
         case 4, 5 -> new Color(255, 85, 85, 255);
         default -> new Color(255, 255, 255, 255);
      };
   }

   private static String HE_JIAN_GUO() {
      return "行走的50万——何炜霖";
   }
}
