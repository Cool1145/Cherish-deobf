package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.树友树友友何何树何何;
import cn.cool.cherish.utils.animations.友何友树树树树何树友;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.树树何友友友友何树友;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树树友树树友树友树 implements IWrapper, 何树友 {
   private static final CopyOnWriteArrayList<何树树友树树友树友树> 树树何何何何树友树友;
   private static final 树树树友友树友树树树 树树何树友友友友何树;
   private final 树树友何何何友友树何 何友树何树何何友友树;
   private static float 何树树树友树树何友友;
   private final 友何友树树树树何树友 树树何友友树树友何何;
   private final String 友何何树友何何何何树;
   private final 树友树友友何何树何何 何树何树何何友友友何;
   private final String 何友树友何友树树树友;
   private final float 何友树树树树树友树树;
   private static String[] 树何树友树树友何何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[42];
   private static final String[] g = new String[42];
   private static String LIU_YA_FENG;

   public 何树树友树树友树友树(树树友何何何友友树何 notificationType, String title, String description, float time) {
      long a = 何树树友树树友树友树.a ^ 79914620856111L;
      long ax = a ^ 106497879467628L;
      long axx = a ^ 19475615851846L;
      super();
      this.何友树友何友树树树友 = title;
      b<"ó">(-8222882925782649910L, a);
      this.友何何树友何何何何树 = description;
      this.何友树树树树树友树树 = (float)((long)(time * 1000.0F));
      this.何树何树何何友友友何 = new 树友树友友何何树何何(ax);
      this.何友树何树何何友友树 = notificationType;
      this.树树何友友树树友何何 = new cn.cool.cherish.utils.animations.何树友友何友友何树树(axx, 500, 1.0);
      b<"ó">(!b<"ó">(-8219505975778712274L, a), -8219461694409464316L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7480944305652586429L, 2496763403089512353L, MethodHandles.lookup().lookupClass()).a(228729685213661L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 4243798686220L;
      a();
      String[] var13 = new String[5];
      b<"ó">(var13, -3400678589978883168L, var9);
      Cipher var0;
      Cipher var14 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[15];
      int var5 = 0;
      String var4 = "¹\u0017k-¢ÕXï»ðSÅ7*!\u0086\u0010]\u0005\u00ad¿¼º+ÁUT¯#\u0091Éãt\u0010öï¬ñMÑ¸\u000bêè¯ÐS*~\u0097 \u009bárâ'Ñ6·\u0087\u001dQ\u0094Oè·\u009aÏ#þ|CòßíÔi¿B¤·\u0000v\u0010ô¡t\u0017X\u0080\u000b×»j\u0080×O:_}\u0018JAcé\u0000ä\u00adU\u001a®ð\u009c4FÌì\u001by\u0093ÛSv/¶\u0010\u008b\u0094\u0010&É\u0094×u\tC\u0005b#ÛsH\u0010]Êª\u0011\u0086è\u001cVb©ñ\u001a\u0012&xv\u0010Ä4Êï£Yª\u0082!Júh\u0080Òï_\u0010õ\u0005dÉ\u0080\u000f\u009c1ãeà;àÍ4ã\u0010\u0018+$PÈgNó2\u0006âaá¯J}\u0010?úVÁ\\ù\u009e-îñ<\u008fÝ!ìy\u0018q\u0003ú¦±\u0017N\u001aï1\u0098)ö'Q\u009d¬,Î`Üï\u0007]";
      short var6 = 252;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var15 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var21 = b(var0.doFinal(var15.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var21;
                  if ((var12 += var3) >= var6) {
                     b = var7;
                     c = new String[15];
                     树树何何何何树友树友 = new CopyOnWriteArrayList<>();
                     树树何树友友友友何树 = Cherish.instance.h();
                     b<"Ì">(2.0F, -3401129240083342871L, var9);
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var21;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "Ybõ4\u0088\u0016\u009e\u0017ã&\u0089\u0094\u0087·é¿e]v\u0095\u009e \u0097~\u0010\u0011þ\u0004C{7\u0005z\nZªAJ(è\u001c";
                  var6 = 41;
                  var3 = 24;
                  var12 = -1;
            }

            var15 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   public static void B(PoseStack poseStack) {
      long a = 何树树友树树友树友树.a ^ 84657393668215L;
      long ax = a ^ 92955372869694L;
      long axx = a ^ 21161521876113L;
      long axxx = a ^ 107782375777862L;
      long axxxx = a ^ 30066577868399L;
      long axxxxx = a ^ 61972171715383L;
      long axxxxxx = a ^ 5746986135055L;
      long axxxxxxx = a ^ 105501523485574L;
      Window window = mc.getWindow();
      b<"ó">(-4991545450404281198L, a);
      float height = 0.0F;
      float width = 0.0F;
      m(2.0F);
      Iterator var25 = b<"Õ">(-4993008285383182489L, a).iterator();
      if (var25.hasNext()) {
         何树树友树树友树友树 notification = (何树树友树树友树友树)var25.next();
         友何友树树树树何树友 animation = b<"A">(notification, -4993363117288029898L, a);
         animation.H(
            b<"A">(notification, -4992533931553398511L, a).Y((long)b<"A">(notification, -4991954893521580512L, a), axxx)
               ? b<"Õ">(-4992303225650883621L, a)
               : b<"Õ">(-4992901447880368289L, a),
            axxxxx
         );
         if (animation.B(b<"Õ">(-4992303225650883621L, a), axx)) {
            b<"Õ">(-4993008285383182489L, a).remove(notification);
         }

         animation.A(400, axxxx);
         float actualOffset = b<"Õ">(-4993088758230448427L, a).C(a<"j">(4153, 4997035133440978576L ^ a)) ? 0.0F : 3.0F;
         if (ClientUtils.o(new Object[]{axxxxxxx})) {
            String var28 = b<"Õ">(-4992847817829685321L, a).getValue();
            byte var29 = -1;
            switch (var28.hashCode()) {
               case -1887554740:
                  if (!var28.equals(a<"j">(6927, 4271945173440816549L ^ a))) {
                     break;
                  }

                  var29 = 0;
               case -352259601:
                  if (!var28.equals(a<"j">(24473, 3463077105976779062L ^ a))) {
                     break;
                  }

                  var29 = 1;
               case 63055923:
                  if (!var28.equals(a<"j">(10839, 964144164575499505L ^ a))) {
                     break;
                  }

                  var29 = 2;
               case 1712985934:
                  if (var28.equals(a<"j">(9907, 5187240489464682525L ^ a))) {
                     var29 = 3;
                  }
            }
            width = switch (var29) {
               case 0 -> {
                  height = 31.0F;
                  yield Math.max(
                     100,
                     Math.max(
                           b<"Õ">(-4991243548359707508L, a).z(20).A(b<"A">(notification, -4991258294715237745L, a)),
                           b<"Õ">(-4991243548359707508L, a).n(18).A(b<"A">(notification, -4991651305607849394L, a))
                        )
                        + 38
                  );
               }
               case 1 -> {
                  height = 27.0F;
                  yield Math.max(
                     100,
                     Math.max(
                        b<"Õ">(-4991243548359707508L, a).n(18).A(b<"A">(notification, -4991651305607849394L, a)) + 4,
                        b<"Õ">(-4991243548359707508L, a).n(14).A(b<"A">(notification, -4991258294715237745L, a)) + 26
                     )
                  );
               }
               case 2 -> {
                  height = 23.0F;
                  yield b<"Õ">(-4991243548359707508L, a).n(18).A(b<"A">(notification, -4991258294715237745L, a)) + 25;
               }
               case 3 -> {
                  height = 24.0F;
                  String timeDisplay = String.format(
                     a<"j">(2181, 1823058185762010661L ^ a),
                     (b<"A">(notification, -4991954893521580512L, a) - (float)b<"A">(notification, -4992533931553398511L, a).p(axxxxxx)) / 1000.0F
                  );
                  float titleWidth = b<"Õ">(-4991243548359707508L, a).X().m(b<"A">(notification, -4991651305607849394L, a));
                  float descWidth = b<"Õ">(-4991243548359707508L, a).X().m(b<"A">(notification, -4991258294715237745L, a) + " " + timeDisplay);
                  yield Math.max(120.0F, Math.max(titleWidth, descWidth) + 30.0F);
               }
               default -> 0.0F;
            };
         }

         String var34 = b<"Õ">(-4992847817829685321L, a).getValue();
         byte var35 = -1;
         switch (var34.hashCode()) {
            case -1887554740:
               if (!var34.equals(a<"j">(6927, 4271945173440816549L ^ a))) {
                  break;
               }

               var35 = 0;
            case -352259601:
               if (!var34.equals(a<"j">(24473, 3463077105976779062L ^ a))) {
                  break;
               }

               var35 = 1;
            case 63055923:
               if (!var34.equals(a<"j">(10839, 964144164575499505L ^ a))) {
                  break;
               }

               var35 = 2;
            case 1712985934:
               if (var34.equals(a<"j">(9907, 5187240489464682525L ^ a))) {
                  var35 = 3;
               }
         }
         width = switch (var35) {
            case 0 -> {
               height = 31.0F;
               yield Math.max(
                  100,
                  Math.max(
                        b<"Õ">(-4991243548359707508L, a).n(20).A(b<"A">(notification, -4991258294715237745L, a)),
                        b<"Õ">(-4991243548359707508L, a).n(18).A(b<"A">(notification, -4991651305607849394L, a))
                     )
                     + 38
               );
            }
            case 1 -> {
               height = 27.0F;
               yield Math.max(
                  100,
                  Math.max(
                     b<"Õ">(-4991243548359707508L, a).n(18).A(b<"A">(notification, -4991651305607849394L, a)) + 4,
                     b<"Õ">(-4991243548359707508L, a).n(14).A(b<"A">(notification, -4991258294715237745L, a)) + 26
                  )
               );
            }
            case 2 -> {
               height = 23.0F;
               yield b<"Õ">(-4991243548359707508L, a).n(18).A(b<"A">(notification, -4991258294715237745L, a)) + 25;
            }
            case 3 -> {
               height = 24.0F;
               String timeDisplay = String.format(
                  a<"j">(2181, 1823058185762010661L ^ a),
                  (b<"A">(notification, -4991954893521580512L, a) - (float)b<"A">(notification, -4992533931553398511L, a).p(axxxxxx)) / 1000.0F
               );
               float titleWidth = b<"Õ">(-4991243548359707508L, a).X().m(b<"A">(notification, -4991651305607849394L, a));
               float descWidth = b<"Õ">(-4991243548359707508L, a).X().m(b<"A">(notification, -4991258294715237745L, a) + " " + timeDisplay);
               yield Math.max(120.0F, Math.max(titleWidth, descWidth) + 30.0F);
            }
            default -> width;
         };
         if (b<"Õ">(-4993211030510645069L, a).C(a<"j">(9368, 1506103306806516283L ^ a))) {
            float var40 = (float)((window.getGuiScaledWidth() / 2.0 + width / 2.0F - width) / animation.T(ax));
            var40 = window.getGuiScaledHeight() / 2.0F + 0.0F + 15.0F;
         }

         float x = (float)(window.getGuiScaledWidth() - width * animation.T(ax));
         float y = window.getGuiScaledHeight() - 0.0F - height - 33.0F;
         poseStack.pushPose();
         if (b<"Õ">(-4992785609007963450L, a).C(a<"j">(32315, 5722249553213685913L ^ a))) {
            poseStack.translate((x + width / 2.0) * (1.0 - animation.T(ax)), (y + height / 2.0) * (1.0 - animation.T(ax)), 0.0);
            poseStack.scale((float)animation.T(ax), (float)animation.T(ax), 0.0F);
         }

         if (b<"Õ">(-4992847817829685321L, a).C(a<"j">(10839, 964144164575499505L ^ a))) {
            notification.U(poseStack, x - 5.0F, y, width, height);
         }

         notification.U(poseStack, x, y, width, height);
         poseStack.popPose();
         float var42 = 0.0F + (float)((height + actualOffset) * animation.T(ax));
      }

      if (b<"ó">(-4992672787254193546L, a)) {
         b<"ó">("Yf4jLc", -4991862939379950579L, a);
      }
   }

   public static void S(树树友何何何友友树何 notificationType, String title, String description, float time) {
      long a = 何树树友树树友树友树.a ^ 98623446039442L;
      b<"Õ">(-7975786809496953726L, a).add(new 何树树友树树友树友树(notificationType, title, description, time));
   }

   private void V(PoseStack poseStack, float x, float y, float width, float height, float percentage, boolean isEnglish) {
      long a = 何树树友树树友树友树.a ^ 127492491496949L;
      long ax = a ^ 63981831811981L;
      Color typeColor = b<"A">(this, -1786119532903029024L, a).E();
      Color bgColor = new Color(0, 0, 0, 110);
      Color textColor = b<"Õ">(-1785447455315014991L, a);
      Color descColor = new Color(200, 200, 200, 255);
      float timeRemaining = (b<"A">(this, -1784766358650235998L, a) - (float)b<"A">(this, -1786578998925017965L, a).p(ax)) / 1000.0F;
      String timeDisplay = String.format(a<"j">(29313, 7088246917860217263L ^ a), Math.max(0.0F, timeRemaining));
      RenderUtils.drawRectangle(poseStack, x, y, width, height, bgColor.getRGB());
      float progressWidth = width * (1.0F - percentage);
      RenderUtils.drawRectangle(poseStack, x, y + height - 1.0F, progressWidth, 1.0F, typeColor.getRGB());
      b<"Õ">(-1785196237427480306L, a).a(30).c(poseStack, b<"A">(this, -1786119532903029024L, a).Z(), x + 6.5F, y + 6.5F, typeColor.getRGB());
      b<"Õ">(-1785196237427480306L, a).X().U(poseStack, b<"A">(this, -1785632587211126836L, a), x + 25.0F, y + 2.0F, textColor.getRGB());
      b<"Õ">(-1785196237427480306L, a).X().U(poseStack, b<"A">(this, -1785323156290083059L, a) + " " + timeDisplay, x + 25.0F, y + 12.5F, descColor.getRGB());
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 58;
               case 1 -> 12;
               case 2 -> 39;
               case 3 -> 41;
               case 4 -> 33;
               case 5 -> 43;
               case 6 -> 38;
               case 7 -> 54;
               case 8 -> 10;
               case 9 -> 30;
               case 10 -> 48;
               case 11 -> 26;
               case 12 -> 7;
               case 13 -> 2;
               case 14 -> 22;
               case 15 -> 46;
               case 16 -> 3;
               case 17 -> 6;
               case 18 -> 34;
               case 19 -> 37;
               case 20 -> 57;
               case 21 -> 18;
               case 22 -> 13;
               case 23 -> 20;
               case 24 -> 60;
               case 25 -> 29;
               case 26 -> 44;
               case 27 -> 11;
               case 28 -> 19;
               case 29 -> 16;
               case 30 -> 56;
               case 31 -> 5;
               case 32 -> 31;
               case 33 -> 4;
               case 34 -> 28;
               case 35 -> 1;
               case 36 -> 25;
               case 37 -> 0;
               case 38 -> 27;
               case 39 -> 17;
               case 40 -> 55;
               case 41 -> 36;
               case 42 -> 52;
               case 43 -> 35;
               case 44 -> 40;
               case 45 -> 63;
               case 46 -> 21;
               case 47 -> 50;
               case 48 -> 59;
               case 49 -> 24;
               case 50 -> 42;
               case 51 -> 49;
               case 52 -> 9;
               case 53 -> 47;
               case 54 -> 32;
               case 55 -> 61;
               case 56 -> 51;
               case 57 -> 62;
               case 58 -> 53;
               case 59 -> 45;
               case 60 -> 23;
               case 61 -> 8;
               case 62 -> 14;
               default -> 15;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树树友树树友树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private void b(PoseStack poseStack, float x, float y, float width, float height, float percentage, boolean isEnglish) {
      long a = 何树树友树树友树友树.a ^ 38603370875285L;
      b<"ó">(7158498241564794224L, a);
      float finalX = b<"A">(this, 7157976104415928960L, a) == b<"Õ">(7158748648929169361L, a) ? x + 3.0F : x;
      Color bgColor = b<"Õ">(7158071214755831607L, a).C(a<"j">(32249, 8962636368301873854L ^ a))
         ? b<"Õ">(7158612447741169361L, a)
         : (b<"Õ">(7158071214755831607L, a).C(a<"j">(24711, 4170611913110996942L ^ a)) ? new Color(0, 0, 0, 75) : b<"Õ">(7158878243873459083L, a));
      Color fontColor = b<"Õ">(7158071214755831607L, a).C(a<"j">(4153, 4997138617059030898L ^ a))
         ? b<"Õ">(7158878243873459083L, a)
         : b<"Õ">(7158612447741169361L, a);
      Color iconcolor = 树树何友友友友何树友.z(b<"A">(this, 7157976104415928960L, a).E(), 70.0F);
      RenderUtils.drawRoundedRect(poseStack, x, y, width, height, 0.0, bgColor);
      RenderUtils.drawRoundedRect(poseStack, x, y + height - 1.0F, width * percentage, 1.0, 0.0, b<"A">(this, 7157976104415928960L, a).E());
      b<"Õ">(7159005501556714862L, a).a(35).c(poseStack, b<"A">(this, 7157976104415928960L, a).Z(), finalX + 5.0F, y + 7.0F, iconcolor.getRGB());
      b<"Õ">(7159005501556714862L, a).n(18).c(poseStack, b<"A">(this, 7158604061400679340L, a), x + 22.0F, y + 4.5F, fontColor.getRGB());
      b<"Õ">(7159005501556714862L, a).n(14).c(poseStack, b<"A">(this, 7158773854227358573L, a), x + 22.0F, y + 17.0F, fontColor.getRGB());
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'A' && var8 != 't' && var8 != 213 && var8 != 204) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'n') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 243) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'A') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 't') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "O]X\u00050C@\u001d\u0015\u000e:^E@\u001eH*E\u0002佦桧桷厔栽栽司桧厭桎";
      f[1] = float.class;
      g[1] = "java/lang/Float";
      f[2] = "\u0011h^!/:\u000f`Dnb \u0015j]2s*\u0015}\u0006\u0003n?\u0002FF\u0017s&\u000fli2s.\u0002EA3u";
      f[3] = "3P\u0007B\u0004#<\u0010JI\u000e>9MA\u000f\u001e89RZ\u000f桺厇桁叵叢佴伾桝伅佫";
      f[4] = "\u0014NE@d\u0006\u001b\u000e\bKn\u001b\u001eS\u0003\rf\u0006\u0013U\u0007F%\u0000\u001aP\u0007\ro\u0000\u0004P\u0007BrG厼叫桺佶佞厢厼叫厠佶";
      f[5] = "Q/K1/(^o\u0006:%5[2\r|6&^4\u0000|)*B-K\u001f/#W\u0017\u0004>5\"";
      f[6] = "Lo\u001cHG2G`\r\u0007;+Hz\u0003D\f\u001b^m\u000fY\u001d7I`";
      f[7] = "s(t\u0017ln|h9\u001cfsy52Zvh>桗桋县佖佔佅厍厑桥佖";
      f[8] = "\u000b\u0001dH<z\u0000\u000eu\u0007Ab\u0013\t|N";
      f[9] = ";)@\u001b1 N\tK\u0014 o3\u0011X\u0013)&[";
      f[10] = void.class;
      g[10] = "java/lang/Void";
      f[11] = "Sk;9C(\\+v2I5Yv}tY.\u001e栔栄桋叧厌校収栄桋栽";
      f[12] = "9.\u0017\nE>$;O(\u00043<=";
      f[13] = ":.EblT5n\bifI03\u0003/nT=5\u0007d-v6$\u001emf";
      f[14] = boolean.class;
      g[14] = "java/lang/Boolean";
      f[15] = "\u0019J)X;'\u0016\ndS1:\u0013Wo\u0015!<\u0013Ht\u00155&\u0013IfO='\u0014W)台企厃桫栵栖台桅伝厱";
      f[16] = "`\u0019\u001dvPMoYP}ZPj\u0004[;JVj\u001b@;^Lj\u001aRaVMm\u0004\u001d叞佪叩栒桦栢栄佪栳又";
      f[17] = "o99_U&d6(\u00104(o=,J";
      f[18] = "\u0016gv&Ty\u001fy}\">伙桦栐佛桄叽厇伢及佛]W*\u000frl`^4\u0004v";
      f[19] = "'2I\u00111R-s\u000bc伂桷桓桛叶桺框伳厉厁5Z3_0z\u000e\u0007-\u001cw";
      f[20] = "8(6\u001e\\Als5\u000f3d\t*>\fQ\u0018t(f\u0013I'";
      f[21] = "\u0006\u0015&!Y\n\u0001\\!<%档你可厅厁佸档栤佱桟B\u0019B\fR\"9W\u0011RU";
      f[22] = "\"V..D9(\u0017l\\佷栜伒栿伏企叩叆厌佻Rf\u0015gt_b6\u0017>v";
      f[23] = "&\u0014/N)\brO,_F'\u0017\u0016'\\$Qj\u0014\u007fC<n)\u000f!\u0014 \u0010pF7QF";
      f[24] = "!&he\u0012\u0019+g*\u0017桥格休伋佉佊桥另桕厕\u0014.\u0005Wv2mk\u0006\u001d)";
      f[25] = "A/]\fD`Kn\u001f~c\\\u00123\u0011\u0015\u0016;A#]D*b\\0\u0018\u0018T;\u0015&]~";
      f[26] = "!o|?k\u0011&&{\"\u0017厢佇伋叟桅佊似佇伋叟\\+Y+(x'e\nu/";
      f[27] = ">yAXt\u00027gJ\\\u001e佢桎栎栨佾佃叼厔叔史#wQ'l[\u001e~O,h";
      f[28] = "?R\u0015u+/5\u0013W\u0007优叐桋使桰佚优叐厑栻i:{|<@\u0003m<-l";
      f[29] = "\u000e$EQ4T\u0004e\u0007#桃桱伾厗叺栺桃厫伾伉9I1\u0019\b,D\u0018+\u0004\u0000";
      f[30] = "*G\u0017/$F-\u000e\u00102X佫叒桧桮休桁叵佌桧桮Ld\u000e \u0000\u00137*]~\u0007";
      f[31] = "\u0018\u001e!im=\u001fW&t\u0011厎叠佺伜叉栈厎叠栾桘\n-u\u0012Y%qc&L^";
      f[32] = ":/mC\u001f\u00010n/1厲你伊框叒佬伬你伊框\u0011\f\u0001Vna/J@E<";
      f[33] = "\u007fa`An[v`uV\u0010c\u000bWNy\u0010\u00190{~Db\u00101ni";
      f[34] = "Y\u000bOE]JSJ\r7Zv\b\u0006\u000fW\f\u000b\nFCL3JIGS\bNH\t\u000bH7";
      f[35] = "\u0015g\"4b\u0013\u001f&`F栕栶伥栎厝厅叏召伥栎^v0I\nw>%<O\u0017";
      f[36] = "\u0012DT(\fiE\u0003\u0005xn^/GK-W=\u0011\u0001\n>\u0005\u0003";
      f[37] = "B\u0019f+RDHX$Y佡去栶厪佇厚栥桡栶厪\u001adL\u0013\u0016W$\"\r\u0000D";
      f[38] = "9Z\u0002rR30[\u0017e,\u001eId;D,qv@\u001cw^xwU\u000b";
      f[39] = "\u0011v^'S\u0002F1\u000fw1伵佱桑史桐栨桱可桑史I\fVC&S#[\u0011\u0012v";
      f[40] = "JCq\nMz\u001d\u0004 Z/jw@n\u000f\u0016.I\u0006/\u001cD\u0010I\rq]In\u0010Dg\u0018/";
      f[41] = "az\u0013\u0005\"Zk;Qw休厥栕栓桶桮桕厥栕栓oN Wv2T\u0013>\u00141";
   }

   private void a(PoseStack poseStack, float x, float y, float width, float height, float percentage) {
      long a = 何树树友树树友树友树.a ^ 111014531785621L;
      Color color = 树树何友友友友何树友.z(树树何友友友友何树友.x(b<"Õ">(5285315280931103115L, a), b<"A">(this, 5284546161711777920L, a).E(), 0.65F), 70.0F);
      Color iconColor = 树树何友友友友何树友.z(b<"A">(this, 5284546161711777920L, a).E(), 70.0F);
      Color textColor = 树树何友友友友何树友.z(b<"Õ">(5285194049907811537L, a), 80.0F);
      RenderUtils.drawRectangle(poseStack, x, y, width + 4.75F, height, new Color(0, 0, 0, 70).getRGB());
      RenderUtils.drawRectangle(poseStack, x, y, width * percentage, height, color.getRGB());
      b<"Õ">(5285434279358416750L, a).a(30).c(poseStack, b<"A">(this, 5284546161711777920L, a).Z(), x + 5.0F, y + 7.0F, iconColor.getRGB());
      b<"Õ">(5285434279358416750L, a).n(18).c(poseStack, b<"A">(this, 5285349164251433325L, a), x + 21.0F, y + 8.65F, textColor.getRGB());
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 17425;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何树树友树树友树友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树树友树树友树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static void m(float toggleTime) {
      long a = 何树树友树树友树友树.a ^ 91911429483372L;
      b<"Ì">(2.0F, -4491053434192705399L, a);
   }

   public static void p(树树友何何何友友树何 notificationType, String title, String description) {
      long a = 何树树友树树友树友树.a ^ 31606465189255L;
      b<"Õ">(9170759490719904407L, a).add(new 何树树友树树友树友树(notificationType, title, description, b<"Õ">(9171542824013723234L, a)));
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void U(PoseStack poseStack, float x, float y, float width, float height) {
      long a = 何树树友树树友树友树.a ^ 85348396275623L;
      long ax = a ^ 4791004965343L;
      long axx = a ^ 103983605851222L;
      b<"ó">(-4797891909201132734L, a);
      float percentage = Math.min((float)b<"A">(this, -4798878190118639935L, a).p(ax) / b<"A">(this, -4798301624241452560L, a), 1.0F);
      boolean isEnglish = ClientUtils.o(new Object[]{axx});
      String var15 = b<"Õ">(-4799194268170559385L, a).getValue();
      byte var16 = -1;
      switch (var15.hashCode()) {
         case -1887554740:
            if (!var15.equals(a<"j">(25944, 2744582341556050988L ^ a))) {
               break;
            }

            var16 = 0;
         case -352259601:
            if (!var15.equals(a<"j">(17718, 7251706225565613121L ^ a))) {
               break;
            }

            var16 = 1;
         case 63055923:
            if (!var15.equals(a<"j">(31524, 3317692667302216284L ^ a))) {
               break;
            }

            var16 = 2;
         case 1712985934:
            if (var15.equals(a<"j">(9810, 1618293651185458979L ^ a))) {
               var16 = 3;
            }
      }

      switch (var16) {
         case 0:
            this.G(poseStack, x, y, width, height, isEnglish);
         case 1:
            this.b(poseStack, x, y, width, height, percentage, isEnglish);
         case 2:
            this.a(poseStack, x, y, width, height, percentage);
         case 3:
            this.V(poseStack, x, y, width, height, percentage, isEnglish);
      }
   }

   public static String[] A() {
      return 树何树友树树友何何何;
   }

   public static void A(String[] var0) {
      树何树友树树友何何何 = var0;
   }

   private void G(PoseStack poseStack, float x, float y, float width, float height, boolean isEnglish) {
      long a = 何树树友树树友树友树.a ^ 21388901583908L;
      long ax = a ^ 124291250797759L;
      b<"ó">(-6419555440309397311L, a);
      Color var10002 = new Color(20, 20, 20, 80);
      double var10003 = x;
      double var10004 = y;
      double var10005 = x + width;
      double axx = y + height;
      double axxx = var10005;
      double axxxx = var10004;
      double axxxxx = var10003;
      Color axxxxxx = var10002;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, 36.0};
      var10011[7] = 8.0;
      var10011[6] = axx;
      var10011[5] = axxx;
      var10011[4] = axxxx;
      var10011[3] = axxxxx;
      var10011[2] = axxxxxx;
      var10011[1] = ax;
      var10011[0] = poseStack;
      RenderUtils.o(var10011);
      Color var10001 = new Color(20, 20, 20, 40);
      double var29 = x + 4.0F;
      var10003 = y + 4.0F;
      var10004 = x + height - 4.0F;
      axx = y + height - 4.0F;
      axxx = var10004;
      axxxx = var10003;
      axxxxx = var29;
      axxxxxx = var10001;
      Object[] var10010 = new Object[]{null, null, null, null, null, null, null, null, 36.0};
      var10010[7] = 4.0;
      var10010[6] = axx;
      var10010[5] = axxx;
      var10010[4] = axxxx;
      var10010[3] = axxxxx;
      var10010[2] = axxxxxx;
      var10010[1] = ax;
      var10010[0] = poseStack;
      RenderUtils.o(var10010);
      b<"Õ">(-6419645985532794657L, a)
         .a(30)
         .c(poseStack, b<"A">(this, -6420148208153467087L, a).Z(), x + 9.5F, y + 11.0F, new Color(200, 200, 200, 255).getRGB());
      if (isEnglish) {
         b<"Õ">(-6419645985532794657L, a)
            .z(20)
            .c(poseStack, b<"A">(this, -6419520522859575779L, a), x + 30.0F, y + 4.0F, new Color(200, 200, 200, 255).getRGB());
         b<"Õ">(-6419645985532794657L, a)
            .n(18)
            .c(poseStack, b<"A">(this, -6419843285446580516L, a), x + 30.0F, y + 17.0F, new Color(200, 200, 200, 255).getRGB());
      }

      b<"Õ">(-6419645985532794657L, a).n(20).c(poseStack, b<"A">(this, -6419520522859575779L, a), x + 30.0F, y + 4.0F, new Color(200, 200, 200, 255).getRGB());
      b<"Õ">(-6419645985532794657L, a).n(18).c(poseStack, b<"A">(this, -6419843285446580516L, a), x + 30.0F, y + 17.0F, new Color(200, 200, 200, 255).getRGB());
   }

   private static String HE_DA_WEI() {
      return "何大伟230622198107200054";
   }
}
