package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.友友友何树友何树树树;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class 友树友何树树何树何何 extends Screen implements IWrapper, 何树友 {
   private long 友友何何何树何何树友 = System.currentTimeMillis();
   private long 友何友何何友树树树树;
   private float 何友树友何友友何友何;
   private float 树树树何何树树树何友;
   private final List<友友友何树友何树树树> 友何何何友友树树树何;
   private boolean 何何友友何何友友何树;
   private float 友树树树树树树树何友;
   private float 何友树树树友树友友何;
   private static boolean 友何何友何何何树友友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[33];
   private static final String[] g = new String[33];
   private static int _何建国230622195906030014 _;

   public 友树友何树树何树何何() {
      super(Component.literal("Drag Edit"));
      D();
      this.友何友何何友树树树树 = 0L;
      this.何何友友何何友友何树 = false;
      this.友树树树树树树树何友 = 0.0F;
      this.何友树树树友树友友何 = 0.0F;
      this.友何何何友友树树树何 = Cherish.instance
         .getModuleManager()
         .p()
         .stream()
         .filter(module -> module instanceof 友友友何树友何树树树)
         .map(module -> (友友友何树友何树树树)module)
         .collect(Collectors.toList());
      if (Module.Z() == null) {
         B(false);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5311083576180357496L, -7000757464386681622L, MethodHandles.lookup().lookupClass()).a(32774913101501L);
      // $VF: monitorexit
      a = var10000;
      a();
      B(false);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(97021333493021L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[4];
      int var5 = 0;
      String var4 = "\u0001E¦\u008d\u0006Ø\u00009ª`PÅo1õàvï\u000fu¡\u0004ßòPëTÔcGyE¼GD\u0084g\u0084yT\u0018sa!§\u0007Û\u001eV`±ìTaQÂ\u0007\u001e-r\u001eG\u007f¦g";
      byte var6 = 65;
      char var3 = '(';
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[4];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "¬-Sd&\u0086\u008c\u0099Â¶Ù,Ë±>ké9uû2\u001bÏl\u0090ÒV\u0006à\u001aY= \nÐ8à\u0087ª&±Ó\u0092IzâK=îè§±\u0017,?Ô\u009cí!5\u0003\u0001\u000fÆ\u009f";
                  var6 = 65;
                  var3 = ' ';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static void B(boolean var0) {
      友何何友何何何树友友 = var0;
   }

   public static boolean D() {
      return 友何何友何何何树友友;
   }

   private void Z() {
      r();
      long now = System.currentTimeMillis();
      float delta = Math.min((float)(now - this.友友何何何树何何树友) / 1000.0F, 0.05F);
      this.友友何何何树何何树友 = now;
      if (!this.何何友友何何友友何树
         && this.R(
            mc.mouseHandler.xpos() * super.width / mc.getWindow().getScreenWidth(), mc.mouseHandler.ypos() * super.height / mc.getWindow().getScreenHeight()
         )) {
      }

      this.何友树树树友树友友何 = RenderUtils.N(this.何友树树树友树友友何, 1.0F, delta * 8.0F);
      if (this.何何友友何何友友何树) {
         this.友树树树树树树树何友 = Math.min(1.0F, (float)(now - this.友何友何何友树树树树) / 1000.0F);
         if (!(this.友树树树树树树树何友 >= 1.0F)) {
            return;
         }

         Iterator var10 = this.友何何何友友树树树何.iterator();
         if (var10.hasNext()) {
            友友友何树友何树树树 dragModule = (友友友何树友何树树树)var10.next();
            if (dragModule.isEnabled()) {
               dragModule.m();
            }
         }

         ClientUtils.P(125527250587045L, "Reset all drag modules!");
         this.何何友友何何友友何树 = false;
      }

      this.友树树树树树树树何友 = Math.max(0.0F, this.友树树树树树树树何友 - delta * 3.0F);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 59;
               case 1 -> 33;
               case 2 -> 57;
               case 3 -> 34;
               case 4 -> 7;
               case 5 -> 35;
               case 6 -> 24;
               case 7 -> 3;
               case 8 -> 22;
               case 9 -> 51;
               case 10 -> 12;
               case 11 -> 55;
               case 12 -> 2;
               case 13 -> 6;
               case 14 -> 41;
               case 15 -> 38;
               case 16 -> 4;
               case 17 -> 13;
               case 18 -> 39;
               case 19 -> 27;
               case 20 -> 60;
               case 21 -> 5;
               case 22 -> 62;
               case 23 -> 17;
               case 24 -> 20;
               case 25 -> 49;
               case 26 -> 36;
               case 27 -> 10;
               case 28 -> 16;
               case 29 -> 48;
               case 30 -> 21;
               case 31 -> 32;
               case 32 -> 19;
               case 33 -> 58;
               case 34 -> 26;
               case 35 -> 25;
               case 36 -> 47;
               case 37 -> 11;
               case 38 -> 50;
               case 39 -> 14;
               case 40 -> 45;
               case 41 -> 54;
               case 42 -> 0;
               case 43 -> 30;
               case 44 -> 29;
               case 45 -> 61;
               case 46 -> 63;
               case 47 -> 44;
               case 48 -> 15;
               case 49 -> 46;
               case 50 -> 53;
               case 51 -> 43;
               case 52 -> 1;
               case 53 -> 8;
               case 54 -> 52;
               case 55 -> 31;
               case 56 -> 9;
               case 57 -> 18;
               case 58 -> 56;
               case 59 -> 40;
               case 60 -> 42;
               case 61 -> 23;
               case 62 -> 37;
               default -> 28;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树友何树树何树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'F' && var8 != 'N' && var8 != 218 && var8 != 'u') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'x') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'p') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'F') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'N') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 218) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "n^:\u001f\bPa\u001ew\u0014\u0002MdC|R\u0012V#叻栅厷伲栮栜佥栅伩伲";
      f[1] = "EISG6oNFB\bJvA\\LK}FWK@Vlj@F";
      f[2] = boolean.class;
      g[2] = "java/lang/Boolean";
      f[3] = long.class;
      g[3] = "java/lang/Long";
      f[4] = "z\u007fUz\u0003au?\u0018q\t|pb\u00137\u0001a}d\u0017|BCvu\u000eu\t";
      f[5] = "\u00030u-d&7\u0013zm)-=\u000e\u007f0\"k5\u0013r6& v1y'?)=G";
      f[6] = float.class;
      g[6] = "java/lang/Float";
      f[7] = "\t]\rLe%\u0014HUn$(\fN";
      f[8] = "\u0001>|i\tQ5\u001ds)DZ?\u0000vtO\u001c7\u001d{rKWt?pcR^?I";
      f[9] = void.class;
      g[9] = "java/lang/Void";
      f[10] = "|7n\r\u0003\u0007b?tBa\u001be\"";
      f[11] = int.class;
      g[11] = "java/lang/Integer";
      f[12] = "/a\u0001e9`/a\u001695o5*\u0016'=l/p[\u0006=g$g\u0007*2}";
      f[13] = "\u0015\f]\u000e\u0014E\u0015\fJR\u0018J\u000fGJL\u0010I\u0015\u001d\u0007m\u0016Y\b\faA\u0017H\u0017\f[";
      f[14] = "Y\u0003YfImR\fH)(cY\u0007Ls";
      f[15] = "61?A]\u000f~=b\"\u000bn}}d\u001b\u001dPa2\u007f\"\u0018^ct\u007f\u001c\u0004\u0011xM";
      f[16] = "K)=<>\u0016\u0003%`_作伪厹厖佟伂参厴伧桌\u0002fb\u001a\u0019.`9eH\u0002";
      f[17] = "]\u001c}P;8\u0015\u0010 3j\u000e]^\u007f\u000f8\u000elPsR>4\u0002Z,Tz";
      f[18] = "z\t+=ob2\u0005v^厓佞厈伨佉厝桉栚桒桬\u0014d18/\u0005hg1h1";
      f[19] = "d9QH#l,5\f+P\rl&\u0003Hgo3!QS\u001c";
      f[20] = "\u001eaxUoLVm%6厓叮佲佀会栯伍佰栶叞G\f1\u0016Km;\u000f1FU";
      f[21] = "7y;|4@\u007fuf\u001fA!?fi|pC`a;g\u000b\u001fo5x`5Swto\u001f";
      f[22] = "\u0014}N;Y>Bn\u001f6<\u0015/+X\u007f_=I/\u0010bCG";
      f[23] = "irU\u001eK\u0016eeO\u001csC\u000e1\u001dZM\u0012\u000e\u0000\u0015RIHf9\u001e^\u001a\u001c";
      f[24] = "ML\u000fT2m\u0005@R7佐叏桥栩栩叴栔叏县佭0\u000bu|DNL\u00062r\u001f";
      f[25] = "SYfx; WRs*T\u0019.rE_T{\u0004Ls}2\u007f\u000fY!";
      f[26] = "*Elm\u0017\"bI1\u000e叫桚栂栠桊栗栱桚但叺S2P3#G/?\u0017=x";
      f[27] = "\u0014*z\u0019bWB9+\u0014\u0007p/|l]dTIx$@x.\u0011($Xx\u0010]0eO\u0007";
      f[28] = "\u0011?[|\u001d$Y3\u0006\u001f栻桜根伞伹栆栻桜佽厀d#Z5\u0018=\u0018.\u001d;C";
      f[29] = "`LK[\u0010\u0011(@\u00168佲厳案右伩叻召伭厒佭t\u0004W\u0000iN\b\t\u0010\u000e2";
      f[30] = "\u00122\u0018#&\u001dZ>E@叚伡佾伓古厃栀桥栺伓'\u007f)\u0007[qH#u\u001e\u001f";
      f[31] = "+ YJ#wc,\u0004)rA+b[\u0015'A\u001alWH&{tf\bNb";
      f[32] = "e\bX\u007fX6-\u0004\u0005\u001c\u001dWm\u0017\n\u007f\u001c52\u0010Xdg";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树友何树树何树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2378;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友树友何树树何树何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static boolean r() {
      D();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private boolean R(double mouseX, double mouseY) {
      D();
      return mouseX >= this.何友树友何友友何友何 && mouseX <= this.何友树友何友友何友何 + 120.0F && mouseY >= this.树树树何何树树树何友 && mouseY <= this.树树树何何树树树何友 + 30.0F;
   }

   private static String HE_WEI_LIN() {
      return "刘凤楠230622109211173513";
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTicks) {
      PoseStack poseStack = graphics.pose();
      D();
      this.Z();
      Color textColor = 何树友友树树友何树何.S(new Color(200, 200, 200), Color.WHITE, this.何友树树树友树友友何);
      RenderUtils.q(
         poseStack, this.何友树友何友友何友何, this.树树树何何树树树何友, this.何友树友何友友何友何 + 120.0F, this.树树树何何树树树何友 + 30.0F, 137876390830295L, new Color(0, 0, 0, 80).getRGB()
      );
      if (this.友树树树树树树树何友 > 0.0F) {
         RenderUtils.q(
            poseStack,
            this.何友树友何友友何友何,
            this.树树树何何树树树何友,
            this.何友树友何友友何友何 + 120.0F * this.友树树树树树树树何友,
            this.树树树何何树树树何友 + 30.0F,
            137876390830295L,
            new Color(255, 255, 255, (int)(100.0F * this.友树树树树树树树何友)).getRGB()
         );
      }

      String buttonText = this.何何友友何何友友何树
         ? String.format("Hold %.1fs", (1000.0F - (float)(System.currentTimeMillis() - this.友何友何何友树树树树)) / 1000.0F)
         : "Hold to Reset";
      float textWidth = Cherish.instance.t().H(16).D(buttonText);
      float textX = this.何友树友何友友何友何 + (120.0F - textWidth) / 2.0F;
      float textY = this.树树树何何树树树何友 + Cherish.instance.t().H(16).f(30.0F) + 1.0F;
      Cherish.instance.t().H(16).q(poseStack, buttonText, textX, textY, textColor.getRGB());
      super.render(graphics, mouseX, mouseY, partialTicks);
      Module.V(new Module[5]);
   }

   public boolean isPauseScreen() {
      return false;
   }

   protected void init() {
      super.init();
      this.何友树友何友友何友何 = (super.width - 120) / 2.0F;
      this.树树树何何树树树何友 = 60.0F;
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      D();
      this.何何友友何何友友何树 = false;
      Iterator var9 = this.友何何何友友树树树何.iterator();
      if (var9.hasNext()) {
         友友友何树友何树树树 dragModule = (友友友何树友何树树树)var9.next();
         dragModule.w(button);
      }

      return super.mouseReleased(mouseX, mouseY, button);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      D();
      if (this.何何友友何何友友何树 && !this.R(mouseX, mouseY)) {
         this.何何友友何何友友何树 = false;
      }

      Iterator var13 = this.友何何何友友树树树何.iterator();
      if (var13.hasNext()) {
         友友友何树友何树树树 dragModule = (友友友何树友何树树树)var13.next();
         dragModule.t(mouseX, mouseY, button);
      }

      return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      D();
      if (button == 0 && this.R(mouseX, mouseY)) {
         this.何何友友何何友友何树 = true;
         this.友何友何何友树树树树 = System.currentTimeMillis();
         this.友树树树树树树树何友 = 0.0F;
         return true;
      } else {
         Iterator var9 = this.友何何何友友树树树何.iterator();
         if (var9.hasNext()) {
            友友友何树友何树树树 dragModule = (友友友何树友何树树树)var9.next();
            if (dragModule.isEnabled() && dragModule.C(mouseX, mouseY, button)) {
               return true;
            }
         }

         return super.mouseClicked(mouseX, mouseY, button);
      }
   }
}
