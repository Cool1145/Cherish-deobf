package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import heilongjiang.zhaoyuan.何树友;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.User;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class 友友树树何友树树何何 extends Screen implements 何树友 {
   public static final 友友树树何友树树何何 何树树何友友树树何树;
   private EditBox 树何何何友友友友何友;
   private EditBox 友树友友树友友树何树;
   private Button 何树何何何何友友树友;
   private static String[] 树树树友何树友友何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[27];
   private static final String[] i = new String[27];
   private static String HE_JIAN_GUO;

   public 友友树树何友树树何何() {
      long a = 友友树树何友树树何何.a ^ 101960173422164L;
      super(Component.literal(a<"g">(22487, 2544339367032751626L ^ a)));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-2557854155459067024L, -7496348840092338833L, MethodHandles.lookup().lookupClass()).a(9618901131586L);
      // $VF: monitorexit
      a = var10000;
      long var20 = a ^ 58383117872773L;
      a();
      String[] var24 = new String[5];
      c<"À">(var24, -5607317417464797314L, var20);
      Cipher var11;
      Cipher var25 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(var20 << var12 * 8 >>> 56);
      }

      var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[12];
      int var16 = 0;
      String var15 = "£Úýê\u0015|\u001cË\u0096m!\u009b\n±òÉ\u0010I\u0006\"\u008e\u0083R_§»K\u0015ûeÂ\u001dDX$Õ\u000b,Úê¦sp\u0003±Òm\u009b«tC\u0011C\u0088\u001fÿ h\u001c.OW\u0082{\u0081óN+\u001f,\u000f\u0001o¡!ê0çDè@x\u0013\u000b×à/ÒÀÓ\u009bÑïê+Êe¡&¿Èòd¸ç4ÌØú£¬Ð\u0080Á\u0089ó\u0015\u0014\u009bXÛ\u007f ß\u0003\u0016uÍ\u0084\u009fý\u0003ÐÁ¹%\"\u0082Ulî2\u0098ö»\u0085uJÊ8Þ\u008d\u0081¼½\u0010µ\u001c7vb:\u0093üz\u008dD~uW9\u0093\u0010Ð:\u0081å\u0090 ¯:\u0089E¥\u0083\u0016A\u0012²\u0010LTìaD\u001cþ+\u0019c\u0096è\u0084l¨\u0099 Ø÷\u0007ëîp\t@\u0017\u0085~\u0017óxÐ©æF\u0019\u00ad6úñ\f\u001b\u0082\u0087\u007f\u000ealþ\u0010Ê\u0084,Ý\t¦¡\u0083\u008bSÝ Ï'\u0089\u000f(Ðò¸\u009d\u0087vÒß/uY»JxÐ\u0001Wñ\u001dû}°-kßÍ)ô-\u000fF\u0017¥z\u000fÕ\u0015vf\t";
      short var17 = 297;
      char var14 = 16;
      int var23 = -1;

      label45:
      while (true) {
         String var26 = var15.substring(++var23, var23 + var14);
         int var10001 = -1;

         while (true) {
            String var35 = a(var11.doFinal(var26.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var35;
                  if ((var23 += var14) >= var17) {
                     b = var18;
                     c = new String[12];
                     g = new HashMap(13);
                     Cipher var0;
                     Cipher var28 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var20 << var1 * 8 >>> 56);
                     }

                     var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "Ó0\tätÅ~-æ¡o\u009eTô«MRå9%ß\u008b¹Ø".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var40 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     e = var6;
                     f = new Integer[3];
                     何树树何友友树树何树 = new 友友树树何友树树何何();
                     return;
                  }

                  var14 = var15.charAt(var23);
                  break;
               default:
                  var18[var16++] = var35;
                  if ((var23 += var14) < var17) {
                     var14 = var15.charAt(var23);
                     continue label45;
                  }

                  var15 = "\u008bgâË\"9ýh¾K\u0007u\rÈ«í\u0010\rËÐ\rXÜ\u0007\u001fN\u0006à(®\u001ej\u008b";
                  var17 = 33;
                  var14 = 16;
                  var23 = -1;
            }

            var26 = var15.substring(++var23, var23 + var14);
            var10001 = 0;
         }
      }
   }

   public static void Z(String[] var0) {
      树树树友何树友友何何 = var0;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 21629;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/友友树树何友树树何何", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友树树何友树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public static String[] s() {
      return 树树树友何树友友何何;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友树树何友树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 38;
               case 1 -> 30;
               case 2 -> 22;
               case 3 -> 7;
               case 4 -> 11;
               case 5 -> 9;
               case 6 -> 15;
               case 7 -> 32;
               case 8 -> 33;
               case 9 -> 37;
               case 10 -> 61;
               case 11 -> 52;
               case 12 -> 28;
               case 13 -> 6;
               case 14 -> 10;
               case 15 -> 56;
               case 16 -> 4;
               case 17 -> 44;
               case 18 -> 48;
               case 19 -> 25;
               case 20 -> 19;
               case 21 -> 60;
               case 22 -> 20;
               case 23 -> 1;
               case 24 -> 47;
               case 25 -> 41;
               case 26 -> 46;
               case 27 -> 62;
               case 28 -> 3;
               case 29 -> 34;
               case 30 -> 8;
               case 31 -> 31;
               case 32 -> 51;
               case 33 -> 12;
               case 34 -> 2;
               case 35 -> 18;
               case 36 -> 45;
               case 37 -> 21;
               case 38 -> 49;
               case 39 -> 16;
               case 40 -> 27;
               case 41 -> 14;
               case 42 -> 42;
               case 43 -> 59;
               case 44 -> 54;
               case 45 -> 26;
               case 46 -> 57;
               case 47 -> 50;
               case 48 -> 53;
               case 49 -> 43;
               case 50 -> 23;
               case 51 -> 55;
               case 52 -> 5;
               case 53 -> 39;
               case 54 -> 63;
               case 55 -> 40;
               case 56 -> 17;
               case 57 -> 24;
               case 58 -> 36;
               case 59 -> 0;
               case 60 -> 29;
               case 61 -> 13;
               case 62 -> 35;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      h[0] = "P^\fdV=_\u001eAo\\ ZCJ)T=WENb\u0017\u001f\\TWk\\";
      h[1] = boolean.class;
      i[1] = "java/lang/Boolean";
      h[2] = "u{\u0013N\u0012`z;^E\u0018}\u007ffU\u0003\bf8叞叶格桬佚叝栄栬佸伨";
      h[3] = int.class;
      i[3] = "java/lang/Integer";
      h[4] = void.class;
      i[4] = "java/lang/Void";
      h[5] = "/Q\u007f\u0005g\"/QhYk-5\u001ahGc./@%L\u007f\"oWdFz$/Qe_ye\u0004Pb_H$9";
      h[6] = "cX\u000f-,S\u0016x\u0004\"=\u001ck`\u0017%4U\u0003";
      h[7] = "VyUrjDVyB.fKL2B0nHVh\u000f;rD\u0016\u007fN1wBVyO(t\u0003ziU(hC";
      h[8] = "~'c.9eu(raE|z2|\"rLl%p?c`{(";
      h[9] = "%i\u001aS,\u000e%i\r\u000f \u0001?\"\r\u0011(\u0002%x@\u001a4\u000eeJ\u0001\u00135";
      h[10] = "\nj\u000eoky\nj\u00193gv\u0010!\u0019-ou\n{T\fo~\u0001l\b `d";
      h[11] = "\nG(\u0016\u001c6\u007fg#\u0019\ry\u0002\u007f0\u001e\u00040j";
      h[12] = "Z|$\u001bXuZ|3GTz@73Y\\yZm~`FyF=\u0004LEy";
      h[13] = "-R[r\u0013%&]J=r+-VNg";
      h[14] = "`\u000eV\u001a@\u001ccK\u000eg9%$D\u000f]\u0011JaWKg";
      h[15] = "_gn2F9\u000bz=zz>1&27Fl1\u00176a\u0002:\u000b{=0\u0010*";
      h[16] = "\u0010E>1Pn\u0013\u0000fL#WT\u000fgv\u00018\u0011\u001c#LQkQ\u001f4/Z=\u0015\u0016^";
      h[17] = "uz-~\u0012`!g~6.g\u001b;q{\u00122\u001b\nu-Vc!f~|Ds";
      h[18] = "\u0012\u001fNH3\u0005F\u0002\u001d\u0000\u000f桵佶伲佱厳双厯叨伲可p4\u0015\u0012\tS\br\u0012A\u0005";
      h[19] = "DnzJL|\u0010s)\u0002pn}!f\u0002\u0017n\u001cq)M\u0019\u0015";
      h[20] = "I<\u0018I#R\u001d!K\u0001\u001f佦桩休伧伬佂司厳桕厹q\"V\u001b5\u001d\u0014a_I)";
      h[21] = "X\u000b4\u001c]\u0015\f\u0016gTa\u0015aEn\u0018\u0000\u000e\u0007\u001cmI\u001c|_CjE\u0013\u001a\u0006@;Ya";
      h[22] = "Dg\u007f\u0004\u0016i\u0010z,L*參桤叔叞栥叩參桤佊栄<\u0011yDqbDW~\u0017}";
      h[23] = "@5\nBAA\u0014(Y\n}zyz\u0016\n\u001aS\u0018*YE\u0014(By\u0015\u0018\u0017KI/Q\u0011}";
      h[24] = "\u00061%ox-\u000e/;a\t\u000eq\n\u0002[FK\u00061%ox-\u000e/;a";
      h[25] = "\u000b(\\\u0013F~_5\u000f[zyei\u0000\u0016F(eX\u0000F\u0017-B:\u0003H\u0013p";
      h[26] = "*\u0017\bt\u001dY~\n[<!^DVTq\u001d\tDgU(\u001a^~_\u0007'\u0019\n";
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 205 && var8 != 248 && var8 != 'M' && var8 != 254) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'a') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 192) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 205) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 248) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'M') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2852;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友友树树何友树树何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友树树何友树树何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void g(User user) {
      long a = 友友树树何友树树何何.a ^ 18539808741415L;

      try {
         Field userField = Minecraft.class.getDeclaredField(a<"g">(18041, 1018186227557648863L ^ a));
         userField.setAccessible(true);
         userField.set(c<"Í">(this, 328682708608489537L, a), user);
      } catch (Exception var5) {
         var5.printStackTrace();
      }
   }

   private String g(String uuid) {
      long a = 友友树树何友树树何何.a ^ 41717511496310L;
      c<"À">(-81966671780925156L, a);
      return uuid.length() != 32
         ? uuid
         : uuid.substring(0, 8) + "-" + uuid.substring(8, 12) + "-" + uuid.substring(12, 16) + "-" + uuid.substring(16, 20) + "-" + uuid.substring(20, 32);
   }

   private void Y(Button button) {
      long a = 友友树树何友树树何何.a ^ 119591204662792L;
      String ign = c<"Í">(this, 8260432839737866324L, a).getValue();
      String token = c<"Í">(this, 8260723132890979429L, a).getValue();
      String uuid = P(ign);

      try {
         User newUser = new User(ign, UUID.fromString(this.g(uuid)).toString(), token, Optional.empty(), Optional.empty(), c<"M">(8259712477129227385L, a));
         this.g(newUser);
         null.println(a<"g">(14799, 2857916931114713156L ^ a) + newUser.getName());
      } catch (Exception var8) {
         var8.printStackTrace();
      }
   }

   public static String P(String name) {
      long a = 友友树树何友树树何何.a ^ 45271940990036L;

      try {
         URL url = new URL(a<"g">(7322, 268852468262620998L ^ a) + name);
         HttpURLConnection connection = (HttpURLConnection)url.openConnection();
         connection.setRequestMethod(a<"g">(31609, 2660751645189908643L ^ a));
         connection.setConnectTimeout(5000);
         connection.setReadTimeout(5000);
         int status = connection.getResponseCode();
         if (status != 200) {
            return null;
         } else {
            Reader reader = new InputStreamReader(connection.getInputStream());
            JsonObject json = (JsonObject)new Gson().fromJson(reader, JsonObject.class);
            return json.get(a<"g">(15339, 4937731453728090175L ^ a)).getAsString();
         }
      } catch (Exception var8) {
         var8.printStackTrace();
         return null;
      }
   }

   public void tick() {
      long a = 友友树树何友树树何何.a ^ 98381931972683L;
      c<"Í">(this, 6116387853507616279L, a).tick();
      c<"Í">(this, 6116115146500717094L, a).tick();
      super.tick();
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      long a = 友友树树何友树树何何.a ^ 25087825969749L;
      c<"À">(6845463321057104191L, a);
      this.renderBackground(guiGraphics);
      guiGraphics.drawCenteredString(
         c<"Í">(this, 6844714089349893685L, a),
         a<"g">(25318, 8213893826559063870L ^ a),
         c<"Í">(this, 6845320515348055022L, a) / 2,
         c<"Í">(this, 6843436137813562759L, a) / 2 - 60,
         b<"w">(960, 4521242388354861383L ^ a)
      );
      guiGraphics.drawString(
         c<"Í">(this, 6844714089349893685L, a),
         a<"g">(5419, 5984554501899174129L ^ a),
         c<"Í">(this, 6845320515348055022L, a) / 2 - 100,
         c<"Í">(this, 6843436137813562759L, a) / 2 - 47,
         b<"w">(4662, 6529937338609703088L ^ a)
      );
      guiGraphics.drawString(
         c<"Í">(this, 6844714089349893685L, a),
         a<"g">(25471, 7087474786559571617L ^ a),
         c<"Í">(this, 6845320515348055022L, a) / 2 - 100,
         c<"Í">(this, 6843436137813562759L, a) / 2 - 12,
         b<"w">(3295, 3056006254744733275L ^ a)
      );
      super.render(guiGraphics, mouseX, mouseY, partialTick);
      if (c<"À">(6843409041550724123L, a)) {
         c<"À">(new String[5], 6845169397860043694L, a);
      }
   }

   private static String HE_DA_WEI() {
      return "何建国230622195906030014";
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      long a = 友友树树何友树树何何.a ^ 67665242005334L;
      c<"À">(4899023336036699196L, a);
      if (keyCode == 256) {
         c<"Í">(this, 4899523287805878064L, a).setScreen(null);
         return true;
      } else if (keyCode == 258) {
         if (c<"Í">(this, 4898969337554585866L, a).isFocused()) {
            c<"Í">(this, 4898969337554585866L, a).setFocused(false);
            c<"Í">(this, 4899259586271423803L, a).setFocused(true);
         }

         c<"Í">(this, 4899259586271423803L, a).setFocused(false);
         c<"Í">(this, 4898969337554585866L, a).setFocused(true);
         return true;
      } else if (c<"Í">(this, 4898969337554585866L, a).isFocused() && c<"Í">(this, 4898969337554585866L, a).keyPressed(keyCode, scanCode, modifiers)) {
         return true;
      } else {
         return c<"Í">(this, 4899259586271423803L, a).isFocused() && c<"Í">(this, 4899259586271423803L, a).keyPressed(keyCode, scanCode, modifiers)
            ? true
            : super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   protected void init() {
      long a = 友友树树何友树树何何.a ^ 100741018111235L;
      c<"À">(-7950623755594703255L, a);
      super.init();
      int centerX = c<"Í">(this, -7950757751386403656L, a) / 2;
      int centerY = c<"Í">(this, -7949264944407569711L, a) / 2;
      c<"ø">(
         this,
         new EditBox(c<"Í">(this, -7950257978569784989L, a), centerX - 100, centerY - 35, 200, 20, Component.literal(a<"g">(29073, 2898637663642217240L ^ a))),
         -7950607350978110625L,
         a
      );
      c<"Í">(this, -7950607350978110625L, a).setMaxLength(50);
      c<"Í">(this, -7950607350978110625L, a).setFocused(true);
      this.addRenderableWidget(c<"Í">(this, -7950607350978110625L, a));
      c<"ø">(
         this,
         new EditBox(c<"Í">(this, -7950257978569784989L, a), centerX - 100, centerY, 200, 20, Component.literal(a<"g">(24627, 6059217732546198204L ^ a))),
         -7950880051677003922L,
         a
      );
      c<"Í">(this, -7950880051677003922L, a).setMaxLength(999);
      this.addRenderableWidget(c<"Í">(this, -7950880051677003922L, a));
      c<"ø">(
         this,
         Button.builder(Component.literal(a<"g">(7788, 5642664121566364909L ^ a)), this::Y).bounds(centerX - 50, centerY + 40, 100, 20).build(),
         -7951009729675174124L,
         a
      );
      this.addRenderableWidget(c<"Í">(this, -7951009729675174124L, a));
      c<"À">(!c<"À">(-7949168845233716403L, a), -7950730870526827064L, a);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      long a = 友友树树何友树树何何.a ^ 85357378580633L;
      c<"À">(7796755630028301299L, a);
      boolean ignClicked = c<"Í">(this, 7796806841080800965L, a).mouseClicked(mouseX, mouseY, button);
      boolean tokenClicked = c<"Í">(this, 7796534190042678004L, a).mouseClicked(mouseX, mouseY, button);
      if (ignClicked) {
         c<"Í">(this, 7796806841080800965L, a).setFocused(true);
         c<"Í">(this, 7796534190042678004L, a).setFocused(false);
         return true;
      } else if (tokenClicked) {
         c<"Í">(this, 7796534190042678004L, a).setFocused(true);
         c<"Í">(this, 7796806841080800965L, a).setFocused(false);
         return true;
      } else {
         c<"Í">(this, 7796806841080800965L, a).setFocused(false);
         c<"Í">(this, 7796534190042678004L, a).setFocused(false);
         return super.mouseClicked(mouseX, mouseY, button);
      }
   }

   public boolean charTyped(char codePoint, int modifiers) {
      long a = 友友树树何友树树何何.a ^ 14548291724781L;
      c<"À">(8739203695090415239L, a);
      if (c<"Í">(this, 8739114241649079217L, a).isFocused() && c<"Í">(this, 8739114241649079217L, a).charTyped(codePoint, modifiers)) {
         return true;
      } else {
         return c<"Í">(this, 8738841533980514176L, a).isFocused() && c<"Í">(this, 8738841533980514176L, a).charTyped(codePoint, modifiers)
            ? true
            : super.charTyped(codePoint, modifiers);
      }
   }
}
