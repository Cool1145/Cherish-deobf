package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.何树何友友何树何何树;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树树树友友树友树树树 implements 何树友 {
   private final 友树何友友何何何树树 树树树友何树何何友树;
   private final List<友何何树友何何何何树> 友友树何何友何何何树;
   private final ConcurrentHashMap<String, 友何何树友何何何何树> 友友何树何树友何友友 = new ConcurrentHashMap<>();
   private final ConcurrentHashMap<String, Font> 友树树树树友何树树树 = new ConcurrentHashMap<>();
   private static final String 树树友何树友友树树友;
   private static final String 树树何友友何何何友树;
   private static String[] 友友树何友友何何友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[22];
   private static final String[] f = new String[22];
   private static int _职业技术教育中心学校 _;

   public 树树树友友树友树树树() {
      this.友友树何何友何何何树 = new ArrayList<>();
      this.树树树友何树何何友树 = new 友树何友友何何何树树();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-8373018382560673982L, 2405434184297564140L, MethodHandles.lookup().lookupClass()).a(44204254618373L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 72745647720997L;
      a();
      String[] var13 = new String[4];
      b<"N">(var13, 3110147123401438750L, var9);
      Cipher var0;
      Cipher var14 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[44];
      int var5 = 0;
      String var4 = "5$#Á»\u0087\\W8e\u009a\u0015\u000e\u0082:Ä1oÃ\u0090¹½6¬\u0099\u008eC\u008b?(\u0016*4õPæ§\u0007\u0000× Î%)Mn¯\u001cìu%ìSD\u0099MI\u0093Ì¿=\u0001£E±ïPd\u0012MK.\u0092(\u0017Ú\u001dç°ä§hÃ¦\u0083é5\t¯f\u009dõse\u001eqL·}W\u0006eÊCÝ©<æ\u008a\u0019\u001f\u001b¡Ö(\u0094¤ä½\u000bgåi<ÝÀl½wÍìöuâr\u0087ü¸m\u0000à\\¹´R?]Ê³by\u008ajl¼ ªIÖ¸R8¼x±ÇðP¿á³\u0092\u0018U,\u0012Ç\u0004\u008eÎ¤fÃ\u008eM¼wU(\u0089qÖ}tVô\f÷Yè9\u0010:èìî\u0017ÛÑ¢°jçùó8 \u0018º%KÆ\u001c¢Ï!ñ=s YTîJ\\9aìÛ0eÿº\u008cÈ\u008co¨\n§\u008b\u009fQ÷\u00035\b\u0090\u0003e\u0004)8L\u0004\u0010\u008b¼Û\rë¨U¤Kõ·^åÀT/ñÈ\u0007z~HÕò×&)Æ\u000fKù\u0085]xN2ô¥¾=h±\u0092ö³ä\u001f\u0092\u001a\u0082\u00929\u008c\u0010ú6\u0098\u009ddÁáÓÍÈ\rÅYÐM\u001c(«ggË\u00968xqËýîz\u00065.l&ößüù£\u0002*w\u0091\u00adÃVÞðà\b\"ÿnÏ\u0007>ï({S\u0082\t´\u0004\t\u0015Ikzè$Ñ\u009d{BËÜ9\u0015æy\u001f|MK8\u0097\b\u0090\u001e«C8â\u0098tî\u007f\u0010\u009aµç\u000b\u0086¤33Ù©1b\u001dæ\u0015\u0012 L\u0014V@V3Í\u0090\u00adx\u008f=\u001fÉJ\u0080À/ú$Uã/\u008157f\u000bÄý\nË\u0018\u007fcµ\u008dsr\u009buþ\u001a8í4¡,ÏáïµÌk=\u0081p V}8õ®½Ç?\u0090GÝÉ\u008aè\u001e'\u000e=\u0082C£¿\u0014;nûÂ\u009c\t«¿\u0084 |xæñpÒØ§Vp2%ýÿD´\u0086á-½Ö?\u000f|üHÀuB|%ª \u009f{ïmWîÚ\u009d<³¬w)D?M\u001cLÏ\u0098´©øâ\u009b\u0091ç«:w8+(D¯ñ\u0098Âï{ÎÞqhz\u0097ð-ñ:/U4\u0081\u009c\\°h\u0018\u0011¬\u0007Òüõ\u0093¨7=Ý\u00ad}¦\u0010\u0098\u0001Mä{ÙM]W\u0017'¼9\u001aË\u009c ·ñ\u0095 9¤¿Ãuÿ\u009b³Î\u0015×\u009eÙSY\u0016Åð`}bîÌ%\u0016\u0094\u0083\u001a \u0019ç2·\u007f\u0089\u008d|â\tmÏIº\u0094nY-ìäW6\u0006\u009b\u0095T\u0095ã\f*±:(!ûvµ®\u008a\u0004dm\u0088N°ñt\u008b¸c\nt{¹\u0086\u0019\u0081\u0094mVp\u0014\u008ahé\u001f\u000f\u00055FÐ\b\u009b\u0010.\u0001âµ\u0085WD\u009d\u0094à\u008b¬\u0010\u0088&\u0099\u0010½´èV\u0081É\u000bâÇó\u0098ÒÊ¿2m\u0018ã<\u009ewR!ã½w{ÆgÉ\u007fÂÉ¿¸¥¤\u008bH>J\u0010\u000f\u008a¶¿\u009a½Ð\u0096KqOÆr«ÿ9\u0010YP8µ\u008ee\u000f, Î6ûÐAû{ ã°éÏ¸(Ê5\u00ad\t~Æ¹ão)Å|\u008aò\u008ez½Wa\u0003PRdvSÐ\u0010WµëCê\\Bù\r¯\u000eq\u0013\u009dØ¸\u0010¢\u0085l\u0014Y\u0096·)Ê:¿1\r%Ì% \\\u0085ä·\u00913É¬âÖt \"ºå\u001am\u0003³ø\u0005cm¦Ññ|\u008b\rqþ @>ö\u008c\u0084öLþN\u0002\u0093)\u0007\u001a²J©\rrä±®ÕÊ¶_(Ì\u0097<÷Ý \u0082!v\u0094uYn&Xw*\u009e\fþÚ\u0092#l&\t\u0002r/7\rÀ\u0081WÉÛ1\u0012\u0018\u0011¸Ï\u0082W\u0087ñ\u009e\u0014õH&\u0016\u0082ð:\u00171\u0097\u0017Ø;\u0099Ì\u00181å\u0099ìá\u0019Y\u0015ê\u000b8\u000e\u0006°\u0006ÀJ×sá^\u00878X8\u009bV\u009d@ªÿ÷¢»\u001c\u0010Dyÿ\u001a\\1^¦\u001e'Ô\u00ad17ã¢ævv¨f\u0092ýV?NÊ+ Ïfúi,\fmÀäuàíÜ\u0015·A(;I\u0097¯#iJª\u0080\u0096ò$£PÒéø\u0000×P\u0091õ*Q\u008abHõÿ{Àhh\u0093R¾ õRP01\u0091È÷V¿È¼v$\u0004eøb¯x\u0081X\u00920¾ä?;ÓÃá·\u0088Æ\u0090t)¸m\u0094\u001dwídwÛ\u0019uh3ð\\(¸\u0000\u001d\u0019¡n:GCÇ¯Ø!µ!\u008ch aöX+bìÖ\u001cÍ|\b\u0019n§\u001bæ:O+õb\\ \u0007Þ@\u008bV}\u001cZ\u0012\u009bä\"\u0092ö··W'~\u009bNZz|LÁßT\u0017ýCc(sãS]È}zJè\u009fËT8\u009fvÃ´ðcdùJÿ\u000efUés\u009a\u0098¸\u0005#Aà\u000eì¦§\u0013(ß\u001a\u00077\u0081S/\u001f²S\u0002eà½éÆ*q)ùË!Í\u00879Ä%gg\u0083=>§²(àÛË¾a Î½\u0003p\u009bT\u008c\u0099Þh®½²eLíj£-\u0085o\u0005ïÐ-¼RáP\u0080\u0011S";
      short var6 = 1401;
      char var3 = '(';
      int var12 = -1;

      label27:
      while (true) {
         String var15 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var21 = a(var0.doFinal(var15.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var21;
                  if ((var12 += var3) >= var6) {
                     b = var7;
                     c = new String[44];
                     树树何友友何何何友树 = a<"l">(11116, 8676023001169678362L ^ var9);
                     树树友何树友友树树友 = a<"l">(18943, 4048131131041198746L ^ var9);
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var21;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "\b\u001e58ÆjÓ;ø)oT\u0013N\u001cøO\u0004=Mý*½\u0002\u0096WLí\u009aL\u0007\u000f\u001b\u008bedë\u000e\u0095f\u0010Éº\u0005Ö+\u0093ÈÈ\n\u0005\u0087?p%ÃÓ";
                  var6 = 57;
                  var3 = '(';
                  var12 = -1;
            }

            var15 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   public 友何何树友何何何何树 F(int size) {
      long a = 树树树友友树友树树树.a ^ 91388597953184L;
      return b<"Î">(this, 264481676224663950L, a).computeIfAbsent(a<"l">(27794, 3922877472313458544L ^ a) + 18, k -> {
         long ax = 树树树友友树友树树树.a ^ 30036380979817L;
         return this.H(a<"l">(17324, 5453954651620073617L ^ ax), size, true);
      });
   }

   public void I() {
      long a = 树树树友友树友树树树.a ^ 32249789872275L;
      b<"Î">(this, 1844309610607752070L, a).forEach(友何何树友何何何何树::close);
      b<"Î">(this, 1844309610607752070L, a).clear();
      b<"Î">(this, 1844486711591472061L, a).clear();
      b<"Î">(this, 1844393707334667192L, a).clear();
   }

   public 友何何树友何何何何树 I(int size) {
      long a = 树树树友友树友树树树.a ^ 111052330686480L;
      return b<"Î">(this, 4115048369786366782L, a).computeIfAbsent(a<"l">(6552, 2009669646072541415L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 31071542793729L;
         return this.H(a<"l">(15817, 34573441266342532L ^ ax), size, false);
      });
   }

   public Font S(int size, File file) {
      long a = 树树树友友树友树树树.a ^ 77974788457726L;
      String cacheKey = file.getName() + "_" + size;
      return b<"Î">(this, -6488066450254481451L, a)
         .computeIfAbsent(
            cacheKey,
            k -> {
               long ax = 树树树友友树友树树树.a ^ 57298169171874L;

               Font font;
               try (FileInputStream fis = new FileInputStream(file)) {
                  font = Font.createFont(0, fis).deriveFont(0, size);
               } catch (Exception var11) {
                  null
                     .println(
                        a<"l">(5492, 3702331499137280902L ^ ax)
                           + file.getName()
                           + a<"l">(22543, 8067193093595162358L ^ ax)
                           + size
                           + a<"l">(19521, 1436080000788165262L ^ ax)
                     );
                  var11.printStackTrace();
                  font = new Font(a<"l">(15781, 8981344615829144419L ^ ax), 0, size);
               }

               return font;
            }
         );
   }

   public 友何何树友何何何何树 Z(int size) {
      long a = 树树树友友树友树树树.a ^ 55900026594044L;
      return b<"Î">(this, -8937462284059930158L, a).computeIfAbsent(a<"l">(31257, 2226063368127490434L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 68064235942026L;
         return this.H(a<"l">(4299, 6145571284628951311L ^ ax), size, false);
      });
   }

   public 友何何树友何何何何树 e(int size) {
      long a = 树树树友友树友树树树.a ^ 71683759703197L;
      return b<"Î">(this, 7320234519328126899L, a).computeIfAbsent(a<"l">(26492, 2827781855507436222L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 17102066432267L;
         return this.H(a<"l">(11174, 4657863676105630711L ^ ax), size, true);
      });
   }

   public 友何何树友何何何何树 e(int size, String fontName) {
      long a = 树树树友友树友树树树.a ^ 53897795886953L;
      return b<"Î">(this, -4728002571998319545L, a)
         .computeIfAbsent(a<"l">(10906, 7012975057056220340L ^ a) + fontName + "_" + size, k -> this.H(fontName, size, false));
   }

   public 友何何树友何何何何树 i(int size) {
      long a = 树树树友友树友树树树.a ^ 110101567673130L;
      return b<"Î">(this, 8224021056412114948L, a).computeIfAbsent(a<"l">(27358, 679804982899230896L ^ a) + 24, k -> {
         long ax = 树树树友友树友树树树.a ^ 98583754892670L;
         return this.H(a<"l">(25737, 4033696288734752957L ^ ax), size, true);
      });
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public 友何何树友何何何何树 b(int size) {
      long a = 树树树友友树友树树树.a ^ 30985587863678L;
      return b<"Î">(this, -3353510882991193264L, a).computeIfAbsent(a<"l">(21931, 5813797732142208135L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 67369471445360L;
         return this.H(a<"l">(8278, 320447876915927114L ^ ax), size, true);
      });
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树树友友树友树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public static String[] x() {
      return 友友树何友友何何友树;
   }

   public 友何何树友何何何何树 x(int size) {
      long a = 树树树友友树友树树树.a ^ 122922471531484L;
      return b<"Î">(this, -4406881650104708878L, a).computeIfAbsent(a<"l">(15785, 1157519152539447068L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 138192072522022L;
         return this.H(a<"l">(6429, 5551242230093156723L ^ ax), size, false);
      });
   }

   public 友何何树友何何何何树 s(int size) {
      long a = 树树树友友树友树树树.a ^ 117896074411434L;
      return b<"Î">(this, 6674783837617180292L, a).computeIfAbsent(a<"l">(28465, 584349132189361141L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 99266243738229L;
         return this.H(a<"l">(18830, 5359886732846842533L ^ ax), size, false);
      });
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public 友何何树友何何何何树 n(int size) {
      long a = 树树树友友树友树树树.a ^ 28777445453247L;
      b<"N">(915347810863507051L, a);
      何树何友友何树何何树 fontSettings = b<"É">(915216209199954399L, a);
      String fontPath = a<"l">(3624, 2281289033145570010L ^ a);
      if (fontSettings != null && fontSettings.isEnabled()) {
         String validFontName = fontSettings.k();
         if (!validFontName.equals(a<"l">(20068, 3663098317857788558L ^ a))) {
            String customFontFileName = validFontName + a<"l">(1039, 4419059991353088232L ^ a);
            fontPath = a<"l">(30858, 5898622628918109288L ^ a) + customFontFileName;
         }
      }

      String finalFontPath = fontPath;
      return b<"Î">(this, 915613483666218641L, a)
         .computeIfAbsent(a<"l">(28493, 3457704623064232893L ^ a) + size + "_" + finalFontPath.hashCode(), k -> this.H(finalFontPath, size, true));
   }

   public 友何何树友何何何何树 l(int size) {
      long a = 树树树友友树友树树树.a ^ 24813379112303L;
      return b<"Î">(this, 3198933568067190337L, a).computeIfAbsent(a<"l">(4426, 6003073885544508749L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 63939963482808L;
         return this.H(a<"l">(8092, 7269570133344279650L ^ ax), size, false);
      });
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树树友友树友树树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 22;
               case 1 -> 37;
               case 2 -> 15;
               case 3 -> 52;
               case 4 -> 3;
               case 5 -> 2;
               case 6 -> 32;
               case 7 -> 63;
               case 8 -> 38;
               case 9 -> 8;
               case 10 -> 18;
               case 11 -> 10;
               case 12 -> 61;
               case 13 -> 53;
               case 14 -> 54;
               case 15 -> 39;
               case 16 -> 29;
               case 17 -> 6;
               case 18 -> 60;
               case 19 -> 59;
               case 20 -> 55;
               case 21 -> 4;
               case 22 -> 48;
               case 23 -> 58;
               case 24 -> 25;
               case 25 -> 30;
               case 26 -> 35;
               case 27 -> 14;
               case 28 -> 11;
               case 29 -> 0;
               case 30 -> 12;
               case 31 -> 36;
               case 32 -> 9;
               case 33 -> 28;
               case 34 -> 21;
               case 35 -> 41;
               case 36 -> 44;
               case 37 -> 31;
               case 38 -> 42;
               case 39 -> 56;
               case 40 -> 24;
               case 41 -> 26;
               case 42 -> 5;
               case 43 -> 16;
               case 44 -> 20;
               case 45 -> 51;
               case 46 -> 46;
               case 47 -> 33;
               case 48 -> 1;
               case 49 -> 27;
               case 50 -> 13;
               case 51 -> 17;
               case 52 -> 50;
               case 53 -> 23;
               case 54 -> 57;
               case 55 -> 40;
               case 56 -> 49;
               case 57 -> 34;
               case 58 -> 7;
               case 59 -> 45;
               case 60 -> 19;
               case 61 -> 62;
               case 62 -> 47;
               default -> 43;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20544;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树树树友友树友树树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 206 && var8 != 192 && var8 != 201 && var8 != 186) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 211) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'N') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 206) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 192) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 201) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public 友何何树友何何何何树 a(int size) {
      long a = 树树树友友树友树树树.a ^ 117999837586261L;
      return b<"Î">(this, -4440944090364424069L, a).computeIfAbsent(a<"l">(87, 5126987426751451732L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 59048245037709L;
         return this.H(a<"l">(22573, 913216116584539121L ^ ax), size, true);
      });
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      e[0] = "\u0012|v[\u00192\u001d<;P\u0013/\u0018a0\u0016\u00034_栃桉栩厽厖桠叙桉栩桧";
      e[1] = "O-\u0018\u001amFQ%\u0002U \\K/\u001b\t1VK8@8,]F9\u001c\t&]Q\u0004\u000f\b+~D<";
      e[2] = "\u0001-_p`i\u001f%E?\u0002u\u00188";
      e[3] = "g\u001b\"B1Zh[oI;Gm\u0006d\u000f+Am\u0019\u007f\u000f,Pw\u001ayS=Pw[^D-Zq\u0007oD-xe\u001bmF;G";
      e[4] = "'l1\u0016B\b\"#\u0001\u001e\u0000\u0004";
      e[5] = "\fA\u0019(\u0007cya\u0012'\u0016,\u0004y\u0001 \u001fel";
      e[6] = void.class;
      f[6] = "java/lang/Void";
      e[7] = "H\u001f\u001a^\u0004\u0001G_WU\u000e\u001cB\u0002\\\u0013\u001e\u0007\u0005厺佡佨桺厥佾伤佡佨桺";
      e[8] = "@u659\u007f5U=:(0HM.=!y ";
      e[9] = "**9S\u001fj%jtX\u0015w 7\u007f\u001e\u001dj-1{U^l$4{\u001e\u0014l:4{Q\t+伜桕佂叻去佐桘休佂校";
      e[10] = "\u0010]`\u0005Y\u000b\u001bRqJ%\u0012\u0014H\u007f\t\u0012\"\u0002_s\u0014\u0003\u000e\u0015R";
      e[11] = "S\u000b\u0012=~K\\K_6tVY\u0016TpdM\u001e厮栭伋叚可佥估佩桏栀";
      e[12] = "!\u000be]\u0018H*\u0004t\u0012yF!\u000fpH";
      e[13] = "?N\u001dV{j!S\u0000f]\fo\u0010\u0011Vb<+U\nY\u00020(O\u001a\u000b;o<YCf";
      e[14] = "\u0006\r8Q.`\\_ JD\b;X\u007fGt:\u000b\u001c:\\{Z";
      e[15] = ":Spi\u001f\t>\n>y$栠栝台桙栜栽栠余株桙\u0005\u001aY4_{5\u001e\u0000zO";
      e[16] = "\tX\u007fA\\\u001d\u0017Ebq另厸桾你佅厲佸伦伺栤\u0018HF\u0016\u0017^`\u0003BCW";
      e[17] = "B\u00138e\u0019\u0006\u0017\u0019x8d厩桡栻伜伇厧伷伥使桘Z_\u0005\u001bX?9\u0005\u0017H\u0012";
      e[18] = "^&*n\u001d\u0007@;7^厧厢佭桚伐桇厧似右厀M#\u001f\u000eP  0\u001f\f";
      e[19] = "8M\f}ls&P\u0011M取栌桏栱桲厎佈栌桏栱k0nz6K\u0006#nx";
      e[20] = "H=|)\r2V a\u0019\u001dT\u0019byc\b+Ob|vtk\u001c:ae\u000b=\u001c?t\u0019";
      e[21] = "SJtuB]MWiE栢栢栤召低桜佦佦叾栶\u0013u\u0004IXPx(\u0003E\u0003";
   }

   public 友何何树友何何何何树 o(int size) {
      long a = 树树树友友树友树树树.a ^ 48537013595956L;
      return b<"Î">(this, -3584900951088669670L, a).computeIfAbsent(a<"l">(6218, 6788755081222817321L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 11280880498476L;
         return this.H(a<"l">(26298, 705797996534767868L ^ ax), size, true);
      });
   }

   public 友何何树友何何何何树 k(int size) {
      long a = 树树树友友树友树树树.a ^ 47447910992105L;
      return b<"Î">(this, -6205159190626616377L, a).computeIfAbsent(a<"l">(28185, 6610517957294987195L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 25670964945335L;
         return this.H(a<"l">(3965, 8914080116087693217L ^ ax), size, true);
      });
   }

   public 友何何树友何何何何树 v(int size) {
      long a = 树树树友友树友树树树.a ^ 6386478467736L;
      return b<"Î">(this, 3140124386499344822L, a).computeIfAbsent(a<"l">(10223, 2943640903354244150L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 92382148648569L;
         return this.H(a<"l">(30322, 6848694545459091822L ^ ax), size, false);
      });
   }

   public 友何何树友何何何何树 z(int size) {
      long a = 树树树友友树友树树树.a ^ 47832005264481L;
      return b<"Î">(this, 2696205028573361999L, a).computeIfAbsent(a<"l">(24454, 2058247440791808702L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 68639276063251L;
         return this.H(a<"l">(26951, 439852999162135057L ^ ax), size, true);
      });
   }

   public 友何何树友何何何何树 u(int size) {
      long a = 树树树友友树友树树树.a ^ 74936132935348L;
      return b<"Î">(this, 9205278025045241242L, a).computeIfAbsent(a<"l">(17687, 5218912813481945855L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 138539764987118L;
         return this.H(a<"l">(11174, 4657988482136419858L ^ ax), size, false);
      });
   }

   public 友树何友友何何何树树 X() {
      long a = 树树树友友树友树树树.a ^ 52040034848876L;
      return b<"Î">(this, 8171272893983714909L, a);
   }

   public static void W(String[] var0) {
      友友树何友友何何友树 = var0;
   }

   public 友何何树友何何何何树 W(int size, String fontName) {
      long a = 树树树友友树友树树树.a ^ 127621531262178L;
      return b<"Î">(this, -4762125997688803380L, a).computeIfAbsent(fontName + "_" + size, k -> this.H(fontName, size, true));
   }

   private 友何何树友何何何何树 H(String fontName, int size, boolean antiAliasing) {
      long a = 树树树友友树友树树树.a ^ 44105088878598L;
      Font font = this.S(size, new File(b<"Î">(Cherish.getResourcesManager(), 2958068763966968953L, a).getAbsolutePath() + File.separator + fontName));
      友何何树友何何何何树 trueTypeFont = new 友何何树友何何何何树(font, antiAliasing);
      b<"Î">(this, 2958153124574790419L, a).add(trueTypeFont);
      return trueTypeFont;
   }

   public 友何何树友何何何何树 G(int size) {
      long a = 树树树友友树友树树树.a ^ 71480819438908L;
      return b<"Î">(this, 3762672491614152210L, a).computeIfAbsent(a<"l">(4932, 2835343904670218033L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 103923322512548L;
         return this.H(a<"l">(12012, 2576199986673679115L ^ ax), size, false);
      });
   }

   public 友何何树友何何何何树 O(int size) {
      long a = 树树树友友树友树树树.a ^ 13273735670974L;
      return b<"Î">(this, 5599662784840130448L, a).computeIfAbsent(a<"l">(30587, 1898839400613210787L ^ a) + size, k -> {
         long ax = 树树树友友树友树树树.a ^ 117905921737449L;
         return this.H(a<"l">(15817, 34519317366673004L ^ ax), size, true);
      });
   }

   private static String LIU_YA_FENG() {
      return "何炜霖黑水";
   }
}
