package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

public class 树树何树友树何树友树 extends Screen implements 何树友 {
   private static final int 何树树树何树何何树树;
   private static final int 树树何友友树友树树树;
   private static final int 树树何树树何友树友树;
   private static final int 何树友树树树树何友何;
   private static final Color 何树树何友树树友何友;
   private static final Color 何友友何树树树树友何;
   private static final Color 何何何何友友树何树树;
   private int 树何友树何友友友友何;
   private final int 友树友友友何何何友友;
   private LinkedList<树树何树友树何树友树.友友友友友友友何树友> 树树何树何树何树友友;
   private 树树何树友树何树友树.友友友友友友友何树友 树何树何友树何树树树;
   private 树树何树友树何树友树.何树树树何何树树友树 友友树友何树何树友友;
   private boolean 友树友友树何何树何友;
   private int 树友友友树友树何何树;
   private final Random 何友树友树友树友何何;
   private int 树友何友树何友何何何;
   private int 树树何友何何树友何树;
   private int 树树树树友树树何友树;
   private int 友友树友树友何树友何;
   private static int[] 树友树友树树树友树友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[59];
   private static final String[] i = new String[59];
   private static int _我是何树友 _;

   public 树树何树友树何树友树() {
      long a = 树树何树友树何树友树.a ^ 52415803097494L;
      super(Component.literal(a<"z">(7850, 7807643759485993346L ^ a)));
      c<"T">(this, 0, -6281957841814516753L, a);
      c<"c">(-6281114803069260282L, a);
      this.友树友友友何何何友友 = b<"o">(22445, 510596805747447910L ^ a);
      this.何友树友树友树友何何 = new Random();
      c<"T">(this, 0, -6281464987552346465L, a);
      c<"T">(this, b<"o">(21496, 5943670806654229558L ^ a), -6278612008311743164L, a);
      c<"T">(this, c<"L">(this, -6278612008311743164L, a), -6278107363098371126L, a);
      c<"T">(this, 0, -6280724860808215884L, a);
      this.K();
      if (!c<"c">(-6281751660699820325L, a)) {
         c<"c">(new int[2], -6282260613922760055L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6524103293268107946L, 8408600777288483105L, MethodHandles.lookup().lookupClass()).a(216001525090143L);
      // $VF: monitorexit
      a = var10000;
      long var20 = a ^ 33168295545685L;
      a();
      c<"c">(null, -2156137048491257782L, var20);
      Cipher var11;
      Cipher var25 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(var20 << var12 * 8 >>> 56);
      }

      var25.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[5];
      int var16 = 0;
      String var15 = "\u008b\u0004\u000f$qÕA^\u0082\f[*Ï{Å?Ùæ7ë\b¯Ô{\u0010>\u0095ü\u0098°®;\u0015\u00120( (ô°Ç@¶\\¢i\u0084çÓ/g\u0087t=\u0010!µ\u0095\t\u009do\u0083~ûø·IÉVÌ\u0083ò\u009e\u0006\u000fÄ×h\u00123\u0011·È~Ë1õhQ,ù~]0Hû¼\u00023à©\u009dE\u000eU>";
      byte var17 = 106;
      char var14 = 24;
      int var24 = -1;

      label54:
      while (true) {
         String var26 = var15.substring(++var24, var24 + var14);
         int var10001 = -1;

         while (true) {
            String var37 = a(var11.doFinal(var26.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var37;
                  if ((var24 += var14) >= var17) {
                     b = var18;
                     c = new String[5];
                     g = new HashMap(13);
                     Cipher var0;
                     Cipher var28 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var20 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(var20 << var1 * 8 >>> 56);
                     }

                     var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[7];
                     int var3 = 0;
                     String var4 = "\u0015L1\nZ\u0017Ú7úeØ ,\u0088À\u0082%Ú¦'7°\u0019ô¸\u0004\f\u00adåç\u0089by\u001b@\u0099©ç\u000bC";
                     byte var5 = 40;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var29 = var6;
                        var10001 = var3++;
                        long var41 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var44 = -1;

                        while (true) {
                           long var8 = var41;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var46 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var44) {
                              case 0:
                                 var29[var10001] = var46;
                                 if (var2 >= var5) {
                                    e = var6;
                                    f = new Integer[7];
                                    树树何树树何友树友树 = b<"o">(2814, var20 ^ 6820371072833097712L);
                                    树树何友友树友树树树 = b<"o">(29093, var20 ^ 6477892424737617068L);
                                    何树友树树树树何友何 = b<"o">(2814, var20 ^ 6820371072833097712L);
                                    何树树树何树何何树树 = b<"o">(24744, var20 ^ 386226560121791907L);
                                    何树树何友树树友何友 = new Color(20, 20, 40);
                                    何友友何树树树树友何 = new Color(65, 105, 225);
                                    何何何何友友树何树树 = new Color(50, 205, 50);
                                    return;
                                 }
                                 break;
                              default:
                                 var29[var10001] = var46;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "*ì}uxxéÂ[5A´ÈC®Ï";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var35 = var2;
                           var2 += 8;
                           var7 = var4.substring(var35, var2).getBytes("ISO-8859-1");
                           var29 = var6;
                           var10001 = var3++;
                           var41 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var44 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var24);
                  break;
               default:
                  var18[var16++] = var37;
                  if ((var24 += var14) < var17) {
                     var14 = var15.charAt(var24);
                     continue label54;
                  }

                  var15 = "Û\u0091\råû(êø»n»î\u0083é\u0090n4\u0016÷Fùk\u0086i \u007fÄ?O\\\u0087\u009f&|Úc\u0080È¾où×¡ê{ðHéæÓ\u009e\u0083ëþCÏÓ";
                  var17 = 57;
                  var14 = 24;
                  var24 = -1;
            }

            var26 = var15.substring(++var24, var24 + var14);
            var10001 = 0;
         }
      }
   }

   private void i() {
      long a = 树树何树友树何树友树.a ^ 83844328196896L;
      c<"c">(-6745657011856284496L, a);

      do {
         树树何树友树何树友树.树何树友树何树友友何 type = c<"Ò">(-6743970838315210129L, a);
         int rand = c<"L">(this, -6744087794891232088L, a).nextInt(100);
         if (rand < 5) {
            type = c<"Ò">(-6744963503209466698L, a);
         }

         if (rand < 10) {
            type = c<"Ò">(-6743779408377304359L, a);
         }

         c<"T">(
            this,
            new 树树何树友树何树友树.友友友友友友友何树友(c<"L">(this, -6744087794891232088L, a).nextInt(20), c<"L">(this, -6744087794891232088L, a).nextInt(20), type),
            -6744003042788573548L,
            a
         );
      } while (this.f(c<"L">(this, -6745582674206933139L, a), c<"L">(this, -6744003042788573548L, a)));
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树何树友树何树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 26387;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树友树何树友树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树何树友树何树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void c(int[] var0) {
      树友树友树树树友树友 = var0;
   }

   private boolean f(LinkedList<树树何树友树何树友树.友友友友友友友何树友> list, 树树何树友树何树友树.友友友友友友友何树友 point) {
      long a = 树树何树友树何树友树.a ^ 84466288726821L;
      c<"c">(4208504054695492789L, a);
      Iterator var6 = list.iterator();
      if (var6.hasNext()) {
         树树何树友树何树友树.友友友友友友友何树友 p = (树树何树友树何树友树.友友友友友友友何树友)var6.next();
         if (c<"L">(p, 4208434379771071276L, a) == c<"L">(point, 4208434379771071276L, a)
            && c<"L">(p, 4210438616180762650L, a) == c<"L">(point, 4210438616180762650L, a)) {
            return true;
         }
      }

      return false;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 8;
               case 1 -> 6;
               case 2 -> 12;
               case 3 -> 57;
               case 4 -> 53;
               case 5 -> 32;
               case 6 -> 17;
               case 7 -> 47;
               case 8 -> 60;
               case 9 -> 44;
               case 10 -> 31;
               case 11 -> 15;
               case 12 -> 54;
               case 13 -> 43;
               case 14 -> 52;
               case 15 -> 40;
               case 16 -> 33;
               case 17 -> 19;
               case 18 -> 23;
               case 19 -> 5;
               case 20 -> 27;
               case 21 -> 13;
               case 22 -> 58;
               case 23 -> 49;
               case 24 -> 55;
               case 25 -> 46;
               case 26 -> 11;
               case 27 -> 35;
               case 28 -> 3;
               case 29 -> 56;
               case 30 -> 2;
               case 31 -> 48;
               case 32 -> 45;
               case 33 -> 25;
               case 34 -> 9;
               case 35 -> 59;
               case 36 -> 39;
               case 37 -> 29;
               case 38 -> 20;
               case 39 -> 16;
               case 40 -> 61;
               case 41 -> 34;
               case 42 -> 24;
               case 43 -> 62;
               case 44 -> 30;
               case 45 -> 41;
               case 46 -> 28;
               case 47 -> 10;
               case 48 -> 26;
               case 49 -> 0;
               case 50 -> 36;
               case 51 -> 63;
               case 52 -> 14;
               case 53 -> 21;
               case 54 -> 37;
               case 55 -> 51;
               case 56 -> 38;
               case 57 -> 42;
               case 58 -> 18;
               case 59 -> 1;
               case 60 -> 4;
               case 61 -> 22;
               case 62 -> 50;
               default -> 7;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'L' && var8 != 'T' && var8 != 210 && var8 != 235) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 252) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'c') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'L') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'T') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 210) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void a() {
      h[0] = "8K\u0013\u0014\u001d$7\u000b^\u001f\u001792VUY\u0007\"u栴栬伢档厀桊佰栬厼档";
      h[1] = int.class;
      i[1] = "java/lang/Integer";
      h[2] = "pL\u0016*FJ{C\u0007e:StY\t&\rcbN\u0005;\u001cOuC";
      h[3] = "^!";
      h[4] = void.class;
      i[4] = "java/lang/Void";
      h[5] = "\u00117@Mh\u0007\u001ew\rFb\u001a\u001b*\u0006\u0000j\u0007\u0016,\u0002K)%\u001d=\u001bBb";
      h[6] = boolean.class;
      i[6] = "java/lang/Boolean";
      h[7] = "eP";
      h[8] = "UQ7+htZ\u0011z bi_Lqfrr\u0018栮栈伝栖叐栧佪栈厃栖?栧佪栈厃栖低栧叴叒伝";
      h[9] = "a4)R\u001e\rntdY\u0014\u0010k)o\u001f\u0004\u000b,桋栖佤桠厩栓伏栖叺桠F叉厑佒叺桠厩叉伏佒叺";
      h[10] = "=5";
      h[11] = "C4D\tl\u000fLt\t\u0002f\u0012I)\u0002Dv\t\u000e桋桻伿栒厫栱伏桻厡栒D併桋桻桻佖伵栱桋厡桻";
      h[12] = "\u00138$\u001dDb\u001cxi\u0016N\u007f\u0019%bP^d^桇栛伫栺叆桡伃栛厵栺)去厝叁厵叠叆去伃栛厵";
      h[13] = "dbC\u001b~yzjYT\u001ce`hP\u001e\u001ce}w";
      h[14] = "\u001azD\bP\u0006\u001azST\\\t\u00001SJT\n\u001ak\u001ekT\u0001\u0011|BG[\u001b";
      h[15] = "{\u001e\u001e2}5f\u000bF\u0010<8~\r";
      h[16] = "4\u001f{m\u0003\u00164\u001fl1\u000f\u0019.Tl/\u0007\u001a4\u000e!$\u001b\u0016t<`-\u001a";
      h[17] = "[Z/'\f\u0016ER5hp\u0002__6+";
      h[18] = "9*\u0016Ipk2%\u0007\u0006\u0011e9.\u0003\\";
      h[19] = "\u0019I\u001bY\u001eH\u0016H\u0006Ac}!n-:\nX\u0000D\u0016D\u0005Y\u001d\\";
      h[20] = ";]\u00074o%4W\u001dk\f桀栒佣桦佗栕厚佖栧桦\n551\u0007\u0010r}8h\u0006";
      h[21] = "\u0001\u001f:x-\u000f_X7p\u0017栦叿厧厔栏叔佢栥厧厔\u0016~QL\u0007*hqPQ\u001f";
      h[22] = "\f.-\u00036\u0015\u0007&mj佔厸叾会桏桳栐桢叾会V\u0003g\u000b^:(\ff\u0016F";
      h[23] = "sO\u0010\u001e]}xGPw桻栊伟句伶伪桻叐伟栿kN\u000e){I\u0013\u0006\u0003pz";
      h[24] = "\u001e}2\r3#\u0015urd栕伐栶佉厊桽佑桔栶栍ITo5\u0011w5[e/N";
      h[25] = "$gNMKC/o\u000e$伩叮栌反栬叧桭叮佈体5ONUv>O\u0019LWu";
      h[26] = "m)\fU\t\u0005f!L<佫伶企伝厴叿栯伶桅桙wUX\u001b?=\tZY\u0006'";
      h[27] = "Am?eHS\u001f*2mr厠桥佋桋又厱伾伡叕桋\u000bO\u0018\u0011xh;\u0011_\u001cp";
      h[28] = "(&<NW3va1Fm叀取伀厒口厮叀栌桄伌 Pxx3k\u0010\u000e?u;";
      h[29] = "F\u0017:y'4\t\u0013j~\u0016叆去伥伇栉叕叆去伥桃\u0010)4\u0003\u0013=,kx\u0019B";
      h[30] = "\u0016\u001dFm\u001e3\u001d\u0015\u0006\u0004核桄栾桭叾栝核伀古桭==Mg\u001e\u001bEu@>\u001f";
      h[31] = "ck)~mjhci\u0017厑叇桋叁伏栎伏栝厑叁R(-`ir>n)f*";
      h[32] = "8\u0018f(\u0014X3\u0010&AB63Iq%KUw\u0001t(+\f1\u001dy!HHy\u0018tA";
      h[33] = "^U\u0002\u0001SPQT\u001f\u0019.\u007fz\u007f6%q.^U\u0002\u0001SPQT\u001f\u0019";
      h[34] = "\u0007\\A\u001a\u0000\u0000S\u0004RZ=!<\u0005Q\u001d@\r\u0003AU\u0012\u0002b";
      h[35] = "H38\u0016\tMC;x\u007f]#Fk8\u0014Q\u001f\u0004'\"E6\u0018\u0013 3@DRC<1\u007f";
      h[36] = "pM`\u0005\u001d4{E lL\rp\u001a&P\u0019\rA\u001dwV\u001b59Uz\u000f\u001a";
      h[37] = "F\u0000\n@g9\u0018G\u0007H]及厸桢伺佳伀佔厸厸桾.deAB\bV,h\u0018C";
      h[38] = "\\jAw\u0002C\b2R7?hg3QpBNXwU\u007f\u0000!\\eF~\u0000S\u00165Z|?";
      h[39] = "c&Z\u0019\u0013\u0016h.\u001ap栵去厑厌核厳栵伥伏桖!I@Bk Y\u0001M\u001bj";
      h[40] = "KLKJ:\u0018@D\u000b#栜伫厹格佭叠叆厵厹佸0\u001aiLCJHRd\u0015B";
      h[41] = "Yh8[I4R`x2\u0018\rY?~\u000eJ\rh8/\bO5\u0010p\"QN";
      h[42] = ".pa0{\u000fz(rpF\u0000\u0015)q7;\u0002*mu8ym";
      h[43] = "\u0011Ov@ahWKp\u0003\u0011栝佳栩栋桢佌余样佭栋{.{J\u000bb\u0017h\u007fLH";
      h[44] = "W_\ru'/\u0011[\u000b6W厀伵根厪伓厔厀桱根伴Nh<\f\u001b\u0019\".8\nX";
      h[45] = "J[1*O\u0010\u0014\u001c<\"u佽厴口企桝桬口伪根桅DH[\u001aNft\u0016\u001c\u0017F";
      h[46] = "\u0005$\u00001\bVC \u0006rx栣叹伆伹叉桡佧叹桂伹\nGE^`\u0014f\u0001AX#";
      h[47] = "\\\u0001_`:nW\t\u001f\t栜參估厫栽佔叆佝估伵$0i:T\u0007\\xdcU";
      h[48] = "*pkGGe%zq\u0018$栀栃低低桠叧叚叙叐低y\u001du *|\u0001Uxy+";
      h[49] = "\u000fnD3lk\u0004f\u0004Z=R\u000f9\u0002fjR>6A!m=W6^*2";
      h[50] = ")\\\u001bPH.\"T[9桮桙佅栬伽栠伪桙叛叶`\bO=sIQF\u0005 `";
      h[51] = "iW\u0007|><b_G\u0015HRg\u000f\u0007~fn%C\u001d/\u0001";
      h[52] = "p<Vn*m{4\u0016\u0007{Tpk\u0010;*TA?Fklm.eW<.";
      h[53] = "\u001ds%\u000f'\u0012\u0012y?PD桷佰栉厞栨厇桷叮位桄1y\u0015@~g\u0001'RMv";
      h[54] = "^fN.]j\u0018bHm-佛厢叚佷栌栴栟似叚叩\u0015\u0012y\u0005\"ZyT}\u0003a";
      h[55] = "\u001dbdv2%\u0016j$\u001f佐桒栵佖叜栆栔厈佱又\u001fvc;Ovayb&W";
      h[56] = "T$<u,=[%!mQ\u001c}\u000b\u0010[Q*S:/k/%R'7";
      h[57] = "e\u001e6/\u0006/n\u0016vF叺厂桍厴桔厅佤桘厗伪M\u007fU{m\u001857X\"l";
      h[58] = "c\u0013ud]Bh\u001b5\r厡栵厑厹栗佐伿栵伏厹\u000e1\u000fR/\u00151u\u000b]m";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 30708;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树友树何树友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树何树友树何树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void E() {
      long a = 树树何树友树何树友树.a ^ 45721561823910L;
      c<"c">(-3178141225203296970L, a);
      if (!c<"L">(this, -3178268545867264277L, a).isEmpty()) {
         树树何树友树何树友树.友友友友友友友何树友 head = (树树何树友树何树友树.友友友友友友友何树友)c<"L">(this, -3178268545867264277L, a).getFirst();
         switch (c<"Ò">(-3175243998330322310L, a)[c<"L">(this, -3175107875565261608L, a).ordinal()]) {
            case 1:
               new 树树何树友树何树友树.友友友友友友友何树友(c<"L">(head, -3178352204954590545L, a), c<"L">(head, -3175848239964667495L, a) - 1);
            case 2:
               new 树树何树友树何树友树.友友友友友友友何树友(c<"L">(head, -3178352204954590545L, a), c<"L">(head, -3175848239964667495L, a) + 1);
            case 3:
               new 树树何树友树何树友树.友友友友友友友何树友(c<"L">(head, -3178352204954590545L, a) - 1, c<"L">(head, -3175848239964667495L, a));
            case 4:
               new 树树何树友树何树友树.友友友友友友友何树友(c<"L">(head, -3178352204954590545L, a) + 1, c<"L">(head, -3175848239964667495L, a));
         }
      }
   }

   public static int[] A() {
      return 树友树友树树树友树友;
   }

   public boolean isPauseScreen() {
      return false;
   }

   public void tick() {
      long a = 树树何树友树何树友树.a ^ 135354833540259L;
      c<"c">(4459034133088009011L, a);
      if (!c<"L">(this, 4459625865726148825L, a)) {
         c<"T">(this, (c<"L">(this, 4460626411702197978L, a) + 1) % 20, 4460626411702197978L, a);
         if (c<"L">(this, 4459468197549660033L, a) > 0) {
            c<"T">(this, c<"L">(this, 4459468197549660033L, a) - 1, 4459468197549660033L, a);
            c<"T">(this, Math.max(1, c<"L">(this, 4461016719309473905L, a) / 2), 4461653445490200319L, a);
         }

         c<"T">(this, c<"L">(this, 4461016719309473905L, a), 4461653445490200319L, a);
         c<"T">(this, c<"L">(this, 4460415660093414314L, a) + 1, 4460415660093414314L, a);
         if (c<"L">(this, 4460415660093414314L, a) >= c<"L">(this, 4461653445490200319L, a)) {
            c<"T">(this, 0, 4460415660093414314L, a);
            this.E();
         }
      }
   }

   private void K() {
      long a = 树树何树友树何树友树.a ^ 33045180849466L;
      c<"T">(this, new LinkedList(), -5442404435298899593L, a);
      c<"L">(this, -5442404435298899593L, a).add(new 树树何树友树何树友树.友友友友友友友何树友(10, 10));
      c<"L">(this, -5442404435298899593L, a).add(new 树树何树友树何树友树.友友友友友友友何树友(9, 10));
      c<"T">(this, c<"Ò">(-5440621015994928894L, a), -5443735201516336316L, a);
      this.i();
      c<"T">(this, false, -5441857910957029056L, a);
      c<"T">(this, 0, -5440920467690778528L, a);
      c<"T">(this, 0, -5440364300483653069L, a);
      c<"T">(this, b<"o">(4269, 454664611880551374L ^ a), -5444339554708061720L, a);
      c<"T">(this, c<"L">(this, -5444339554708061720L, a), -5443832443040250010L, a);
      c<"T">(this, 0, -5441945227753890280L, a);
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      long a = 树树何树友树何树友树.a ^ 31997831239514L;
      super.render(guiGraphics, mouseX, mouseY, partialTicks);
      c<"c">(-137133376823510838L, a);
      int gameAreaX = (c<"L">(this, -135951565696608402L, a) - 300) / 2;
      int gameAreaY = (c<"L">(this, -135538095447689487L, a) - 300) / 2;
      guiGraphics.fill(gameAreaX - 1, gameAreaY - 1, gameAreaX + 300 + 1, gameAreaY + 300 + 1, c<"Ò">(-139129187512927384L, a).getRGB());
      guiGraphics.fill(gameAreaX, gameAreaY, gameAreaX + 300, gameAreaY + 300, c<"Ò">(-136802988966003497L, a).getRGB());
      int i = 0;
      Iterator pulse = c<"L">(this, -137165073324514537L, a).iterator();
      if (pulse.hasNext()) {
         树树何树友树何树友树.友友友友友友友何树友 p = (树树何树友树何树友树.友友友友友友友何树友)pulse.next();
         float hue = 0.0F / c<"L">(this, -137165073324514537L, a).size() * 0.3F + 0.3F;
         Color segmentColor = Color.getHSBColor(hue, 0.8F, 0.9F);
         if (p.equals(c<"L">(this, -137165073324514537L, a).getFirst())) {
            segmentColor = c<"Ò">(-138863068409392236L, a);
         }

         guiGraphics.fill(
            gameAreaX + c<"L">(p, -137345438365511853L, a) * 15,
            gameAreaY + c<"L">(p, -139283567460651931L, a) * 15,
            gameAreaX + c<"L">(p, -137345438365511853L, a) * 15 + 15 - 1,
            gameAreaY + c<"L">(p, -139283567460651931L, a) * 15 + 15 - 1,
            segmentColor.getRGB()
         );
         i++;
         c<"c">(!c<"c">(-136074602167695428L, a), -135778499877337998L, a);
      }

      float pulsex = Math.abs(c<"L">(this, -135615867183112925L, a) / 20.0F * 2.0F - 1.0F);
      Color currentFoodColor = c<"L">(c<"L">(c<"L">(this, -138998416732216594L, a), -136960827364453657L, a), -139259289638381069L, a);
      Color foodColor = new Color(Math.min(255, currentFoodColor.getRed() + (int)(pulsex * 50.0F)), currentFoodColor.getGreen(), currentFoodColor.getBlue());
      guiGraphics.fill(
         gameAreaX + c<"L">(c<"L">(this, -138998416732216594L, a), -137345438365511853L, a) * 15,
         gameAreaY + c<"L">(c<"L">(this, -138998416732216594L, a), -139283567460651931L, a) * 15,
         gameAreaX + c<"L">(c<"L">(this, -138998416732216594L, a), -137345438365511853L, a) * 15 + 15 - 1,
         gameAreaY + c<"L">(c<"L">(this, -138998416732216594L, a), -139283567460651931L, a) * 15 + 15 - 1,
         foodColor.getRGB()
      );
      String scoreText = a<"z">(22622, 5509572150995374527L ^ a) + c<"L">(this, -135683314500838912L, a);
      guiGraphics.drawString(c<"L">(this, -137029140043999404L, a), scoreText, gameAreaX, gameAreaY - 9 - 5, c<"Ò">(-136787703664493470L, a).getRGB());
      if (c<"L">(this, -136708112819055496L, a) > 0) {
         String speedText = a<"z">(1075, 1164293014267858387L ^ a) + (c<"L">(this, -136708112819055496L, a) / 20 + 1) + "s";
         guiGraphics.drawString(
            c<"L">(this, -137029140043999404L, a),
            speedText,
            gameAreaX + 300 - c<"L">(this, -137029140043999404L, a).width(speedText),
            gameAreaY - 9 - 5,
            c<"Ò">(-139363003957726875L, a).getRGB()
         );
      }

      if (c<"L">(this, -136620813366820064L, a)) {
         MutableComponent var22 = Component.literal(a<"z">(16913, 5067935407983578098L ^ a));
         Component restartComponent = Component.literal(a<"z">(26957, 3010690234870653103L ^ a));
         guiGraphics.drawCenteredString(
            c<"L">(this, -137029140043999404L, a),
            var22,
            c<"L">(this, -135951565696608402L, a) / 2,
            c<"L">(this, -135538095447689487L, a) / 2 - 9,
            c<"Ò">(-136163288024394430L, a).getRGB()
         );
         guiGraphics.drawCenteredString(
            c<"L">(this, -137029140043999404L, a),
            restartComponent,
            c<"L">(this, -135951565696608402L, a) / 2,
            c<"L">(this, -135538095447689487L, a) / 2 + 5,
            c<"Ò">(-136787703664493470L, a).getRGB()
         );
      }
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      long a = 树树何树友树何树友树.a ^ 39769894612013L;
      c<"c">(5003486928955769789L, a);
      if (c<"L">(this, 5002823165193566295L, a)) {
         if (keyCode == 82) {
            this.K();
            return true;
         }
      } else {
         if (keyCode == 265 && c<"L">(this, 5000347485024074323L, a) != c<"Ò">(5001750236580604200L, a)) {
            c<"T">(this, c<"Ò">(5001398094003114126L, a), 5000347485024074323L, a);
            return true;
         }

         if (keyCode == 264 && c<"L">(this, 5000347485024074323L, a) != c<"Ò">(5001398094003114126L, a)) {
            c<"T">(this, c<"Ò">(5001750236580604200L, a), 5000347485024074323L, a);
            return true;
         }

         if (keyCode == 263 && c<"L">(this, 5000347485024074323L, a) != c<"Ò">(5001302519350820885L, a)) {
            c<"T">(this, c<"Ò">(5003145501197870537L, a), 5000347485024074323L, a);
            return true;
         }

         if (keyCode == 262 && c<"L">(this, 5000347485024074323L, a) != c<"Ò">(5003145501197870537L, a)) {
            c<"T">(this, c<"Ò">(5001302519350820885L, a), 5000347485024074323L, a);
            return true;
         }
      }

      if (keyCode == 256) {
         c<"L">(this, 5003342015913708710L, a).setScreen(null);
         return true;
      } else {
         return super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   private static String LIU_YA_FENG() {
      return "何炜霖国企上班";
   }

   private static enum 何树树树何何树树友树 implements  {
      树友何何友树何友树何,
      树何树树树何何树何树,
      何友友何树树树何友友,
      友何树友何友友树树何;

      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-2896571691901878228L, -2510098695730508256L, MethodHandles.lookup().lookupClass()).a(203676061789776L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 130748925943039L;
         a();
         Cipher var1;
         Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[4];
         int var6 = 0;
         String var5 = "³a\u0000òZ\u0006ÎÀ\b°\u0083õñbÿ~\u008b";
         byte var7 = 17;
         char var4 = '\b';
         int var12 = -1;

         label28:
         while (true) {
            String var14 = var5.substring(++var12, var12 + var4);
            byte var10001 = -1;

            while (true) {
               String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var20;
                     if ((var12 += var4) >= var7) {
                        树友何何友树何友树何 = new 树树何树友树何树友树.何树树树何何树树友树();
                        树何树树树何何树何树 = new 树树何树友树何树友树.何树树树何何树树友树();
                        何友友何树树树何友友 = new 树树何树友树何树友树.何树树树何何树树友树();
                        友何树友何友友树树何 = new 树树何树友树何树友树.何树树树何何树树友树();
                        return;
                     }

                     var4 = var5.charAt(var12);
                     break;
                  default:
                     var0[var6++] = var20;
                     if ((var12 += var4) < var7) {
                        var4 = var5.charAt(var12);
                        continue label28;
                     }

                     var5 = "_Çû¬\u0083\u0081S7\b£7/§\u009c\u0006@*";
                     var7 = 17;
                     var4 = '\b';
                     var12 = -1;
               }

               var14 = var5.substring(++var12, var12 + var4);
               var10001 = 0;
            }
         }
      }

      public static 树树何树友树何树友树.何树树树何何树树友树[] I() {
         long var0 = a ^ 5957732905195L;
         return (树树何树友树何树友树.何树树树何何树树友树[])a<"â">(8661281346841083006L, var0).clone();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      public static 树树何树友树何树友树.何树树树何何树树友树 x(String name) {
         return Enum.valueOf(树树何树友树何树友树.何树树树何何树树友树.class, name);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'C' && var8 != 241 && var8 != 226 && var8 != 'z') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 203) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 255) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'C') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 241) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 226) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树友树何树友树$何树树树何何树树友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 19;
                  case 1 -> 57;
                  case 2 -> 44;
                  case 3 -> 61;
                  case 4 -> 23;
                  case 5 -> 9;
                  case 6 -> 36;
                  case 7 -> 43;
                  case 8 -> 40;
                  case 9 -> 3;
                  case 10 -> 26;
                  case 11 -> 13;
                  case 12 -> 54;
                  case 13 -> 4;
                  case 14 -> 8;
                  case 15 -> 58;
                  case 16 -> 18;
                  case 17 -> 29;
                  case 18 -> 63;
                  case 19 -> 35;
                  case 20 -> 50;
                  case 21 -> 48;
                  case 22 -> 59;
                  case 23 -> 47;
                  case 24 -> 11;
                  case 25 -> 14;
                  case 26 -> 2;
                  case 27 -> 33;
                  case 28 -> 45;
                  case 29 -> 62;
                  case 30 -> 24;
                  case 31 -> 52;
                  case 32 -> 41;
                  case 33 -> 22;
                  case 34 -> 32;
                  case 35 -> 55;
                  case 36 -> 31;
                  case 37 -> 30;
                  case 38 -> 37;
                  case 39 -> 25;
                  case 40 -> 46;
                  case 41 -> 12;
                  case 42 -> 39;
                  case 43 -> 42;
                  case 44 -> 28;
                  case 45 -> 0;
                  case 46 -> 1;
                  case 47 -> 6;
                  case 48 -> 7;
                  case 49 -> 60;
                  case 50 -> 56;
                  case 51 -> 51;
                  case 52 -> 34;
                  case 53 -> 21;
                  case 54 -> 53;
                  case 55 -> 20;
                  case 56 -> 27;
                  case 57 -> 49;
                  case 58 -> 17;
                  case 59 -> 16;
                  case 60 -> 10;
                  case 61 -> 38;
                  case 62 -> 5;
                  default -> 15;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = ":A_$,\u00185\u0001\u0012/&\u00050\\\u0019i6\u001ew栾桠伒桒厼案佺桠厌桒S伌栾桠桖伖伢案栾厺桖";
         b[1] = "}NDWa\u0016ImK\u0017,\u001dCpNJ'[Sk\t栨桞传样叉栶佬桞厾样&佲栨桞桤佳佗栶栨厄桤\u001d";
         b[2] = "w\u000b9>3X|\u0004(qRVw\u000f,+";
         b[3] = "\u0015\u001a@\r\u0018D\u0010\u000fE5厤佥桨厴佾叶厤校桨伪#Q\n[I\b_T\u001f^";
         b[4] = "\u0000\u00053<)E\u0005\u00106\u0004桏叺伹伵厓栝伋叺桽伵P`;Z\\\u0017,e._";
         b[5] = "n\njp=zk\u001foH桛佛叉伺及桑厁佛叉桾\tqybz\u0000x\"{d5";
         b[6] = "J5\u0016)Y+O \u0013\u0011佻厔叭伅桬栈栿伊叭厛uuK4\u0016'\tp^1";
         b[7] = "}\rS<!\u007fx\u0018V\u0004桇佞栀桹栩余伃栚佄桹0`3`!\u001fLe&e";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static String HE_JIAN_GUO() {
         return "刘凤楠230622109211173513";
      }
   }

   private static class 友友友友友友友何树友 implements 何树友 {
      int 树树何何树友友友友何;
      int 树树何树何树友何树树;
      树树何树友树何树友树.树何树友树何树友友何 树何树友树友树友何树;
      private static final long a;
      private static final Object[] b = new Object[13];
      private static final String[] c = new String[13];
      private static String HE_SHU_YOU;

      友友友友友友友何树友(int x, int y) {
         long a = 树树何树友树何树友树.友友友友友友友何树友.a ^ 107191932559502L;
         super();
         a<"s">(this, a<"ý">(3965194570593359803L, a), 3965050428242045951L, a);
         a<"s">(this, x, 3964800361511870244L, a);
         a<"s">(this, 10, 3965108219831438897L, a);
      }

      友友友友友友友何树友(int x, int y, 树树何树友树何树友树.树何树友树何树友友何 type) {
         long a = 树树何树友树何树友树.友友友友友友友何树友.a ^ 105001583280339L;
         super();
         a<"s">(this, a<"ý">(-7540699825310468122L, a), -7540276636774429790L, a);
         a<"s">(this, x, -7541010471373766791L, a);
         a<"s">(this, y, -7540192456905953684L, a);
         a<"s">(this, type, -7540276636774429790L, a);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(9123526833827822148L, -8402644486357564645L, MethodHandles.lookup().lookupClass()).a(50171409564601L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      @Override
      public boolean equals(Object obj) {
         long a = 树树何树友树何树友树.友友友友友友友何树友.a ^ 56213013751079L;
         a<"Ò">(8263879718182523527L, a);
         if (this == obj) {
            return true;
         } else if (obj != null && this.getClass() == obj.getClass()) {
            树树何树友树何树友树.友友友友友友友何树友 point = (树树何树友树何树友树.友友友友友友友何树友)obj;
            return a<"Ç">(this, 8263153902265178765L, a) == a<"Ç">(point, 8263153902265178765L, a)
               && a<"Ç">(this, 8264024740334635928L, a) == a<"Ç">(point, 8264024740334635928L, a);
         } else {
            return false;
         }
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树友树何树友树$友友友友友友友何树友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 199 && var8 != 's' && var8 != 253 && var8 != 163) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 213) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 210) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 199) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 's') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 253) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static void a() {
         b[0] = "kY\f\u0016`pd\u0019A\u001djmaDJ[zv&栦栳传栞叔栙佢栳厾栞;參叼叩厾叄叔參佢栳厾";
         b[1] = int.class;
         c[1] = "java/lang/Integer";
         b[2] = "\u0000U9,^E\u000f\u0015t'TX\nH\u007faDCM株栆会栠叡桲佮栆厄栠\u000e桲佮栆厄栠使桲台叜会";
         b[3] = "B;\n?w\u0018I4\u001bp\u000b\u0001F.\u00153<1P9\u0019.-\u001dG4";
         b[4] = "U]\fhiDZ\u001dAccY_@J%sB\u0018栢栳佞栗叠栧佦栳叀栗";
         b[5] = "w+";
         b[6] = "\u001eK\u0019Eq\u0004\u0015D\b\n\u0010\n\u001eO\fP";
         b[7] = "\u0006,\flUzO/W\u001e栨栘佫低桾叝史参叵低go]zSp\u0003!Zh";
         b[8] = "\u0005r\u000e5\u000eJLqUG\u00031\u000f$X(\u0017\r\b'\u000b?j\u000b\\p\n:V\f_#\u001dG";
         b[9] = "\u0010\u0018eu\u007f\u001c\u001aJ)%\u00025+K`4y\u0011B\u0012?v||";
         b[10] = "\u0004\toY^\u0007M\n4+栣伡栭叵栝叨栣县佩栯\u0004\u0012H\u0010PY8\u001a[\u0017N";
         b[11] = "jk2r\u0003A#hi\u0000桾栣伇桍伄栙厤佧桃桍Yq\u000bA?7=?\fS";
         b[12] = "'[tMV\u001b/HsS9古标佴栁只叺佺佃只栁)\u0000UrMw\u0015\bFuS";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 34;
                  case 1 -> 48;
                  case 2 -> 55;
                  case 3 -> 4;
                  case 4 -> 31;
                  case 5 -> 25;
                  case 6 -> 37;
                  case 7 -> 62;
                  case 8 -> 16;
                  case 9 -> 28;
                  case 10 -> 51;
                  case 11 -> 61;
                  case 12 -> 52;
                  case 13 -> 10;
                  case 14 -> 43;
                  case 15 -> 24;
                  case 16 -> 2;
                  case 17 -> 6;
                  case 18 -> 60;
                  case 19 -> 5;
                  case 20 -> 29;
                  case 21 -> 63;
                  case 22 -> 36;
                  case 23 -> 22;
                  case 24 -> 15;
                  case 25 -> 56;
                  case 26 -> 45;
                  case 27 -> 0;
                  case 28 -> 54;
                  case 29 -> 32;
                  case 30 -> 57;
                  case 31 -> 13;
                  case 32 -> 18;
                  case 33 -> 53;
                  case 34 -> 21;
                  case 35 -> 58;
                  case 36 -> 40;
                  case 37 -> 46;
                  case 38 -> 41;
                  case 39 -> 12;
                  case 40 -> 7;
                  case 41 -> 11;
                  case 42 -> 30;
                  case 43 -> 59;
                  case 44 -> 9;
                  case 45 -> 1;
                  case 46 -> 17;
                  case 47 -> 33;
                  case 48 -> 26;
                  case 49 -> 44;
                  case 50 -> 27;
                  case 51 -> 47;
                  case 52 -> 49;
                  case 53 -> 42;
                  case 54 -> 38;
                  case 55 -> 23;
                  case 56 -> 19;
                  case 57 -> 14;
                  case 58 -> 20;
                  case 59 -> 39;
                  case 60 -> 35;
                  case 61 -> 3;
                  case 62 -> 50;
                  default -> 8;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static String LIU_YA_FENG() {
         return "我是何树友";
      }
   }

   private static enum 树何树友树何树友友何 implements  {
      友树何树友友何何友树,
      何友友何树树友何树树,
      友友何友友友友树树何;

      final int 友友树何何何何友友树;
      final Color 树友友友树友何树友友;
      private static final long a;
      private static final Object[] b = new Object[7];
      private static final String[] c = new String[7];
      private static int _何树友，和树做朋友 _;

      private 树何树友树何树友友何(int points, Color color) {
         this.友友树何何何何友友树 = points;
         this.树友友友树友何树友友 = color;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-2377560147230533675L, 1222560564715447564L, MethodHandles.lookup().lookupClass()).a(190598868226688L);
         // $VF: monitorexit
         a = var10000;
         long var9 = a ^ 132536062069269L;
         a();
         Cipher var1;
         Cipher var12 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
         }

         var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[3];
         int var6 = 0;
         char var4 = '\b';
         int var3 = -1;

         while (true) {
            String var14 = a(var1.doFinal("úÂ\u0094\u001eé¶5r\b\u0017k¸n\u009fÉi\u001a\bH\u0092ÒÝ\t'eQ".substring(++var3, var3 + var4).getBytes("ISO-8859-1")))
               .intern();
            byte var10001 = -1;
            var0[var6++] = var14;
            if ((var3 += var4) >= 26) {
               友树何树友友何何友树 = new 树树何树友树何树友树.树何树友树何树友友何(1, new Color(220, 20, 60));
               何友友何树树友何树树 = new 树树何树友树何树友树.树何树友树何树友友何(3, new Color(255, 215, 0));
               友友何友友友友树树何 = new 树树何树友树何树友树.树何树友树何树友友何(1, new Color(0, 191, 255));
               return;
            }

            var4 = "úÂ\u0094\u001eé¶5r\b\u0017k¸n\u009fÉi\u001a\bH\u0092ÒÝ\t'eQ".charAt(var3);
         }
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      public static 树树何树友树何树友树.树何树友树何树友友何[] s() {
         long var0 = a ^ 75046006332612L;
         return (树树何树友树何树友树.树何树友树何树友友何[])a<"Ø">(1779489086861926937L, var0).clone();
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'l' && var8 != 198 && var8 != 216 && var8 != 'j') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 170) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'U') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'l') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 198) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 216) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树树何树友树何树友树$树何树友树何树友友何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 58;
                  case 1 -> 50;
                  case 2 -> 42;
                  case 3 -> 3;
                  case 4 -> 27;
                  case 5 -> 28;
                  case 6 -> 60;
                  case 7 -> 34;
                  case 8 -> 16;
                  case 9 -> 15;
                  case 10 -> 43;
                  case 11 -> 26;
                  case 12 -> 59;
                  case 13 -> 8;
                  case 14 -> 39;
                  case 15 -> 63;
                  case 16 -> 2;
                  case 17 -> 30;
                  case 18 -> 40;
                  case 19 -> 45;
                  case 20 -> 48;
                  case 21 -> 21;
                  case 22 -> 31;
                  case 23 -> 41;
                  case 24 -> 23;
                  case 25 -> 29;
                  case 26 -> 24;
                  case 27 -> 54;
                  case 28 -> 0;
                  case 29 -> 38;
                  case 30 -> 56;
                  case 31 -> 4;
                  case 32 -> 53;
                  case 33 -> 44;
                  case 34 -> 7;
                  case 35 -> 20;
                  case 36 -> 52;
                  case 37 -> 14;
                  case 38 -> 19;
                  case 39 -> 49;
                  case 40 -> 35;
                  case 41 -> 61;
                  case 42 -> 55;
                  case 43 -> 36;
                  case 44 -> 9;
                  case 45 -> 11;
                  case 46 -> 25;
                  case 47 -> 22;
                  case 48 -> 47;
                  case 49 -> 6;
                  case 50 -> 5;
                  case 51 -> 57;
                  case 52 -> 18;
                  case 53 -> 33;
                  case 54 -> 62;
                  case 55 -> 17;
                  case 56 -> 1;
                  case 57 -> 37;
                  case 58 -> 10;
                  case 59 -> 12;
                  case 60 -> 32;
                  case 61 -> 46;
                  case 62 -> 51;
                  default -> 13;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "ns~I-\u0011a33B'\fdn8\u00047\u0017#栌桁使桓厵栜佈桁叡桓Z栜佈桁叡桓伫栜取厛使";
         b[1] = "{^\\q\u001f6O}S1R=E`VlY{U{\u0011栎栠伀栱叙栮佊栠厞栱6栮佊栠厞栱佇栮叔叺伀\u001b";
         b[2] = "\b\u0003?Nn\u0001\u0003\f.\u0001\u000f\u000f\b\u0007*[";
         b[3] = ">\u0005R|.M6K\u0012\u0002厍号伊号厨叁厍栭桎佩kk\u007f\r)T\u0012c1M";
         b[4] = "\u0014\"\u007f$\u001d\"\u001cl?Z传厘厾低桟桃厾伆桤栊F3Lb\u0003s?;\u0002\"";
         b[5] = "2%Xl$p:k\u0018\u0012桝佔桂佉似栋桝栐桂佉a+|sbr\u0000r-h>";
         b[6] = "H-\u0002_tZ@cB!受栺佼栅司叢佉佾叢栅;H%\u001a_|B@kZ";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public static 树树何树友树何树友树.树何树友树何树友友何 m(String name) {
         return Enum.valueOf(树树何树友树何树友树.树何树友树何树友友何.class, name);
      }

      private static String LIU_YA_FENG() {
         return "何大伟：我要教育何炜霖";
      }
   }
}
