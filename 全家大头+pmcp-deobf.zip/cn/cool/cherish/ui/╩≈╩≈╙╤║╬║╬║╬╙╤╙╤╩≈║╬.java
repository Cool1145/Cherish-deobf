package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public enum 树树友何何何友友树何 implements  {
   友树友友树友何友树友,
   树何友何何树何友友树,
   树何何树树树树友何友,
   何何树友树树树友树友;

   private final Color 树何何树何树何树何友;
   private final String 何何树何何何何树树友;
   private static String 友友树何何树何友友树;
   private static final long a;
   private static final Object[] b = new Object[17];
   private static final String[] c = new String[17];
   private static String HE_WEI_LIN;

   private 树树友何何何友友树何(Color color, String icon) {
      this.树何何树何树何树何友 = color;
      this.何何树何何何何树树友 = icon;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-8619894407682590666L, -8402931420649883232L, MethodHandles.lookup().lookupClass()).a(254184528660087L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 88873763412068L;
      a();
      if (a<"r">(2761436941517487733L, var9) != null) {
         a<"r">("ekyeo", 2761664410708941805L, var9);
      }

      Cipher var1;
      Cipher var13 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(var9 << var2 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[4];
      int var6 = 0;
      String var5 = "ëÿN´v©\u0088/\bu®\\\u0000ïØ\u0088´";
      byte var7 = 17;
      char var4 = '\b';
      int var12 = -1;

      label32:
      while (true) {
         String var14 = var5.substring(++var12, var12 + var4);
         byte var10001 = -1;

         while (true) {
            String var20 = a(var1.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var0[var6++] = var20;
                  if ((var12 += var4) >= var7) {
                     友树友友树友何友树友 = new 树树友何何何友友树何(new Color(0, 255, 0), "A");
                     树何友何何树何友友树 = new 树树友何何何友友树何(new Color(255, 0, 0), "B");
                     树何何树树树树友何友 = new 树树友何何何友友树何(a<"W">(2761321003776389256L, var9), "C");
                     何何树友树树树友树友 = new 树树友何何何友友树何(a<"W">(2761697363425782990L, var9), "D");
                     return;
                  }

                  var4 = var5.charAt(var12);
                  break;
               default:
                  var0[var6++] = var20;
                  if ((var12 += var4) < var7) {
                     var4 = var5.charAt(var12);
                     continue label32;
                  }

                  var5 = "\u0092xò¦\"'\u001f\u0098\bÓ.a£s\u001a\u0094\u0092";
                  var7 = 17;
                  var4 = '\b';
                  var12 = -1;
            }

            var14 = var5.substring(++var12, var12 + var4);
            var10001 = 0;
         }
      }
   }

   public String Z() {
      long a = 树树友何何何友友树何.a ^ 82241442020011L;
      return a<"b">(this, -4279825561227425119L, a);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   public static 树树友何何何友友树何 s(String name) {
      return Enum.valueOf(树树友何何何友友树何.class, name);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a() {
      b[0] = "?~i\u0014X\u001f0>$\u001fR\u00025c/YB\u0019r栁桖厼佢伥伉叛厌桦佢";
      b[1] = "\u0007\u0005e\u0001Cj\u001a\u0010=#\u0002g\u0002\u0016";
      b[2] = "6hL\u0018\u00115=g]Wl-.`T\u001e";
      b[3] = void.class;
      c[3] = "java/lang/Void";
      b[4] = "B=Q\u001c\u0011wv\u001e^\\\\||\u0003[\u0001W:l\u0018\u001c档栮叟佌伤佧厹叴栅佌J";
      b[5] = "n\u0000/r\"*e\u000f>=C$n\u0004:g";
      b[6] = "]LC\u0014B8T\u0000\u0005q叻桂叵厾桥厲佥厘栯厾|\u001a\tdS\u0007\u001f\u0013E\"";
      b[7] = ";\u0013\u001c_\u001252_Z:桱伋厓使佾栣伵厕厓栻#QYi5X@X\u0015/";
      b[8] = "\u0014N\u0019{h*L\u0019\u00123\u0014\u001e`a1NKO\u0014N\u0019{h*L\u0019\u00123";
      b[9] = "\u001cV{\u0003P\u0000\u0015\u001a=f栳伾伪桾桝桿栳厠伪厤D\r\u001b\\\u0012\u001d'\u0004W\u001a";
      b[10] = "\u0007e\u0018|BN\u000e)^\u0019e-U:\u0019yJNRoIc8";
      b[11] = "\\\u0011/6\n/U]iS伭厏叴佽叓伎伭休栮佽\u0010hO2UNscL W";
      b[12] = "\u0004yp\fCo\r56i佤佑桶压桖桰栠叏桶压O\u0002\b3\n2,\u000bDu";
      b[13] = "\bj\u0014b,K\u0001&R\u0007,(Z5\u0015g$K]`E}V\u0012\u000e'I9&K\u001c+R\u0007";
      b[14] = "p\u0012\u001eQs}(E\u0015\u0019\u000fW\u00130##6s%\u000b\u000eFn$.C";
      b[15] = "\\s:O,GU?|*桏佹佪桛佘栳伋栽佪厁\u0005\u0013=HE>`KjC\r";
      b[16] = "\u0010+,\u0000xG\u0019gje佟佹桢佇低伸佟栽桢叙\u0013\\l\u001a\u001bhp[9J\u0001";
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树友何何何友友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 53;
               case 1 -> 4;
               case 2 -> 6;
               case 3 -> 59;
               case 4 -> 42;
               case 5 -> 48;
               case 6 -> 38;
               case 7 -> 18;
               case 8 -> 50;
               case 9 -> 49;
               case 10 -> 17;
               case 11 -> 10;
               case 12 -> 37;
               case 13 -> 35;
               case 14 -> 22;
               case 15 -> 51;
               case 16 -> 12;
               case 17 -> 40;
               case 18 -> 3;
               case 19 -> 36;
               case 20 -> 54;
               case 21 -> 47;
               case 22 -> 16;
               case 23 -> 1;
               case 24 -> 29;
               case 25 -> 33;
               case 26 -> 7;
               case 27 -> 15;
               case 28 -> 63;
               case 29 -> 5;
               case 30 -> 32;
               case 31 -> 23;
               case 32 -> 14;
               case 33 -> 34;
               case 34 -> 13;
               case 35 -> 2;
               case 36 -> 58;
               case 37 -> 45;
               case 38 -> 41;
               case 39 -> 0;
               case 40 -> 61;
               case 41 -> 24;
               case 42 -> 19;
               case 43 -> 30;
               case 44 -> 27;
               case 45 -> 57;
               case 46 -> 55;
               case 47 -> 56;
               case 48 -> 60;
               case 49 -> 46;
               case 50 -> 43;
               case 51 -> 26;
               case 52 -> 11;
               case 53 -> 44;
               case 54 -> 39;
               case 55 -> 20;
               case 56 -> 8;
               case 57 -> 9;
               case 58 -> 31;
               case 59 -> 52;
               case 60 -> 25;
               case 61 -> 21;
               case 62 -> 62;
               default -> 28;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'b' && var8 != 'e' && var8 != 'W' && var8 != 219) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 249) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'r') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'b') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'e') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'W') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public static String U() {
      return 友友树何何树何友友树;
   }

   public static 树树友何何何友友树何[] z() {
      long var0 = a ^ 86113753887860L;
      return (树树友何何何友友树何[])a<"W">(-3872269637299286887L, var0).clone();
   }

   public static void r(String var0) {
      友友树何何树何友友树 = var0;
   }

   public Color E() {
      long a = 树树友何何何友友树何.a ^ 38001762549018L;
      return a<"b">(this, -8994388158611948817L, a);
   }

   private static String HE_SHU_YOU() {
      return "解放村多种2队1144号";
   }
}
