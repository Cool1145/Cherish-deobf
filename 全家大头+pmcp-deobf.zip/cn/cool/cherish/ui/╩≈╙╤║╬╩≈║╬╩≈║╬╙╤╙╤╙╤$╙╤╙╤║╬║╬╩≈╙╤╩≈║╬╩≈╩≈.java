package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// $VF: synthetic class
class 树友何树何树何友友友$友友何何树友树何树树 implements 何树友 {
   private static final Object[] a = new Object[12];
   private static final String[] b = new String[12];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7918450632011948558L, 8918943437656344205L, MethodHandles.lookup().lookupClass()).a(123392321861405L);
      // $VF: monitorexit
      long var0 = var10000 ^ 31342781195348L;
      a();

      try {
         a<"Ö">(-1261356897662247846L, var0)[a<"Ö">(-1261615362091592097L, var0).ordinal()] = 1;
      } catch (NoSuchFieldError var8) {
      }

      try {
         a<"Ö">(-1261356897662247846L, var0)[a<"Ö">(-1261479838366220681L, var0).ordinal()] = 2;
      } catch (NoSuchFieldError var7) {
      }

      try {
         a<"Ö">(-1261356897662247846L, var0)[a<"Ö">(-1261714594766275488L, var0).ordinal()] = 3;
      } catch (NoSuchFieldError var6) {
      }

      try {
         a<"Ö">(-1261356897662247846L, var0)[a<"Ö">(-1261830900738824692L, var0).ordinal()] = 4;
      } catch (NoSuchFieldError var5) {
      }

      try {
         a<"Ö">(-1261356897662247846L, var0)[a<"Ö">(-1261656923886231007L, var0).ordinal()] = 5;
      } catch (NoSuchFieldError var4) {
      }

      try {
         a<"Ö">(-1261356897662247846L, var0)[a<"Ö">(-1261379149329552784L, var0).ordinal()] = 6;
      } catch (NoSuchFieldError var3) {
      }

      try {
         a<"Ö">(-1261356897662247846L, var0)[a<"Ö">(-1261537547943305753L, var0).ordinal()] = 7;
      } catch (NoSuchFieldError var2) {
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = a[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(b[var4]);
            a[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (var5 instanceof String) {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         a[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = a[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = b[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         a[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'S' && var8 != 216 && var8 != 214 && var8 != 246) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'H') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 231) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'S') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 216) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 214) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何树何树何友友友$友友何何树友树何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (b[var4] != null) {
         return var4;
      } else {
         Object var5 = a[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 16;
               case 1 -> 35;
               case 2 -> 15;
               case 3 -> 56;
               case 4 -> 18;
               case 5 -> 47;
               case 6 -> 40;
               case 7 -> 12;
               case 8 -> 29;
               case 9 -> 20;
               case 10 -> 33;
               case 11 -> 4;
               case 12 -> 7;
               case 13 -> 42;
               case 14 -> 62;
               case 15 -> 34;
               case 16 -> 38;
               case 17 -> 31;
               case 18 -> 13;
               case 19 -> 14;
               case 20 -> 37;
               case 21 -> 26;
               case 22 -> 9;
               case 23 -> 52;
               case 24 -> 43;
               case 25 -> 49;
               case 26 -> 61;
               case 27 -> 23;
               case 28 -> 53;
               case 29 -> 45;
               case 30 -> 51;
               case 31 -> 30;
               case 32 -> 10;
               case 33 -> 55;
               case 34 -> 11;
               case 35 -> 1;
               case 36 -> 5;
               case 37 -> 41;
               case 38 -> 58;
               case 39 -> 57;
               case 40 -> 44;
               case 41 -> 3;
               case 42 -> 8;
               case 43 -> 28;
               case 44 -> 39;
               case 45 -> 2;
               case 46 -> 19;
               case 47 -> 6;
               case 48 -> 46;
               case 49 -> 60;
               case 50 -> 0;
               case 51 -> 59;
               case 52 -> 32;
               case 53 -> 21;
               case 54 -> 17;
               case 55 -> 25;
               case 56 -> 36;
               case 57 -> 50;
               case 58 -> 22;
               case 59 -> 24;
               case 60 -> 27;
               case 61 -> 54;
               case 62 -> 48;
               default -> 63;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            b[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      a[0] = "X \n9aYW`G2kDR=LtcY_;H? 佣佮厅佱伏叅佣佮桟栵";
      a[1] = "\u0011>\u0007n\u0015J\u001e~Je\u001fW\u001b#A#\u000fL\\桁叢佘桫佰档伅叢叆厱\u0001厹厛佼佘桫叮档伅核栜";
      a[2] = "Tu";
      a[3] = "\u0010y%q_\u001e\u001bv4>>\u0010\u0010}0d";
      a[4] = "60V_\f\u0019$/N>传厦厗厒叭叽传伸桍厒.\\\u001c\u001d5 RN\u0003\u0005";
      a[5] = "s\r\u0018\u0000$Ia\u0012\u0000a桌栬佌桵桹桸伈叶叒厯`\u00034Mp\u001d\u001c\u0011+U";
      a[6] = "'xac\u0013i5gy\u0002厡栌历叚佄佟厡佈桜叚\u0019`\u0003m$her\u001cu";
      a[7] = "nYVd~8|FN\u0005双伙佑佥佳叆栖厇栕校.gn<mIRuq$";
      a[8] = "W[\r8\u001b9ED\u0015Y厩历栬栣伨厚厩优栬叹u;\u000b=TK\t)\u0014%";
      a[9] = "WkP)C\u001aEtHH栫桿栬佗併压佯桿叶叉(*S\u001eT{T8L\u0006";
      a[10] = "\u001d\u001b<p(x\nGn\u0002桍栏桸厽栚佟厗佋桸桧\u0003;9)\\N39$}P";
      a[11] = "F\u0005\u0018T5$T\u001a\u00005伙桁叧桽伽栬伙伅栽厧`W% E\u0015\u001cE:8";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_SHU_YOU() {
      return "何树友为什么濒天了";
   }
}
