package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 树友友友何树树树树友 implements 何树友 {
   private float 何树友友树何友友何树;
   private float 何何树树友树何何何何;
   private float 树友何友树何友树何友;
   private float 友何友树树友友何树何;
   private float 友友友何友友友友树树;
   private long 树友友友何何友何何何;
   private float 何树树何何友友树树友;
   private static final long a;
   private static final Object[] b = new Object[16];
   private static final String[] c = new String[16];
   private static String HE_DA_WEI;

   public 树友友友何树树树树友() {
      long a = 树友友友何树树树树友.a ^ 137337872485982L;
      super();
      a<"ÿ">(this, Float.MAX_VALUE, 3691536033016566372L, a);
      a<"ÿ">(this, 0.0F, 3690912569231050215L, a);
      a<"ÿ">(this, 0.0F, 3691356647530296528L, a);
      a<"ÿ">(this, 0.0F, 3691577858855100211L, a);
      a<"ÿ">(this, 0.0F, 3691328279390355465L, a);
      a<"ÿ">(this, 1.0F, 3691417287181537067L, a);
      a<"ÿ">(this, System.currentTimeMillis(), 3691720311247123254L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6928220571805883087L, -987559210190881927L, MethodHandles.lookup().lookupClass()).a(96984196006794L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public void D(float scroll) {
      long a = 树友友友何树树树树友.a ^ 36169562328570L;
      a<"ÿ">(this, scroll, -5719779824366396265L, a);
   }

   public void Z(long lastTime) {
      long a = 树友友友何树树树树友.a ^ 76897419547272L;
      a<"ÿ">(this, lastTime, -1158101268896387104L, a);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public float s() {
      long a = 树友友友何树树树树友.a ^ 79850966272878L;
      return a<"î">(this, 8505317390948155607L, a);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public float l() {
      long a = 树友友友何树树树树友.a ^ 108751143329548L;
      return a<"î">(this, -2132172398431072671L, a);
   }

   public void d(float delta) {
      long a = 树友友友何树树树树友.a ^ 86774874782772L;
      a<"ÿ">(this, a<"î">(this, -9128785996821417373L, a) + delta, -9128785996821417373L, a);
      a<"ÿ">(
         this,
         Math.max(Math.min(a<"î">(this, -9127965838731233395L, a), a<"î">(this, -9128785996821417373L, a)), -a<"î">(this, -9128573840601030642L, a)),
         -9128785996821417373L,
         a
      );
      a<"ÿ">(this, System.currentTimeMillis(), -9128354355383762596L, a);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 53;
               case 1 -> 45;
               case 2 -> 51;
               case 3 -> 44;
               case 4 -> 31;
               case 5 -> 54;
               case 6 -> 8;
               case 7 -> 10;
               case 8 -> 6;
               case 9 -> 12;
               case 10 -> 46;
               case 11 -> 26;
               case 12 -> 57;
               case 13 -> 36;
               case 14 -> 5;
               case 15 -> 29;
               case 16 -> 3;
               case 17 -> 17;
               case 18 -> 43;
               case 19 -> 13;
               case 20 -> 49;
               case 21 -> 15;
               case 22 -> 38;
               case 23 -> 47;
               case 24 -> 60;
               case 25 -> 48;
               case 26 -> 42;
               case 27 -> 1;
               case 28 -> 56;
               case 29 -> 19;
               case 30 -> 25;
               case 31 -> 16;
               case 32 -> 35;
               case 33 -> 2;
               case 34 -> 11;
               case 35 -> 63;
               case 36 -> 22;
               case 37 -> 18;
               case 38 -> 9;
               case 39 -> 23;
               case 40 -> 24;
               case 41 -> 4;
               case 42 -> 58;
               case 43 -> 41;
               case 44 -> 50;
               case 45 -> 7;
               case 46 -> 33;
               case 47 -> 28;
               case 48 -> 40;
               case 49 -> 14;
               case 50 -> 52;
               case 51 -> 21;
               case 52 -> 32;
               case 53 -> 27;
               case 54 -> 62;
               case 55 -> 20;
               case 56 -> 39;
               case 57 -> 34;
               case 58 -> 30;
               case 59 -> 59;
               case 60 -> 0;
               case 61 -> 37;
               case 62 -> 55;
               default -> 61;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "/wgSRd 7*XXy%j!\u001eHbb栈厂叻叶佞桝栈桘校叶";
      b[1] = float.class;
      c[1] = "java/lang/Float";
      b[2] = long.class;
      c[2] = "java/lang/Long";
      b[3] = "rEX\u0015#U}\u0005\u0015\u001e)HxX\u001eX9S?叠桧厽桝佯栀叠厽厽桝";
      b[4] = int.class;
      c[4] = "java/lang/Integer";
      b[5] = "o\t1\u000f\u0007/d\u0006 @{6k\u001c.\u0003L\u0006}\u000b\"\u001e]*j\u0006";
      b[6] = "l:\b\u007f)\u0010g5\u00190H\u001el>\u001dj";
      b[7] = "\nI\u000fq\tEQ\u0012EJ佬使栭桭叼桓佬使佩伩?sXNP\u000f\u0004%IGD";
      b[8] = "a\u0002\u0007\u0010\u0012;:YM+叩企厜栦栮叨叩企框佢7\u0012C0;D\fDR9/";
      b[9] = "q`-RK#*;gi\u001aDt-lV\u001ay\u007f\"`\u0002s\u007f?,\"\u0000Nt0 vi";
      b[10] = "\u0013\u0019BOv:HB\bt桗厞叮叧伯伩厍伀佰佹rM3a\u0010\u0018\u001cL5\"\u0010";
      b[11] = "+uB(8\u0007zc\u000ej\u0007\u0000\u0011$\u0010li[saGbnc";
      b[12] = "B-\u0017\u000e\u001d\u0018\u0019v]5另厼县位古叶另厼桥栉'\fL\u0013\u0018k\u001cZ]\u001a\f";
      b[13] = "~\u0007J_PU%\\\u0000d桱叱伝叹档伹厫栫伝叹z]\u0001^$AA\u000b\u0010W0";
      b[14] = "g>@%F\u007f<e\n\u001e伣栁桀佞伭叝厽栁桀叀p'\u0017t=xKq\u0006})";
      b[15] = "e=\u001fhr2>fUS众桌厘參栶伎厉厖伆栙/j#9?{\u0014<20+";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友友友何树树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 238 && var8 != 255 && var8 != 228 && var8 != 'w') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 214) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'b') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 238) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 255) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 228) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public long m() {
      long a = 树友友友何树树树树友.a ^ 107350527177809L;
      return a<"î">(this, 5275049259025680697L, a);
   }

   public void o(float target) {
      long a = 树友友友何树树树树友.a ^ 129962202237241L;
      a<"ÿ">(this, target, -5450145718350772370L, a);
   }

   public void t(float maxScroll) {
      long a = 树友友友何树树树树友.a ^ 78792396106245L;
      a<"ÿ">(this, Math.max(0.0F, maxScroll), 6296528397654603327L, a);
      a<"ÿ">(
         this,
         Math.max(Math.min(a<"î">(this, 6297151771246059964L, a), a<"î">(this, 6296314587360257106L, a)), -a<"î">(this, 6296528397654603327L, a)),
         6296314587360257106L,
         a
      );
      a<"ÿ">(
         this,
         Math.max(Math.min(a<"î">(this, 6297151771246059964L, a), a<"î">(this, 6296073793246608232L, a)), -a<"î">(this, 6296528397654603327L, a)),
         6296073793246608232L,
         a
      );
      a<"ÿ">(this, a<"î">(this, 6296073793246608232L, a), 6296434773544702091L, a);
   }

   public void g() {
      long a = 树友友友何树树树树友.a ^ 95982870828479L;
      a<"ÿ">(this, a<"î">(this, 2943642004598005254L, a), 2944086365784043313L, a);
      a<"ÿ">(this, a<"î">(this, 2943642004598005254L, a), 2943723732191954130L, a);
      a<"ÿ">(this, a<"î">(this, 2943642004598005254L, a), 2943964513417534440L, a);
      a<"ÿ">(this, System.currentTimeMillis(), 2943818911483406551L, a);
   }

   public void v(float rawScroll) {
      long a = 树友友友何树树树树友.a ^ 41696838071919L;
      a<"ÿ">(this, rawScroll, 795743314236394721L, a);
   }

   public float q() {
      long a = 树友友友何树树树树友.a ^ 20100805986170L;
      return a<"î">(this, 4187950552622947136L, a);
   }

   public void U(float minScroll) {
      long a = 树友友友何树树树树友.a ^ 36878026874209L;
      a<"ÿ">(this, minScroll, -6915387114420889896L, a);
   }

   public void z(float animationSpeed) {
      long a = 树友友友何树树树树友.a ^ 72433415472331L;
      a<"ÿ">(this, animationSpeed, 8768422155191076286L, a);
   }

   public float z() {
      long a = 树友友友何树树树树友.a ^ 89583735477218L;
      return a<"î">(this, -5870980795051860555L, a);
   }

   public float P() {
      long a = 树友友友何树树树树友.a ^ 108760918636207L;
      return a<"î">(this, 849855772859878433L, a);
   }

   public float W() {
      long a = 树友友友何树树树树友.a ^ 95055019366613L;
      return a<"î">(this, 7327821606477257120L, a);
   }

   public void Q() {
      long a = 树友友友何树树树树友.a ^ 52676485414189L;
      a<"b">(-4591274116252347979L, a);
      float difference = a<"î">(this, -4591023429011672198L, a) - a<"î">(this, -4591334606914409408L, a);
      if (Math.abs(difference) < 0.1F) {
         a<"ÿ">(this, a<"î">(this, -4591023429011672198L, a), -4591334606914409408L, a);
         a<"ÿ">(this, a<"î">(this, -4591023429011672198L, a), -4591131400308521053L, a);
      } else {
         long currentTime = System.currentTimeMillis();
         float deltaTime = Math.min(0.1F, (float)(currentTime - a<"î">(this, -4591152567813980091L, a)) / 1000.0F);
         a<"ÿ">(this, currentTime, -4591152567813980091L, a);
         float step = difference * Math.min(1.0F, deltaTime * a<"î">(this, -4590892646220104616L, a) * 10.0F);
         a<"ÿ">(this, a<"î">(this, -4591334606914409408L, a) + step, -4591334606914409408L, a);
         a<"ÿ">(this, a<"î">(this, -4591334606914409408L, a), -4591131400308521053L, a);
      }
   }

   private static String LIU_YA_FENG() {
      return "何大伟：我要教育何炜霖";
   }
}
