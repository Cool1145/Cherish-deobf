package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.友何何何何友何友友树;
import cn.cool.cherish.utils.animations.何友友何何友何友友何;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.animations.树友树何树树何树树何;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectUtil;

public class 树友友树何友友树何树 implements IWrapper, 何树友 {
   private static final Map<MobEffect, 树友树何树树何树树何> 友友何友树何友何友树;
   private static final Map<MobEffect, 何友友何何友何友友何> 友树友友何何何何友树;
   private static final int 树何何友何树树树何何;
   private static final int 友何何友树友树树树友;
   private static final int 何何何树树友树何友树;
   private static final int 何树友树友树树何何友;
   private static final int 树树树何树友树树友友;
   private static final int 何树友树树何树何友何;
   private static final String 友何友友树树何友何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[17];
   private static final String[] g = new String[17];
   private static String LIU_YA_FENG;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(507512468422708978L, -6499388454249407436L, MethodHandles.lookup().lookupClass()).a(230312814101557L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var13;
      Cipher var24 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(28623634707644L << var14 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[10];
      int var18 = 0;
      String var17 = "B\u0006ç\u0001¤î©dB¢OïWÄÂH\u0010\u0091\u00ad<å\u0012\u0014¶\u0081\u001a^T½MÚ'p\u0010\u0080\u0001\u008aÆ\u0088\u0015ü$r\u008fÇ`ñÒüá\u0010üHñµ\u009e_\u0015=V\u0086Ê\u000bé&=1\u0010àºæH\u0083\u001b7ª#\u000f\u00114u\u0011å\u0003\u0010ø\u009d\u0089úü«¸t\u0087Ú\\ü+ÿ,Ö ·òµX9FU\u000f&ÑÔ\u0097N\u0080(ùpØ\u001f±/Ü&N¨n2\u008ca5\u0096S\u0010Êã\u0099\u0081\u008b\u008aZA\u008bwÒ9\u0096\u001e-\u0019";
      short var19 = 151;
      char var16 = 16;
      int var23 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            String var36 = b(var13.doFinal(var25.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var23 += var16) >= var19) {
                     b = var20;
                     c = new String[10];
                     友何友友树树何友何何 = "Status Effects";
                     Cipher var1;
                     Cipher var27 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var2 = 1; var2 < 8; var2++) {
                        var10003[var2] = (byte)(28623634707644L << var2 * 8 >>> 56);
                     }

                     var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var0 = new long[6];
                     int var4 = 0;
                     String var5 = "\u0011=ÿ)´\r\u009cíÍ¬\u0082\u001eh\u00ad,2TÂ÷ã\u0015ëKÇ\tpitò\u0006ÂÑ";
                     byte var6 = 32;
                     byte var3 = 0;

                     label36:
                     while (true) {
                        var10001 = var3;
                        var3 += 8;
                        byte[] var7 = var5.substring(var10001, var3).getBytes("ISO-8859-1");
                        long[] var28 = var0;
                        var10001 = var4++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var43 = -1;

                        while (true) {
                           long var8 = var40;
                           byte[] var10 = var1.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var3 >= var6) {
                                    树树树何树友树树友友 = (int)var0[3];
                                    何何何树树友树何友树 = (int)var0[1];
                                    树何何友何树树树何何 = (int)var0[2];
                                    何树友树树何树何友何 = (int)var0[5];
                                    友何何友树友树树树友 = (int)var0[0];
                                    何树友树友树树何何友 = (int)var0[4];
                                    友友何友树何友何友树 = new HashMap<>();
                                    友树友友何何何何友树 = new HashMap<>();
                                    return;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var3 < var6) {
                                    continue label36;
                                 }

                                 var5 = "ý(Í\u008e\u0004Vþ¥\u009fi\u0001=¾\b\u0088É";
                                 var6 = 16;
                                 var3 = 0;
                           }

                           byte var34 = var3;
                           var3 += 8;
                           var7 = var5.substring(var34, var3).getBytes("ISO-8859-1");
                           var28 = var0;
                           var10001 = var4++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label54;
                  }

                  var17 = "^iüo.1ÜÃÄ?ê@/\u008eS\u00141ª\u008d`bSú½\u0018BBpcvsË¶O£Â£Pâ\u0007M÷W\u009e\u001e\u0095\u008d°\u0011";
                  var19 = 49;
                  var16 = 24;
                  var23 = -1;
            }

            var25 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   }

   private static float Z(List<MobEffectInstance> effects, 何何友友树何树何友树 font, 何何友友树何树何友树 titleFont) {
      float titleWidth = titleFont.D("Status Effects") + 16;
      友树何友友树何何树树.z();
      float maxWidth = Math.max(120.0F, titleWidth);
      Iterator var8 = effects.iterator();
      if (var8.hasNext()) {
         MobEffectInstance effect = (MobEffectInstance)var8.next();
         String name = K(effect);
         String time = effect.getDuration() == -1 ? "∞" : MobEffectUtil.formatDuration(effect, 1.0F).getString();
         float nameWidth = font.D(name);
         float timeWidth = font.D(time);
         float textWidth = Math.max(nameWidth, timeWidth);
         float totalWidth = 26.0F + textWidth + 16.0F + 16.0F;
         maxWidth = Math.max(maxWidth, totalWidth);
      }

      return maxWidth;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 25;
               case 1 -> 7;
               case 2 -> 42;
               case 3 -> 38;
               case 4 -> 5;
               case 5 -> 2;
               case 6 -> 16;
               case 7 -> 44;
               case 8 -> 35;
               case 9 -> 27;
               case 10 -> 19;
               case 11 -> 28;
               case 12 -> 40;
               case 13 -> 59;
               case 14 -> 57;
               case 15 -> 48;
               case 16 -> 21;
               case 17 -> 18;
               case 18 -> 46;
               case 19 -> 11;
               case 20 -> 37;
               case 21 -> 12;
               case 22 -> 3;
               case 23 -> 0;
               case 24 -> 41;
               case 25 -> 1;
               case 26 -> 39;
               case 27 -> 63;
               case 28 -> 31;
               case 29 -> 52;
               case 30 -> 15;
               case 31 -> 45;
               case 32 -> 32;
               case 33 -> 30;
               case 34 -> 47;
               case 35 -> 50;
               case 36 -> 60;
               case 37 -> 6;
               case 38 -> 49;
               case 39 -> 43;
               case 40 -> 13;
               case 41 -> 62;
               case 42 -> 55;
               case 43 -> 22;
               case 44 -> 24;
               case 45 -> 54;
               case 46 -> 58;
               case 47 -> 17;
               case 48 -> 51;
               case 49 -> 26;
               case 50 -> 29;
               case 51 -> 20;
               case 52 -> 56;
               case 53 -> 33;
               case 54 -> 34;
               case 55 -> 61;
               case 56 -> 23;
               case 57 -> 53;
               case 58 -> 14;
               case 59 -> 10;
               case 60 -> 9;
               case 61 -> 36;
               case 62 -> 4;
               default -> 8;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void e(List<MobEffectInstance> effects) {
      友友何友树何友何友树.entrySet().removeIf(entry -> {
         MobEffect effect = entry.getKey();
         return effects.stream().noneMatch(e -> e.getEffect() == effect);
      });
      友树友友何何何何友树.entrySet().removeIf(entry -> {
         MobEffect effect = entry.getKey();
         return effects.stream().noneMatch(e -> e.getEffect() == effect);
      });
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 200 && var8 != 'l' && var8 != '$' && var8 != 'g') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 202) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 222) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 200) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'l') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友友树何友友树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public static void c(PoseStack poseStack, List<MobEffectInstance> effects, float x, float y, 友何何何何友何友友树 module) {
      b<"Þ">(-3777650455850342064L, 15047929416599L);
      if (mc.player != null && mc.level != null && !effects.isEmpty()) {
         e(effects);
         W(effects);
         何何友友树何树何友树 zw18 = Cherish.instance.t().C(18);
         何何友友树何树何友树 zw16 = Cherish.instance.t().C(16);
         何何友友树何树何友树 titleFont = Cherish.instance.t().C(20);
         float totalWidth = Z(effects, zw18, titleFont);
         float totalHeight = 30 + effects.size() * 28 + (effects.size() - 1) * 6 + 16;
         poseStack.pushPose();
         Color glassColor = new Color(0, 0, 0, 60);
         Color borderColor = new Color(255, 255, 255, 120);
         ShaderUtils.M(132138673613539L, poseStack, x, y, totalWidth, totalHeight, 8.0F, 1.5F, borderColor, glassColor, 12.0F);
         float titleX = x + totalWidth / 2.0F - titleFont.D("") / 2.0F;
         float titleY = y + 8.0F + 2.0F;
         titleFont.q(poseStack, "Status Effects", titleX, titleY, b<"$">(-3777384224833698627L, 15047929416599L).getRGB());
         ShaderUtils.o(poseStack, 100739365455537L, x + 8.0F, titleY + titleFont.x() + 4.0F, totalWidth - 16.0F, 1.0F, 0.5F, new Color(255, 255, 255, 80));
         float currentY = y + 8.0F + 22.0F + 8.0F;
         Iterator var25 = effects.iterator();
         if (var25.hasNext()) {
            MobEffectInstance effect = (MobEffectInstance)var25.next();
            a(poseStack, effect, x + 8.0F, currentY, totalWidth - 16.0F, zw18, zw16);
            float var10000 = currentY + 34.0F;
         }

         poseStack.popPose();
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "<Z\u0001a\bm3\u001aLj\u0002p6GG,\u0012kq栥古叉桶佗厔叿栾佗桶";
      f[1] = "~\u0004! \u001cpu\u000b0o`iz\u0011>,WYl\u000621Fu{\u000b";
      f[2] = "y\u00068:;YvFu11Ds\u001b~w!_4厣标伌原叽栋伽佃案桅";
      f[3] = "`rn\u00196A\u0015Re\u0016'\u000ehJv\u0011.G\u0000";
      f[4] = ".\u0006\u0010\t6z0\u000e\nFUn4";
      f[5] = "V\u001eF\u0004_RY^\u000b\u000fUO\\\u0003\u0000I]RQ\u0005\u0004\u0002\u001eTX\u0000\u0004ITTF\u0000\u0004\u0006I\u0013叾伥伽伲佥叶你去厣桶";
      f[6] = "^&6I^OQf{BTRT;p\u0004DTT$k\u0004PNT%y^XOS;6叡佤栱叶桙位使叺栱栬";
      f[7] = "(W\u0001(_D5BY\n\u001eI-D";
      f[8] = "\u001e\"\u001et@\u000e\u0015-\u000f;!\u0000\u001e&\u000ba";
      f[9] = "\u0005\u0010<MpoP\u001b:O\u000b栚栠厱栜召佖栚叺伯佘/7a\u0000\u0010~Cbj\u0006\u0012";
      f[10] = "\u0000zE1\u001a\u001cW6J}!伿佦佚佳叏叢厡司叄叭\f\u001a\\JaOu\u0011\rK9";
      f[11] = "!ej'-~wdj\\厉桛变叚伎企众伟变栀Sgt3}x*l%2%";
      f[12] = "8N\u0012w{Ut\u001fS4\u001ftE0tC\u001f\u0016:KQjaZk\n\u0012";
      f[13] = "?C6\u00132IiB6h厖厶佘叼栖伵厖伨叆栦\u000fSk\u0004c^vX:\u0005;";
      f[14] = "\u0014\f\u0001L\t\u001eA\u0007\u0007Nr桫栱伳校佳桫伯併厭叻.N\u0010\u0011\fCB\u001b\u001b\u0017\u000e";
      f[15] = "y\u0002u9&p/\u0003uB(L;\u0011 s>u)\u0015,B9#/O3{+'#~";
      f[16] = "iWr[XN>\u001d|N=MP\u0016xO]]k\u0015z]B?";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友友树何友友树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a(PoseStack poseStack, MobEffectInstance effect, float x, float y, float width, 何何友友树何树何友树 nameFont, 何何友友树何树何友树 timeFont) {
      友树何友友树何何树树.z();
      String potionName = K(effect);
      if (effect.getDuration() == -1) {
      }

      String potionTime = MobEffectUtil.formatDuration(effect, 1.0F).getString();
      int maxDuration = 友何何何何友何友友树.何何何何友友友友友友.getOrDefault(effect.getEffect(), Math.max(effect.getDuration(), 1));
      if (maxDuration == 0 || maxDuration == -1) {
         maxDuration = 1;
      }

      float progress = Math.min(1.0F, (float)effect.getDuration() / maxDuration);
      何友友何何友何友友何 progressAnim = 友树友友何何何何友树.get(effect.getEffect());
      double var10001 = progress;
      Object[] var10004 = new Object[]{null, 26371741931631L};
      var10004[0] = var10001;
      progressAnim.p(var10004);
      float smoothProgress = (float)progressAnim.D(new Object[]{124111691745592L});
      if (effect.getDuration() < 12 && effect.getDuration() >= 0) {
         友友何友树何友何友树.get(effect.getEffect()).n(new Object[]{友何树友树何何友树树.树树友树友何树友何何, 59020024422499L});
      }

      友友何友树何友何友树.get(effect.getEffect()).n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
      double animOutput = 友友何友树何友何友树.get(effect.getEffect()).D(new Object[]{124111691745592L});
      if (!(animOutput < 0.1)) {
         poseStack.pushPose();
         poseStack.scale((float)animOutput, (float)animOutput, 1.0F);
         poseStack.translate(x * (1.0 - animOutput) / animOutput, y * (1.0 - animOutput) / animOutput, 0.0);
         GuiGraphics guiGraphics = new GuiGraphics(mc, mc.renderBuffers().bufferSource());
         TextureAtlasSprite texture = mc.getMobEffectTextures().get(effect.getEffect());
         RenderSystem.setShaderTexture(0, texture.atlasLocation());
         int iconX = (int)x + 2;
         int iconY = (int)y + 5;
         guiGraphics.blit(iconX, iconY, 0, 18, 18, texture);
         int textX = iconX + 18 + 8;
         int nameY = (int)y + 3;
         nameFont.Q(poseStack, potionName, textX, nameY, Color.WHITE.getRGB());
         int timeY = nameY + nameFont.x() + 2;
         timeFont.Q(poseStack, potionTime, textX, timeY, Color.WHITE.getRGB());
         float progressBarWidth = width - 18.0F - 16.0F;
         float progressBarY = y + 28.0F - 3.0F - 2.0F;
         ShaderUtils.o(poseStack, 100739365455537L, textX, progressBarY, progressBarWidth, 3.0F, 1.5F, new Color(255, 255, 255, 40));
         if (smoothProgress > 0.0F) {
            ShaderUtils.o(poseStack, 100739365455537L, textX, progressBarY, progressBarWidth * smoothProgress, 3.0F, 1.5F, Color.WHITE);
         }

         poseStack.popPose();
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 560;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树友友树何友友树何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String g(int num) {
      友树何友友树何何树树.z();
      int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
      String[] symbols = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
      StringBuilder sb = new StringBuilder();
      int i = 0;
      if (0 < values.length && num > 0) {
         if (values[0] <= num) {
            int var10000 = num - values[0];
            sb.append(symbols[0]);
         }

         i++;
      }

      return sb.toString();
   }

   private static void W(List<MobEffectInstance> effects) {
      友树何友友树何何树树.z();
      Iterator var4 = effects.iterator();
      if (var4.hasNext()) {
         MobEffectInstance instance = (MobEffectInstance)var4.next();
         MobEffect effect = instance.getEffect();
         友友何友树何友何友树.computeIfAbsent(effect, k -> new 树友树何树树何树树何(37618987749219L, 300, 1.0, 1.8F));
         友树友友何何何何友树.computeIfAbsent(effect, k -> new 何友友何何友何友友何(300, 16923, 1.0, 47854, '溑'));
      }
   }

   private static String K(MobEffectInstance potionEffect) {
      return potionEffect.getEffect().getDisplayName().getString() + "" + g(potionEffect.getAmplifier() + 1);
   }

   private static String HE_SHU_YOU() {
      return "我是何树友";
   }
}
