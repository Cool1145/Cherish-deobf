package cn.cool.cherish.ui.dynamicisland;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.MethodHandles;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class DynamicIsland$何树何何何何何友何友 implements 何树友 {
   public static final int 友树树何友友何何何友 = 0;
   public static final int 何树树何何友树友树友 = 1;
   public static final int 树何树友何友树何何树;
   public static final int 何友何何友何友友何友;
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(393570072838841247L, -2075492197837043930L, MethodHandles.lookup().lookupClass()).a(53638431210815L);
      // $VF: monitorexit
      long var1 = var10000 ^ 69097359961814L;
      Cipher var3;
      Cipher var13 = var3 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var1 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var4 = 1; var4 < 8; var4++) {
         var10003[var4] = (byte)(var1 << var4 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var0 = new long[2];
      int var6 = 0;
      byte var5 = 0;

      do {
         int var10001 = var5;
         var5 += 8;
         byte[] var9 = "^~\u0099·Xkå\u008eù´»\u0018\u0082Qá»".substring(var10001, var5).getBytes("ISO-8859-1");
         var10001 = var6++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var3.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         byte var15 = -1;
         var0[var10001] = var10004;
      } while (var5 < 16);

      何友何何友何友友何友 = (int)var0[0];
      树何树友何友树何何树 = (int)var0[1];
   }

   private static String HE_DA_WEI() {
      return "何炜霖大狗叫";
   }
}
