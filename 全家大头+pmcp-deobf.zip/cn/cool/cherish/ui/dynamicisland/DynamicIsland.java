package cn.cool.cherish.ui.dynamicisland;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.combat.KillAura;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.module.impl.display.树友何友友何何树友树;
import cn.cool.cherish.module.impl.display.树友树树何何友何何友;
import cn.cool.cherish.module.impl.player.友友树树何何友树何友;
import cn.cool.cherish.module.impl.player.树友何何友何树何树友;
import cn.cool.cherish.ui.何友友友树友何友树何;
import cn.cool.cherish.ui.何树何友友何何友友树;
import cn.cool.cherish.ui.友树何友何友何树树树;
import cn.cool.cherish.ui.树友何何何树友树何友;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.animations.何何树何树何树树何何;
import cn.cool.cherish.utils.animations.何友友友树何何友树何;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.utils.wrapper.WrapperUtils;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.BrewingStandMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.FurnaceMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.scores.PlayerTeam;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;
import why.tree.friend.antileak.Fucker;

public class DynamicIsland implements IWrapper, 何树友 {
   public static DynamicIsland 何友何何树何友何何何;
   private static final List<DynamicIsland.友友友何何树树树友树> 何友何友何树何友友友;
   private static final List<DynamicIsland.树何何何何何树友树友> 何树友友树何友友树何;
   private static final List<String> 树何何何树友何树树友;
   private static final List<DynamicIsland.友树友树友树何友友树> 友友友何何何树树友友;
   private static final List<DynamicIsland.友何何何何树何何友友> 何何树何友友友树友何;
   private static float 友树何何树友树友何友;
   private static float 友友何友友何友友树树;
   private static float 何何友友何树友何何友;
   private static float 树树树何何友何何何友;
   private static DynamicIsland.树树友树友树何何何友 树友树树友树何友友何;
   private static int 何树友树何树何何树友;
   private static Vec3 何友友何何何树何何友;
   private static long 何友树树何友何友何树;
   private static double 友树友友何友何何何友;
   private static String 何友何何树树何友何树;
   private static String 友何何友树何树友友何;
   private static boolean 何何树树友何友树树树;
   private static boolean 何何友何树树树友友树;
   private static final 何何树何树何树树何何 何友树友何树何友何何;
   private static final 何何树何树何树树何何 树何友树友友树何树何;
   private static final 何友友何树何树何树友 友树友友树何树友友友;
   private static final 何友友何树何树何树友 树友树何树树友树友树;
   private static final 何友友何树何树何树友 树树友树树友树树树何;
   private static final 何友友何树何树何树友 树友何何友树何树何树;
   private static final 何友友何树何树何树友 树何何友何树树树友友;
   private static int[] 树何友何友树何友友友;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[107];
   private static final String[] j = new String[107];
   private static int _刘凤楠230622109211173513 _;

   public DynamicIsland() {
      何友何何树何友何何何 = this;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(8420969090768669866L, 2585139485651211718L, MethodHandles.lookup().lookupClass()).a(65545208935944L);
      // $VF: monitorexit
      a = var10000;
      a();
      int[] var22 = new int[5];
      z(var22);
      Cipher var11;
      Cipher var23 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(118734927519403L << var12 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[70];
      int var16 = 0;
      String var15 = "ì\u0088\u001a\u008a;íOºi\u001e]\u009fàª¦\u0098Z \u0018\u009a£\u0080ÀE\u0015\u0084\u0000dÙ{\tÐ\u0010»Í@Vã\u0086*ºsÃlq0#`}\u0010\rF\u0014¯Æ9³\u0004¾Çbº1ªW\f\u0018na#í\u009c\u009c\u0018u\u009bñ\u008d¥À\u008fÖ@\nk\u009c,:,P¨\u0010£ñ8\u0015uSw\u0007ê'\u00ad¦J\u008f\u0015A \u007f Eq)\u0015Rñ\u0003V BÈXù°\u0005\u0085¿í\u008f2\u0013\u0096O´\u008d\u001bUÌ>x\u0010ÊõÒÌb¢\u001dè\u0010^\u0099E\u0082<\u0016\u0088\u0018\u0099k«Åt\u0012b¬\rÚª\f¼×7ktÁ\u009dØß[qÈ\u0010\u0095®)è9\u0087SCê¦ü<\u0011f\u001d\u0002\u0018@}(\u0004tS×\fõLæð\u001d~\u0092RèÈ¬Ýu53÷\u0010p_\u0084\u0010YÝûàÂâ5ço´#V \u009e\u0016eîý\u009f5ì³}ï\u009c¬\b4[C\\Yõ£ÚR\u007ftp\u0098è\u0011:Áy =í©ig¡\u0091Èålr\u00ad!ºÖ[\u0086?--\u0083Fì\u0014Wp\u000768D\u0016Á\u0010\u009dýÑ\u000fà©B\u0013Å6>A±{Úß y\u0002\u009bó\tÆÁåC\u001e\u0018Ú{á\u0093\u008d°H³Y©¸¶J\u000bâV\t¾òS÷\u0010E*\u001dO±°\u0086G\ruÈ\u0080\u0091\u008fU) \u0018\u0082%úç\u0016\u0001üz\u0014\u001dD¢fN¼õæPÞâ\u0082b\u00015tÓ:\u0014zºÔ\u0010Ö\u000fÕ(UJÛ8Ú/\u0098¼×\nÍ\u0087\u00109Z9S\nzßéY\u0086òC\u0016îç\u0084 ·vû\u0097\u008c\u0002Í\u00ad\u00ad\u0083ø²ñãÒ\u0016òú° í\u001b\u009d-\u0098FÂæ\u008fïi@\u0010\u00001\u008fÕænu\u001ai:\u00181?ÍÈ´\u0010_9HØ\u0088s\u009bL¢·åÛàµ²j _<å¡é\u001f\u0011\u0090KOéPØu@f\u0099þàëþX\u000e\u0000\u009eBË4j\u0089ÖÐ\u0010U\u0084d8±µ&\u007fnõ\u001c\u0083<Óøï\u0010£¤\u001e¨ÅKE\u0093¿º®\u008a'Ñ\u0019<\u0010¯\u0016«8\u001a-\u0093Ô\u0019õ\u0001\u0002\u0097Ä3Z ¹\u0018p@%~8F\u0085óqëúÑÝ\u0015y\u0082¼ó\"Ïêì\u0000G¤çN¬-@ P\u0097\rÂ½12³×ð\u0080\u0094óc\u008fO^\u0096\u0003i õVF'©0£fÆ0½\u0010;òÛ{S\u0087 t\u001b\u001d\u007f2´Ã0þ\u0010\u0003ò8¶S\u00adü\u0095oOzj¯§\u0095\u0099\u0010Tm(\u0005ãÇKèç2\u0081\u001fB«\u008e6\u0010y\u0094ºãD\u008a/ýÒ«©+´\u008f\u00ad\n\u00101ïävÜ\u0094xÙ=\u008c4_tºéÊ8\u0091eelI*çC\u008fhÔ×ñª¿\u0011\rH¹>ÔqÓúg1ÜÞÖ²5=ßuL\u0083+'RLù\u0081<9\u0090¨=»kT|å~ÛW¡\u0010ô·\u0082gùÝL\u0010\balÝ\u008a\u0082ÎÎ \u0090ÝÂ<|\u008aÂ¬\u008dæ\u0001 \u0085\u0091ÚÛ\u007f\u0094?\"%æ\u0096\u008fP\u001aq\u00ad\u0013\u008cûú ¯»NYÂã\u009fX´ø\u008a\u001fõLU|\fÅj@\u001d\u001cÑÌ±ú\u0080\u009d÷\u000eFÈ\u0010Ìa\u0094\u0095\\2l\u0090î[\u0081`$&W_ \u0017Ù\u008a=¨,\u0012h\u0090\u008e\u00adô0Ô8Ñ¹&Y¨ÞDZâ{¯Dì#!\"$\u0018\u0098ªÁß/tÿ½\u0011\bC¢\u008eP}\u0000¸i`¹ì¼\u0004ÿ D¦\u0012Ý´bv°ê¿Á24&9\u0002\by±\u0003_¹æb\t©\u0017¬0\u0001\u0087v ZtåÃ\u001dú¾¼\u0092reB$a\u007f\u008f:tÝ8úÒ·®\u0001ÒÏ8wxÉl\u0018À9\u008fÕ×{äfÓ\f9\t\u0088³'\u0007që\u0099\u0080ifòI\u0010\fúM\u0003Zçh\tlÍ9\u0012\u009cË?¶8°\u001f\u0089\u0097ÂH\u0002ã³yT[\u00169ëÝ\u0005\u007fG\u00ade©o\u00978\u0018yNp´oë\nÛ»RgÊWÒ\bï®+\u009c\u0001\fPË*Ì¾\u008cânG\u0010ÐáSB\u00849ñÿ\"p\u0011Rsø*»\u0010[0í\t¼§¹\u0000Í±Â_ò\u0013 ê\u0010ö\u0086}¾\u0096»I\u009c\u000foÐ\u0091î³,\u0085\u0010\u0006-nO\u0097[FO\u001fnsr´$¢\u0012 ÑnQÃ\u001a\u0087ð'\u0016 ÃÚ\u0007\u0014\u008bî§I«\u0085¼ó\u008a7óù(C5 Ãv\u0010ô÷\u001a·\u0017æwý\u009c\u001cç\u008e÷¹¨*\u0018tá\u0085ÂgJûÂ°ò±\u0004n\u007f\u009cÓt\u0087ÙÓ\u0005\u0087Ö\u0004\u0010Öð8\u000eæm\u0098!ý\u001a\u0019º¶6»°(\"ÆS»\u0000j:\u0007Ñï\u0011\u001f3b{.\u008b³|\u0096Ï9¶akTÓü/Áv©\u0087/[\u009eþ\u0089B\u0096\u0018<0\u008fÜVL\u0085mÔaÁ\u0017\u001a@ëò]ï.·Þ.\u008c@\u0010©\u0006Ò¸\u001eàºÎ\u0083çwp$\u0015\u0084;\u0010G?\u0090ÔÀÁ\n\u0093ûÐ\u0002ëÚO\u0089®8Y\u0099Ù\b~ÅÉÞâ\rwï«Îõ×lÄ{pd\u000e\u001aÜßÞ÷\u00199ý\u0090Èm\u0012ÙD6i&l+uW\u008dì\u0004\u0086\u001fù,\u009a\u000f\u008dNÜ= HÎXÕE¦\u009b¹e#ãjd\u0095\u0083©ý6]$#Ùz¶®\u0087s¤l¥\u001aÿ\u0010\u009bìá\u000bÑZ\u008cBLW=úV\\\u0099!\u0010e[4¥·\u0093;\u0010ªW\u0007ü»\"Þà\u0018$UÀÄf1g]\rÏ\u0091Ü\u0003N/Æ_âÜ\u0099Ì&nP\u0010\u001fJ\u000fH(o,\u0017+Ì\u008c®Ø\u0085Q\u009a\u0010\u0015ö¶!Ö´JZ´·³&\u0085%\u0016s\u0018\u00ad\u001bÁÝ¾¶\u000f3¶8\u0094I¨[sÊåàáq\u008bÖ¤b\u0010ìäOc\r\u0089@\u0003B\u0096G_\u0011n¶Ç\u0010\u008f'\u000fì`l ¥¶¸úÄ\u0098f¾\u008b\u0010?«&\u0082j\u0083qÖ\u0082\u0098Ôø¾\u0080¯Â";
      short var17 = 1643;
      char var14 = ' ';
      int var21 = -1;

      label54:
      while (true) {
         String var24 = var15.substring(++var21, var21 + var14);
         int var10001 = -1;

         while (true) {
            String var35 = b(var11.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var35;
                  if ((var21 += var14) >= var17) {
                     b = var18;
                     c = new String[70];
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var26 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(118734927519403L << var1 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[5];
                     int var3 = 0;
                     String var4 = "ª\u0088l\u0085Ö!¨ïö\u000b\u0097Áó<kE\u009b|\u0094¯\u0005 0\u0004";
                     byte var5 = 24;
                     byte var2 = 0;

                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var27 = var6;
                        var10001 = var3++;
                        long var39 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var42 = -1;

                        while (true) {
                           long var8 = var39;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var44 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var42) {
                              case 0:
                                 var27[var10001] = var44;
                                 if (var2 >= var5) {
                                    f = var6;
                                    g = new Long[5];
                                    何友何友何树何友友友 = new ArrayList<>();
                                    何树友友树何友友树何 = new ArrayList<>();
                                    树何何何树友何树树友 = new ArrayList<>();
                                    友友友何何何树树友友 = new ArrayList<>();
                                    何何树何友友友树友何 = new ArrayList<>();
                                    友树何何树友树友何友 = 0.0F;
                                    友友何友友何友友树树 = 0.0F;
                                    何何友友何树友何何友 = 0.0F;
                                    树树树何何友何何何友 = 0.0F;
                                    树友树树友树何友友何 = null;
                                    何树友树何树何何树友 = 0;
                                    何友友何何何树何何友 = null;
                                    何友树树何友何友何树 = 0L;
                                    友树友友何友何何何友 = 0.0;
                                    何友何何树树何友何树 = "";
                                    友何何友树何树友友何 = "";
                                    何何友何树树树友友树 = false;
                                    何友树友何树何友何何 = new 何何树何树何树树何何((short)0, 760481532, 62373);
                                    树何友树友友树何树何 = new 何何树何树何树树何何((short)0, 760481532, 62373);
                                    友树友友树何树友友友 = new 何友友何树何树何树友(51913986529303L);
                                    树友树何树树友树友树 = new 何友友何树何树何树友(51913986529303L);
                                    树树友树树友树树树何 = new 何友友何树何树何树友(51913986529303L);
                                    树友何何友树何树何树 = new 何友友何树何树何树友(51913986529303L);
                                    树何何友何树树树友友 = new 何友友何树何树何树友(51913986529303L);
                                    return;
                                 }
                                 break;
                              default:
                                 var27[var10001] = var44;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "Êh-rY\u000bzX\u0003!q³/O\tÄ";
                                 var5 = 16;
                                 var2 = 0;
                           }

                           byte var33 = var2;
                           var2 += 8;
                           var7 = var4.substring(var33, var2).getBytes("ISO-8859-1");
                           var27 = var6;
                           var10001 = var3++;
                           var39 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var42 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var21);
                  break;
               default:
                  var18[var16++] = var35;
                  if ((var21 += var14) < var17) {
                     var14 = var15.charAt(var21);
                     continue label54;
                  }

                  var15 = "\u0005Õ3ß)ÓÉ\u008e\u001eâ;\u000e3\u0003\u0007F\u0018½;ëc¡nS¤ø¹êÜ\u0002\\é3\u0015ÈAÂ\u0088p]\u0099";
                  var17 = 41;
                  var14 = 16;
                  var21 = -1;
            }

            var24 = var15.substring(++var21, var21 + var14);
            var10001 = 0;
         }
      }
   }

   public static boolean B() {
      Z();
      return 树友树树何何友何何友.友何何友友友树何树何 != null && 树友树树何何友何何友.友何何友友友树何树何.G() && 树友树树何何友何何友.友何何友友友树何树何.isEnabled();
   }

   private static String C(树友何何何树友树何友 n) {
      try {
         Field f = 树友何何何树友树何友.class.getDeclaredField("树树何友树何何友何何");
         f.setAccessible(true);
         return (String)f.get(n);
      } catch (Exception var4) {
         return null;
      }
   }

   private static void D(PoseStack poseStack, int screenWidth) {
      Z();
      if (!何何树何友友友树友何.isEmpty()) {
         友树何友何友何树树树 fontManager = Cherish.instance.t();
         String title = (ClientUtils.H(80470882894842L) ? "玩家列表 " : "Player List") + "(" + 何何树何友友友树友何.size() + ")";
         fontManager.C(14).h(poseStack, title, 友树何何树友树友何友 + 友友何友友何友友树树 / 2.0F, 25.0, Color.WHITE.getRGB());
         ShaderUtils.o(poseStack, 100739365455537L, 友树何何树友树友何友 + 10.0F, 43.0F, 友友何友友何友友树树 - 20.0F, 1.0F, 0.5F, new Color(80, 80, 80, 180));
         int columns = 何何树何友友友树友何.size() > 8 ? 2 : 1;
         float columnWidth = (友友何友友何友友树树 - 16.0F - (columns - 1) * 4.0F) / columns;
         int itemsPerColumn = (int)Math.ceil((double)何何树何友友友树友何.size() / columns);
         int col = 0;
         if (0 < columns) {
            float columnX = 友树何何树友树友何友 + 8.0F + 0.0F * (columnWidth + 4.0F);
            int row = 0;
            if (0 < itemsPerColumn) {
               int index = 0 * itemsPerColumn + 0;
               if (index < 何何树何友友友树友何.size()) {
                  DynamicIsland.友何何何何树何何友友 info = 何何树何友友友树友何.get(index);
                  m(poseStack, info, columnX, 49.0F, columnWidth, 20.0F, fontManager);
                  row++;
               }
            }

            col++;
         }
      }
   }

   private static float F(List<DynamicIsland.树何何何何何树友树友> contents) {
      Z();
      float totalHeight = 5.0F;
      Iterator var5 = contents.iterator();
      if (var5.hasNext()) {
         DynamicIsland.树何何何何何树友树友 content = (DynamicIsland.树何何何何何树友树友)var5.next();
         totalHeight = 5.0F + (content.何树树树树何何何友树 + 2.0F);
      }

      return totalHeight + 5.0F;
   }

   private static Color I(int ping) {
      Z();
      if (ping < 50) {
         return new Color(100, 255, 100);
      } else if (ping < 100) {
         return new Color(255, 255, 100);
      } else {
         return ping < 150 ? new Color(255, 180, 100) : new Color(255, 100, 100);
      }
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   private static void I(PoseStack poseStack, DynamicIsland.友友友何何树树树友树 content, float x, float y, float size) {
      Z();
      if (!content.友树何何何何何树树何.contains("生命值: ") && content.友树何何何何何树树何.toLowerCase().contains("Health: ")) {
      }

      content.友友树树何树树树树何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
      switch (DynamicIsland$友树树何友友友友友树.何何何何树友树何友树[content.何何友何树树树友树友.ordinal()]) {
         case 1:
            友树何友何友何树树树 fontManager = Cherish.instance.t();
            fontManager.H(16).q(poseStack, " /", x + 4.0F, y + size / 4.0F, Color.WHITE.getRGB());
         case 2:
            Cherish.instance.t().H(20).q(poseStack, "✓", x + 6.0F, y + size / 4.0F, Color.WHITE.getRGB());
         case 3:
            Cherish.instance.t().H(20).q(poseStack, "✗", x + 6.0F, y + size / 4.0F, Color.WHITE.getRGB());
         case 4:
            Cherish.instance.t().H(20).q(poseStack, "ⓘ", x + 6.0F, y + size / 4.0F, Color.WHITE.getRGB());
      }
   }

   private static void I(PoseStack poseStack, LivingEntity target, float x, float y, 友树何友何友何树树树 fontManager) {
      Z();
      String targetName = target.getName().getString();
      float currentHealth = target.getHealth();
      float absorption = target.getAbsorptionAmount();
      float maxHealth = target.getMaxHealth();
      float totalHealth = currentHealth + absorption;
      String healthStr = String.valueOf(Math.round(totalHealth * 10.0F) / 10.0F);
      String maxHealthStr = String.valueOf(Math.round(maxHealth * 10.0F) / 10.0F);
      float avatarX = x + 16.0F;
      float avatarY = 15.0F + (何何友友何树友何何友 - 32.0F) / 2.0F;
      if (target instanceof AbstractClientPlayer) {
         RenderUtils.S(poseStack, avatarX, avatarY, 32.0F, 13836444665765L, 32.0F, (AbstractClientPlayer)target);
      }

      ShaderUtils.o(poseStack, 100739365455537L, avatarX, avatarY, 32.0F, 32.0F, 6.0F, new Color(100, 100, 100, 150));
      fontManager.C(20).h(poseStack, "?", avatarX + 16.0F, avatarY + 16.0F - fontManager.C(20).x() / 2, Color.WHITE.getRGB());
      float textX = avatarX + 32.0F + 12.0F;
      float topY = y + 16.0F;
      fontManager.C(18).q(poseStack, targetName, textX, topY, Color.WHITE.getRGB());
      String healthText = (ClientUtils.H(80470882894842L) ? "生命值: " : "Health: ") + healthStr + " /" + maxHealthStr;
      float nameWidth = fontManager.C(18).D(targetName);
      fontManager.H(16).q(poseStack, healthText, textX + nameWidth + 10.0F, topY + 2.0F, new Color(200, 200, 200).getRGB());
      float barWidth = 友友何友友何友友树树 - (textX - x) - 16.0F;
      float barY = topY + fontManager.C(18).x() + 8.0F;
      float healthPercent = Math.max(0.0F, Math.min(1.0F, totalHealth / maxHealth));
      float animatedWidth = barWidth * healthPercent;
      树何友树友友树何树何.g(animatedWidth, 36433523484945L, 18);
      ShaderUtils.o(poseStack, 100739365455537L, textX, barY, barWidth, 6.0F, 3.0F, new Color(40, 40, 40, 180));
      if (树何友树友友树何树何.S(69444441903267L) > 0.0F) {
         ShaderUtils.o(poseStack, 100739365455537L, textX, barY, 树何友树友友树何树何.S(69444441903267L), 6.0F, 3.0F, Color.WHITE);
      }

      H(poseStack, target, x, y);
   }

   private static float S(float current, float target, float speed) {
      Z();
      float difference = current - target;
      float smoothing = Math.max(Math.abs(target - current) * 0.2F, 0.15F);
      if (difference > speed) {
         current = Math.max(current - smoothing, target);
      }

      if (difference < -speed) {
         Math.min(current + smoothing, target);
      }

      return target;
   }

   public static boolean Z() {
      Z();
      if (树友树树何何友何何友.友何何友友友树何树何 == null || !树友树树何何友何何友.友何何友友友树何树何.d()) {
         return false;
      } else if (友友树树何何友树何友.树友树友友何树何树何 == null || !友友树树何何友树何友.树友树友友何树何树何.isEnabled()) {
         return false;
      } else if (mc.player != null && mc.player.containerMenu != null) {
         boolean isSupportedContainer = mc.player.containerMenu instanceof ChestMenu
            || mc.player.containerMenu instanceof FurnaceMenu
            || mc.player.containerMenu instanceof BrewingStandMenu;
         return !isSupportedContainer ? false : !友友树树何何友树何友.树友树友友何树何树何.p() || 友友树树何何友树何友.g();
      } else {
         return false;
      }
   }

   private static void Z(int x, int y, int width, int height) {
      GL11.glEnable(3089);
      int scale = (int)mc.getWindow().getGuiScale();
      GL11.glScissor(x * scale, (mc.getWindow().getGuiScaledHeight() - 15 - height) * scale, width * scale, height * scale);
   }

   public static int[] Z() {
      return 树何友何友树何友友友;
   }

   private static void V(PoseStack poseStack, float x, float y, 友树何友何友何树树树 fontManager, String idleText, float logoSize, float padding, float spacing) {
      float currentX = x + 12.0F;
      float textY = 15.0F + (何何友友何树友何何友 - fontManager.C(20).x()) / 2.0F;
      float centerY = y + (何何友友何树友何何友 - 20.0F) / 2.0F;
      fontManager.r(55).q(poseStack, "k", currentX - 1.0F, centerY - 2.0F, Color.WHITE.getRGB());
      currentX += logoSize + 8.0F;
      fontManager.C(20).q(poseStack, idleText, currentX, textY, Color.WHITE.getRGB());
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 38;
               case 1 -> 26;
               case 2 -> 17;
               case 3 -> 13;
               case 4 -> 24;
               case 5 -> 48;
               case 6 -> 7;
               case 7 -> 31;
               case 8 -> 22;
               case 9 -> 36;
               case 10 -> 39;
               case 11 -> 61;
               case 12 -> 32;
               case 13 -> 18;
               case 14 -> 55;
               case 15 -> 2;
               case 16 -> 37;
               case 17 -> 47;
               case 18 -> 63;
               case 19 -> 33;
               case 20 -> 6;
               case 21 -> 19;
               case 22 -> 11;
               case 23 -> 44;
               case 24 -> 62;
               case 25 -> 20;
               case 26 -> 34;
               case 27 -> 53;
               case 28 -> 15;
               case 29 -> 3;
               case 30 -> 51;
               case 31 -> 14;
               case 32 -> 21;
               case 33 -> 25;
               case 34 -> 49;
               case 35 -> 46;
               case 36 -> 42;
               case 37 -> 50;
               case 38 -> 23;
               case 39 -> 59;
               case 40 -> 5;
               case 41 -> 40;
               case 42 -> 27;
               case 43 -> 52;
               case 44 -> 57;
               case 45 -> 54;
               case 46 -> 41;
               case 47 -> 0;
               case 48 -> 16;
               case 49 -> 30;
               case 50 -> 12;
               case 51 -> 43;
               case 52 -> 1;
               case 53 -> 35;
               case 54 -> 8;
               case 55 -> 56;
               case 56 -> 28;
               case 57 -> 29;
               case 58 -> 4;
               case 59 -> 10;
               case 60 -> 9;
               case 61 -> 60;
               case 62 -> 45;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void e(PoseStack poseStack, float x, float y, 友树何友何友何树树树 fontManager) {
      Z();
      Iterator var8 = 何树友友树何友友树何.iterator();
      if (var8.hasNext()) {
         DynamicIsland.树何何何何何树友树友 content = (DynamicIsland.树何何何何何树友树友)var8.next();
         poseStack.pushPose();
         poseStack.translate(x, 20.0F, 0.0F);
         content.友友树树何友何树何友.accept(poseStack);
         poseStack.popPose();
         float var10000 = 20.0F + (content.何树树树树何何何友树 + 2.0F);
      }
   }

   public static void e(DynamicIsland.友何树友树友友树何友 type, String title, String description, long time) {
      Z();
      DynamicIsland.友友友何何树树树友树 content = new DynamicIsland.友友友何何树树树友树(type, title, description, time);
      if (description.contains("箱子") || description.toLowerCase().contains("Chest")) {
         content.友友树树何树树树树何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
      }

      if (description.contains("熔炉") || description.toLowerCase().contains("Furnace")) {
         content.友友树树何树树树树何.n(new Object[]{友何树友树何何友树树.树树友树友何树友何何, 59020024422499L});
      }

      content.友友树树何树树树树何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
      何友何友何树何友友友.add(content);
   }

   private static void e() {
      Z();
      if (树友树树何何友何何友.友何何友友友树何树何.d() && h()) {
         AbstractContainerMenu menu = mc.player.containerMenu;
         if (mc.screen instanceof ContainerScreen) {
            何友何何树树何友何树 = mc.screen.getTitle().getString();
         }

         if (menu instanceof ChestMenu) {
            何友何何树树何友何树 = ClientUtils.H(80470882894842L) ? "箱子" : "Chest";
         }

         if (menu instanceof FurnaceMenu) {
            何友何何树树何友何树 = ClientUtils.H(80470882894842L) ? "熔炉" : "Furnace";
         }

         if (menu instanceof BrewingStandMenu) {
            何友何何树树何友何树 = ClientUtils.H(80470882894842L) ? "酿造台" : "Brewing Stand";
         }

         树友树何树树友树友树.D(11747522392279L);
      }

      if (树友树何树树友树友树.A(300L, 118344821288830L)) {
         何友何何树树何友何树 = "";
      }
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14963;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 197 && var8 != 200 && var8 != 237 && var8 != 170) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 196) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 220) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 197) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 200) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 237) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static LivingEntity x() {
      Z();
      树友何友友何何树友树 targetHUDModule = (树友何友友何何树友树)Cherish.instance.getModuleManager().getModule(树友何友友何何树友树.class);
      if (targetHUDModule != null && !targetHUDModule.isEnabled()) {
         if (KillAura.instance != null && KillAura.instance.isEnabled()) {
            LivingEntity kaTarget = KillAura.instance.Y();
            if (mc.player.distanceTo(kaTarget) <= 4.0F) {
               return kaTarget;
            }
         }

         if (!(mc.screen instanceof 何树何友友何何友友树) && !(mc.screen instanceof 何友友友树友何友树何) && mc.screen instanceof ChatScreen) {
         }

         return mc.player;
      } else {
         return null;
      }
   }

   private static void s(PoseStack poseStack) {
      Z();
      友树何友何友何树树树 fontManager = Cherish.instance.t();
      int screenWidth = mc.getWindow().getGuiScaledWidth();
      LivingEntity islandTarget = x();
      boolean chestActive = 树友树树何何友何何友.友何何友友友树何树何.d() && h();
      boolean scaffoldActive = 树友树树何何友何何友.友何何友友友树何树何.E() && 树友何何友何树何树友.树友友树友友友友树何 != null && 树友何何友何树何树友.树友友树友友友友树何.isEnabled();
      boolean hasActiveNotifications = 树友树树何何友何何友.友何何友友友树何树何.N() && (!何树友友树何友友树何.isEmpty() || !何友何友何树何友友友.isEmpty());
      String idleText = z();
      float idleTextWidth = fontManager.C(20).D(idleText);
      A(islandTarget, fontManager);
      if (chestActive) {
         p();
      }

      if (scaffoldActive) {
      }

      if (hasActiveNotifications) {
         M(何树友友树何友友树何);
         F(何树友友树何友友树何);
      }

      float targetWidth = 40.0F + idleTextWidth + 12.0F;
      float targetX = (screenWidth - targetWidth) / 2.0F;
      if (友树何何树友树友何友 == 0.0F && 友友何友友何友友树树 == 0.0F) {
         友树何何树友树友何友 = targetX;
         友友何友友何友友树树 = targetWidth;
         何何友友何树友何何友 = 26.0F;
         树树树何何友何何何友 = 13.0F;
      }

      友树何何树友树友何友 = S(友树何何树友树友何友, targetX, 0.2F);
      友友何友友何友友树树 = S(友友何友友何友友树树, targetWidth, 0.2F);
      何何友友何树友何何友 = S(何何友友何树友何何友, 26.0F, 0.2F);
      树树树何何友何何何友 = S(树树树何何友何何何友, 13.0F, 0.2F);
      if (树友树树何何友何何友.友何何友友友树何树何.I()) {
         ShaderUtils.M(
            132138673613539L,
            poseStack,
            友树何何树友树友何友,
            15.0F,
            友友何友友何友友树树,
            何何友友何树友何何友,
            树树树何何友何何何友,
            1.0F,
            new Color(255, 255, 255, 100),
            new Color(0, 0, 0, 80),
            10.0F
         );
      }

      ShaderUtils.o(poseStack, 100739365455537L, 友树何何树友树友何友, 15.0F, 友友何友友何友友树树, 何何友友何树友何何友, 树树树何何友何何何友, new Color(0, 0, 0, 120));
      poseStack.pushPose();
      Z((int)友树何何树友树友何友, 15, (int)友友何友友何友友树树, (int)何何友友何树友何何友);
      I(poseStack, islandTarget, 友树何何树友树友何友, 15.0F, fontManager);
      if (chestActive) {
         f(poseStack, 友树何何树友树友何友, 15.0F, fontManager);
      }

      if (scaffoldActive) {
         K(poseStack, 友树何何树友树友何友, 15.0F, fontManager);
      }

      if (hasActiveNotifications) {
         e(poseStack, 友树何何树友树友何友, 15.0F, fontManager);
      }

      V(poseStack, 友树何何树友树友何友, 15.0F, fontManager, idleText, 20.0F, 12.0F, 8.0F);
      v();
      poseStack.popPose();
   }

   public static boolean s() {
      Z();
      return mc != null && mc.getWindow() != null ? GLFW.glfwGetKey(mc.getWindow().getWindow(), 258) == 1 : false;
   }

   public static void c(PoseStack poseStack) {
      Z();
      if (mc != null && 树友树树何何友何何友.友何何友友友树何树何 != null) {
         if (友何何友树何树友友何.isEmpty() && mc.player != null) {
            友何何友树何树友友何 = WrapperUtils.f(111441258359257L);
         }

         s();
         树友树树何何友何何友.友何何友友友树何树何.G();
         T();
         a(poseStack);
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static boolean h() {
      Z();
      if (mc.player == null || mc.player.containerMenu == null) {
         return false;
      } else if (友友树树何何友树何友.树友树友友何树何树何 != null && 友友树树何何友树何友.树友树友友何树何树何.isEnabled()) {
         boolean isSupportedContainer = mc.player.containerMenu instanceof ChestMenu
            || mc.player.containerMenu instanceof FurnaceMenu
            || mc.player.containerMenu instanceof BrewingStandMenu;
         if (!isSupportedContainer) {
            return false;
         } else {
            return 友友树树何何友树何友.g() ? true : !友友树树何何友树何友.树友树友友何树何树何.p();
         }
      } else {
         return false;
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static void f(PoseStack poseStack, float x, float y, 友树何友何友何树树树 fontManager) {
      c<"Ü">(7683553472229123983L, 58290076150449L);
      if (mc.player != null && c<"Å">(mc.player, 7683983431472668491L, 58290076150449L) != null) {
         String title = c<"í">(7690646107600565222L, 58290076150449L).isEmpty()
            ? (ClientUtils.H(80470882894842L) ? "" : "Container")
            : c<"í">(7690646107600565222L, 58290076150449L);
         if (title.length() > 18) {
            title = title.substring(0, 18) + "...";
         }

         fontManager.C(16).q(poseStack, title, x + 12.0F, 27.0F, c<"í">(7686292172018922904L, 58290076150449L).getRGB());
         if (友友树树何何友树何友.g()) {
            String statusText = ClientUtils.H(80470882894842L) ? "正在工作..." : "Working...";
            fontManager.H(12)
               .q(
                  poseStack,
                  statusText,
                  x + c<"í">(7684113793855984648L, 58290076150449L) - 12.0F - fontManager.H(12).D(statusText),
                  27.0F,
                  new Color(85, 255, 85).getRGB()
               );
         }

         if (c<"í">(7684581288482503873L, 58290076150449L) != null && c<"í">(7684581288482503873L, 58290076150449L).isEnabled()) {
            String statusText = ClientUtils.H(80470882894842L) ? "就绪" : "Ready";
            fontManager.H(12)
               .q(
                  poseStack,
                  statusText,
                  x + c<"í">(7684113793855984648L, 58290076150449L) - 12.0F - fontManager.H(12).D(statusText),
                  27.0F,
                  new Color(255, 255, 85).getRGB()
               );
         }

         float currentY = 27.0F + (fontManager.C(16).x() + 8.0F);
         AbstractContainerMenu menu = c<"Å">(mc.player, 7683983431472668491L, 58290076150449L);
         int containerSize = 0;
         int filledSlots = 0;
         if (menu instanceof ChestMenu) {
            containerSize = c<"Å">(menu, 7691080682207052210L, 58290076150449L).size() > 63 ? 54 : 27;
         }

         if (menu instanceof FurnaceMenu) {
            containerSize = 3;
         }

         if (menu instanceof BrewingStandMenu) {
            containerSize = 5;
         }

         int i = 0;
         if (0 < containerSize && 0 < c<"Å">(menu, 7691080682207052210L, 58290076150449L).size()) {
            if (!menu.getSlot(0).getItem().isEmpty()) {
               filledSlots++;
            }

            i++;
         }

         String containerInfo;
         if (menu instanceof ChestMenu) {
            containerInfo = (
                  containerSize == 27 ? (ClientUtils.H(80470882894842L) ? "小箱子" : "Small Chest") : (ClientUtils.H(80470882894842L) ? "大箱子" : "Large Chest")
               )
               + " ("
               + filledSlots
               + "/"
               + containerSize
               + ")";
         } else if (menu instanceof FurnaceMenu) {
            containerInfo = (ClientUtils.H(80470882894842L) ? "熔炉" : "Furnace") + " (" + filledSlots + "/" + containerSize + ")";
         } else if (menu instanceof BrewingStandMenu) {
            containerInfo = (ClientUtils.H(80470882894842L) ? "酿造台" : "Brewing Stand") + " (" + filledSlots + "/" + containerSize + ")";
         } else {
            containerInfo = (ClientUtils.H(80470882894842L) ? "容器" : "Container") + " (" + filledSlots + "/" + containerSize + ")";
         }

         fontManager.H(14).q(poseStack, containerInfo, x + 12.0F, currentY, c<"í">(7686292172018922904L, 58290076150449L).getRGB());
         currentY += fontManager.H(14).x() + 10.0F;
         m(poseStack, x + 12.0F, currentY, fontManager);
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13120;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[\u0006\u00adB\u0081~$M×±àÂ{Ð")[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static void a(PoseStack poseStack) {
      Z();
      int screenWidth = mc.getWindow().getGuiScaledWidth();
      int columns = 何何树何友友友树友何.size() > 8 ? 2 : 1;
      float targetTabWidth = columns == 2 ? Math.min(380.0F, screenWidth - 40.0F) : Math.min(220.0F, screenWidth - 40.0F);
      int itemsPerColumn = (int)Math.ceil((double)何何树何友友友树友何.size() / columns);
      float targetTabHeight = 28.0F + itemsPerColumn * 22.0F + 20.0F;
      float maxHeight = mc.getWindow().getGuiScaledHeight() - 100.0F;
      targetTabHeight = Math.min(targetTabHeight, maxHeight);
      float targetX = (screenWidth - targetTabWidth) / 2.0F;
      if (友树何何树友树友何友 == 0.0F && 友友何友友何友友树树 == 0.0F) {
         友树何何树友树友何友 = targetX;
         友友何友友何友友树树 = targetTabWidth;
         何何友友何树友何何友 = targetTabHeight;
         树树树何何友何何何友 = 8.0F;
      }

      友树何何树友树友何友 = S(友树何何树友树友何友, targetX, 0.2F);
      友友何友友何友友树树 = S(友友何友友何友友树树, targetTabWidth, 0.2F);
      何何友友何树友何何友 = S(何何友友何树友何何友, targetTabHeight, 0.2F);
      树树树何何友何何何友 = S(树树树何何友何何何友, 8.0F, 0.2F);
      if (树友树树何何友何何友.友何何友友友树何树何.I()) {
         ShaderUtils.M(
            132138673613539L,
            poseStack,
            友树何何树友树友何友,
            15.0F,
            友友何友友何友友树树,
            何何友友何树友何何友,
            树树树何何友何何何友,
            1.0F,
            new Color(255, 255, 255, 100),
            new Color(0, 0, 0, 80),
            10.0F
         );
      }

      ShaderUtils.o(poseStack, 100739365455537L, 友树何何树友树友何友, 15.0F, 友友何友友何友友树树, 何何友友何树友何何友, 树树树何何友何何何友, new Color(0, 0, 0, 120));
      poseStack.pushPose();
      Z((int)友树何何树友树友何友, 15, (int)友友何友友何友友树树, (int)何何友友何树友何何友);
      D(poseStack, screenWidth);
      v();
      poseStack.popPose();
   }

   private static Exception a(Exception var0) {
      return var0;
   }

   private static void a() {
      i[0] = "?OigDl0\u000f$lNq5R/*^jrE>jJn5B.wGb2Ei@Rm=L.gbp0@)`";
      i[1] = "2]>\u001b\u0014w=\u001ds\u0010\u001ej8@xV\u000el8_cV伮叓厚佦栁伭桪位桀司";
      i[2] = "p\u0003x\u001cyin\u000bbS\u001bui\u0016";
      i[3] = "'.";
      i[4] = "\u0013\u007fM81\f\u0018p\\wZ\u0018\u001a{K-v\u000f\u0017";
      i[5] = "}\u000f\u001f*\u0006,rOR!\f1w\u0012Yg\u001c*0\u0005H'\b.w\u0002X:\u0005\"p\u0005\u001f\r\u0010-\u007f\fX* 0r\u0000_-M桒佋伴佤伜似桒叕桰叺";
      i[6] = int.class;
      j[6] = "java/lang/Integer";
      i[7] = "#YB\u0006\u000eR>L\u001a$O_&J";
      i[8] = "C9<\u001a\u0014\u0018Lyq\u0011\u001e\u0005I$zW\u000e\u001e\u000e3k\u0017\u001a\u001aI4{\n\u0017\u0016N3<=\u0002\u0019A:{\u001a2\u0004L6|\u001d_厼叫厜佇伬桪桦栱厜栃";
      i[9] = "tBC\u001e(\u007f{\u0002\u000e\u0015\"b~_\u0005S2y9H\u0014\u0013&}~O\u0004\u000e+qyHC9>~vA\u0004\u001e\u000ec{M\u0003\u0019c叛佂栽厦桬厌叛栆佹厦";
      i[10] = "_3?cgrT<.,\u001ajG;'e";
      i[11] = "6HaC?y9\b,H5d<U'\u000e%b<J<\u000e1x<K.T9y;Ua叫伅标厞样会併厛标桄";
      i[12] = "@\u001d\u001e\">,O]S)41J\u0000Xo$7J\u001fCo0-J\u001eQ58,M\u0000\u001e伔厚厈叨桢佥伔厚桒佶";
      i[13] = "rW&e\u00005}\u0017kn\n(xJ`(\u001a3?]qh\u000e7xZau\u0003;\u007f]&B\u00164pTae&)}XfbK厑栀栨佝反厤厑叚史栙";
      i[14] = "\u0003?";
      i[15] = float.class;
      j[15] = "java/lang/Float";
      i[16] = "DxI\t\bpK8\u0004\u0002\u0002mNe\u000fD\npCc\u000b\u000fIvJf\u000bD\u0003vTf\u000b\u000b\u001e1栶叝桶桻伲佊召佃伲厡";
      i[17] = "rmt<fI}-97lTxp2qdIuv6:'O|s6qyJpz?-'样叚佖伏厔作样佄栒厑";
      i[18] = long.class;
      j[18] = "java/lang/Long";
      i[19] = ")#eI,T&c(B&I#>#\u00046O#!8\u0004\"U# *^*T$>e使伖株伟桜伞栻桒佮伟";
      i[20] = ">m8`V/1-uk\\24p~-L)sgomX-4`\u007fpU!3g8G@.<n\u007f`p31bxg\u001d压桌又标又栨伕厖又标";
      i[21] = double.class;
      j[21] = "java/lang/Double";
      i[22] = "\fB$\u0011\u0019I\fB3M\u0015F\u0016\t'P\u0006L\u0006\t W\rSLq5\\G";
      i[23] = boolean.class;
      j[23] = "java/lang/Boolean";
      i[24] = "I\u0015N\\Y.FU\u0003WS3C\b\b\u0011C(\u0004\u001f\u0019QW,C\u0018\tLZ D\u001fN{O/K\u0016\t\\\u007f2F\u001a\u000e[\u0012桐栻厰桱叴栧伔使伮厫";
      i[25] = "\u0011U";
      i[26] = void.class;
      j[26] = "java/lang/Void";
      i[27] = "S\u001d\u0018|c\u0002S\u001d\u000f o\rIV\u001b=|\u0007YV\t<z\u0002I\u0001B\u001eg\u001dT\u0016\u000b\u0017`\u001fT\f\u0015";
      i[28] = "\u0003y|]\u0005\u001e\f91V\u000f\u0003\td:\u0010\u0007\u001e\u0004b>[D\u0018\rg>\u0010\t\u001e\ru3JD:\t{>\u007f\u001f\u0003\u0001";
      i[29] = "`J\u001bI~%`J\f\u0015r*z\u0001\f\u000bz)`[A*z\"kL\u001d\u0006u8";
      i[30] = "\u0014\u001a\u0019j\u001d,\u0014\u001a\u000e6\u0011#\u000eQ\u000e(\u0019 \u0014\u000bC#\u0005,T\f\u000e6\u0015 \u0014\fC\u0017\u00137\u001f\u001a\u0003";
      i[31] = "3\u000b\fA\u001d\u00043\u000b\u001b\u001d\u0011\u000b)@\u001b\u0003\u0019\b3\u001aV\u001f\u001c\f$\u000b\nA<\u0002>\u000f\u0014?\u001c\f$\u000b\n";
      i[32] = "Z.\u00034!\"Z.\u0014h--@e\u0000u>'Pe\u001et:.Z?\u0018h5eu)\u0004n>*W?4u\"?U\"\u0019\u007f>\u0006Q%\u0002";
      i[33] = "*\tE\u000ea\\%I\b\u0005kA \u0014\u0003Cc\\-\u0012\u0007\b Z$\u0017\u0007C~_(\u001e\u000e\u001f 司厂桶桺伸佛司桘伲厠";
      i[34] = "V\f4<\u0007LV\f#`\u000bCLG#}\u0018@\u0016'/|$PT\u0005\f{\u0019Q";
      i[35] = "\u00037";
      i[36] = "RZmSw\u001a]\u001a X}\u0007XG+\u001em\u001c\u001fP:^y\u0018XW*Ct\u0014_Pmta\u001bPY*SQ\u0006]U-T<厾佤佡伖佥栉传佤叿厈";
      i[37] = "@H\u001bT(-@H\f\b$\"Z\u0003\f\u0016,!@YA\n)%WH\u001dT\u0004&]Y\u001d\u001b&0mA\u0006\u001f+0~A\u000e\u0003 6";
      i[38] = "R7if\u0006QL?s)NQV5knGJ\u0016\u0015pi[QU3m";
      i[39] = ")Sl\u001bw#&\u0013!\u0010}>#N*Vu#.H.\u001d6%'M.V|%9M.\u0019ab\u0002h\u0006";
      i[40] = "\t\u0002\u0002\t0\u0003\u0006BO\u0002:\u001e\u0003\u001fDD)\r\u0006\u0019ID6\u0001\u001a\u0000\u0002'0\b\u000f:M\u0006*\t";
      i[41] = "%\u000eMcoo.\u0001\\,\u000ea%\nXv";
      i[42] = "ZRR&Z4\t\u001bO,*伏伹厨佳桎栳桋厧桲叭W\u00141T\u0002\u0015o\u001a8\u001f\u0010";
      i[43] = "\u0015\u0005qE\u0000a\u001fTvW=叝伢伷变叨叾标伢桳但+Wq\u0015\u0004&T] \u0012\u0016";
      i[44] = "\u001b./Q:{J(z#伝又桢厂众栺伝又伦伜JO%kF;u\u001a0l\u0015";
      i[45] = "V\fND06\u0007\n\u001b6桓厅栯伾栲栯厉桟叵桺+\u000fs*G\u001eMT-9\n";
      i[46] = "\t4,\u0006\u0005dX2yt伢受伴伆桐桭伢受伴桂IK\u001btS&u\u0018\u0012/\b";
      i[47] = "\u0019u\nA\u0012U\u0014|\u0015\u000frH\u001c6\u0014\u0019\u0014B\u0017M\u000bH\u0010\u0018\u001a1\u0006A\u000fV";
      i[48] = "?\b\ru\u0014\u000blA\u0010\u007fd厮参栨桨余桽桴栘栨伬\u0004T\u0003;I\u0016b\u001e\u0016{\u0001";
      i[49] = "]\u0004SN=M\f\u0002\u0006<会叾你伶栯佡厄你你伶6\\(XO\u0011F\r.\r";
      i[50] = "[pOy\u001d<\nv\u001a\u000b伺休司叜佷栒厤休佦叜*b\u001d|DbL2\\*B";
      i[51] = ";lKQ\f'?h\u0001\u0012c桏厓厗档叠厠厕厓桍伧#\bna&\u0015R\fj+e";
      i[52] = "3\u001a;5G'$\u001c>08;\u0001H6{\u0003d\u0001s`/\u0001j7Jl$\u0006$";
      i[53] = "@Ze!\t\u0010\u0011\\0S伮伽根佨參厐厰桹口佨\u0000iJ\u0004AE`8\u0003\u001fK";
      i[54] = ")tY)\u001f\rxr\f[厦桤伔但栥厘桼厾伔变<2\u001fM6fZb^\u001b0";
      i[55] = "'\u0013(zI\b!K*i*\r\u0012\u0012)\"\u0013]\u0012(-w\u0014\r Suo\u0012\r";
      i[56] = " \u001f\u0013%D/7\u0000\u0017 (厌厛桢栰伞叫厌桁伦佴C\u0015/&\u001fV&\u0012 ?C";
      i[57] = ".XTcF)\u007f^\u0001\u0011叿伄伓叴栨佌栥厚厍佪1.X9tJ\r}Qb/";
      i[58] = "+1+\u00149A:7&\u0014^佲厅反伟厭厝栶桟体伟n7Uvq?\bg\u0014 w";
      i[59] = "MmyQNGZr}T\"古佨佔厀佪叡古栬栐伞7\u001eC\u000bg&LF[\rg";
      i[60] = "\u000fhN\u00143\b^n\u001bf厊桡厬叄栲伻桐去厬叄+_p\u0014\u001ezM\u0004.\u0007S";
      i[61] = "Qq*OWo\u0000w\u007f=叮栆史叝伒叾佰佂佬叝OPQ&P{.]Cp\u0001";
      i[62] = "\n\t`U[aY@}_+叄栭佭佁佹佶佚栭栩佁$\u0014cT\na\u0018Gj\u000fQ";
      i[63] = "-M`d7r|K5\u0016厎叁厎使佘佋桔栛厎叡\u0005,tf,Re}=}&";
      i[64] = "w+\fw\u0011l&-Y\u0005桲叟佊伙厪栜伶栅佊桝i<Rpf9\u000fg\fc+";
      i[65] = "H0U\u0000\u0007a\u00196\u0000r/\u0011O U\u0002G*VoIL}";
      i[66] = "F\\)\u0003l=GA\u007f\u001f\t伒伪叽历伲栐厌伪佣历on0\u0012N\u007fTw\u007f\u000e\u0000";
      i[67] = "c(<\u000b\u0002@t78\u000en根栂休佛估厭佽但休佛m\u0001\u001a~qe\n\u0017Be*";
      i[68] = "_Mw\u0019\u0014K\u000eK\"k伳佦叼使栋桲桷司叼栻\u0012\u0004T^\u0002Au\u0012\fEY";
      i[69] = "^PG\u00064\u001dOVJ\u0006S厰株厬佳伡伎伮佮厬样|:\t\u0003\u0010S\u001ajHU\u0016";
      i[70] = "y\u0011/\u0011\u001f/(\u0017zc\f_#\u0002)\u0001X1(\u0000;Yeee\u001d(^\u000bng\u000fpc";
      i[71] = "k\u001aSQ\u0007;z\u001c^Q`厖叅格叹栲桹厖栟佸叹+\t/6ZGMYn`\\";
      i[72] = "L8\b\u001fB'M%^\u0003'伈传伇伹桪古桌传厙桽s@*\u0018*^HYe\u0004d";
      i[73] = "|i9\"*l-olP厓叟佁叅原伍厓叟栅栟\\9*,c{:ikze";
      i[74] = "ok_\u0015\bPxt[\u0010d右栎栖桼伮伹佭叔双厦s[Tw5\u0018O\b],n";
      i[75] = "F4?J\u000b\u0005H=tX0栤桡厔双叠右叾去厔佒#\u000e^H>4\u001b\u0000W\u0003,";
      i[76] = "\b$6\"v\r\u0006>%?\u000e\b<wmb>^<F0ap\b\u0004??b5\u0005";
      i[77] = "JHu\u000f\u0002i\u001bN }桡栀叩栾栉厾桡栀栳佺\u0010DAu[Zv\u001f\u001ff\u0016";
      i[78] = "2O,\\y\u001ecIy.qn5_,^9U,\u00100\u0010\u0003\u000fl[6O`\u001fiB6.";
      i[79] = "7]`\u000e(Y=\u001d(DW\b\u0004\u001egLfX\u0004%<\u001dj\u0018,W+\u001bo\u001d";
      i[80] = "\u0019.U\u001b2\u007f\u0012(L^\r桘厼栊叴叠佐桘伢栊佪#k|\u001d+\b\u001d`z\u0004n";
      i[81] = "<R\u007f@\u000edmT*2桭佉企叾佇栫桭栍原叾\u001a\u000bMx-@|P\u0013k`";
      i[82] = "-Eb\u000bh\bhM|T\u0016桿厔桭发桶栏厥厔桭住omV4\rnUu\\7D";
      i[83] = ";d\u001a\bpPjbOz佗口伆又伢档佗口厘又\u007f@3D:{\u001f\u0011z_0";
      i[84] = "\"=\n#\u0002\u0004s;_Q桡伩厁桋厬厒桡伩桛伏o=\u001d\u0014\u007f(Ph\b\u0013,";
      i[85] = "A\u007f^#K\u0016\u0010y\u000bQ佬厥核栉佦厒佬厥佼栉;:V^C.D<\u000f\u0005\\";
      i[86] = "kZ4T:O(V<_]厷桉叺优佻厞伩桉佤桜&a\u0010nW ]9\bhW";
      i[87] = "F82!W\f\u0015q/+'桳桡作伓桉栾伷去参厍P\u001eS\u0014p36E\r\u0007=";
      i[88] = "\u007fu0}\u0004\u0005$q.;`桢桙及桎历伽桢厃佔伊E_\u0007'13;\u0004\u00039w";
      i[89] = "\r8eW o\\>0%伇栆厮厔栙佸厙叜桴伊\u0000\u001fc{\f'`N*`\u0006";
      i[90] = "t U\u001bMz%&\u0000i栮佗佉伒栩厪佪栓栍厌0S\u000enu?P\u0002Gu\u007f";
      i[91] = ">_<}\u001a)oYi\u000f桹厚桇栩厚栖伽厚厝佭Y`\u0006<>J6k\u001bh,";
      i[92] = "f+fx\u0010H7-3\n伷佥栟桝叀佗厩校栟桝\u0003eP];'ds\bF`";
      i[93] = "\u001c\u000eG\u0017jj\u000b\u0011C\u0012\u0006佗桽桳桤伬叅栓桽厩传q9n\u0004P\u0000Mjg_\u000b";
      i[94] = ";bA;w\t`f_}\u0013桮栝佃栿佞栊伪余叝句\u0003,\u000bc&B}w\u000f}`";
      i[95] = "{\u0012v2@d8\u001e~9'厜厃桨栞伝古伂桙伬叄@^\"*\u0017;)\u00168!\u001e";
      i[96] = "dscg$EuungC栲及厏佗叞桚栲及桕叉\u001d*Q93w{z\u0010o5";
      i[97] = "f\u000b\u000f-m=%\u0007\u0007&\n佛桄桱桧框佗佛伀厫桧_6bc\u0006\u001b$nze\u0006";
      i[98] = "\u001b\u0010F|AV\u001a\u0010S&9T\"]\u0005~\u0006\u000b\"mR>\u0000[\u0010\f_,V\n";
      i[99] = "oeNssXxzJv\u001f校佊作厷取佂校佊参桭\u0015gFv0\u0019|fDe{";
      i[100] = ":A\u001a-e\u0004;A\u000fw\u001d\u0006\u0003\fY/-Q\u0003<\u000eo$\t1]\u0003}rX";
      i[101] = "\u0006Q4mB4WWa\u001f佥厇厥佣伌佂校伙伻叽QqE=XF=pE(\u0002";
      i[102] = "\t\u000e\u000fj,kZG\u0012`\\収佪栮桪但桅佐佪叴桪\u001b7j\u000fUMd13TJ";
      i[103] = "zcv,]a+e#^栾栈栃佑低厝佺佌佇叏\u00137]!equg\u001cwc";
      i[104] = "sn.\u0011Sbta7M,X\u000eO\f8,:.p4\nI=!ih";
      i[105] = "\u0003J\u000f|6RP\u0003\u0012vF号栤厰伮佐桟佩叾桪厰\ryP]I\u000e1*Y\u0006\u0012";
      i[106] = "m\u0001L\u0001Pm<\u0007\u0019s佷栄収桷佴桪佷佀栔厭)ON#c\u000bR\u0017V%c";
   }

   private static void m(PoseStack poseStack, DynamicIsland.友何何何何树何何友友 info, float x, float y, float width, float height, 友树何友何友何树树树 fontManager) {
      Z();
      Color bgColor = info.树树何何何友何何何何 ? new Color(30, 120, 30, 100) : new Color(35, 35, 35, 80);
      ShaderUtils.o(poseStack, 100739365455537L, x, 49.0F, width, 20.0F, 6.0F, bgColor);
      if (info.树何何友友何树何友树 != null) {
         RenderUtils.S(poseStack, x + 5.0F, y + (height - 16.0F) / 2.0F, 16.0F, 13836444665765L, 16.0F, info.树何何友友何树何友树);
      }

      ShaderUtils.o(poseStack, 100739365455537L, x + 5.0F, y + (height - 16.0F) / 2.0F, 16.0F, 16.0F, 4.0F, new Color(60, 60, 60, 120));
      fontManager.H(10).h(poseStack, "?", x + 5.0F + 8.0F, y + height / 2.0F - 2.0F, Color.WHITE.getRGB());
      float nameX = x + 5.0F + 16.0F + 6.0F;
      float nameY = y + (height - fontManager.H(12).x()) / 2.0F;
      Color nameColor = info.树树何何何友何何何何 ? new Color(80, 255, 80) : Color.WHITE;
      String displayName = info.友树树树何何何友友友;
      String teamDisplay = !info.何树树树何友树树友何.isEmpty() ? "..." + info.何树树树何友树树友何 + "]" : "";
      String fullDisplay = displayName + teamDisplay;
      float maxNameWidth = width - (nameX - x) - 45.0F;
      float fullWidth = fontManager.H(12).D(fullDisplay);
      if (fullWidth > maxNameWidth && fullWidth > maxNameWidth && displayName.length() > 1) {
         displayName = displayName.substring(0, displayName.length() - 1);
         fullDisplay = displayName + "• " + teamDisplay;
         float var10000 = fontManager.H(12).D(fullDisplay);
      }

      fontManager.H(12).q(poseStack, displayName, nameX, nameY, nameColor.getRGB());
      float currentTextX = nameX + fontManager.H(12).D(displayName);
      if (!info.何树树树何友树树友何.isEmpty()) {
         fontManager.H(12).q(poseStack, " x" + info.何树树树何友树树友何 + "]", currentTextX, nameY, info.友友树树何友友树何何.getRGB());
      }

      String pingText = info.友何何友何友友树树何 + "空容器";
      Color pingColor = I(info.友何何友何友友树树何);
      float pingWidth = fontManager.H(11).D(pingText);
      fontManager.H(11).q(poseStack, pingText, x + width - 5.0F - pingWidth, nameY, pingColor.getRGB());
      float dotX = x + width - 5.0F - pingWidth - 4.0F - 5.0F;
      float dotY = y + height / 2.0F - 2.0F;
      ShaderUtils.B(poseStack, dotX + 2.0F, 38709770127847L, dotY + 2.0F, 2.0F, pingColor);
      if (info.树树何何何友何何何何) {
         float crownX = x + 5.0F + 16.0F - 5.0F;
         float crownY = y + (height - 16.0F) / 2.0F;
         fontManager.H(10).q(poseStack, "♔", crownX, crownY, new Color(255, 215, 0).getRGB());
      }
   }

   private static void m(PoseStack poseStack, float startX, float startY, 友树何友何友何树树树 fontManager) {
      Z();
      if (mc.player != null && mc.player.containerMenu != null) {
         AbstractContainerMenu menu = mc.player.containerMenu;
         float currentY = startY;
         int itemCount = 0;
         int i = 0;
         if (0 < Math.min(27, menu.slots.size())) {
            Slot slot = menu.getSlot(0);
            ItemStack stack = slot.getItem();
            if (!stack.isEmpty()) {
               String itemName = stack.getDisplayName().getString();
               if (itemName.length() > 12) {
                  itemName = itemName.substring(0, 12) + "...";
               }

               String itemText = "• " + itemName;
               if (stack.getCount() > 1) {
                  itemText = itemText + " x" + stack.getCount();
               }

               fontManager.H(12).q(poseStack, itemText, startX, startY, Color.WHITE.getRGB());
               currentY = startY + (fontManager.H(12).x() + 2.0F);
               itemCount++;
            }

            i++;
         }

         if (itemCount == 0) {
            fontManager.H(12).q(poseStack, ClientUtils.H(80470882894842L) ? "空容器" : "Empty", startX, currentY, new Color(160, 160, 160).getRGB());
         }
      }
   }

   private static float p() {
      Z();
      if (mc.player != null && mc.player.containerMenu != null) {
         AbstractContainerMenu menu = mc.player.containerMenu;
         int containerSize = 0;
         if (menu instanceof ChestMenu) {
            containerSize = menu.slots.size() > 63 ? 54 : 27;
         }

         if (menu instanceof FurnaceMenu) {
            containerSize = 3;
         }

         if (menu instanceof BrewingStandMenu) {
            containerSize = 5;
         }

         int itemsPerRow = menu instanceof ChestMenu ? 9 : 3;
         int totalRows = (int)Math.ceil((double)containerSize / itemsPerRow);
         return 90.0F + totalRows * 18.0F;
      } else {
         return 120.0F;
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static void v() {
      GL11.glDisable(3089);
   }

   private static Color q(String playerName) {
      Z();

      try {
         if (mc.level != null && mc.level.getScoreboard() != null) {
            PlayerTeam team = mc.level.getScoreboard().getPlayersTeam(playerName);
            if (team == null) {
               return Color.WHITE;
            } else {
               ChatFormatting color = team.getColor();
               return y(color);
            }
         } else {
            return Color.WHITE;
         }
      } catch (Exception var6) {
         return Color.WHITE;
      }
   }

   private static String z(String playerName) {
      Z();

      try {
         if (mc.level != null && mc.level.getScoreboard() != null) {
            PlayerTeam team = mc.level.getScoreboard().getPlayersTeam(playerName);
            if (team == null) {
               return "";
            } else {
               String teamName = team.getName();
               return teamName != null && !teamName.isEmpty() ? teamName.toUpperCase() : "";
            }
         } else {
            return "";
         }
      } catch (Exception var6) {
         return "";
      }
   }

   private static String z() {
      c<"Ü">(-747535560862517106L, 134630019102128L);
      String ircID = "";
      if (mc.player != null && Fucker.W(51167843857826L, WrapperUtils.f(111441258359257L))) {
         ircID = Fucker.x(10046672269524L, WrapperUtils.f(111441258359257L)).何树何树友何何何友友;
      }

      String fpsText = mc.getFps() + "FPS";
      String baseText = ircID + " | " + fpsText;
      if (HUD.instance != null) {
         return HUD.instance.isEnabled() && !c<"Å">(HUD.instance, -746201040944917588L, 134630019102128L).K("None") ? baseText : "Cherish | B3.7 |" + baseText;
      } else {
         return baseText;
      }
   }

   public static void z(int[] var0) {
      树何友何友树何友友友 = var0;
   }

   private static void u() {
      Z();
      何树友友树何友友树何.clear();
      何友何友何树何友友友.removeIf(contentx -> contentx.树树何何树树何友友友.A(contentx.友何树树何树何何友树, 118344821288830L));
      if (!何友何友何树何友友友.isEmpty()) {
         Iterator var3 = 何友何友何树何友友友.iterator();
         if (var3.hasNext()) {
            DynamicIsland.友友友何何树树树友树 content = (DynamicIsland.友友友何何树树树友树)var3.next();
            float titleHeight = Cherish.instance.t().C(16).x();
            float descHeight = Cherish.instance.t().H(14).x();
            float titleWidth = Cherish.instance.t().C(16).D(content.友树友何何树何友树友);
            float descWidth = Cherish.instance.t().H(14).D(content.友树何何何何何树树何);
            float maxTextWidth = Math.max(titleWidth, descWidth);
            float totalWidth = Math.max(120.0F, maxTextWidth + 24.0F + 24.0F);
            float totalHeight = titleHeight + descHeight + 3.0F + 16.0F;
            何树友友树何友友树何.add(new DynamicIsland.树何何何何何树友树友(poseStack -> {
               I(poseStack, content, padding, padding, iconSize);
               友树何友何友何树树树 fontManager = Cherish.instance.t();
               float textX = padding + iconSize + 8.0F;
               fontManager.C(16).q(poseStack, content.友树友何何树何友树友, textX, padding, Color.WHITE.getRGB());
               float textY = padding + (titleHeight + lineSpacing);
               fontManager.H(14).q(poseStack, content.友树何何何何何树树何, textX, textY, Color.WHITE.getRGB());
            }, (int)totalWidth, (int)totalHeight, 0));
         }
      }
   }

   private static Color y(ChatFormatting formatting) {
      return Color.WHITE;
   }

   private static float A(LivingEntity target, 友树何友何友何树树树 fontManager) {
      String targetName = target.getName().getString();
      String healthStr = String.valueOf(Math.round((target.getHealth() + target.getAbsorptionAmount()) * 10.0F) / 10.0F);
      String maxHealthStr = String.valueOf(Math.round(target.getMaxHealth() * 10.0F) / 10.0F);
      String healthText = (ClientUtils.H(80470882894842L) ? "生命值: " : "Health: ") + healthStr + " /" + maxHealthStr;
      float nameWidth = fontManager.C(18).D(targetName);
      float healthWidth = fontManager.H(16).D(healthText);
      float totalTextWidth = nameWidth + 10.0F + healthWidth;
      return Math.max(250.0F, totalTextWidth + 32.0F + 12.0F + 32.0F);
   }

   private static void L() {
      Z();
      if (树友树树何何友何何友.友何何友友友树何树何 != null && 树友树树何何友何何友.友何何友友友树何树何.N()) {
         try {
            Field notificationsField = 树友何何何树友树何友.class.getDeclaredField("友友何树何树树友树友");
            notificationsField.setAccessible(true);
            CopyOnWriteArrayList<树友何何何树友树何友> notifications = (CopyOnWriteArrayList<树友何何何树友树何友>)notificationsField.get(null);
            if (notifications.size() > 何树友树何树何何树友) {
               int i = 何树友树何树何何树友;
               if (i < notifications.size()) {
                  树友何何何树友树何友 notification = notifications.get(i);
                  String title = C(notification);
                  String description = K(notification);
                  if (description != null) {
                     String notificationId = title + ":" + description + ":" + System.currentTimeMillis();
                     if (!树何何何树友何树树友.contains(notificationId)
                        && (
                           title.contains("模块")
                              || title.contains("开启")
                              || title.contains("关闭")
                              || title.toLowerCase().contains("module")
                              || title.toLowerCase().contains("enabled")
                              || title.toLowerCase().contains("disabled")
                        )) {
                        String notificationTitle = ClientUtils.H(80470882894842L) ? "模块切换" : "Module Toggle";
                        e(DynamicIsland.友何树友树友友树何友.树树友友友友友友友何, notificationTitle, description, 树友树树何何友何何友.友何何友友友树何树何.P());
                        树何何何树友何树树友.add(notificationId);
                        if (树何何何树友何树树友.size() > 50) {
                           树何何何树友何树树友.subList(0, 25).clear();
                        }
                     }
                  }

                  i++;
               }
            }

            何树友树何树何何树友 = notifications.size();
         } catch (Exception var13) {
            var13.printStackTrace();
         }
      }
   }

   private static void M() {
      c<"Ü">(-2056983404404527526L, 108105337660260L);
      if (c<"í">(-2059458292553364762L, 108105337660260L).u(b<"v">(26932, 4803888397557814085L), true, 77209916186210L)) {
         if (c<"í">(-2060237003532609277L, 108105337660260L) != null && c<"í">(-2060237003532609277L, 108105337660260L).isEnabled()) {
            if (mc.player != null) {
               long currentTime = System.currentTimeMillis();
               Vec3 currentPosition = mc.player.position();
               if (c<"í">(-2054453185596703682L, 108105337660260L) == null) {
                  c<"ª">(currentPosition, -2054453185596703682L, 108105337660260L);
                  c<"ª">(currentTime, -2057828224747942793L, 108105337660260L);
               }

               double timeDiff = (currentTime - c<"í">(-2057828224747942793L, 108105337660260L)) / 1000.0;
               if (timeDiff > 0.0) {
                  double distance = Math.sqrt(
                     Math.pow(
                           c<"Å">(currentPosition, -2054491395688265939L, 108105337660260L)
                              - c<"Å">(c<"í">(-2054453185596703682L, 108105337660260L), -2054491395688265939L, 108105337660260L),
                           2.0
                        )
                        + Math.pow(
                           c<"Å">(currentPosition, -2054399418103641479L, 108105337660260L)
                              - c<"Å">(c<"í">(-2054453185596703682L, 108105337660260L), -2054399418103641479L, 108105337660260L),
                           2.0
                        )
                  );
                  if (distance <= 100.0) {
                     c<"ª">(distance / timeDiff, -2059511626513069790L, 108105337660260L);
                  }

                  c<"ª">(currentPosition, -2054453185596703682L, 108105337660260L);
                  c<"ª">(currentTime, -2057828224747942793L, 108105337660260L);
               }
            }

            c<"í">(-2058348521485232829L, 108105337660260L)
               .g(Math.min((float)c<"í">(-2059511626513069790L, 108105337660260L) / 10.0F, 1.0F), 36433523484945L, 35);
         } else {
            c<"ª">(null, -2054453185596703682L, 108105337660260L);
            c<"ª">(0.0, -2059511626513069790L, 108105337660260L);
            c<"í">(-2058348521485232829L, 108105337660260L).g(0.0F, 36433523484945L, 10);
         }
      }
   }

   private static float M(List<DynamicIsland.树何何何何何树友树友> contents) {
      Z();
      float maxWidth = 0.0F;
      Iterator var5 = contents.iterator();
      if (var5.hasNext()) {
         DynamicIsland.树何何何何何树友树友 content = (DynamicIsland.树何何何何何树友树友)var5.next();
         if (0.0F < content.友树友何何友何树何树) {
            maxWidth = content.友树友何何友何树何树;
         }
      }

      return maxWidth;
   }

   private static void H(PoseStack poseStack, LivingEntity target, float x, float y) {
      Z();
      if (树友何何友树何树何树.u(16L, true, 77209916186210L)) {
         友友友何何何树树友友.removeIf(p -> {
            Z();
            p.r();
            return p.友树友何何何何何友树 <= 0.0F;
         });
      }

      Iterator particleColor = 友友友何何何树树友友.iterator();
      if (particleColor.hasNext()) {
         DynamicIsland.友树友树友树何友友树 p = (DynamicIsland.友树友树友树何友友树)particleColor.next();
         ShaderUtils.B(poseStack, x + p.树友友何友树树友树友, 38709770127847L, y + p.何友友何友友树树何何, p.友友树友树树友树何友, p.d());
      }

      if (target.hurtTime == 10 && !何何树树友何友树树树) {
         if (mc.player == null) {
            return;
         }

         Color particleColorx = Color.WHITE;
         RandomSource r = mc.player.getRandom();
         int i = 0;
         友友友何何何树树友友.add(
            new DynamicIsland.友树友树友树何友友树(
               26.0F, 26.0F, (r.nextFloat() - 0.5F) * 2.8F, (r.nextFloat() - 0.5F) * 2.8F, r.nextFloat() * 3.0F + 1.0F, particleColorx
            )
         );
         i++;
         何何树树友何友树树树 = true;
      }

      if (target.hurtTime <= 0) {
         何何树树友何友树树树 = false;
      }
   }

   private static void T() {
      Z();
      if (树何何友何树树树友友.u(500L, true, 77209916186210L)) {
         何何树何友友友树友何.clear();
         if (mc.getConnection() != null) {
            Iterator var7 = mc.getConnection().getOnlinePlayers().iterator();
            if (var7.hasNext()) {
               PlayerInfo playerInfo = (PlayerInfo)var7.next();
               String playerName = playerInfo.getProfile().getName();
               int ping = playerInfo.getLatency();
               boolean isLocal = playerName.equals(WrapperUtils.f(111441258359257L));
               AbstractClientPlayer player = null;
               if (mc.level != null) {
                  for (AbstractClientPlayer p : mc.level.players()) {
                     if (p.getName().getString().equals(playerName)) {
                        player = p;
                        break;
                     }
                  }
               }

               Color teamColor = q(playerName);
               String teamName = z(playerName);
               何何树何友友友树友何.add(new DynamicIsland.友何何何何树何何友友(playerName, ping, isLocal, player, teamColor, teamName));
            }

            何何树何友友友树友何.sort((a, b) -> {
               Z();
               return !a.何树树树何友树树友何.equals(b.何树树树何友树树友何) ? a.何树树树何友树树友何.compareTo(b.何树树树何友树树友何) : Integer.compare(a.友何何友何友友树树何, b.友何何友何友友树树何);
            });
         }
      }
   }

   private static String K(树友何何何树友树何友 n) {
      try {
         Field f = 树友何何何树友树何友.class.getDeclaredField("Scaffold");
         f.setAccessible(true);
         return (String)f.get(n);
      } catch (Exception var4) {
         return null;
      }
   }

   private static void K(PoseStack poseStack, float x, float y, 友树何友何友何树树树 fontManager) {
      Z();
      if (树友何何友何树何树友.树友友树友友友友树何 != null) {
         fontManager.C(16).q(poseStack, "Scaffold", x + 10.0F, 25.0F, Color.WHITE.getRGB());
         int blockSlot = 树友何何友何树何树友.树友友树友友友友树何.s();
         if (blockSlot != -1) {
            ItemStack blockItem = mc.player.getInventory().getItem(blockSlot);
            if (!blockItem.isEmpty() && blockItem.getItem() instanceof BlockItem) {
               String blockName = blockItem.getDisplayName().getString();
               if (blockName.length() > 8) {
                  blockName = blockName.substring(0, 8) + "...";
               }

               float blockTextWidth = fontManager.H(12).D(blockName);
               fontManager.H(12).q(poseStack, blockName, x + 友友何友友何友友树树 - 10.0F - blockTextWidth, 27.0F, Color.WHITE.getRGB());
            }
         }

         float currentY = 25.0F + (fontManager.C(16).x() + 6.0F);
         String blockText = (ClientUtils.H(80470882894842L) ? "方块: " : "Blocks: ") + 树友何何友何树何树友.树友友树友友友友树何.u();
         fontManager.H(14).q(poseStack, blockText, x + 10.0F, currentY, Color.WHITE.getRGB());
         String speedText = (ClientUtils.H(80470882894842L) ? "速度: " : "Speed: ") + String.format("%.2f", 友树友友何友何何何友) + " b/s";
         float speedTextWidth = fontManager.H(14).D(speedText);
         fontManager.H(14).q(poseStack, speedText, x + 友友何友友何友友树树 - 10.0F - speedTextWidth, currentY, Color.WHITE.getRGB());
         currentY += fontManager.H(14).x() + 6.0F;
         float barWidth = 友友何友友何友友树树 - 20.0F;
         float barX = x + 10.0F;
         ShaderUtils.o(poseStack, 100739365455537L, barX, currentY, barWidth, 4.0F, 2.0F, new Color(40, 40, 40, 150));
         float progress = 何友树友何树何友何何.S(69444441903267L);
         if (progress > 0.01F) {
            ShaderUtils.o(poseStack, 100739365455537L, barX, currentY, barWidth * progress, 4.0F, 2.0F, Color.WHITE);
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "解放村多种2队1144号";
   }

   private static void O() {
      Z();
      boolean currentChestState = h();
      boolean shouldShowChestGUI = 树友树树何何友何何友.友何何友友友树何树何.d() && 友友树树何何友树何友.树友树友友何树何树何 != null && 友友树树何何友树何友.树友树友友何树何树何.isEnabled() && currentChestState;
      if (currentChestState != 何何友何树树树友友树) {
         树树友树树友树树树何.D(11747522392279L);
         何何友何树树树友友树 = currentChestState;
      }

      if (shouldShowChestGUI) {
         if (mc.screen instanceof ContainerScreen) {
            mc.setScreen(null);
         }

         if (树友树树友树何友友何 != null && mc.screen == 树友树树友树何友友何) {
            return;
         }

         树友树树友树何友友何 = new DynamicIsland.树树友树友树何何何友();
         mc.setScreen(树友树树友树何友友何);
      }

      if (树友树树友树何友友何 != null && 树树友树树友树树树何.u(500L, false, 77209916186210L)) {
         if (mc.screen == 树友树树友树何友友何) {
            mc.setScreen(null);
         }

         树友树树友树何友友何 = null;
      }
   }

   public static boolean shouldBlockTabRender() {
      Z();
      return B() && s();
   }

   private record 友何何何何树何何友友(String 友树树树何何何友友友, int 友何何友何友友树树何, boolean 树树何何何友何何何何, AbstractClientPlayer 树何何友友何树何友树, Color 友友树树何友友树何何, String 何树树树何友树树友何)
      implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[13];
      private static final String[] c = new String[13];
      private static String HE_DA_WEI;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(1677315517625134896L, 4242326603026356436L, MethodHandles.lookup().lookupClass()).a(267569979758211L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public String b() {
         return this.何树树树何友树树友何;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      public Color x() {
         return this.友友树树何友友树何何;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 217 && var8 != 'N' && var8 != 'H' && var8 != 'i') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'W') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'z') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 217) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'N') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'H') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland$友何何何何树何何友友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 7;
                  case 1 -> 35;
                  case 2 -> 50;
                  case 3 -> 38;
                  case 4 -> 18;
                  case 5 -> 6;
                  case 6 -> 2;
                  case 7 -> 52;
                  case 8 -> 23;
                  case 9 -> 36;
                  case 10 -> 32;
                  case 11 -> 57;
                  case 12 -> 17;
                  case 13 -> 60;
                  case 14 -> 41;
                  case 15 -> 0;
                  case 16 -> 8;
                  case 17 -> 25;
                  case 18 -> 27;
                  case 19 -> 30;
                  case 20 -> 9;
                  case 21 -> 39;
                  case 22 -> 53;
                  case 23 -> 49;
                  case 24 -> 63;
                  case 25 -> 12;
                  case 26 -> 48;
                  case 27 -> 54;
                  case 28 -> 42;
                  case 29 -> 45;
                  case 30 -> 21;
                  case 31 -> 31;
                  case 32 -> 29;
                  case 33 -> 58;
                  case 34 -> 56;
                  case 35 -> 15;
                  case 36 -> 40;
                  case 37 -> 55;
                  case 38 -> 10;
                  case 39 -> 20;
                  case 40 -> 3;
                  case 41 -> 47;
                  case 42 -> 43;
                  case 43 -> 59;
                  case 44 -> 1;
                  case 45 -> 24;
                  case 46 -> 51;
                  case 47 -> 14;
                  case 48 -> 37;
                  case 49 -> 5;
                  case 50 -> 33;
                  case 51 -> 4;
                  case 52 -> 46;
                  case 53 -> 61;
                  case 54 -> 44;
                  case 55 -> 26;
                  case 56 -> 22;
                  case 57 -> 13;
                  case 58 -> 16;
                  case 59 -> 19;
                  case 60 -> 28;
                  case 61 -> 34;
                  case 62 -> 62;
                  default -> 11;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "?\rl\u007f~\b0M!tt\u00155\u0010*2d\u000er\u0007;rp\n5\u0000+o}\u00062\u0007lXh\t=\u000e+\u007fX\u00140\u0002,x5厬伉伶众佉栀伲伉厨厉";
         b[1] = "\fB_J0+\fBH\u0016<$\u0016\tH\b4'\fS\u0005\u00141#\u001bBYJ\u001c \u0011SY\u0005>6!KB\u0001362KJ\u001d80";
         b[2] = int.class;
         c[2] = "java/lang/Integer";
         b[3] = "}j6-5Vve'bHNeb.+";
         b[4] = boolean.class;
         c[4] = "java/lang/Boolean";
         b[5] = "\u0007I\u0002bf<\u001a\\Z@'1\u0002Z";
         b[6] = "\t(\u001e.0\u0019\u0002'\u000faQ\u0017\t,\u000b;";
         b[7] = "\u0014\f9QKW[Ve2厴右栲桱佘叱厴栩佶伵\u0005\t\u0010]\u001aYd\u000eG\u0001Z";
         b[8] = "&z_u\"@i \u0003\u0016叝佺佄叝伾叕叝栾栀佃c/y\u001c!g\u000fxdL`";
         b[9] = ".\u0004 Z\u0013#a^|9召桝栈桹佁佤佲厇叒厣\u001c\u0003\u0013=}\n GN\"c";
         b[10] = "1aM\u001aep~;\u0011y伄栎栗栜伬厺桀栎反佘qCenboM\u00078q|";
         b[11] = "\r/]t\u00109Bu\u0001\u0017栵伃佯厈厢佊栵伃叱桒a.\u001d3\\7\u0001(P2X";
         b[12] = "-\u001c>\u0001?^bFbb栚栠住伥佟厡佞佤住伥\u0002XqUv\u0018a\u0007s\\b";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public boolean E() {
         return this.树树何何何友何何何何;
      }

      public AbstractClientPlayer M() {
         return this.树何何友友何树何友树;
      }

      public int P() {
         return this.友何何友何友友树树何;
      }

      public String H() {
         return this.友树树树何何何友友友;
      }

      private static String HE_WEI_LIN() {
         return "何树友为什么濒天了";
      }
   }

   public static enum 友何树友树友友树何友 implements  {
      树树友友友友友友友何,
      友树何友友友何何友何,
      树何何何树何树友树友,
      树树何何友何树树树友;

      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // $VF: Failed to inline enum fields
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-6629570621395231835L, 4724987134194970308L, MethodHandles.lookup().lookupClass()).a(256134805646133L);
         // $VF: monitorexit
         a = var10000;
         a();
         Cipher var1;
         Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var2 = 1; var2 < 8; var2++) {
            var10003[var2] = (byte)(19436596632556L << var2 * 8 >>> 56);
         }

         var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String[] var0 = new String[4];
         int var6 = 0;
         String var5 = "ì\u0084®Òãß\u0007¤\bQ\u007f^TÍQåÃ";
         byte var7 = 17;
         char var4 = '\b';
         int var9 = -1;

         label28:
         while (true) {
            String var11 = var5.substring(++var9, var9 + var4);
            byte var10001 = -1;

            while (true) {
               String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
               switch (var10001) {
                  case 0:
                     var0[var6++] = var17;
                     if ((var9 += var4) >= var7) {
                        树树友友友友友友友何 = new DynamicIsland.友何树友树友友树何友();
                        友树何友友友何何友何 = new DynamicIsland.友何树友树友友树何友();
                        树何何何树何树友树友 = new DynamicIsland.友何树友树友友树何友();
                        树树何何友何树树树友 = new DynamicIsland.友何树友树友友树何友();
                        return;
                     }

                     var4 = var5.charAt(var9);
                     break;
                  default:
                     var0[var6++] = var17;
                     if ((var9 += var4) < var7) {
                        var4 = var5.charAt(var9);
                        continue label28;
                     }

                     var5 = "RÚgr\u0085y°Ø\b¬/]¶85¾ë";
                     var7 = 17;
                     var4 = '\b';
                     var9 = -1;
               }

               var11 = var5.substring(++var9, var9 + var4);
               var10001 = 0;
            }
         }
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public static DynamicIsland.友何树友树友友树何友 c(String name) {
         return Enum.valueOf(DynamicIsland.友何树友树友友树何友.class, name);
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'C' && var8 != 186 && var8 != 224 && var8 != 'v') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 251) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 216) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'C') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 186) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 224) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 46;
                  case 1 -> 41;
                  case 2 -> 29;
                  case 3 -> 18;
                  case 4 -> 19;
                  case 5 -> 48;
                  case 6 -> 53;
                  case 7 -> 59;
                  case 8 -> 14;
                  case 9 -> 26;
                  case 10 -> 58;
                  case 11 -> 34;
                  case 12 -> 9;
                  case 13 -> 28;
                  case 14 -> 2;
                  case 15 -> 17;
                  case 16 -> 47;
                  case 17 -> 40;
                  case 18 -> 8;
                  case 19 -> 51;
                  case 20 -> 27;
                  case 21 -> 36;
                  case 22 -> 16;
                  case 23 -> 15;
                  case 24 -> 39;
                  case 25 -> 35;
                  case 26 -> 32;
                  case 27 -> 5;
                  case 28 -> 21;
                  case 29 -> 20;
                  case 30 -> 31;
                  case 31 -> 55;
                  case 32 -> 60;
                  case 33 -> 6;
                  case 34 -> 1;
                  case 35 -> 11;
                  case 36 -> 25;
                  case 37 -> 43;
                  case 38 -> 22;
                  case 39 -> 33;
                  case 40 -> 30;
                  case 41 -> 54;
                  case 42 -> 56;
                  case 43 -> 45;
                  case 44 -> 7;
                  case 45 -> 61;
                  case 46 -> 44;
                  case 47 -> 13;
                  case 48 -> 0;
                  case 49 -> 37;
                  case 50 -> 49;
                  case 51 -> 52;
                  case 52 -> 62;
                  case 53 -> 23;
                  case 54 -> 3;
                  case 55 -> 10;
                  case 56 -> 57;
                  case 57 -> 38;
                  case 58 -> 50;
                  case 59 -> 4;
                  case 60 -> 42;
                  case 61 -> 12;
                  case 62 -> 24;
                  default -> 63;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "<C\u00190s\f3\u0003T;y\u00116^_}i\nqIN=}\u000e6N^ p\u00021I\u0019\u0017e\r>@^0U\u00103LY78厨伊格叼桂受厨桎佸叼";
         b[1] = "\u007fNgc\u00003Kmh#M8Apm~F~Qk*iW>EomnG#Hcji\u0000\u0014]le`G3mqhl@4\u0000叉佑栜句桁可叉栕佘句k";
         b[2] = "]f\u0006:\u0011[Vi\u0017upU]b\u0013/";
         b[3] = "\u0017\u0007lGf\r\u0003\u0012~=栂桶伤伥反你栂桶桠去\u000eSd\r\u0003\u0005lGq\u001f";
         b[4] = "\u0003+\u0005V1\u0000\u0017>\u0017,厏伿桴伉伺栵桕桻厮伉g\\)\u000b\u00065\u0004\u0016v\t";
         b[5] = "KT;383_A)I历案佸叨厚厊优伌另佶Y':3_V;3/!";
         b[6] = "~[Hnx\u0005jNZ\u0014栜桾叓叧叩受叆厤叓佹*zz\u0005jYHno\u0017";
         b[7] = "\u0001:92X\u0003\u0015/+H格似伲优桂伕格厢桶历[&Z\u0003\u0015892O\u0011";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland$友何树友树友友树何友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      public static DynamicIsland.友何树友树友友树何友[] R() {
         return (DynamicIsland.友何树友树友友树何友[])友何树何何树树树友何.clone();
      }

      private static String HE_WEI_LIN() {
         return "何炜霖大狗叫";
      }
   }

   private static class 友友友何何树树树友树 implements 何树友 {
      private final DynamicIsland.友何树友树友友树何友 何何友何树树树友树友;
      private final String 友树友何何树何友树友;
      private final String 友树何何何何何树树何;
      private final 何友友友树何何友树何 友友树树何树树树树何;
      private final 何友友何树何树何树友 树树何何树树何友友友;
      private final long 友何树树何树何何友树;
      private static final long a;
      private static final Object[] b = new Object[17];
      private static final String[] c = new String[17];
      private static String HE_WEI_LIN;

      友友友何何树树树友树(DynamicIsland.友何树友树友友树何友 type, String title, String description, long time) {
         this.何何友何树树树友树友 = type;
         this.友树友何何树何友树友 = title;
         this.友树何何何何何树树何 = description;
         DynamicIsland.Z();
         this.友友树树何树树树树何 = new 何友友友树何何友树何(800, 47697109727437L, 1.0);
         this.友友树树何树树树树何.n(new Object[]{友何树友树何何友树树.树树何树何树何何友友, 59020024422499L});
         this.树树何何树树何友友友 = new 何友友何树何树何树友(51913986529303L);
         this.友何树树何树何何友树 = time;
         if (Module.Z() == null) {
            DynamicIsland.z(new int[4]);
         }
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(8054003235064337153L, 164544811185655980L, MethodHandles.lookup().lookupClass()).a(73467562266707L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'B' && var8 != 'C' && var8 != 'e' && var8 != 'O') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 163) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 219) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'B') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'C') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'e') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland$友友友何何树树树友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static void a() {
         b[0] = "5@$~Rl:\u0000iuXq?]b3HjxJss\\n?McnQb8J$YDm7Cc~tp:Ody\u0019又厝句佟佈栬栒桇句栛";
         b[1] = "I?(\ny7B09E\u0005.M*7\u00062\u001e[=;\u001b#2L0";
         b[2] = ",\u0001  \\k#Am+Vv&\u001cfmFma\u000bw-Ri&\fg0_e!\u000b \u0007Jj.\u0002g zw#\u000e`'";
         b[3] = "\u001f%";
         b[4] = "wD\u0016^.#x\u0004[U$>}YP\u0013,#p_TXo\u0001{NMQ$";
         b[5] = ")TI\u0012#\u000f\u001dwFRn\u0004\u0017jC\u000feB\u001fwN\ta\t\\UE\u0018x\u0000\u0017#";
         b[6] = "4JH}\u000b\u0019;\n\u0005v\u0001\u0004>W\u000e0\u0011\u0002>H\u00150\u0005\u0018>I\u0007j\r\u00199WH佋厯厽厜栵伳佋厯桧伂";
         b[7] = ">7@.p\u00141w\r%z\t4*\u0006cj\u000f45\u001dc~\u001544\u000f9v\u00143*@历佊桪厖案伻优叔桪桌";
         b[8] = "\\N";
         b[9] = void.class;
         c[9] = "java/lang/Void";
         b[10] = "-)~P\tY&&o\u001fhW--kE";
         b[11] = "S\u001e\u0001X\u0019\u000b\u0017Y\u001f\u0010|)h\u001d_\nEF\u000fX_P\u0019{";
         b[12] = "IiwUJ+B9y8D@\t%!V\u0017)J3s8V2N9'Q\u0015$\u001cW";
         b[13] = "u \u0004z>b~p\n\u0017厚及桗标伳栎桀栐桗佃n+#p(\u007fR|4ju";
         b[14] = "\u0012$\u0002\t\u001e!Jw\b\u0003s桚栶佁桺伿桪伞佲叟厠bN{Nw\u000e\u0000\u0016(D}";
         b[15] = "h\bE\u0007+G=L\u0018\u000bWgQO_\t/E`N\u001cVk5";
         b[16] = "\u0002u\u0005\rK\u0001W1X\u00017\u0001;2\u001f\u0003O\u0003\n3\\\\\u000bs\u0005o\u0000\u0019JH_q\u0012\u00037";
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 17;
                  case 1 -> 1;
                  case 2 -> 46;
                  case 3 -> 4;
                  case 4 -> 19;
                  case 5 -> 53;
                  case 6 -> 41;
                  case 7 -> 2;
                  case 8 -> 50;
                  case 9 -> 10;
                  case 10 -> 5;
                  case 11 -> 22;
                  case 12 -> 51;
                  case 13 -> 8;
                  case 14 -> 35;
                  case 15 -> 15;
                  case 16 -> 16;
                  case 17 -> 23;
                  case 18 -> 40;
                  case 19 -> 28;
                  case 20 -> 0;
                  case 21 -> 13;
                  case 22 -> 42;
                  case 23 -> 25;
                  case 24 -> 11;
                  case 25 -> 47;
                  case 26 -> 43;
                  case 27 -> 34;
                  case 28 -> 49;
                  case 29 -> 58;
                  case 30 -> 9;
                  case 31 -> 39;
                  case 32 -> 57;
                  case 33 -> 63;
                  case 34 -> 29;
                  case 35 -> 14;
                  case 36 -> 56;
                  case 37 -> 24;
                  case 38 -> 18;
                  case 39 -> 37;
                  case 40 -> 27;
                  case 41 -> 44;
                  case 42 -> 62;
                  case 43 -> 60;
                  case 44 -> 45;
                  case 45 -> 38;
                  case 46 -> 61;
                  case 47 -> 54;
                  case 48 -> 52;
                  case 49 -> 48;
                  case 50 -> 26;
                  case 51 -> 7;
                  case 52 -> 33;
                  case 53 -> 36;
                  case 54 -> 59;
                  case 55 -> 30;
                  case 56 -> 20;
                  case 57 -> 3;
                  case 58 -> 32;
                  case 59 -> 55;
                  case 60 -> 6;
                  case 61 -> 31;
                  case 62 -> 12;
                  default -> 21;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static String LIU_YA_FENG() {
         return "何建国230622195906030014";
      }
   }

   private static class 友树友树友树何友友树 implements 何树友 {
      float 树友友何友树树友树友 = 26.0F;
      float 何友友何友友树树何何 = 26.0F;
      float 何何何树何树何树何树;
      float 友树树树何树树何友树;
      float 友友树友树树友树何友;
      float 友树友何何何何何友树;
      final Color 友友友何树何树树树何;
      private static final long a;
      private static final Object[] b = new Object[22];
      private static final String[] c = new String[22];
      private static int _何炜霖黑水 _;

      public 友树友树友树何友友树(float x, float y, float dX, float dY, float size, Color color) {
         this.何何何树何树何树何树 = dX;
         this.友树树树何树树何友树 = dY;
         this.友友树友树树友树何友 = size;
         this.友友友何树何树树树何 = color;
         this.友树友何何何何何友树 = 255.0F;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-8690107029107668504L, -2598220206130150549L, MethodHandles.lookup().lookupClass()).a(141167881760598L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public Color d() {
         return new Color(this.友友友何树何树树树何.getRed(), this.友友友何树何树树树何.getGreen(), this.友友友何树何树树树何.getBlue(), (int)this.友树友何何何何何友树);
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/dynamicisland/DynamicIsland$友树友树友树何友友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'Z' && var8 != 'N' && var8 != 'n' && var8 != 193) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 234) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 233) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'Z') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'N') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'n') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 61;
                  case 1 -> 38;
                  case 2 -> 1;
                  case 3 -> 7;
                  case 4 -> 9;
                  case 5 -> 17;
                  case 6 -> 56;
                  case 7 -> 62;
                  case 8 -> 19;
                  case 9 -> 34;
                  case 10 -> 25;
                  case 11 -> 6;
                  case 12 -> 42;
                  case 13 -> 63;
                  case 14 -> 33;
                  case 15 -> 35;
                  case 16 -> 49;
                  case 17 -> 31;
                  case 18 -> 22;
                  case 19 -> 44;
                  case 20 -> 24;
                  case 21 -> 12;
                  case 22 -> 16;
                  case 23 -> 11;
                  case 24 -> 26;
                  case 25 -> 13;
                  case 26 -> 18;
                  case 27 -> 36;
                  case 28 -> 30;
                  case 29 -> 20;
                  case 30 -> 32;
                  case 31 -> 53;
                  case 32 -> 41;
                  case 33 -> 2;
                  case 34 -> 27;
                  case 35 -> 51;
                  case 36 -> 29;
                  case 37 -> 14;
                  case 38 -> 59;
                  case 39 -> 10;
                  case 40 -> 40;
                  case 41 -> 37;
                  case 42 -> 46;
                  case 43 -> 3;
                  case 44 -> 50;
                  case 45 -> 23;
                  case 46 -> 52;
                  case 47 -> 45;
                  case 48 -> 15;
                  case 49 -> 43;
                  case 50 -> 21;
                  case 51 -> 47;
                  case 52 -> 8;
                  case 53 -> 4;
                  case 54 -> 54;
                  case 55 -> 28;
                  case 56 -> 55;
                  case 57 -> 0;
                  case 58 -> 39;
                  case 59 -> 60;
                  case 60 -> 48;
                  case 61 -> 5;
                  case 62 -> 58;
                  default -> 57;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "\u0016\u000372\u00029\u0019Cz9\b$\u001c\u001eq\u007f\u0018?[\t`?\f;\u001c\u000ep\"\u00017\u001b\t7\u0015\u00148\u0014\u0000p2$%\u0019\fw5I厝桤厦栈厚桼伃厾厦栈";
         b[1] = ">}[Z~k#h\u0003x?f;n";
         b[2] = float.class;
         c[2] = "java/lang/Float";
         b[3] = "o\bb\u0018\n\u0015`H/\u0013\u0000\be\u0015$U\u0010\u0013\"\u00025\u0015\u0004\u0017e\u0005%\b\t\u001bb\u0002b?\u001c\u0014m\u000b%\u0018,\t`\u0007\"\u001f";
         b[4] = "3\u0016";
         b[5] = "M\f[\u0018\u000f\u0001F\u0003JWs\u0018I\u0019D\u0014D(_\u000eH\tU\u0004H\u0003";
         b[6] = "Bxm6k5M8 =a(He+{i5Ec/0*\u0017Nr69a";
         b[7] = "P[\"  Zdx-`mQne(=f\u0017fx%;b\\%Z.*{Un,";
         b[8] = "\u0002`+tJ\u00026C$4\u0007\t<^!i\fO4C,o\b\u0004wa'~\u0011\r<\u0017";
         b[9] = void.class;
         c[9] = "java/lang/Void";
         b[10] = "V >F\nL]//\tkBV$+S";
         b[11] = "<SCEuokB\u001d&厍桊収佱佺佻伓伎収栵'\u001cw8qGJ\u0016*0`";
         b[12] = "QI0G\u0016\u0016\u0006Xn$佰佷伽栯伉栽佰栳伽栯T\u001e\u0014A\u001c]9\u0014II\r";
         b[13] = "\u0005i.mW=Rxp\u000e桵参号佋厉栗桵参栭叕J4UjH}'>\bbY";
         b[14] = "&`\u001aY@\u000ed,\u0006[&.\u001a`E\u0005\u0017\u0016\u007f8\u0001\bM|";
         b[15] = "}\u0005-J<\u001d*\u0014s)叄叢桕厹桐栰叄核休厹I\u0013>J0\u0011$\u0019cB!";
         b[16] = "e`\u000f\u001f]y2qQ|伻历厗佂厨县桿桜伉佂kF_.(t\u0006L\u0002&9";
         b[17] = "\u0000<W\u0011,}BpK\u0013JQ<<\bM{eYdL@!\u000f\u0002f_\tw5B<N\u0013J";
         b[18] = "{8\u0012\f>\u0006,)Lo叆栣桓桞伫桶栜佧厉桞vU<Q6,\u001b_aY'";
         b[19] = "\u0011z|/\u0017VR>sxiv+~lwTTZ6}k\u001b$";
         b[20] = "$\u000e1-4bs\u001foN双厝取伬桌伓栖桇栌伬Uw6fp\u001c5?jc,";
         b[21] = "p|8\u001c\f('mf\u007f^\u0014zc'\u001dR.8~,\u00067/!x>\u001a\rm<s%\u007f";
      }

      public void r() {
         this.树友友何友树树友树友 = this.树友友何友树树友树友 + this.何何何树何树何树何树;
         DynamicIsland.Z();
         this.何友友何友友树树何何 = this.何友友何友友树树何何 + this.友树树树何树树何友树;
         this.何何何树何树何树何树 *= 0.97F;
         this.友树树树何树树何友树 *= 0.97F;
         this.友树友何何何何何友树 -= 4.0F;
         if (this.友树友何何何何何友树 < 0.0F) {
            this.友树友何何何何何友树 = 0.0F;
         }

         Module.V(new Module[1]);
      }

      private static String HE_WEI_LIN() {
         return "何树友，和树做朋友";
      }
   }

   public static class 树何何何何何树友树友 implements 何树友 {
      private final Consumer<PoseStack> 友友树树何友何树何友;
      private final int 友树友何何友何树何树;
      private final int 何树树树树何何何友树;
      private final int 友友树友树树友树何友;
      private static int _何炜霖黑水 _;

      private 树何何何何何树友树友(Consumer<PoseStack> content, int width, int height, int weight) {
         this.友友树树何友何树何友 = content;
         this.友树友何何友何树何树 = width;
         this.何树树树树何何何友树 = height;
         this.友友树友树树友树何友 = 0;
      }

      private static String HE_SHU_YOU() {
         return "何大伟230622198107200054";
      }
   }

   public static class 树友友何友友树树何友 implements 何树友 {
      public static final int 友何友何树何何友友何 = 0;
      public static final int 树友何何友何何友树何 = 1;
      public static final int 友树友树何友何友友友;
      public static final int 何友何何树何何何何何;
      private static int _行走的50万——何炜霖 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-7776588321302461862L, -3340732813809406773L, MethodHandles.lookup().lookupClass()).a(162000716414360L);
         // $VF: monitorexit
         long var1 = var10000 ^ 127174056037390L;
         Cipher var3;
         Cipher var13 = var3 = Cipher.getInstance("DES/CBC/NoPadding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{(byte)(var1 >>> 56), 0, 0, 0, 0, 0, 0, 0};

         for (int var4 = 1; var4 < 8; var4++) {
            var10003[var4] = (byte)(var1 << var4 * 8 >>> 56);
         }

         var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         long[] var0 = new long[2];
         int var6 = 0;
         byte var5 = 0;

         do {
            int var10001 = var5;
            var5 += 8;
            byte[] var9 = "Æ¬fz\rý9\u009d'!¬\u0006y}\u0002Z".substring(var10001, var5).getBytes("ISO-8859-1");
            var10001 = var6++;
            long var10 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            byte[] var12 = var3.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var10004 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            byte var15 = -1;
            var0[var10001] = var10004;
         } while (var5 < 16);

         何友何何树何何何何何 = (int)var0[1];
         友树友树何友何友友友 = (int)var0[0];
      }

      private static String HE_WEI_LIN() {
         return "何炜霖大狗叫";
      }
   }

   private static class 树树友树友树何何何友 extends Screen implements 何树友 {
      private static final long a;
      private static final String b;
      private static String HE_WEI_LIN;

      public 树树友树友树何何何友() {
         super(Component.literal("Dynamic Island"));
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-5358979357828876003L, 8707735712065230866L, MethodHandles.lookup().lookupClass()).a(281338212626715L);
         // $VF: monitorexit
         a = var10000;
         Cipher var2;
         Cipher var4 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
         SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
         byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

         for (int var3 = 1; var3 < 8; var3++) {
            var10003[var3] = (byte)(59543493370515L << var3 * 8 >>> 56);
         }

         var4.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
         String var5 = a(var2.doFinal("Ýb@\u0093V¦-;×egq¥Í:5".getBytes("ISO-8859-1"))).intern();
         byte var10001 = -1;
         b = var5;
      }

      private static String a(byte[] var0) {
         int var1 = 0;
         int var2;
         char[] var3 = new char[var2 = var0.length];

         for (int var4 = 0; var4 < var2; var4++) {
            int var5;
            if ((var5 = 255 & var0[var4]) < 192) {
               var3[var1++] = (char)var5;
            } else if (var5 < 224) {
               char var6 = (char)((char)(var5 & 31) << 6);
               byte var8 = var0[++var4];
               var6 = (char)(var6 | (char)(var8 & 63));
               var3[var1++] = var6;
            } else if (var4 < var2 - 2) {
               char var12 = (char)((char)(var5 & 15) << '\f');
               byte var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63) << 6);
               var9 = var0[++var4];
               var12 = (char)(var12 | (char)(var9 & 63));
               var3[var1++] = var12;
            }
         }

         return new String(var3, 0, var1);
      }

      private static String HE_WEI_LIN() {
         return "何炜霖国企上班";
      }

      public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
         super.render(guiGraphics, mouseX, mouseY, partialTicks);
      }

      public boolean isPauseScreen() {
         return false;
      }
   }
}
