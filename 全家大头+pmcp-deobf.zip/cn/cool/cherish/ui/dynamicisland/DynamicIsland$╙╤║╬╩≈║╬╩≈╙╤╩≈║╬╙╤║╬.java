package cn.cool.cherish.ui.dynamicisland;

import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.util.function.Consumer;

public class DynamicIsland$友何树何树友树何友何 implements 何树友 {
   private final Consumer<PoseStack> 何何友树树树何何何何;
   private final int 何友树友何树何友何何;
   private final int 友树何树友树何友何树;
   private final int 树友何树何友何何友何;
   private static String HE_WEI_LIN;

   private DynamicIsland$友何树何树友树何友何(Consumer<PoseStack> content, int width, int height, int weight) {
      this.何何友树树树何何何何 = content;
      this.何友树友何树何友何何 = width;
      this.友树何树友树何友何树 = height;
      this.树友何树何友何何友何 = weight;
   }

   private static String HE_SHU_YOU() {
      return "我是何树友";
   }
}
