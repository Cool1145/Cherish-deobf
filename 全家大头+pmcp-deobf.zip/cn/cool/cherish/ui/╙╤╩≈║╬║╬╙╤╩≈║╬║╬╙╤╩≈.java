package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.友友何友何何树何树树;
import cn.cool.cherish.utils.animations.何何友树友树友树树何;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectUtil;

public class 友树何何友树何何友树 implements IWrapper, 何树友 {
   private static final Map<MobEffect, 何何友树友树友树树何> 何树友何何树树何友树;
   private static final Map<MobEffect, cn.cool.cherish.utils.animations.何树友友何友友何树树> 何何何树友友树何树何;
   private static final int 树何友何树何树友何友;
   private static final int 何树何友友何树树友树;
   private static final int 友树友树树何树何友友;
   private static final int 友树树何树何树何友树;
   private static final int 何树何何何何树何何树;
   private static final int 何树友何何树友树何树;
   private static final String 友树何树树树树树友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[17];
   private static final String[] g = new String[17];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-198783827519887914L, -6374757277903896283L, MethodHandles.lookup().lookupClass()).a(154100082209431L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 72803065956111L;
      Cipher var13;
      Cipher var24 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[10];
      int var18 = 0;
      String var17 = "ç\u008c\u000fRüQT\r\u000ePy¢Y¹É\u001b\u0010\u0001|à½\u0083¿[°ê6?\u009c±rm5\u0010[N\u0092\u0000ÁÂ¬ºô¸\u0010\u0001\u0082\u0097u: ë¼µ\u0007\u007f|cMÔ\u008aI\u0000íWæ¯Cë¼¬EÉ/2\u001f¿6Ò\u00996L(\u0010 ?Õ\u0098§\u008cx8oÊe´|2Ô#\u0010I3\u000eÀ»\u007fÍÁõ¿Ù\u0004e·Íú\u0010é\nèVbÀ3hj³Ï\u0084Ë\u0007y \u0018\u008f\u0084\u008dpÌv7±¿\r¼ÿpX=QP&Y¸/\u001e\u0090ë";
      short var19 = 159;
      char var16 = 16;
      int var23 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            String var36 = b(var13.doFinal(var25.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var23 += var16) >= var19) {
                     b = var20;
                     c = new String[10];
                     友树何树树树树树友树 = a<"o">(27318, 9043473867692174265L ^ var11);
                     Cipher var1;
                     Cipher var27 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var2 = 1; var2 < 8; var2++) {
                        var10003[var2] = (byte)(var11 << var2 * 8 >>> 56);
                     }

                     var27.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var0 = new long[6];
                     int var4 = 0;
                     String var5 = "ù\u0087 ¸ýqiÌÔ\u0097ç\r§,¹±'ïâ¸R¸iÇ¢1(\u000b\u001dï×u";
                     byte var6 = 32;
                     byte var3 = 0;

                     label36:
                     while (true) {
                        var10001 = var3;
                        var3 += 8;
                        byte[] var7 = var5.substring(var10001, var3).getBytes("ISO-8859-1");
                        long[] var28 = var0;
                        var10001 = var4++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte var43 = -1;

                        while (true) {
                           long var8 = var40;
                           byte[] var10 = var1.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var3 >= var6) {
                                    何树友何何树友树何树 = (int)var0[4];
                                    友树友树树何树何友友 = (int)var0[3];
                                    何树何何何何树何何树 = (int)var0[0];
                                    何树何友友何树树友树 = (int)var0[1];
                                    友树树何树何树何友树 = (int)var0[5];
                                    树何友何树何树友何友 = (int)var0[2];
                                    何树友何何树树何友树 = new HashMap<>();
                                    何何何树友友树何树何 = new HashMap<>();
                                    return;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var3 < var6) {
                                    continue label36;
                                 }

                                 var5 = "\u0011\\\u0015\u001f\u008a\u00158FÕûæHR¦zc";
                                 var6 = 16;
                                 var3 = 0;
                           }

                           byte var34 = var3;
                           var3 += 8;
                           var7 = var5.substring(var34, var3).getBytes("ISO-8859-1");
                           var28 = var0;
                           var10001 = var4++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label54;
                  }

                  var17 = "¹~ \u0012és>¸%\u0019±u\u007fé\u0005ç \u0013\u0015\tWwÀ»\u0087À?\u001b&`»ðGvø\u001f·07Ï\u001a\u008e\u0080\r\u007f\u0085O.Ä";
                  var19 = 49;
                  var16 = 16;
                  var23 = -1;
            }

            var25 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   }

   private static String D(int num) {
      long a = 友树何何友树何何友树.a ^ 92766125328458L;
      b<"Í">(-7461548259016081898L, a);
      int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
      String[] symbols = new String[]{
         "M",
         a<"o">(1201, 255370519998139127L ^ a),
         "D",
         a<"o">(18448, 3268796231278184027L ^ a),
         "C",
         a<"o">(26883, 7423078804466263873L ^ a),
         "L",
         a<"o">(8786, 6935020178404092951L ^ a),
         "X",
         a<"o">(11292, 5049210947390546527L ^ a),
         "V",
         a<"o">(10108, 5642006153429887293L ^ a),
         "I"
      };
      StringBuilder sb = new StringBuilder();
      int i = 0;
      if (0 < values.length && num > 0) {
         if (values[0] <= num) {
            int var10000 = num - values[0];
            sb.append(symbols[0]);
         }

         i++;
      }

      return sb.toString();
   }

   private static float S(List<MobEffectInstance> effects, 友何何树友何何何何树 font, 友何何树友何何何何树 titleFont) {
      long a = 友树何何友树何何友树.a ^ 84622399039670L;
      b<"Í">(-536111096699609366L, a);
      float titleWidth = titleFont.A(a<"o">(10803, 8583168189716153483L ^ a)) + 16;
      float maxWidth = Math.max(120.0F, titleWidth);
      Iterator var8 = effects.iterator();
      if (var8.hasNext()) {
         MobEffectInstance effect = (MobEffectInstance)var8.next();
         String name = l(effect);
         String time = effect.getDuration() == -1 ? "∞" : MobEffectUtil.formatDuration(effect, 1.0F).getString();
         float nameWidth = font.A(name);
         float timeWidth = font.A(time);
         float textWidth = Math.max(nameWidth, timeWidth);
         float totalWidth = 26.0F + textWidth + 16.0F + 16.0F;
         maxWidth = Math.max(maxWidth, totalWidth);
      }

      return maxWidth;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 40;
               case 1 -> 43;
               case 2 -> 6;
               case 3 -> 28;
               case 4 -> 33;
               case 5 -> 14;
               case 6 -> 34;
               case 7 -> 13;
               case 8 -> 7;
               case 9 -> 16;
               case 10 -> 44;
               case 11 -> 12;
               case 12 -> 31;
               case 13 -> 36;
               case 14 -> 24;
               case 15 -> 57;
               case 16 -> 2;
               case 17 -> 42;
               case 18 -> 53;
               case 19 -> 19;
               case 20 -> 10;
               case 21 -> 23;
               case 22 -> 49;
               case 23 -> 29;
               case 24 -> 38;
               case 25 -> 15;
               case 26 -> 61;
               case 27 -> 39;
               case 28 -> 58;
               case 29 -> 41;
               case 30 -> 21;
               case 31 -> 63;
               case 32 -> 56;
               case 33 -> 18;
               case 34 -> 5;
               case 35 -> 25;
               case 36 -> 8;
               case 37 -> 17;
               case 38 -> 27;
               case 39 -> 51;
               case 40 -> 11;
               case 41 -> 37;
               case 42 -> 9;
               case 43 -> 20;
               case 44 -> 52;
               case 45 -> 0;
               case 46 -> 3;
               case 47 -> 50;
               case 48 -> 47;
               case 49 -> 35;
               case 50 -> 45;
               case 51 -> 55;
               case 52 -> 48;
               case 53 -> 32;
               case 54 -> 26;
               case 55 -> 1;
               case 56 -> 4;
               case 57 -> 54;
               case 58 -> 62;
               case 59 -> 59;
               case 60 -> 46;
               case 61 -> 60;
               case 62 -> 30;
               default -> 22;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何何友树何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'w' && var8 != 'G' && var8 != 229 && var8 != 227) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 219) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 205) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'w') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'G') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 229) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static void b(PoseStack poseStack, List<MobEffectInstance> effects, float x, float y, 友友何友何何树何树树 module) {
      long a = 友树何何友树何何友树.a ^ 133127695025664L;
      long ax = a ^ 32601804371061L;
      long axx = a ^ 57103514353338L;
      b<"Í">(-3010255927641952164L, (long)a);
      if (mc.player != null && mc.level != null && !effects.isEmpty()) {
         N(effects);
         y(effects);
         友何何树友何何何何树 zw18 = Cherish.instance.h().z(18);
         友何何树友何何何何树 zw16 = Cherish.instance.h().z(16);
         友何何树友何何何何树 titleFont = Cherish.instance.h().z(20);
         float totalWidth = S(effects, zw18, titleFont);
         float totalHeight = 30 + effects.size() * 28 + (effects.size() - 1) * 6 + 16;
         poseStack.pushPose();
         Color glassColor = new Color(0, 0, 0, 60);
         Color borderColor = new Color(255, 255, 255, 120);
         ShaderUtils.e((PoseStack)ax, y, (long)totalWidth, totalHeight, 8.0F, 1.5F, (float)borderColor, (float)glassColor, 12.0F);
         float titleX = x + totalWidth / 2.0F - titleFont.A(a<"o">(5546, 7903102050725647776L ^ a)) / 2.0F;
         float titleY = y + 8.0F + 2.0F;
         titleFont.c(poseStack, a<"o">(5546, 7903102050725647776L ^ a), titleX, titleY, b<"å">(-3010474681801955787L, (long)a).getRGB());
         float var10003 = x + 8.0F;
         float var10004 = titleY + titleFont.K() + 4.0F;
         float var10005 = totalWidth - 16.0F;
         float var10007 = 1.0F;
         ShaderUtils.h((int)0.5F, (long)(new Color(255, 255, 255, 80)));
         float currentY = y + 8.0F + 22.0F + 8.0F;
         Iterator var25 = effects.iterator();
         if (var25.hasNext()) {
            MobEffectInstance effect = (MobEffectInstance)var25.next();
            l(poseStack, effect, x + 8.0F, currentY, totalWidth - 16.0F, zw18, zw16);
            float var10008 = currentY + 34.0F;
         }

         poseStack.popPose();
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static String l(MobEffectInstance potionEffect) {
      long a = 友树何何友树何何友树.a ^ 617130129837L;
      return potionEffect.getEffect().getDisplayName().getString() + a<"o">(19804, 4405732585841242876L ^ a) + D(potionEffect.getAmplifier() + 1);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5682;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友树何何友树何何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      f[0] = "d{\u0005r,:k;Hy&'nfC?6<)叞叠佄厈桄佒佀叠叚厈";
      f[1] = "])o\u001a<L(\td\u0015-\u0003U\u0011w\u0012$J=";
      f[2] = "UM^dewZ\r\u0013ooj_P\u0018)\u007fl_O\u0003)kv_N\u0011scwXP^双佟叓栧栲桡双栛位叽";
      f[3] = "'sXV4\\(3\u0015]>A-n\u001e\u001b6\\ h\u001aPuZ)m\u001a\u001b?Z7m\u001aT\"\u001d厏取伣叾伎佦桕佈桧栤";
      f[4] = "\u0001\b74!;\u001f\u0000-{B/\u001b";
      f[5] = "0#o1JF?c\":@[:>)|P@}历桐伇佰叢桂优伔厙栴";
      f[6] = "/\u0012~\"E\u0004$\u001dom9\u001d+\u0007a.\u000e-=\u0010m3\u001f\u0001*\u001d";
      f[7] = "!\u0007gnn<<\u0012?L/1$\u0014";
      f[8] = "W\u000fE\u0018Jm\\\u0000TW+cW\u000bP\r";
      f[9] = "d?\u001b\u0018Spy?\u0005x]H>|\u0014FT-a\"\u0017\u0015-";
      f[10] = "\u000f\u0013mZl\u0010\u0003Ht^\t伴株叫佌佦栐桰佮叫栈;3\u0015WQ*\u00073\u000b\u000eL";
      f[11] = "M(\"K_\u000bDxu\t3伵桭桞伕栮台厫伩厄伕7\n\u0007\u001e;$T\u0003WIy";
      f[12] = "Bp[\u0011#$H}\b\u0012X栀桡佌栩厩伅佄伥叒栩jbe\u001ch\u000bVb{Eu";
      f[13] = "[Xdn`HW\u0003}j\u0005Xg_~p5\u0001\t\u0011!?n1[\u0005g?5_\u0015Z(d\u0005";
      f[14] = "Z 9\u0014L\u0001Z*c\b3>'Q\u000373\\Wv1\u0005S\\],-";
      f[15] = "w-LVTJ{vUR1佮伖佋栩叴史株伖栏佭7\u000bO/o\u000b\u000b\u000bQvr";
      f[16] = "U\u0002Zw41\\R\r5X伏桵桴栩佖伅厑厯厮右\u000ba=\u0006\u0011\\hhmQS";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何何友树何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static void y(List<MobEffectInstance> effects) {
      long a = 友树何何友树何何友树.a ^ 106925049174673L;
      b<"Í">(-3843694714645041971L, a);
      Iterator var4 = effects.iterator();
      if (var4.hasNext()) {
         MobEffectInstance instance = (MobEffectInstance)var4.next();
         MobEffect effect = instance.getEffect();
         b<"å">(-3843659893730784820L, a).computeIfAbsent(effect, k -> {
            long ax = 友树何何友树何何友树.a ^ 41814434653095L ^ 23848765605530L;
            return new 何何友树友树友树树何(300, 1.0, ax, 1.8F);
         });
         b<"å">(-3843300948160577856L, a).computeIfAbsent(effect, k -> {
            long ax = 友树何何友树何何友树.a ^ 45264508228371L ^ 11486948469637L;
            return new cn.cool.cherish.utils.animations.何树友友何友友何树树(ax, 300, 1.0);
         });
      }
   }

   private static void N(List<MobEffectInstance> effects) {
      long a = 友树何何友树何何友树.a ^ 100485634990910L;
      b<"å">(3677094450703904867L, a).entrySet().removeIf(entry -> {
         MobEffect effect = (MobEffect)entry.getKey();
         return effects.stream().noneMatch(e -> {
            long var10000 = 友树何何友树何何友树.a ^ 6681904154828L;
            return e.getEffect() == effect;
         });
      });
      b<"å">(3676872974158366575L, a).entrySet().removeIf(entry -> {
         MobEffect effect = (MobEffect)entry.getKey();
         return effects.stream().noneMatch(e -> {
            long var10000 = 友树何何友树何何友树.a ^ 68566852821947L;
            return e.getEffect() == effect;
         });
      });
   }

   private static String HE_SHU_YOU() {
      return "职业技术教育中心学校";
   }
}
