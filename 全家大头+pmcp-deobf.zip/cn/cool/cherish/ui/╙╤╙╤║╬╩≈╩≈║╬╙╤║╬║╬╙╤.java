package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.value.impl.BooleanValue;
import com.mojang.math.Axis;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import net.minecraft.client.gui.GuiGraphics;

public class 友友何树树何友何何友 implements 树何何何树友友友友友<BooleanValue>,  {
   private final HashMap<BooleanValue, Float> 树何何友何友树何树友 = new HashMap<>();
   private static final float 何树树树何友友何树树 = 7.0F;
   private static final long a;
   private static final Object[] b = new Object[12];
   private static final String[] c = new String[12];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8078526220232062571L, 2315700454479577073L, MethodHandles.lookup().lookupClass()).a(130219973775493L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public float B(BooleanValue setting, 树何友何树树何何树树 componentsInstance) {
      return 0.0F;
   }

   public boolean i(BooleanValue setting, char chr, int modifiers, 树何友何树树何何树树 componentsInstance) {
      return false;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void n(
      GuiGraphics guiGraphics,
      BooleanValue value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      何何友友树何树何友树 settingNameFont,
      何何友友树何树何友树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      树何友何树树何何树树 componentsInstance
   ) {
      友友树何何友树树友树.V();
      float animationProgress = this.树何何友何友树何树友.computeIfAbsent(value, k -> value.getValue() ? 1.0F : 0.0F);
      float targetProgress = value.getValue() ? 1.0F : 0.0F;
      if (Math.abs(animationProgress - targetProgress) > 0.001F) {
         float var38 = animationProgress + (targetProgress - animationProgress) * 0.25F * partialTicks * 5.0F;
         animationProgress = Math.max(0.0F, Math.min(1.0F, var38));
         this.树何何友何友树何树友.put(value, animationProgress);
      }

      float boxX = x + width - 22.0F;
      float boxY = middleY - 5.0F;
      RenderUtils.drawRoundedRect(guiGraphics.pose(), boxX, boxY, 10.0, 10.0, 0.0, darkBgColor.brighter());
      何何友友树何树何友树 checkMarkFont = Cherish.instance.t().V(18);
      float checkMarkCharWidth = checkMarkFont.D("\ueb53");
      float checkMarkCharHeight = checkMarkFont.x();
      float checkMarkX = boxX + (10.0F - checkMarkCharWidth) / 2.0F;
      float checkMarkY = boxY + (10.0F - checkMarkCharHeight) / 2.0F + 1.0F;
      Color checkColor = 何树友友树树友何树何.p(new Color(100, 100, 100, 0), accentColor, animationProgress);
      int alpha = (int)(accentColor.getAlpha() * animationProgress);
      if (animationProgress < 0.01F) {
         alpha = 0;
      }

      if (alpha > 5) {
         Color finalCheckColor = new Color(checkColor.getRed(), checkColor.getGreen(), checkColor.getBlue(), alpha);
         guiGraphics.pose().pushPose();
         float charCenterX = checkMarkX + checkMarkCharWidth / 2.0F;
         float charCenterY = checkMarkY + checkMarkCharHeight / 2.0F;
         float rotationDegrees = (1.0F - animationProgress) * 180.0F;
         guiGraphics.pose().translate(charCenterX, charCenterY, 0.0F);
         guiGraphics.pose().mulPose(Axis.ZP.rotationDegrees(rotationDegrees));
         guiGraphics.pose().translate(-charCenterX, -charCenterY, 0.0F);
         checkMarkFont.q(guiGraphics.pose(), "\ueb53", checkMarkX, checkMarkY, finalCheckColor.getRGB());
         guiGraphics.pose().popPose();
      }
   }

   public void l(BooleanValue setting, double mouseX, double mouseY, int button, 树何友何树树何何树树 componentsInstance) {
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 63;
               case 1 -> 36;
               case 2 -> 2;
               case 3 -> 3;
               case 4 -> 58;
               case 5 -> 60;
               case 6 -> 57;
               case 7 -> 9;
               case 8 -> 17;
               case 9 -> 53;
               case 10 -> 46;
               case 11 -> 42;
               case 12 -> 38;
               case 13 -> 24;
               case 14 -> 30;
               case 15 -> 48;
               case 16 -> 37;
               case 17 -> 40;
               case 18 -> 62;
               case 19 -> 13;
               case 20 -> 27;
               case 21 -> 32;
               case 22 -> 50;
               case 23 -> 23;
               case 24 -> 26;
               case 25 -> 35;
               case 26 -> 16;
               case 27 -> 28;
               case 28 -> 20;
               case 29 -> 56;
               case 30 -> 0;
               case 31 -> 45;
               case 32 -> 49;
               case 33 -> 5;
               case 34 -> 59;
               case 35 -> 21;
               case 36 -> 8;
               case 37 -> 14;
               case 38 -> 29;
               case 39 -> 41;
               case 40 -> 19;
               case 41 -> 47;
               case 42 -> 4;
               case 43 -> 54;
               case 44 -> 52;
               case 45 -> 34;
               case 46 -> 15;
               case 47 -> 43;
               case 48 -> 18;
               case 49 -> 12;
               case 50 -> 25;
               case 51 -> 1;
               case 52 -> 55;
               case 53 -> 11;
               case 54 -> 61;
               case 55 -> 31;
               case 56 -> 22;
               case 57 -> 44;
               case 58 -> 51;
               case 59 -> 33;
               case 60 -> 39;
               case 61 -> 10;
               case 62 -> 7;
               default -> 6;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "M\u0016E^\u0002KBV\bU\bVG\u000b\u0003\u0013\u0018M\u0000厳厠栬伸佱句桩桺叶桼";
      b[1] = boolean.class;
      c[1] = "java/lang/Boolean";
      b[2] = "\u0016Pe\u0014S4\u0019\u0010(\u001fY)\u001cM#YI2[叵厀伢栭桊传叵伞伢号";
      b[3] = "\u0010qgKT\u001f\u001b~v\u0004(\u0006\u0014dxG\u001f6\u0002stZ\u000e\u001a\u0015~";
      b[4] = "\\\u0001\"Jp8B\t8\u0005\u0016,E\b\u0019J.";
      b[5] = "|hjzP<ufi3\u0013>~soz|+vt";
      b[6] = "\u001bMn6E;\u0010B\u007fy$5\u001bI{#";
      b[7] = "\u001aCqk\u0005e\n\t:R?^BI(.\u001d#\u001f\u001d!oa";
      b[8] = "x\u0005U/:\u0005}Q\\dW桠伜伷另伉厔桠伜桳另Tm\u0007%R^3'\t%\u0000";
      b[9] = "\fF0#x\b\u001c\f{\u001aN3TLif`N\t\u0018`'\u001c";
      b[10] = "-?\u000baR3).\u0006?\"eA~_;\u001e3-\u0013b:Ybv4Z>Ho(";
      b[11] = "L}\u0002F\u000e-I)\u000b\rc8u(\u001f\u0004\u001c=KxOBYQO\u007fKB\u000fo\u001f/\r\u0007c";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 231 && var8 != '$' && var8 != 236 && var8 != 'D') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'Q') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'g') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 231) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 236) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友何树树何友何何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public boolean o(
      BooleanValue setting, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 树何友何树树何何树树 componentsInstance
   ) {
      友友树何何友树树友树.Z();
      float boxX = x + width - 22.0F;
      float boxY = middleY - 5.0F;
      if (mouseX >= boxX && mouseX <= boxX + 10.0F && mouseY >= boxY && mouseY <= boxY + 10.0F && button == 0) {
         setting.G(!setting.getValue());
         return true;
      } else {
         return false;
      }
   }

   public void v(BooleanValue setting, 树何友何树树何何树树 componentsInstance) {
      this.树何何友何友树何树友.put(setting, setting.getValue() ? 1.0F : 0.0F);
   }

   public boolean E(BooleanValue setting, int keyCode, int scanCode, int modifiers, 树何友何树树何何树树 componentsInstance) {
      return false;
   }

   private static String HE_SHU_YOU() {
      return "何树友被何大伟克制了";
   }
}
