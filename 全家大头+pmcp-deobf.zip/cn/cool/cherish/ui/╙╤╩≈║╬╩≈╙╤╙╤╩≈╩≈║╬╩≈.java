package cn.cool.cherish.ui;

import cn.cool.cherish.value.树何何何友树树何友何;
import java.awt.Color;
import net.minecraft.client.gui.GuiGraphics;

public interface 友树何树友友树树何树<T extends 树何何何友树树何友何<?>> {
   float h(T var1, 友树友树何树友友友树 var2);

   void g(T var1, 友树友树何树友友友树 var2);

   boolean r(T var1, double var2, double var4, int var6, float var7, float var8, float var9, float var10, float var11, 友树友树何树友友友树 var12);

   boolean E(T var1, int var2, int var3, int var4, 友树友树何树友友友树 var5);

   void Y(
      GuiGraphics var1,
      T var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      int var8,
      int var9,
      float var10,
      友何何树友何何何何树 var11,
      友何何树友何何何何树 var12,
      Color var13,
      Color var14,
      Color var15,
      友树友树何树友友友树 var16
   );

   void N(T var1, double var2, double var4, int var6, 友树友树何树友友友树 var7);

   boolean Q(T var1, char var2, int var3, 友树友树何树友友友树 var4);
}
