package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何何友何何友何何树树;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class 树友友友树树树树树何 extends Screen implements IWrapper, 何树友 {
   public static final 树友友友树树树树树何 友何友树友何何何树友;
   private boolean 树友树友何树树树何树;
   private float 树何友树何友何树友何;
   private long 友何树何树何友友树何;
   private final List<树友何树何树何友友友> 友何何树何何树何树树;
   private 树友何树何树何友友友 友何友何友友何何何何;
   private float 何树友树友友树树何何;
   private float 友友树友友树树友树何;
   public final float 何树友树何树何友树树;
   public final float 友友友友友友友友友树;
   public final float 何树树友树何树友何友;
   public final float 何树何友树何树何友树;
   public final float 友何何友何树树何树树;
   final float 何何何树树友何友树树;
   final float 树树何树友友树何树何;
   public final Color 树树友树友树树何友何;
   public final Color 何友友树何何何何何友;
   public final Color 树友树友树友树何何何;
   public final Color 树友树何树友树友树树;
   public final Color 友友友友何树树树树树;
   public final Color 何树树何友树友树何何;
   public final Color 友树树友何何友友友何;
   public final Color 友何树何何何何友树友;
   public final Color 友树树何何友树何树树;
   public boolean 树何友何友友何树何树;
   public 友何何树友何何何何树 何友友友树友树何何树;
   public 友何何树友何何何何树 友树何树友树何何树树;
   public 友何何树友何何何何树 何友友何友树何树树何;
   public 友何何树友何何何何树 友何树树树树何何友何;
   public 友何何树友何何何何树 友友何友树何友何树树;
   public 友何何树友何何何何树 何树友树友树树何何友;
   public 友何何树友何何何何树 树友树何友何何友友树;
   public 友树何树友友何树友友 何友何何树树何友何树;
   public 树友何树何树何友友友 友何树何友树友友何何;
   private static int 何树友友何友何树树何;
   private static final long a;
   private static final String b;
   private static final long c;
   private static final Object[] e = new Object[54];
   private static final String[] f = new String[54];
   private static int _解放村多种2队1144号 _;

   protected 树友友友树树树树树何() {
      long a = 树友友友树树树树树何.a ^ 39576353165373L;
      super(Component.nullToEmpty(b));
      a<"û">(this, false, 7200424948147713228L, a);
      a<"û">(this, 0.0F, 7198542921718534562L, a);
      this.友何何树何何树何树树 = new ArrayList<>();
      a<"û">(this, null, 7197032773773252112L, a);
      this.何树友树何树何友树树 = 110.0F;
      this.友友友友友友友友友树 = 20.0F;
      this.何树树友树何树友何友 = 18.0F;
      this.何树何友树何树何友树 = 16.0F;
      this.友何何友何树树何树树 = 2.0F;
      this.何何何树树友何友树树 = 3.0F;
      this.树树何树友友树何树何 = 300.0F;
      this.树树友树友树树何友何 = new Color(30, 30, 30);
      this.何友友树何何何何何友 = new Color(40, 40, 40);
      this.树友树友树友树何何何 = new Color(45, 45, 45);
      this.树友树何树友树友树树 = new Color(55, 55, 55);
      this.友友友友何树树树树树 = new Color(200, 200, 200);
      this.何树树何友树友树何何 = a<"s">(7198901500980976449L, a);
      this.友树树友何何友友友何 = new Color(25, 25, 25);
      this.友何树何何何何友树友 = new Color(35, 35, 35);
      this.友树树何何友树何树树 = new Color(100, 100, 120);
      a<"û">(this, null, 7197576126391610107L, a);
      a<"û">(this, null, 7198462574121015600L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-45721370773280321L, -1842521749726428818L, MethodHandles.lookup().lookupClass()).a(217529278966236L);
      // $VF: monitorexit
      a = var10000;
      long var8 = a ^ 29352795360673L;
      a();
      if (a<"N">(9115074155718282673L, var8) == 0) {
         a<"N">(99, 9111368035226499433L, var8);
      }

      Cipher var5;
      Cipher var10 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var8 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(var8 << var6 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var13 = b(var5.doFinal("R\u009aå\u0000);ÇóC\u008fZWØ¹VÏ".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      b = var13;
      Cipher var0;
      Cipher var11 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)(var8 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var8 << var1 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var4 = var0.doFinal(new byte[]{50, 122, -99, -40, 95, 94, -33, 61});
      long var15 = (var4[0] & 255L) << 56
         | (var4[1] & 255L) << 48
         | (var4[2] & 255L) << 40
         | (var4[3] & 255L) << 32
         | (var4[4] & 255L) << 24
         | (var4[5] & 255L) << 16
         | (var4[6] & 255L) << 8
         | var4[7] & 255L;
      var10001 = -1;
      c = var15;
      友何友树友何何何树友 = new 树友友友树树树树树何();
   }

   public static int J() {
      b();

      try {
         return 30;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public Color Z(Color color, int alpha) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.min(Math.max(0, alpha), color.getAlpha()));
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 57;
               case 1 -> 58;
               case 2 -> 22;
               case 3 -> 17;
               case 4 -> 30;
               case 5 -> 41;
               case 6 -> 55;
               case 7 -> 61;
               case 8 -> 15;
               case 9 -> 3;
               case 10 -> 7;
               case 11 -> 26;
               case 12 -> 8;
               case 13 -> 48;
               case 14 -> 24;
               case 15 -> 16;
               case 16 -> 42;
               case 17 -> 14;
               case 18 -> 62;
               case 19 -> 21;
               case 20 -> 5;
               case 21 -> 38;
               case 22 -> 47;
               case 23 -> 31;
               case 24 -> 54;
               case 25 -> 37;
               case 26 -> 29;
               case 27 -> 4;
               case 28 -> 2;
               case 29 -> 11;
               case 30 -> 13;
               case 31 -> 56;
               case 32 -> 32;
               case 33 -> 1;
               case 34 -> 36;
               case 35 -> 53;
               case 36 -> 27;
               case 37 -> 50;
               case 38 -> 19;
               case 39 -> 28;
               case 40 -> 51;
               case 41 -> 43;
               case 42 -> 10;
               case 43 -> 12;
               case 44 -> 9;
               case 45 -> 44;
               case 46 -> 35;
               case 47 -> 60;
               case 48 -> 33;
               case 49 -> 63;
               case 50 -> 52;
               case 51 -> 49;
               case 52 -> 20;
               case 53 -> 39;
               case 54 -> 23;
               case 55 -> 18;
               case 56 -> 45;
               case 57 -> 34;
               case 58 -> 40;
               case 59 -> 25;
               case 60 -> 59;
               case 61 -> 46;
               case 62 -> 6;
               default -> 0;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static int b() {
      return 何树友友何友何树树何;
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'M' && var8 != 251 && var8 != 's' && var8 != 224) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 208) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'N') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'M') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 's') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static void l(int var0) {
      何树友友何友何树树何 = var0;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      e[0] = "\b*q\u0011\u0013T\u0007j<\u001a\u0019I\u000277\\\tRE桕厔厹厷株桺桕桎档伩";
      e[1] = int.class;
      f[1] = "java/lang/Integer";
      e[2] = void.class;
      f[2] = "java/lang/Void";
      e[3] = "{J\u0006Y^WpE\u0017\u0016\"N\u007f_\u0019U\u0015~iH\u0015H\u0004R~E";
      e[4] = "36K\u001c^B<v\u0006\u0017T_9+\rQDD~桉厮伪栠佸桁伍厮厴叺";
      e[5] = float.class;
      f[5] = "java/lang/Float";
      e[6] = boolean.class;
      f[6] = "java/lang/Boolean";
      e[7] = "s9V\u0015kmn,\u000e7*`v*";
      e[8] = "\u0017sU\u00128s\t{O]Zo\u000ef";
      e[9] = "B#U \u0004\u000fMc\u0018+\u000e\u0012H>\u0013m\u001d\u0001M8\u001em\u0002\rQ!U\r\u001e\rC(\t\u0015\n\fT(";
      e[10] = "\u0004\u0010gt+\u0017\u001a\u0018};H\u0003\u001e";
      e[11] = "\u000ef/Ii\u0000\u0001&bBc\u001d\u0004{i\u0004p\u000e\u0001}d\u0004o\u0002\u001dd/叡栗伺桼參及使栗厤厦";
      e[12] = long.class;
      f[12] = "java/lang/Long";
      e[13] = "\u0003>\f\u0000M8\f~A\u000bG%\t#JMO8\u0004%N\u0006\f伂伵厛佷伶叩伂伵桁栳";
      e[14] = ".w?\n\u0004^!7r\u0001\u000eC$jyG\u001eXc叒佄似桺叺优佌佄似桺";
      e[15] = ")$GE\u001bA\"+V\nzO) RP";
      e[16] = ":t\u001d\u001fJY4h\u000f|^?js\u001a\u0010\u000b\u0005a!\u001a\u00197\u0005:s\u001c@\r\u000ehs\u0015|";
      e[17] = "\u0014W'\b\u001f\u000bE\u0007}\u0015\u007f佨栶栥叝伴厼佨佲栥佃iO\u000eKG%U\u0001[C\u0000";
      e[18] = "T{\u0000co\u0019\u0005+Z~\u000f古厬位栠叁双古桶栉叺\u00020C\u0004,_kpH\u0005q";
      e[19] = "\b'\u001aR\u0005\u0014\u0006;\b1伥桫厡桓厴栨桡伯伿厉wX\u0011\u0003\u0002(O\u000f\u0015\u0015\u001e";
      e[20] = "W\u007f\r.WMYc\u001fM栳佶叾住厣厎佷栲你栋`qH\u0010_s\u000f!\u0010GX";
      e[21] = "v:\n/\u001c\u0017x&\u0018L\u0005q%j\b#\u0005\u001fw+\u0001#aHe&\u001c,\u0002\n}=\u001cL";
      e[22] = "ih*r\u0019%gt8\u0011\n\u00142;z-X\u0014\u0003<z~\u000b'mn;w\u000b";
      e[23] = "\rB#u9Y\u0003^1\u0016.?^\u0012!y Q\fS(yD";
      e[24] = "\u0017A y\u0014$F\u0011zdt佇可叩栀叛伩栃佱栳叚\u0018Jc\u0017Nx~\u001bc\u001d\u0012";
      e[25] = "\u0014\u000eZ\u0019Uw\u001a\u0012Hz栱叒桧厠佪档栱栈伣桺7FJ*\u001c\u0002X\u0016\u0012}\u001b";
      e[26] = "hF\u000bJ\u0003o9\u0016QWc厒厐栴栫叨厠案伎栴栫+\t<>NOM\u0007 ,";
      e[27] = "9\bA:|H7\u0014SY参叭伎厦栵伄参佳桊桼,0h_3\u0007\u0014glI/";
      e[28] = "\u0012?\u0013OE\r\u001c#\u0001,V<IlC\u0010\u0003<xkCCW\u000f\u00169\u0002JW";
      e[29] = "*|2uj\u0018$` \u0016叔伣桙佌框佋叔厽桙佌_&}\u001a/~%|,\u0004?";
      e[30] = "5L\u0017\\L+>H[^%桘栝栱伷佮另伜栝叫厩3\u0014%yG\u0003Y\u001f!5E";
      e[31] = "V\u0000\u00031\u001cN\u0007PY,|桩厮桲叹桉伡桩厮桲栣P@\u0012V\t[?\u0010J\u0001\u000e";
      e[32] = "=\u0006b\u001bd`lV8\u0006\u0004桇佛桴桂伧叇厝佛估伆z;:mQ=\u0013{1l\f";
      e[33] = "\\}O]'_Ra]>\u00189\u000f-MQ>W]lDQZ";
      e[34] = "\u0004w\u0018[Z.\nk\n8栾桑厭栃厶校栾伕厭佇u\u0005N:\f!\u0012\u0001]1\u0015";
      e[35] = ",r\u0003N#X\"n\u0011-桇叽桟佂厭佰伃叽厅栆nD7O&}V\u00133Y:";
      e[36] = "\u0014[\u001f]v4\u001aG\r>又伏伣栯伯佣栒伏桧栯r\u000067\u0003X\b\u0000v0\u001f";
      e[37] = "Wq,)A(\u0006!v4!佋伱栃佈伕叢佋桵叙栌H\u001d,\u0005hep^\u007f\rg";
      e[38] = "\u0018\u001bIJ\u0012\u000b\u0016\u0007[)伲厮伯伫栽栰伲厮伯桯$\u0019T\t\tM\u0018W\u0001\u0001N";
      e[39] = "]6HQ9!\ff\u0012LY佂厥伀厲佭桀佂厥厞厲0f{\ra\u0017Y&p\f<";
      e[40] = "(i\u001e[\u000f:&u\f8伯原厁叇桪叻桫企伟栝sQ\u001b-\"fK\u0006\u001f;>";
      e[41] = "v\nEW/)x\u0016W4厑桖佁桾叫栭伏伒栅桾(];>|\u0005\u0010\n?(`";
      e[42] = "\u0013\u007f\fy4VB/VdT伵叫佉佨栁伉桱栱栍栬\u0018hRAfE +\u0001Ii";
      e[43] = "S*&z\t\u000e]64\u0019厷厫栠厄厈栀桭厫栠会K%N\u0001K7sf\u001d\tD";
      e[44] = "\br#%\u0014$Y\"y8t栃株佄栃伙厷叙株叚叙DHx\b{{+\u0018 _|";
      e[45] = ".\u0019l%\u0019\u0016\u007fI68y叫取厱伈桝伤併取伯桌DEJ.\u00104+\u0015\u0012y\u0017";
      e[46] = "]UacJ!SIs\u0000叴会叴佥叏參佪会佪佥\f;\\~VX2j\f$K";
      e[47] = "ZG\fs%\u0015T[\u001e\u0010伅厰右佷厢栉伅桪栩佷ay1\u0002PHY.5\u0014L";
      e[48] = "GB28c1I^ [叝伊栴栶框桂佃伊叮佲_2w&MMges0Q";
      e[49] = "\u0017\u0017\u0002n[\u0003\u0019\u000b\u0010\r佻桼厾档厬収栿桼传伧o1\u001c\f\u000f\nWrO\u0004\u0000";
      e[50] = ">a_/\u0004go1\u00052d伄栜栓桿伓桽厚叆佗伻NU=xe\u000f$^94g";
      e[51] = "\u001b%Ynzm\u001f6RwAUf\rwAA7O>I7&3\\5P";
      e[52] = "\u0013B+-NN\u001d^9N株併厺栶伛厍佮栱厺佲Fr\tA\u000b_~1ZI\u0004";
      e[53] = "/\u001e}^3B!\u0002o=厍佹桜伮叓栤厍叧优伮\u0010\u0006%\u001d$\u0013.WuG9";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友友友树树树树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public boolean w(double mouseX, double mouseY, float rectX, float rectY, float rectWidth, float rectHeight) {
      long a = 树友友友树树树树树何.a ^ 6732790923839L;
      a<"N">(3594192507828879919L, a);
      return mouseX >= rectX && mouseX <= rectX + rectWidth && mouseY >= rectY && mouseY <= rectY + rectHeight;
   }

   private float X(float progress) {
      long a = 树友友友树树树树树何.a ^ 34428944312224L;
      a<"N">(6088367812246546352L, a);
      if (progress >= 1.0F) {
         return 1.0F;
      } else if (progress <= 0.0F) {
         return 0.0F;
      } else {
         return progress < 0.5F ? 4.0F * progress * progress * progress : 1.0F - (float)Math.pow(-2.0F * progress + 2.0F, 3.0) / 2.0F;
      }
   }

   private void N() {
      long a = 树友友友树树树树树何.a ^ 86946702041908L;
      a<"N">(-8004468808304270556L, a);
      long time = System.currentTimeMillis();
      float elapsed = (float)(time - a<"M">(this, -8005873289944514986L, a));
      if (a<"M">(this, -8006167885325629499L, a)) {
         a<"û">(this, Math.max(0.0F, 1.0F - elapsed / 200.0F), -8003124924462046549L, a);
         if (a<"M">(this, -8003124924462046549L, a) != 0.0F) {
            return;
         }

         super.onClose();
      }

      a<"û">(this, Math.min(1.0F, elapsed / 200.0F), -8003124924462046549L, a);
   }

   public boolean isPauseScreen() {
      return false;
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      long a = 树友友友树树树树树何.a ^ 121440666070927L;
      a<"N">(-7179646578783655295L, a);
      if (mc != null) {
         this.N();
         if (!(a<"M">(this, -7182096640762417648L, a) <= 0.001F) || !a<"M">(this, -7178946872964314242L, a)) {
            float mainGuiAnimScale = this.X(a<"M">(this, -7182096640762417648L, a));
            int mainGuiActualAlpha = (int)(255.0F * mainGuiAnimScale);
            guiGraphics.fill(
               0,
               0,
               a<"M">(this, -7179232884897564638L, a),
               a<"M">(this, -7179677592968568818L, a),
               this.Z(a<"M">(this, -7182759248753737712L, a), (int)(mainGuiActualAlpha * 0.85F)).getRGB()
            );
            Iterator var10 = a<"M">(this, -7183199823810603728L, a).iterator();
            if (var10.hasNext()) {
               树友何树何树何友友友 panel = (树友何树何树何友友友)var10.next();
               panel.p();
               panel.P(guiGraphics, mouseX, mouseY, mainGuiActualAlpha);
            }

            if (a<"M">(this, -7182482053019817566L, a) != null) {
               a<"û">(a<"M">(this, -7182482053019817566L, a), mouseX - a<"M">(this, -7181731916769217851L, a), -7182243803795893044L, a);
               a<"û">(a<"M">(this, -7182482053019817566L, a), mouseY - a<"M">(this, -7182129788528604841L, a), -7183124049128682757L, a);
            }
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖230622200409390090";
   }

   public void onClose() {
      long a = 树友友友树树树树树何.a ^ 25663204680932L;
      a<"û">(this, true, 6283710047864111125L, a);
      a<"û">(this, System.currentTimeMillis(), 6283987043574446470L, a);
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      long a = 树友友友树树树树树何.a ^ 99181229674130L;
      a<"N">(4414074361291852700L, a);
      if (keyCode == 256) {
         if (a<"M">(this, 4417350158852371540L, a) != null) {
            a<"û">(this, null, 4417350158852371540L, a);
            if (a<"M">(this, 4416177838099728287L, a) != null) {
               a<"û">(a<"M">(this, 4416177838099728287L, a), null, 4413628374193649438L, a);
            }

            a<"û">(this, null, 4416177838099728287L, a);
            return true;
         } else {
            boolean settingsWereExpanded = false;
            Iterator var8 = a<"M">(this, 4417206149509248045L, a).iterator();
            if (var8.hasNext()) {
               树友何树何树何友友友 panel = (树友何树何树何友友友)var8.next();
               if (!a<"M">(panel, 4417443635177048426L, a).isEmpty()) {
                  Iterator var10 = new ArrayList(a<"M">(panel, 4417443635177048426L, a).keySet()).iterator();
                  if (var10.hasNext()) {
                     Module m = (Module)var10.next();
                     if (a<"M">(panel, 4417443635177048426L, a).getOrDefault(m, false)) {
                        a<"M">(panel, 4417443635177048426L, a).put(m, false);
                        a<"M">(panel, 4413705382473722894L, a).put(m, System.currentTimeMillis() - c);
                        settingsWereExpanded = true;
                     }
                  }
               }

               if (a<"M">(panel, 4417761994581686126L, a)) {
                  a<"û">(panel, false, 4417761994581686126L, a);
               }
            }

            if (settingsWereExpanded) {
               return true;
            } else {
               a<"û">(this, true, 4414219905062808163L, a);
               a<"û">(this, System.currentTimeMillis(), 4414505716227576816L, a);
               return true;
            }
         }
      } else if (a<"M">(this, 4416177838099728287L, a) != null && a<"M">(this, 4417350158852371540L, a) != null) {
         return a<"M">(this, 4416177838099728287L, a).r(keyCode, scanCode, modifiers, a<"M">(this, 4417350158852371540L, a));
      } else {
         return a<"M">(this, 4416177838099728287L, a) != null
               && a<"M">(a<"M">(this, 4416177838099728287L, a), 4415929210651048624L, a) == a<"s">(4414582854380817466L, a)
               && a<"M">(a<"M">(this, 4416177838099728287L, a), 4417761994581686126L, a)
            ? a<"M">(this, 4416177838099728287L, a).r(keyCode, scanCode, modifiers, null)
            : super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   protected void init() {
      long a = 树友友友树树树树树何.a ^ 12562609162590L;
      long ax = a ^ 86558951932832L;
      long axx = a ^ 124391811048381L;
      a<"N">(-392481231677682608L, a);
      super.init();
      if (!this.w(new Object[]{ax})) {
         a<"û">(this, false, -392335688443892305L, a);
         a<"û">(this, 0.0F, -394781609686202175L, a);
         a<"û">(this, System.currentTimeMillis(), -392049735277423556L, a);
         a<"û">(this, ClientUtils.o(new Object[]{axx}), -392577325381390814L, a);
         a<"û">(this, a<"M">(this, -392577325381390814L, a) ? Cherish.instance.h().z(16) : Cherish.instance.h().n(16), -392784040456651237L, a);
         a<"û">(this, a<"M">(this, -392577325381390814L, a) ? Cherish.instance.h().z(14) : Cherish.instance.h().n(14), -395632615800455315L, a);
         a<"û">(this, Cherish.instance.h().n(14), -395707155054233971L, a);
         a<"û">(this, Cherish.instance.h().n(12), -395276071540569977L, a);
         a<"û">(this, Cherish.instance.h().n(12), -395092970941108737L, a);
         a<"û">(this, Cherish.instance.h().F(18), -392202135176757714L, a);
         a<"û">(this, Cherish.instance.h().i(24), -396118923709673534L, a);
         a<"M">(this, -395964036962405407L, a).clear();
         float currentX = 30.0F;
         float currentY = 30.0F;
         何何友何何友何何树树[] configPanel = 何何友何何友何何树树.M();
         int var11 = configPanel.length;
         int var12 = 0;
         if (0 < var11) {
            何何友何何友何何树树 cat = configPanel[0];
            if (cat == a<"s">(-391831928354124810L, a)) {
            }

            树友何树何树何友友友 panel = new 树友何树何树何友友友(cat, 30.0F, 30.0F, this);
            a<"M">(this, -395964036962405407L, a).add(panel);
            currentX = 150.0F;
            if (260.0F > a<"M">(this, -391997174281871629L, a) - 30.0F) {
               currentX = 30.0F;
               currentY = 370.0F;
            }

            var12++;
         }

         树友何树何树何友友友 configPanelx = new 树友何树何树何友友友(a<"s">(-391831928354124810L, a), currentX, currentY, this);
         a<"M">(this, -395964036962405407L, a).add(configPanelx);
         a<"û">(this, null, -395235124821962893L, a);
         a<"û">(this, null, -395817828864429160L, a);
         a<"û">(this, null, -394844520857026477L, a);
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      long a = 树友友友树树树树树何.a ^ 96441339212902L;
      a<"N">(5167314035061862760L, a);
      if (a<"M">(this, 5169332946684130809L, a) < 0.95F && !a<"M">(this, 5167449699871838359L, a)) {
         return false;
      } else {
         a<"û">(this, null, 5168878267341632075L, a);
         a<"M">(this, 5168330352805826208L, a);
         a<"M">(this, 5169402135889476971L, a);
         a<"û">(this, null, 5168330352805826208L, a);
         a<"û">(this, null, 5169402135889476971L, a);
         int i = a<"M">(this, 5168192923419676377L, a).size() - 1;
         树友何树何树何友友友 panel = (树友何树何树何友友友)a<"M">(this, 5168192923419676377L, a).get(i);
         友树何树友友何树友友 newlyFocusedInPanel = panel.u(mouseX, mouseY, button);
         a<"û">(this, newlyFocusedInPanel, 5168330352805826208L, a);
         a<"û">(this, panel, 5169402135889476971L, a);
         if (a<"M">(panel, 5167836593699015850L, a)) {
            a<"û">(this, panel, 5168878267341632075L, a);
            a<"û">(this, (float)mouseX - a<"M">(panel, 5168639876127395621L, a), 5169117635209750828L, a);
            a<"û">(this, (float)mouseY - a<"M">(panel, 5168253827985330450L, a), 5168666482367828670L, a);
         }

         return true;
      }
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
      long a = 树友友友树树树树树何.a ^ 66868698166636L;
      a<"N">(-8737097781664845726L, a);
      if (a<"M">(this, -8739442290460232461L, a) < 1.0F) {
         return false;
      } else {
         int i = a<"M">(this, -8740511113678041133L, a).size() - 1;
         树友何树何树何友友友 panel = (树友何树何树何友友友)a<"M">(this, -8740511113678041133L, a).get(i);
         if (panel.e(mouseX, mouseY)) {
            panel.c(delta);
            return true;
         } else {
            i--;
            return super.mouseScrolled(mouseX, mouseY, delta);
         }
      }
   }

   public boolean charTyped(char typedChar, int modifiers) {
      long a = 树友友友树树树树树何.a ^ 106398142406049L;
      a<"N">(3346961560835250351L, a);
      return a<"M">(this, 3349077956905276588L, a) != null && a<"M">(this, 3350306901901715303L, a) != null
         ? a<"M">(this, 3349077956905276588L, a).r(typedChar, modifiers, a<"M">(this, 3350306901901715303L, a))
         : super.charTyped(typedChar, modifiers);
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      long a = 树友友友树树树树树何.a ^ 34520470800896L;
      a<"N">(-441851452294952432L, a);
      if (button == 0) {
         if (a<"M">(this, -441981998076539859L, a) != null) {
            a<"û">(a<"M">(this, -441981998076539859L, a), false, -445415650155531572L, a);
            a<"û">(this, null, -441981998076539859L, a);
         }

         Iterator var9 = a<"M">(this, -441541020744961857L, a).iterator();
         if (var9.hasNext()) {
            树友何树何树何友友友 panel = (树友何树何树何友友友)var9.next();
            if (a<"M">(panel, -445730886026501478L, a) != null) {
               a<"û">(panel, null, -445730886026501478L, a);
            }

            if (a<"M">(panel, -441793930162300837L, a) != null) {
               Iterator var11 = a<"M">(panel, -441793930162300837L, a).values().iterator();
               if (var11.hasNext()) {
                  何树树友树树友友何何 handler = (何树树友树树友友何何)var11.next();
                  if (handler instanceof 何友树树树友何友树何) {
                     ((何友树树树友何友树何)handler).V();
                  }
               }
            }
         }
      }

      return super.mouseReleased(mouseX, mouseY, button);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaYmouse) {
      long a = 树友友友树树树树树何.a ^ 74672301016358L;
      a<"N">(-5263044526800814040L, a);
      if (a<"M">(this, -5261436666247412981L, a) != null && button == 0) {
         a<"û">(a<"M">(this, -5261436666247412981L, a), (float)mouseX - a<"M">(this, -5261205720810153876L, a), -5261709825224999323L, a);
         a<"û">(a<"M">(this, -5261436666247412981L, a), (float)mouseY - a<"M">(this, -5261648468396907522L, a), -5262096457478463406L, a);
         return true;
      } else {
         Iterator var13 = a<"M">(this, -5262165569726578791L, a).iterator();
         if (var13.hasNext()) {
            树友何树何树何友友友 panel = (树友何树何树何友友友)var13.next();
            if (a<"M">(panel, -5262967907865580100L, a) != null) {
               if (panel.e(a<"M">(panel, -5262967907865580100L, a)) instanceof 树友树何树何友何树何 numberHandler) {
                  float valueX = a<"M">(panel, -5261709825224999323L, a) + 2.0F;
                  Objects.requireNonNull(a<"M">(panel, -5262816960477301499L, a));
                  Objects.requireNonNull(a<"M">(panel, -5262816960477301499L, a));
                  numberHandler.V(mouseX, valueX, 106.0F, a<"M">(panel, -5262967907865580100L, a));
               }

               return true;
            }

            if (a<"M">(panel, -5262400852058122371L, a) != null && a<"M">(panel, -5261910491403042082L, a) != null) {
               Iterator handler = a<"M">(panel, -5261910491403042082L, a).keySet().iterator();
               if (handler.hasNext()) {
                  Module module = (Module)handler.next();
                  if (a<"M">(panel, -5261910491403042082L, a).getOrDefault(module, false)) {
                     Iterator valueX = module.q().iterator();
                     if (valueX.hasNext()) {
                        树何何何友树树何友何<?> val = (树何何何友树树何友何<?>)valueX.next();
                        if (val instanceof 树友何友何何友树树友) {
                           何树树友树树友友何何 handlerx = panel.e(val);
                           if (handlerx instanceof 何友树树树友何友树何) {
                           }
                        }
                     }
                  }
               }
            }
         }

         return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaYmouse);
      }
   }
}
