package cn.cool.cherish.ui;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.ModeValue;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 树友树树何友何何树友 implements 友友何何何树友友何树, 何树友 {
   private final Map<String, Float> 友树何树友何友何友何 = new HashMap<>();
   private final Map<String, Boolean> 何友友树树何何树何树 = new HashMap<>();
   private final Map<String, Long> 树友何树友友友何树何 = new HashMap<>();
   private boolean 何友树友何何树友何何 = false;
   private float 友友树树友友树友树何 = 0.0F;
   private long 友友友友友友何树何何 = 0L;
   private static int 何何树何友何何树友何;
   private static final long a;
   private static final long[] b;
   private static final Long[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[43];
   private static final String[] f = new String[43];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-6658974522548324913L, 361917802259891838L, MethodHandles.lookup().lookupClass()).a(147237889118148L);
      // $VF: monitorexit
      a = var10000;
      a();
      L(0);
      Cipher var0;
      Cipher var11 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(133511908045826L << var1 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      int var3 = 0;
      byte var2 = 0;

      do {
         int var10001 = var2;
         var2 += 8;
         byte[] var7 = "½ÕÒ\u0017\u0084\u008aö,a|\u0093U9[W%".substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         byte var13 = -1;
         var6[var10001] = var10004;
      } while (var2 < 16);

      b = var6;
      c = new Long[2];
   }

   private float I(树树树友何何树何友何 panel, ModeValue mv) {
      Y();
      float naturalDropdownHeight = 0.0F;
      if (mv.n().length > 0) {
         float var10001 = mv.n().length;
         Objects.requireNonNull(panel.友友何友何树何何树树);
         naturalDropdownHeight = 2.0F + var10001 * 14.8F;
      }

      return naturalDropdownHeight;
   }

   @Override
   public float Z(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value) {
      Objects.requireNonNull(panel.友友何友何树何何树树);
      Y();
      Objects.requireNonNull(panel.友友何友何树何何树树);
      树友树树何友何何树友.树何何何友友何友友友 layout = 树友树树何友何何树友.何友何友友友何树树何.k(panel, value, 0.0F, 0.0F, 106.0F);
      float baseHeight = 16.0F + layout.友友友何树何友友何树;
      float naturalDropdownHeight = 0.0F;
      if (value instanceof ModeValue mv && mv.n().length > 0) {
         float var10001 = mv.n().length;
         Objects.requireNonNull(panel.友友何友何树何何树树);
         naturalDropdownHeight = 2.0F + var10001 * 14.8F;
      }

      return baseHeight + naturalDropdownHeight * this.友友树树友友树友树何;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友树树何友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 2;
               case 1 -> 36;
               case 2 -> 31;
               case 3 -> 57;
               case 4 -> 49;
               case 5 -> 39;
               case 6 -> 52;
               case 7 -> 6;
               case 8 -> 10;
               case 9 -> 62;
               case 10 -> 19;
               case 11 -> 23;
               case 12 -> 9;
               case 13 -> 55;
               case 14 -> 12;
               case 15 -> 51;
               case 16 -> 53;
               case 17 -> 30;
               case 18 -> 41;
               case 19 -> 60;
               case 20 -> 20;
               case 21 -> 59;
               case 22 -> 45;
               case 23 -> 40;
               case 24 -> 3;
               case 25 -> 32;
               case 26 -> 8;
               case 27 -> 38;
               case 28 -> 4;
               case 29 -> 1;
               case 30 -> 42;
               case 31 -> 24;
               case 32 -> 18;
               case 33 -> 46;
               case 34 -> 34;
               case 35 -> 28;
               case 36 -> 17;
               case 37 -> 44;
               case 38 -> 54;
               case 39 -> 29;
               case 40 -> 21;
               case 41 -> 26;
               case 42 -> 5;
               case 43 -> 58;
               case 44 -> 27;
               case 45 -> 33;
               case 46 -> 15;
               case 47 -> 61;
               case 48 -> 56;
               case 49 -> 16;
               case 50 -> 37;
               case 51 -> 0;
               case 52 -> 63;
               case 53 -> 22;
               case 54 -> 11;
               case 55 -> 35;
               case 56 -> 7;
               case 57 -> 43;
               case 58 -> 25;
               case 59 -> 14;
               case 60 -> 50;
               case 61 -> 48;
               case 62 -> 13;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      e[0] = ":\nL\u0001i\f5J\u0001\nc\u00110\u0017\nLs\nw桵厩桳栗伶厒伱伷桳反";
      e[1] = float.class;
      f[1] = "java/lang/Float";
      e[2] = long.class;
      f[2] = "java/lang/Long";
      e[3] = boolean.class;
      f[3] = "java/lang/Boolean";
      e[4] = "<\\R\u001eay3\u001c\u001f\u0015kd6A\u0014S{\u007fq栣桭桬叅佃伊栣伩厶佛";
      e[5] = "\u007f,\u001ea:bplSj0\u007fu1X, d2众校佗厞叆佉众叻叉桄";
      e[6] = "n\r763\u0013e\u0002&yO\nj\u0018(:x:|\u000f$'i\u0016k\u0002";
      e[7] = int.class;
      f[7] = "java/lang/Integer";
      e[8] = void.class;
      f[8] = "java/lang/Void";
      e[9] = "yfJ?P\tds\u0012\u001d\u0011\u0004|u";
      e[10] = "8A\u001d\b,\u00027\u0001P\u0003&\u001f2\\[E6\u0004u栾司桺桒伸厐佺佦桺厈I桊佺佦伾厈厦伎古司厠";
      e[11] = "0\n6*\u0017[?J{!\u001dF:\u0017pg\r]}伱位厂厳栥伆桵位厂桩";
      e[12] = ":sGjQ\u000653\na[\u001b0n\u0001'S\u0006=h\u0005l\u0010$6y\u001ce[";
      e[13] = "wBLX(RCaC\u0018eYI|FEn\u001fAaKCjT\u0002C@Rs]I5";
      e[14] = "3`\u0005\u0004Qe8o\u0014K,}+h\u001d\u0002";
      e[15] = "#\u0001`\t\b)\u0017\"oIE\"\u001d?j\u0014Nd\u0015\"g\u0012J/V\u0000l\u0003S&\u001dv";
      e[16] = "dU1u=\nz]+:^\u001e~";
      e[17] = "\u000f0h\u0018p0\u0004?yW\u0011>\u000f4}\r";
      e[18] = "\u001b`|:c\u0010\u0019rsD佝厼厷栆栗伙佝桦伩栆\u000e.g@\u000ess6`\u001fN";
      e[19] = "P.>Z;\u0014SlaB\u0007桱伶伏桄你栞伵桲伏厞=9\u000f\u0006,d]a\t\u00139";
      e[20] = "u\u0010\u001a1#;.\u001dNpB厊厉叮伭桐伟厊厉佰桩I{v$INrsyq\u0014";
      e[21] = "$yp{LA\u007ft$:-株但伙佇叀栴台但厇栃\u0003\u0014\fu $8\u001c\u0003 }";
      e[22] = "~#\u0014\b\rLv-^]a#N4ZT\u001fH27B\u0001]q";
      e[23] = "0axD[\u00072sw:叻厫厜叝叉叹佥桱伂佃\n\u0003@Uc`3B\tPe";
      e[24] = "C>q,rIA,~R佌句栵厂佞伏栈句佱伜\u0003hv\u0018\u00150ec-\u001dW";
      e[25] = "?\"Bx:M7,\b-V.\u000f5\f$(Is6\u0014qjp1d\u000e/1\u0012b.\nwV";
      e[26] = "\u007f>R3,\u0013},]M桖县位桘口厎厌伡栉伜 '(Cj-]?/\u001c*";
      e[27] = "ihF6z'kzIH叚压栟栎号压栀压栟佊4q&&b)\u000fy)s?";
      e[28] = "f/,\u0011*\r=\"xPK厼厚发伛厪桒伢桀栋厅ir@7vxRzOb+";
      e[29] = "1\tL\u0016Af3\u001bChf\tcF\u000f\u0018\u001c14\nT\t\"7f\nY\u000f@d,\u000e\u0001h";
      e[30] = "yFDa'6\"K\u0010 F厇桟伦样佄桟伙厅厸佳\u0019\u007f{(\u001f\u0010\"wt}B";
      e[31] = "75Cgg\bu&R4X叻収众叺伇桁佥佐桓栠ZcDn-\u0005&`\u000615";
      e[32] = "@-<R9XCocJ\u0005叧伦伌伂佨栜叧桢伌框55\u001f\u0012)fE{\u001c\u00165";
      e[33] = "0\u0003^\fX-k\u000e\nM9厜栖佣栭桭栠厜佒栧佩t\u0000`aZ\nO\bo4\u0007";
      e[34] = "OOx/\u001fsM]wQ1\u001c\u001d\u0000;!B$JL`0|";
      e[35] = "1y,p'&3k#\u000e-Ib|'g57g` 4Du$\u007f7\u007f:p8xd\u000e";
      e[36] = "B\fj\tS|\u0019\u0001>H2反桤佬參伬佯体桤佬參q\u000b1\u0013U>J\u0003>F\b";
      e[37] = "r]l^sBq\u001f3FO栧厊佼佒叺桖叽厊佼栖9qY$_6Y)_1J";
      e[38] = "\u0019\"R)TR\u001b0]Wf=Km\u0011'\t\u0005\u001c!J67";
      e[39] = "c\u001b)`Wk`Yvxk栎桁桾厉栞伶叔伅伺桓\u0007Up5\u0019sg\rv \f";
      e[40] = "s\u0017Z\u0006\u0000\u0001pU\u0005\u001e<桤伕伶叺似栥传桑厨栠a\fF!\u0013\u0000\u0011BE%\u000f";
      e[41] = "JL\u000eUMc\u0011AZ\u0014,叒厶桨伹佰佱佌桬厲伹-E,\u0004K\u000eWT+\u0005\u0018";
      e[42] = "NW\u000e\u0019VKLE\u0001g叶栽佼栱县伺叶佹叢併|\rR\u001b[D\u0001\u0015UD\u001b";
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'S' && var8 != 223 && var8 != 226 && var8 != 240) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 202) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'P') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'S') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 226) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   public void a(GuiGraphics g, 树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      E();
      this.q();
      树友树树何友何何树友.树何何何友友何友友友 layout = 树友树树何友何何树友.何友何友友友何树树何.k(panel, value, valx, valy, valw);
      ModeValue mv = (ModeValue)value;
      panel.友友何友何树何何树树
         .友何何何何树友树何树
         .s(g.pose(), layout.友友树何何何何树友何, layout.友友友何友树何树树友, layout.树何何何友树友何友树, panel.友友何友何树何何树树.o(panel.友友何友何树何何树树.树友何何友树友友何树, alpha).getRGB());
      Objects.requireNonNull(panel.友友何友何树何何树树);
      float boxY = layout.友树何友何何何树何友 + 8.0F - 6.4F;
      RenderUtils.drawRectangle(g.pose(), layout.友树何树树树友何树何, boxY, layout.友树何树何树何友友何, 12.8F, panel.友友何友何树何何树树.o(panel.友友何友何树何何树树.树何何树何树何树何友, alpha).getRGB());
      panel.友友何友何树何何树树
         .树何何友何树何树友树
         .s(
            g.pose(),
            mv.getValue(),
            layout.友树何树树树友何树何 + 2.0F,
            boxY + 6.4F - panel.友友何友何树何何树树.树何何友何树何树友树.x() / 2.0F,
            panel.友友何友何树何何树树.o(panel.友友何友何树何何树树.树友何何友树友友何树, alpha).getRGB()
         );
      String arrowString = (!(this.友友树树友友树友树何 > 0.5F) || !this.何友树友何何树友何何) && (!(this.友友树树友友树友树何 > 0.01F) || !this.何友树友何何树友何何 || this.友友友友友友何树何何 == 0L)
         ? "v"
         : "^";
      panel.友友何友何树何何树树
         .树何何友何树何树友树
         .s(
            g.pose(),
            arrowString,
            layout.友树何树树树友何树何 + layout.友树何树何树何友友何 - 2.0F - panel.友友何友何树何何树树.树何何友何树何树友树.D(arrowString),
            boxY + 6.4F - panel.友友何友何树何何树树.树何何友何树何树友树.x() / 2.0F,
            panel.友友何友何树何何树树.o(panel.友友何友何树何何树树.树友何何友树友友何树, alpha).getRGB()
         );
      float dropdownContentStartY = boxY + 12.8F + 2.0F;
      this.v(panel, mv, mousex, mousey, layout.友树何树树树友何树何, layout.友树何树何树何友友何, 12.8F, dropdownContentStartY, boxY, 12.8F);
      if (this.友友树树友友树友树何 > 0.001F) {
         float naturalDropdownTotalHeight = this.I(panel, mv);
         float animatedDropdownRenderHeight = naturalDropdownTotalHeight * this.友友树树友友树友树何;
         g.pose().pushPose();
         g.enableScissor(
            (int)layout.友树何树树树友何树何,
            (int)(boxY + 12.8F),
            (int)(layout.友树何树树树友何树何 + layout.友树何树何树何友友何),
            (int)(boxY + 12.8F + animatedDropdownRenderHeight + 1.0F)
         );
         int optionContainerAlpha = (int)(alpha * Mth.clamp(this.友友树树友友树友树何 * 1.5F, 0.0F, 1.0F));
         String[] var23 = mv.n();
         int var24 = var23.length;
         int var25 = 0;
         if (0 < var24) {
            String mode = var23[0];
            if (dropdownContentStartY < boxY + 12.8F + animatedDropdownRenderHeight && dropdownContentStartY + 12.8F > boxY + 12.8F) {
               float hoverProgress = this.友树何树友何友何友何.getOrDefault(mode, 0.0F);
               Color blendedColor = G(panel, hoverProgress);
               RenderUtils.drawRectangle(
                  g.pose(), layout.友树何树树树友何树何, dropdownContentStartY, layout.友树何树何树何友友何, 12.8F, panel.友友何友何树何何树树.o(blendedColor, optionContainerAlpha).getRGB()
               );
               panel.友友何友何树何何树树
                  .树何何友何树何树友树
                  .s(
                     g.pose(),
                     mode,
                     layout.友树何树树树友何树何 + 2.0F,
                     dropdownContentStartY + 6.4F - panel.友友何友何树何何树树.树何何友何树何树友树.x() / 2.0F,
                     panel.友友何友何树何何树树.o(panel.友友何友何树何何树树.树友何何友树友友何树, optionContainerAlpha).getRGB()
                  );
            }

            float optionY = dropdownContentStartY + 14.8F;
            if (!(optionY > boxY + 12.8F + animatedDropdownRenderHeight + 12.8F)) {
               var25++;
               Module.V(new Module[1]);
            }
         }

         g.disableScissor();
         g.pose().popPose();
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 24238;
      if (c[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = b[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])d.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树树何友何何树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         c[var3] = var15;
      }

      return c[var3];
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友树树何友何何树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void v(
      树树树友何何树何友何 panel,
      ModeValue mv,
      int mousex,
      int mousey,
      float controlx,
      float controlw,
      float boxh,
      float dropdownContentStartY,
      float mainBoxVy,
      float mainBoxH
   ) {
      long currentTime = System.currentTimeMillis();
      E();
      String[] var17 = mv.n();
      int var18 = var17.length;
      int var19 = 0;
      if (0 < var18) {
         String mode = var17[0];
         boolean isMouseOverThisOption = false;
         if (this.友友树树友友树友树何 > 0.1F) {
            isMouseOverThisOption = panel.友友何友何树何何树树.g(mousex, mousey, controlx, dropdownContentStartY, controlw, 12.8F)
               && dropdownContentStartY + boxh > mainBoxVy + 12.8F
               && dropdownContentStartY < mainBoxVy + mainBoxH + this.I(panel, mv) * this.友友树树友友树友树何;
         }

         this.何友友树树何何树何树.put(mode, isMouseOverThisOption);
         float currentProgress = this.友树何树友何友何友何.getOrDefault(mode, 0.0F);
         this.何友友树树何何树何树.getOrDefault(mode, false);
         long lastUpdate = this.树友何树友友友何树何.getOrDefault(mode, 0L);
         if (lastUpdate == 0L && Math.abs(currentProgress - 1.0F) > 0.001F) {
            lastUpdate = currentTime - 16L;
         }

         if (lastUpdate != 0L) {
            long deltaTime = currentTime - lastUpdate;
            if (Math.abs(currentProgress - 1.0F) > 0.001F) {
               if (deltaTime > 0L) {
                  float diff = 1.0F - currentProgress;
                  float interpolationFactorRaw = (float)deltaTime / 120.0F * 2.0F;
                  if (interpolationFactorRaw >= 1.0F) {
                     currentProgress = 1.0F;
                  }

                  Mth.clamp(currentProgress + diff * interpolationFactorRaw, 0.0F, 1.0F);
               }

               this.树友何树友友友何树何.put(mode, currentTime);
            }

            currentProgress = 1.0F;
            this.树友何树友友友何树何.remove(mode);
         }

         this.友树何树友何友何友何.put(mode, currentProgress);
         float var10000 = dropdownContentStartY + (boxh + 2.0F);
         var19++;
      }
   }

   private void q() {
      E();
      long currentTime = System.currentTimeMillis();
      if (this.友友友友友友何树何何 == 0L && (this.何友树友何何树友何何 ? this.友友树树友友树友树何 < 1.0F : this.友友树树友友树友树何 > 0.0F)) {
         this.友友友友友友何树何何 = currentTime - 16L;
      }

      if (this.友友友友友友何树何何 != 0L) {
         long deltaTime = currentTime - this.友友友友友友何树何何;
         float targetFactor = this.何友树友何何树友何何 ? 1.0F : 0.0F;
         if (Math.abs(this.友友树树友友树友树何 - targetFactor) > 0.001F) {
            if (deltaTime > 0L) {
               float diff = targetFactor - this.友友树树友友树友树何;
               float interpolationFactorRaw = (float)deltaTime / 150.0F * 2.0F;
               if (interpolationFactorRaw >= 1.0F) {
                  this.友友树树友友树友树何 = targetFactor;
               }

               this.友友树树友友树友树何 += diff * interpolationFactorRaw;
               this.友友树树友友树友树何 = Mth.clamp(this.友友树树友友树友树何, 0.0F, 1.0F);
            }

            this.友友友友友友何树何何 = currentTime;
         }

         this.友友树树友友树友树何 = targetFactor;
         this.友友友友友友何树何何 = 0L;
      }
   }

   public static int E() {
      return 何何树何友何何树友何;
   }

   public static int Y() {
      E();

      try {
         return 8;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public static void L(int var0) {
      何何树何友何何树友何 = var0;
   }

   @Override
   public 何何何友友何树何何何 K(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      树友树树何友何何树友.树何何何友友何友友友 layout = 树友树树何友何何树友.何友何友友友何树树何.k(panel, value, vx, vy, vw);
      E();
      ModeValue mv = (ModeValue)value;
      Objects.requireNonNull(panel.友友何友何树何何树树);
      float mainModeBoxActualRenderY = layout.友树何友何何何树何友 + 8.0F - 6.4F;
      if (panel.友友何友何树何何树树.g(mx, my, layout.友树何树树树友何树何, mainModeBoxActualRenderY, layout.友树何树何树何友友何, 12.8F)) {
         if (btn == 0) {
            List<String> modes = Arrays.asList(mv.n());
            int currentIndex = modes.indexOf(mv.getValue());
            int nextIndex = (currentIndex + 1) % modes.size();
            mv.G(modes.get(nextIndex));
            if (this.何友树友何何树友何何) {
               this.何友树友何何树友何何 = false;
               if (this.友友友友友友何树何何 == 0L) {
                  this.友友友友友友何树何何 = System.currentTimeMillis() - 16L;
               }
            }

            return null;
         }

         if (btn == 1) {
            this.何友树友何何树友何何 = !this.何友树友何何树友何何;
            if (this.友友友友友友何树何何 == 0L) {
               this.友友友友友友何树何何 = System.currentTimeMillis() - 16L;
            }

            return null;
         }
      }

      if (this.何友树友何何树友何何 && this.友友树树友友树友树何 > 0.8F) {
         float optionVisualY = mainModeBoxActualRenderY + 12.8F + 2.0F;
         String[] currentIndex = mv.n();
         int nextIndex = currentIndex.length;
         int var21 = 0;
         if (0 < nextIndex) {
            String mode = currentIndex[0];
            if (optionVisualY < mainModeBoxActualRenderY + 12.8F + this.I(panel, mv) * this.友友树树友友树友树何
               && optionVisualY + 12.8F > mainModeBoxActualRenderY + 12.8F
               && panel.友友何友何树何何树树.g(mx, my, layout.友树何树树树友何树何, optionVisualY, layout.友树何树何树何友友何, 12.8F)
               && btn == 0) {
               mv.G(mode);
               this.何友树友何何树友何何 = false;
               if (this.友友友友友友何树何何 == 0L) {
                  this.友友友友友友何树何何 = System.currentTimeMillis() - 16L;
               }

               return null;
            }

            float var10000 = optionVisualY + 14.8F;
            var21++;
         }
      }

      return null;
   }

   private static String HE_SHU_YOU() {
      return "何炜霖诈骗";
   }

   private static Color G(树树树友何何树何友何 panel, float hoverProgress) {
      Color defaultColor = panel.友友何友何树何何树树.树何何树何树何树何友;
      Color hoverColor = panel.友友何友何树何何树树.树树树友树何友何何树;
      int red = (int)(defaultColor.getRed() + (hoverColor.getRed() - defaultColor.getRed()) * hoverProgress);
      int green = (int)(defaultColor.getGreen() + (hoverColor.getGreen() - defaultColor.getGreen()) * hoverProgress);
      int blue = (int)(defaultColor.getBlue() + (hoverColor.getBlue() - defaultColor.getBlue()) * hoverProgress);
      return new Color(red, green, blue);
   }

   public static class 何友何友友友何树树何 implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[14];
      private static final String[] c = new String[14];
      private static int _何建国230622195906030014 _;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-6864869226281868027L, 250525471383373908L, MethodHandles.lookup().lookupClass()).a(38866071087213L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树树何友何何树友$何友何友友友何树树何" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'a' && var8 != 'n' && var8 != 'B' && var8 != 229) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'X') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 'E') {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'a') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'n') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'B') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static void a() {
         b[0] = "%\f!S\u0010e*LlX\u001ax/\u0011g\u001e\nch伷栞佥厴叁伓伷叄叻桮";
         b[1] = boolean.class;
         c[1] = "java/lang/Boolean";
         b[2] = "\\\u0006\u0016 \u007f_SF[+uBV\u001bPmeY\u0011桹栩桒叛佥佪桹佭厈佅";
         b[3] = "\u0017$['W]\u0018d\u0016,]@\u001d9\u001djM[Z伟传厏右栣伡桛传厏栩";
         b[4] = "R.+,h\u000b]nf'b\u0016X3mar\r\u001f桑収桞栖伱叺伕佐桞双";
         b[5] = int.class;
         c[5] = "java/lang/Integer";
         b[6] = "\u0002Cv;qO\r\u0003;0{R\b^0vkIO格厓桉栏併厪佸伍桉叕\u0004伴另伍厓叕叫伴格桉伍";
         b[7] = "A\u0003~kqLJ\fo$\rUE\u0016ag:eS\u0001mz+ID\f";
         b[8] = "g\u0002b(^xl\rsg?vg\u0006w=";
         b[9] = "}At'W3|\t>G桾栐低桨厍桞伺栐叐桨N>\u00032*\n%?Wf";
         b[10] = "\u0010FQLMIO\u0010\u0016\u0007##+E\\GB\u0018E\u0010Q\r]r";
         b[11] = ")VQ\u000blbtV\u0017O\u0016厑叓佪厮佭栏伏位栮桴0xb*W]\ny*`";
         b[12] = "Z-6\u0004_\r[e|d厬佪佩佀佑桽厬栮佩栄\f^\fX_fm\u0003\u0011\f\u0004";
         b[13] = "\u000b\u0015\u0013+\u0003 S\u0000\u001b*;y7E\u000f(@`\u000b\u001a\\cG\u0010\n\u0016\u0013!K,UEX&;";
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 1;
                  case 1 -> 41;
                  case 2 -> 39;
                  case 3 -> 30;
                  case 4 -> 51;
                  case 5 -> 54;
                  case 6 -> 3;
                  case 7 -> 63;
                  case 8 -> 16;
                  case 9 -> 27;
                  case 10 -> 20;
                  case 11 -> 19;
                  case 12 -> 52;
                  case 13 -> 58;
                  case 14 -> 7;
                  case 15 -> 24;
                  case 16 -> 53;
                  case 17 -> 22;
                  case 18 -> 37;
                  case 19 -> 44;
                  case 20 -> 57;
                  case 21 -> 40;
                  case 22 -> 26;
                  case 23 -> 21;
                  case 24 -> 14;
                  case 25 -> 42;
                  case 26 -> 17;
                  case 27 -> 35;
                  case 28 -> 5;
                  case 29 -> 48;
                  case 30 -> 61;
                  case 31 -> 0;
                  case 32 -> 55;
                  case 33 -> 56;
                  case 34 -> 28;
                  case 35 -> 4;
                  case 36 -> 15;
                  case 37 -> 29;
                  case 38 -> 45;
                  case 39 -> 25;
                  case 40 -> 2;
                  case 41 -> 8;
                  case 42 -> 34;
                  case 43 -> 33;
                  case 44 -> 11;
                  case 45 -> 38;
                  case 46 -> 32;
                  case 47 -> 23;
                  case 48 -> 59;
                  case 49 -> 10;
                  case 50 -> 62;
                  case 51 -> 12;
                  case 52 -> 46;
                  case 53 -> 18;
                  case 54 -> 9;
                  case 55 -> 36;
                  case 56 -> 6;
                  case 57 -> 47;
                  case 58 -> 60;
                  case 59 -> 50;
                  case 60 -> 13;
                  case 61 -> 49;
                  case 62 -> 31;
                  default -> 43;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static RuntimeException a(RuntimeException var0) {
         return var0;
      }

      public static 树友树树何友何何树友.树何何何友友何友友友 k(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, float itemX, float itemY, float itemW) {
         树友树树何友何何树友.Y();
         String valueNameStr = panel.友友何友何树何何树树.树树何树友树何树友树 ? value.r() : value.V();
         float nameStringWidth = panel.友友何友何树何何树树.友何何何何树友树何树.D(valueNameStr);
         Objects.requireNonNull(panel.友友何友何树何何树树);
         float nameWidthUsedForCondition = nameStringWidth + 2.0F;
         float potentialControlWidthIfSideBySide = 106.0F - nameStringWidth - 6.0F;
         boolean isControlBelowName = nameWidthUsedForCondition > itemW * 0.55F || potentialControlWidthIfSideBySide < itemW * 0.25F;
         float nameDrawY = 8.0F - panel.友友何友何树何何树树.友何何何何树友树何树.x() / 2.0F;
         Objects.requireNonNull(panel.友友何友何树何何树树);
         float var10000 = itemY + 12.8F;
         var10000 = itemX + 2.0F;
         var10000 = itemW - 4.0F;
         float ctrlX = itemX + nameStringWidth + 4.0F;
         return new 树友树树何友何何树友.树何何何友友何友友友(isControlBelowName, valueNameStr, 2.0F, nameDrawY, ctrlX, itemY, potentialControlWidthIfSideBySide, 12.8F);
      }

      private static String HE_WEI_LIN() {
         return "解放村多种2队1144号";
      }
   }

   public record 树何何何友友何友友友(
      boolean 树何何何友何树树何友, String 友友树何何何何树友何, float 友友友何友树何树树友, float 树何何何友树友何友树, float 友树何树树树友何树何, float 友树何友何何何树何友, float 友树何树何树何友友何, float 友友友何树何友友何树
   ) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[13];
      private static final String[] c = new String[13];
      private static int _何炜霖230622200409390090 _;

      public 树何何何友友何友友友(
         boolean 树何何何友何树树何友, String 友友树何何何何树友何, float 友友友何友树何树树友, float 树何何何友树友何友树, float 友树何树树树友何树何, float 友树何友何何何树何友, float 友树何树何树何友友何, float 友友友何树何友友何树
      ) {
         this.树何何何友何树树何友 = 树何何何友何树树何友;
         this.友友树何何何何树友何 = 友友树何何何何树友何;
         this.友友友何友树何树树友 = 友友友何友树何树树友;
         this.树何何何友树友何友树 = 树何何何友树友何友树;
         this.友树何树树树友何树何 = 友树何树树树友何树何;
         this.友树何友何何何树何友 = 友树何友何何何树何友;
         this.友树何树何树何友友何 = 友树何树何树何友友何;
         this.友友友何树何友友何树 = 12.8F;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(2268364973855613192L, -6400385786273508571L, MethodHandles.lookup().lookupClass()).a(25552650368194L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public String Z() {
         return this.友友树何何何何树友何;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public float n() {
         return this.友树何树树树友何树何;
      }

      public boolean l() {
         return this.树何何何友何树树何友;
      }

      public float d() {
         return this.友友友何树何友友何树;
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 't' && var8 != 'c' && var8 != 192 && var8 != 207) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 199) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 226) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 't') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'c') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 192) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树树何友何何树友$树何何何友友何友友友" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 42;
                  case 1 -> 25;
                  case 2 -> 5;
                  case 3 -> 61;
                  case 4 -> 17;
                  case 5 -> 46;
                  case 6 -> 16;
                  case 7 -> 24;
                  case 8 -> 47;
                  case 9 -> 1;
                  case 10 -> 20;
                  case 11 -> 18;
                  case 12 -> 36;
                  case 13 -> 43;
                  case 14 -> 53;
                  case 15 -> 44;
                  case 16 -> 26;
                  case 17 -> 32;
                  case 18 -> 28;
                  case 19 -> 34;
                  case 20 -> 48;
                  case 21 -> 30;
                  case 22 -> 56;
                  case 23 -> 21;
                  case 24 -> 50;
                  case 25 -> 2;
                  case 26 -> 59;
                  case 27 -> 0;
                  case 28 -> 14;
                  case 29 -> 37;
                  case 30 -> 13;
                  case 31 -> 62;
                  case 32 -> 52;
                  case 33 -> 49;
                  case 34 -> 6;
                  case 35 -> 41;
                  case 36 -> 19;
                  case 37 -> 15;
                  case 38 -> 54;
                  case 39 -> 11;
                  case 40 -> 8;
                  case 41 -> 57;
                  case 42 -> 27;
                  case 43 -> 3;
                  case 44 -> 31;
                  case 45 -> 55;
                  case 46 -> 10;
                  case 47 -> 45;
                  case 48 -> 29;
                  case 49 -> 38;
                  case 50 -> 60;
                  case 51 -> 51;
                  case 52 -> 40;
                  case 53 -> 12;
                  case 54 -> 7;
                  case 55 -> 23;
                  case 56 -> 22;
                  case 57 -> 58;
                  case 58 -> 35;
                  case 59 -> 39;
                  case 60 -> 9;
                  case 61 -> 63;
                  case 62 -> 33;
                  default -> 4;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "\u001b\\<]RT\u0014\u001cqVXI\u0011Az\u0010HRV栣叙栯栬佮厳佧佇栯叶\u001f桩佧佇佫叶台伭叹叙叵";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = "Z(\tPz:Q'\u0018\u001f\u0007\"B \u0011V";
         b[3] = boolean.class;
         c[3] = "java/lang/Boolean";
         b[4] = "|X`5aPwWqz\u0000^|\\u ";
         b[5] = "$\u0007rdGN~\u0012j_古株佇厯佈伂佺株佇厯\u0015'UX!\r,d[^";
         b[6] = "HI(}\u001b\u001f\u0012\\0F厸厡厵使厌桟伦桻桯叡O>\t\tMCv}\u0007\u000f";
         b[7] = "P>3%ap\n++\u001e参収桷伈伉佃作栔厭伈T'yl\u001f0iwhf\u000e";
         b[8] = "JRI\u0011\u001c\u001d\u0010GQ*县桹伩栠佳栳伡厣厷佤.R\u000e\u000bOX\u0017\u0011\u0000\r";
         b[9] = "p\u0011f\u001ccI*\u0004~'栚佩伓伧参佺栚栭伓厹\u0001\u001d`\u000b#\u0019hG:\f.";
         b[10] = "j\u0015l\u0011P!0\u0000t*右原厗伣栒佷右原伉桧\u000bRB7o\u001f2\u0011L1";
         b[11] = "NB\rTKd\u0014W\u0015o叨栀伭栰桳桶叨佄桩佴j\u0017YrKHSTWt";
         b[12] = "O^\u001d\u001c\u0005Y\u0015K\u0005'桼佹伬佨厹栾厦佹厲栬z_\u0017OJTC\u001c\u0019I";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public float A() {
         return this.友友友何友树何树树友;
      }

      public float P() {
         return this.友树何树何树何友友何;
      }

      public float H() {
         return this.友树何友何何何树何友;
      }

      public float K() {
         return this.树何何何友树友何友树;
      }

      private static String HE_JIAN_GUO() {
         return "职业技术教育中心学校";
      }
   }
}
