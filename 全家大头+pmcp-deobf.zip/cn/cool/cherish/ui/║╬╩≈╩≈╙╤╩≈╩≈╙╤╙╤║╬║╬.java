package cn.cool.cherish.ui;

import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import net.minecraft.client.gui.GuiGraphics;

public interface 何树树友树树友友何何 {
   友树何树友友何树友友 o(树友何树何树何友友友 var1, 树何何何友树树何友何<?> var2, double var3, double var5, int var7, float var8, float var9, float var10);

   float t(树友何树何树何友友友 var1, 树何何何友树树何友何<?> var2);

   void v(GuiGraphics var1, 树友何树何树何友友友 var2, 树何何何友树树何友何<?> var3, float var4, float var5, float var6, int var7, int var8, int var9);
}
