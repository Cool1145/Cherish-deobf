package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.animations.树友何何何友友树何友;
import cn.cool.cherish.utils.render.RenderUtils;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 友树何树友友何何友树 implements 何树友 {
   private static final 树友何何何友友树何友 何友何何何何树何友树;
   private static final 树友何何何友友树何友 友树何友何友何何何何;
   private static final 树友何何何友友树何友 何友何树友何友树何树;
   private static final 树友何何何友友树何友 树友何树友友树何友树;
   private static final long a;
   private static final Object[] b = new Object[9];
   private static final String[] c = new String[9];
   private static int _何树友，和树做朋友 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8818806948109544307L, 8446464229072263676L, MethodHandles.lookup().lookupClass()).a(65412960635880L);
      // $VF: monitorexit
      a = var10000;
      long var2 = a ^ 106666473393041L ^ 42812112453896L;
      a();
      何友何何何何树何友树 = new 树友何何何友友树何友(var2);
      友树何友何友何何何何 = new 树友何何何友友树何友(var2);
      何友何树友何友树何树 = new 树友何何何友友树何友(var2);
      树友何树友友树何友树 = new 树友何何何友友树何友(var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树何树友友何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 226 && var8 != 'u' && var8 != 200 && var8 != 'X') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'H') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 238) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 226) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 200) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void a() {
      b[0] = "F4\u001bj}\u000fItVaw\u0012L)]'g\t\u000b厑栤作栃厫叮伏你参栃";
      b[1] = "wx\u0010\u0011\u001eLx8]\u001a\u0014Q}eV\\\u0004W}zM\\\u0010M}{_\u0006\u0018Lze\u0010档厺佶佁佃叵厹桠佶叟";
      b[2] = "\u0019\u0015\r\u001bL`\u0004\u0000U9\rm\u001c\u0006";
      b[3] = "z.n\n\t\u001aq!\u007fEh\u0014z*{\u001f";
      b[4] = "\u0006d\u0014v\b\u0017\u00142\u0013\u001f桭县伵桀厶叜桭伡厫桀u&E\u0005Uc\u001bx\u0017\u0015\b";
      b[5] = "\u0013{{E+`\u0001-|,伊又传桟叙佱厔栒传桟\u001a\u0015fr@|tK4b\u001d";
      b[6] = "(Z&\u000fjf:\f!f佋収伛伺会伻栏佐厅桾G_'t{])\u0001ud&";
      b[7] = "TF\u0011\u0011\u001fQF\u0010\u0016x厠栣佧厸伭去伾佧佧伦pARC\u0007A\u001e\u001f\u0000SZ";
      b[8] = "\u0018*~\u0018\u0013X\u001fbg\u0016}ma\u0012Ce}\u000bX2/F\u0017\f\u0010+!";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 61;
               case 1 -> 2;
               case 2 -> 29;
               case 3 -> 40;
               case 4 -> 37;
               case 5 -> 57;
               case 6 -> 15;
               case 7 -> 33;
               case 8 -> 32;
               case 9 -> 55;
               case 10 -> 52;
               case 11 -> 11;
               case 12 -> 17;
               case 13 -> 50;
               case 14 -> 43;
               case 15 -> 34;
               case 16 -> 49;
               case 17 -> 36;
               case 18 -> 5;
               case 19 -> 51;
               case 20 -> 44;
               case 21 -> 45;
               case 22 -> 4;
               case 23 -> 38;
               case 24 -> 19;
               case 25 -> 41;
               case 26 -> 1;
               case 27 -> 0;
               case 28 -> 21;
               case 29 -> 22;
               case 30 -> 8;
               case 31 -> 60;
               case 32 -> 58;
               case 33 -> 3;
               case 34 -> 6;
               case 35 -> 59;
               case 36 -> 63;
               case 37 -> 24;
               case 38 -> 48;
               case 39 -> 56;
               case 40 -> 25;
               case 41 -> 26;
               case 42 -> 23;
               case 43 -> 39;
               case 44 -> 12;
               case 45 -> 13;
               case 46 -> 46;
               case 47 -> 7;
               case 48 -> 18;
               case 49 -> 62;
               case 50 -> 53;
               case 51 -> 31;
               case 52 -> 54;
               case 53 -> 35;
               case 54 -> 9;
               case 55 -> 28;
               case 56 -> 30;
               case 57 -> 27;
               case 58 -> 20;
               case 59 -> 14;
               case 60 -> 16;
               case 61 -> 42;
               case 62 -> 10;
               default -> 47;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void a(PoseStack poseStack, float x, float y, float width, float height, float armor, float maxArmor, Color bgColor, Color barColor) {
      long a = 友树何树友友何何友树.a ^ 66542390261246L;
      long ax = a ^ 45280806913790L;
      long axx = a ^ 133567689213515L;
      RenderUtils.drawRoundedRect(poseStack, x, y, width, height, 0.0, bgColor);
      float targetWidth = Math.min(armor / maxArmor, 1.0F) * width;
      a<"È">(-7490195084895134688L, a).y(targetWidth, axx, 80);
      a<"È">(-7490303516839778438L, a).y(targetWidth, axx, 30);
      RenderUtils.drawRoundedRect(poseStack, x, y, a<"È">(-7490303516839778438L, a).y(ax), height, 0.0, barColor);
      RenderUtils.drawRoundedRect(
         poseStack, x, y, a<"È">(-7490195084895134688L, a).y(ax), height, 0.0, new Color(barColor.getRed(), barColor.getGreen(), barColor.getBlue(), 150)
      );
   }

   private static void H(
      PoseStack poseStack, float x, float y, float width, float height, float health, float maxHealth, Color bgColor, Color barColor, Color gradientColor
   ) {
      long a = 友树何树友友何何友树.a ^ 88461883935665L;
      long ax = a ^ 76826140145841L;
      long axx = a ^ 23687248541700L;
      RenderUtils.drawRectangle(poseStack, x, y, width, height, bgColor.getRGB());
      float targetWidth = Math.min(health / maxHealth, 1.0F) * width;
      a<"È">(2757008840613905647L, a).y(targetWidth, axx, 80);
      a<"È">(2756953492883790968L, a).y(targetWidth, axx, 30);
      RenderUtils.drawGradientRectL2R(poseStack, x, y, a<"È">(2756953492883790968L, a).y(ax), height, barColor.getRGB(), gradientColor.getRGB());
      RenderUtils.drawGradientRectL2R(
         poseStack,
         x,
         y,
         a<"È">(2757008840613905647L, a).y(ax),
         height,
         new Color(barColor.getRed(), barColor.getGreen(), barColor.getBlue(), 150).getRGB(),
         new Color(gradientColor.getRed(), gradientColor.getGreen(), gradientColor.getBlue(), 150).getRGB()
      );
   }

   private static String HE_DA_WEI() {
      return "职业技术教育中心学校";
   }
}
