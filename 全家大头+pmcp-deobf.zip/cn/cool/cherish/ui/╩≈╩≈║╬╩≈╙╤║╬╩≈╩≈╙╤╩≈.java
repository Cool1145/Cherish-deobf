package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 树树何树友何树树友树 implements 何树友 {
   private float 何树何何树何树友树何 = Float.MAX_VALUE;
   private float 友何何何友何何友友树 = 0.0F;
   private float 何何何何友树何何何友 = 0.0F;
   private float 何树树何树何友何树友 = 0.0F;
   private float 友友树树友树树何何友 = 0.0F;
   private long 友何树何树树友何何树;
   private float 树友何何友友友树树友 = 1.0F;
   private static final long a;
   private static final Object[] b = new Object[16];
   private static final String[] c = new String[16];
   private static String HE_DA_WEI;

   public 树树何树友何树树友树() {
      this.友何树何树树友何何树 = System.currentTimeMillis();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7601083944515586369L, 7814029224292175850L, MethodHandles.lookup().lookupClass()).a(151994124755226L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public void I(float target) {
      this.友友树树友树树何何友 = target;
   }

   public void J(float maxScroll) {
      this.何树何何树何树友树何 = Math.max(0.0F, maxScroll);
      this.友友树树友树树何何友 = Math.max(Math.min(this.友何何何友何何友友树, this.友友树树友树树何何友), -this.何树何何树何树友树何);
      this.何树树何树何友何树友 = Math.max(Math.min(this.友何何何友何何友友树, this.何树树何树何友何树友), -this.何树何何树何树友树何);
      this.何何何何友树何何何友 = this.何树树何树何友何树友;
   }

   public float e() {
      return this.友友树树友树树何何友;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public void s(float rawScroll) {
      this.何何何何友树何何何友 = rawScroll;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public float h() {
      return this.何树何何树何树友树何;
   }

   public float f() {
      return this.友何何何友何何友友树;
   }

   public float l() {
      return this.何何何何友树何何何友;
   }

   public void l(float scroll) {
      this.何树树何树何友何树友 = scroll;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 3;
               case 1 -> 36;
               case 2 -> 35;
               case 3 -> 29;
               case 4 -> 6;
               case 5 -> 4;
               case 6 -> 33;
               case 7 -> 15;
               case 8 -> 37;
               case 9 -> 46;
               case 10 -> 52;
               case 11 -> 51;
               case 12 -> 45;
               case 13 -> 9;
               case 14 -> 27;
               case 15 -> 32;
               case 16 -> 41;
               case 17 -> 1;
               case 18 -> 43;
               case 19 -> 22;
               case 20 -> 31;
               case 21 -> 60;
               case 22 -> 10;
               case 23 -> 12;
               case 24 -> 25;
               case 25 -> 47;
               case 26 -> 56;
               case 27 -> 7;
               case 28 -> 24;
               case 29 -> 5;
               case 30 -> 49;
               case 31 -> 13;
               case 32 -> 58;
               case 33 -> 21;
               case 34 -> 30;
               case 35 -> 14;
               case 36 -> 2;
               case 37 -> 0;
               case 38 -> 17;
               case 39 -> 55;
               case 40 -> 50;
               case 41 -> 34;
               case 42 -> 42;
               case 43 -> 57;
               case 44 -> 39;
               case 45 -> 18;
               case 46 -> 28;
               case 47 -> 62;
               case 48 -> 59;
               case 49 -> 26;
               case 50 -> 48;
               case 51 -> 54;
               case 52 -> 8;
               case 53 -> 40;
               case 54 -> 23;
               case 55 -> 44;
               case 56 -> 11;
               case 57 -> 19;
               case 58 -> 16;
               case 59 -> 61;
               case 60 -> 63;
               case 61 -> 20;
               case 62 -> 53;
               default -> 38;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "u\u001e\u0011rJ\u0004z^\\y@\u0019\u007f\u0003W?P\u00028桡栮佄栴厠佃桡栮叚栴";
      b[1] = float.class;
      c[1] = "java/lang/Float";
      b[2] = long.class;
      c[2] = "java/lang/Long";
      b[3] = "[9#\u000f4pP62@Hi_,<\u0003\u007fYI;0\u001enu^6";
      b[4] = "L\u0012fS$mCR+X.pF\u000f \u001e>k\u0001桭伝叻伞栓栾伩伝校桚";
      b[5] = "\u0006X6\\\u0014Fsx=S\u0005\t\u000e`.T\f@f";
      b[6] = "\u0007\u001er\b#n\f\u0011cGB`\u0007\u001ag\u001d";
      b[7] = "\u001d'/\u001b8<Hi$t伅桅伬佄框伩桁原桨佄_\bc&Js5\u0014cc";
      b[8] = "\u00140\u000f\"G\"A~\u0004M古厁桡栗厼桔栾伟伥反\u007f1\u001c8Cd\u0015-\u001c}";
      b[9] = "BVhv8,\u0017\u0018c\u0019伅休佳伵叛栀伅休佳厫\u0018ec6\u0015\u0002rycs";
      b[10] = "CZ\u001f;]y\u0016\u0014\u0014T叾佄佲伹厬伉你叚召桽o(\u0006c\u0014\u000e\u00054\u0006&";
      b[11] = "\u0003\u0005k\u001c}\u0019VK`styU\u0006q\u0019wH^Af\u001e\u001dCRQq\u0019,H\u0015Fvs";
      b[12] = "\u0005b-\u001c\f\u0016P,&s伱桯桰企桄伮厯伫桰原]\u000fW\fR67\u0013WI";
      b[13] = "k\u0014~#\u000e*>ZuL厭众栞佷栗桕厭众佚栳\u000eu\u000b!c\u0011d/\u0005.d";
      b[14] = "1\u0010E\u001d2\u0017`\u001fX\u0018\t<\nG\u0006\u0019h\fuB\\Avl";
      b[15] = "+IU\u001f\u001f\u001e~\u0007^p桦厽会伪另厳厼桧桞厴%\fD\u0004|\u001dO\u0010DA";
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 224 && var8 != 222 && var8 != 'k' && var8 != 'f') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'R') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'j') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 224) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 222) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'k') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树何树友何树树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void m(long lastTime) {
      this.友何树何树树友何何树 = lastTime;
   }

   public float v() {
      return this.树友何何友友友树树友;
   }

   public long E() {
      return this.友何树何树树友何何树;
   }

   public float Y() {
      return this.何树树何树何友何树友;
   }

   public void M() {
      this.何何何何友树何何何友 = this.友何何何友何何友友树;
      this.何树树何树何友何树友 = this.友何何何友何何友友树;
      this.友友树树友树树何何友 = this.友何何何友何何友友树;
      this.友何树何树树友何何树 = System.currentTimeMillis();
   }

   public void P(float animationSpeed) {
      this.树友何何友友友树树友 = animationSpeed;
   }

   public void W() {
      树何友何树树何何树树.X();
      float difference = this.友友树树友树树何何友 - this.何树树何树何友何树友;
      if (Math.abs(difference) < 0.1F) {
         this.何树树何树何友何树友 = this.友友树树友树树何何友;
         this.何何何何友树何何何友 = this.友友树树友树树何何友;
      } else {
         long currentTime = System.currentTimeMillis();
         float deltaTime = Math.min(0.1F, (float)(currentTime - this.友何树何树树友何何树) / 1000.0F);
         this.友何树何树树友何何树 = currentTime;
         float step = difference * Math.min(1.0F, deltaTime * this.树友何何友友友树树友 * 10.0F);
         this.何树树何树何友何树友 += step;
         this.何何何何友树何何何友 = this.何树树何树何友何树友;
      }
   }

   public void R(float minScroll) {
      this.友何何何友何何友友树 = minScroll;
   }

   private static String HE_JIAN_GUO() {
      return "我是何树友";
   }

   public void O(float delta) {
      this.友友树树友树树何何友 += delta;
      this.友友树树友树树何何友 = Math.max(Math.min(this.友何何何友何何友友树, this.友友树树友树树何何友), -this.何树何何树何树友树何);
      this.友何树何树树友何何树 = System.currentTimeMillis();
   }
}
