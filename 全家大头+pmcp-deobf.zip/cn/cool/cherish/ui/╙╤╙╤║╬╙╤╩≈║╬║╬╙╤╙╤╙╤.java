package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.友友何友何何树何树树;
import cn.cool.cherish.utils.animations.何何友树友树友树树何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;

public class 友友何友树何何友友友 implements IWrapper, 何树友 {
   private static final Map<MobEffect, 何何友树友树友树树何> 友何友树何何树友何何;
   private static final Map<MobEffect, cn.cool.cherish.utils.animations.何树友友何友友何树树> 树何何友何树树树友友;
   private static final Map<MobEffect, MobEffectInstance> 何树树何树何友树何何;
   private static String[] 何何何树树友何树何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[24];
   private static final String[] g = new String[24];
   private static String LIU_YA_FENG;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(4903842879004539418L, -526028856803446193L, MethodHandles.lookup().lookupClass()).a(226598531728529L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 23268948036273L;
      a();
      b<"ß">(null, 2653632745429691207L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[8];
      int var5 = 0;
      String var4 = "\u0005\u0096² \u0018Z/Dûf\u009b\u0092÷\u0007g-\u0010.íJmhÄÎ¾zVÏ\u0095÷È\u008d¾\u0010Ey×ø5\u0016¥C\"ta&\u001c\u001bðè\u0010Ä½¤FÇ QVM£\u009a¢',\"Ì\u0010\"ÎpÅn\u0080Ý\u0095C\u0010,Ü×8}Ñ\u0010q:\u0001B\\.\u001cë¢4¢ÛÄ\u0088êÅ";
      byte var6 = 101;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = b(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     b = var7;
                     c = new String[8];
                     友何友树何何树友何何 = new HashMap<>();
                     树何何友何树树树友友 = new HashMap<>();
                     何树树何树何友树何何 = new HashMap<>();
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "TÜ\u001cdÖ\u0081\u0097IÙ÷s}ÓIç6\u0010i\u0084#fÜÆJ\u0093,\u008a®á©\u0010ö\u0006";
                  var6 = 33;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 33;
               case 1 -> 15;
               case 2 -> 31;
               case 3 -> 29;
               case 4 -> 54;
               case 5 -> 39;
               case 6 -> 18;
               case 7 -> 34;
               case 8 -> 22;
               case 9 -> 27;
               case 10 -> 14;
               case 11 -> 13;
               case 12 -> 4;
               case 13 -> 20;
               case 14 -> 56;
               case 15 -> 43;
               case 16 -> 9;
               case 17 -> 59;
               case 18 -> 57;
               case 19 -> 8;
               case 20 -> 62;
               case 21 -> 16;
               case 22 -> 58;
               case 23 -> 63;
               case 24 -> 50;
               case 25 -> 48;
               case 26 -> 11;
               case 27 -> 49;
               case 28 -> 7;
               case 29 -> 51;
               case 30 -> 53;
               case 31 -> 36;
               case 32 -> 35;
               case 33 -> 46;
               case 34 -> 21;
               case 35 -> 45;
               case 36 -> 55;
               case 37 -> 23;
               case 38 -> 17;
               case 39 -> 24;
               case 40 -> 19;
               case 41 -> 38;
               case 42 -> 25;
               case 43 -> 60;
               case 44 -> 28;
               case 45 -> 42;
               case 46 -> 37;
               case 47 -> 5;
               case 48 -> 12;
               case 49 -> 47;
               case 50 -> 61;
               case 51 -> 1;
               case 52 -> 32;
               case 53 -> 3;
               case 54 -> 44;
               case 55 -> 26;
               case 56 -> 52;
               case 57 -> 30;
               case 58 -> 40;
               case 59 -> 10;
               case 60 -> 2;
               case 61 -> 41;
               case 62 -> 0;
               default -> 6;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友何友树何何友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'k' && var8 != 229 && var8 != 200 && var8 != 231) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 228) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 223) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'k') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 229) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 200) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static String[] x() {
      return 何何何树树友何树何何;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static void n(List<MobEffectInstance> currentEffects) {
      long a = 友友何友树何何友友友.a ^ 18916338097373L;
      long ax = a ^ 9159248149304L;
      b<"ß">(3656758473919420797L, a);
      Set activeEffectsSet = currentEffects.stream().map(MobEffectInstance::getEffect).collect(Collectors.toSet());
      Iterator var7 = currentEffects.iterator();
      if (var7.hasNext()) {
         MobEffectInstance instance = (MobEffectInstance)var7.next();
         MobEffect effect = instance.getEffect();
         b<"È">(3654998723270071006L, a).put(effect, instance);
         b<"È">(3655072729198345034L, a).computeIfAbsent(effect, k -> {
            long axx = 友友何友树何何友友友.a ^ 104692049610262L ^ 135256597372273L;
            return new 何何友树友树友树树何(300, 1.0, axx, 1.8F);
         });
         b<"È">(3654695358638766292L, a).computeIfAbsent(effect, k -> {
            long axx = 友友何友树何何友友友.a ^ 11404608030547L ^ 68738009268639L;
            return new cn.cool.cherish.utils.animations.何树友友何友友何树树(axx, 300, 1.0);
         });
      }

      var7 = b<"È">(3655072729198345034L, a).entrySet().iterator();
      if (var7.hasNext()) {
         Entry<MobEffect, 何何友树友树友树树何> entry = (Entry<MobEffect, 何何友树友树友树树何>)var7.next();
         entry.getValue().H(new Object[]{activeEffectsSet.contains(entry.getKey()) ? b<"È">(3655155082465484997L, a) : b<"È">(3656894921027149582L, a), ax});
      }

      b<"È">(3655072729198345034L, a)
         .entrySet()
         .removeIf(
            entryx -> {
               long axxx = 友友何友树何何友友友.a ^ 119441449425904L;
               long ax = axxx ^ 59190925839301L;
               long axxxx = axxx ^ 122494903727989L;
               b<"ß">(-751511933623263664L, axxx);
               boolean finished = ((何何友树友树友树树何)entryx.getValue()).Y(new Object[]{ax}) == b<"È">(-751367644053628893L, axxx)
                  && ((何何友树友树友树树何)entryx.getValue()).g(new Object[]{axxxx});
               if (finished) {
                  MobEffect key = (MobEffect)entryx.getKey();
                  b<"È">(-750575542413524999L, axxx).remove(key);
                  b<"È">(-750882412217362957L, axxx).remove(key);
               }

               return finished;
            }
         );
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "g\u0017v7A\u001chW;<K\u0001m\n0z[\u001a*厲厓企句桢佑伬厓原句";
      f[1] = "(e\u0017jmG]E\u001ce|\b ]\u000fbuAH";
      f[2] = "66\u0005<S+9vH7Y6<+CqQ+1-G:\u0012-8(GqX-&(G>Ej厞厓佾厔佩休桄伍栺桎";
      f[3] = "2)\u001b\u001e/\u000e,!\u0001QL\u001a(";
      f[4] = "\u0001@\u000e\u000f$S\u000e\u0000C\u0004.N\u000b]HB=]\u000e[EB\"Q\u0012B\u000e!$X\u0007xA\u0000>Y";
      f[5] = "gb\\\u0011:ElmM^F\\cwC\u001dqlu`O\u0000`@bm";
      f[6] = "$ZuU\u0001\n9O-w@\u0007!I";
      f[7] = "o2\u00014\\F`rL?V[e/GyEH`)JyZD|0\u0001\u0015\\F`9N9eH`)J";
      f[8] = "}\u0012\ty\u0018+\b2\u0002v\tdu*\u0011q\u0000-\u001d";
      f[9] = void.class;
      g[9] = "java/lang/Void";
      f[10] = "\u0012:j3j/\u001dz'8`2\u0018',~p4\u001887~d.\u00189%$l/\u001f'j厛佐压桠桅桕厛栔伕厺";
      f[11] = "Y;\r.,gR4\u001caMiY?\u0018;";
      f[12] = "\f/;MQbZ$90H\u0012T`9K\u0007b\u00038<M8";
      f[13] = "~$|\u0012^\b\u007f)b\u0019=桱桞伄栙厪你伵会厚栙i\u0007Vx5~XOVx\"";
      f[14] = "2\u000eY-+\u0014aH]tB佴栔株佯栋厁只佐台佯\u0012}\u0014f\f[/.RbU";
      f[15] = "K\u0007\bD\n\u001b\u001d\f\n9\u001ek\u0013H\nB\\\u001bD\u0010\u000fDcU@\t\u001a\u0002\n\u0002K\u0010\u00019";
      f[16] = "\u0012dol1XDom\u00111(Ovt)bALiahX\u0013\u0017m4+1\u0010\bxu\u0011";
      f[17] = "\u0014`\u001crh%Bk\u001e\u000f栘伈伯叒伢栖栘桌厱叒\u007f5?j\u001eoN}?j\t";
      f[18] = "\u0002y>/\u0002J\u000fp(18{~X\u001e\u001a8\u0018^e:mV\u0015Ws$";
      f[19] = "iv\u001bX)\u0016h{\u0005SJ厵桉又桾佾众伫桉又桾#w\u001di6\u000b\u001bt\u001f1a";
      f[20] = "V\u000e<=<8\u0000\u0005>@厖伕右桦伂伝桌压佭伢_zkw\\\u0001n2kwK";
      f[21] = "\u0006R\u000e^Q*PY\f#佥桃桹佾桴佾叻桃伽佾m\u0019\u0006e\f]\\Q\u0006e\u001b";
      f[22] = "gYe44\u0006fT{?W桿厝佹佄厌厔伻伃佹叚Om\u00149]}5&\u0014.J";
      f[23] = "$-\u001b\b\u0014\u007fwk\u001fQ}伟栂栉桩佪传厁变叓厳7B\u007fp/\u0019\n\u00119tv";
   }

   public static void a(PoseStack poseStack, List<MobEffectInstance> effects, float x, float y, 友友何友何何树何树树 module) {
      long a = 友友何友树何何友友友.a ^ 82950201313733L;
      b<"ß">(7468991490799799397L, a);
      if (mc.player != null) {
         n(effects);
         Cherish.instance.h().n(18);
         Cherish.instance.h().n(24);
         new GuiGraphics(mc, mc.renderBuffers().bufferSource());

         for (MobEffect effectKey : new HashMap(b<"È">(7467310186949111378L, a)).keySet()) {
            MobEffectInstance var10000 = (MobEffectInstance)b<"È">(7467376910055540678L, a).get(effectKey);
         }
      }
   }

   private static String a(MobEffectInstance potionEffect) {
      return potionEffect.getEffect().getDisplayName().getString() + " " + o(potionEffect.getAmplifier() + 1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友友何友树何何友友友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 31184;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友友何友树何何友友友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String o(int num) {
      long a = 友友何友树何何友友友.a ^ 56411346723251L;
      b<"ß">(-8083600626144418797L, a);
      if (num <= 0) {
         return "";
      } else {
         int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
         String[] symbols = new String[]{
            "M",
            a<"m">(4482, 4687683313885144960L ^ a),
            "D",
            a<"m">(30830, 5356353303019982442L ^ a),
            "C",
            a<"m">(4764, 5115692847477843098L ^ a),
            "L",
            a<"m">(24834, 413987850866857730L ^ a),
            "X",
            a<"m">(35, 5136690577435817510L ^ a),
            "V",
            a<"m">(31933, 168910652096023228L ^ a),
            "I"
         };
         StringBuilder sb = new StringBuilder();
         int i = 0;
         if (0 < values.length && num > 0) {
            if (values[0] <= num) {
               int var10000 = num - values[0];
               sb.append(symbols[0]);
            }

            i++;
         }

         return sb.toString();
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void u(String[] var0) {
      何何何树树友何树何何 = var0;
   }

   private static String HE_DA_WEI() {
      return "何炜霖国企变私企";
   }
}
