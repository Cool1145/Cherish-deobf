package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.NumberValue;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 树友树何树何友何树何 implements 何树树友树树友友何何, 何树友 {
   private float 树友何树何何何树树树;
   private final float 友树何友何友何友树树;
   private final float 友友何树树树何何何友;
   private long 友友树树友何何何何树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[27];
   private static final String[] f = new String[27];
   private static String HE_DA_WEI;

   public 树友树何树何友何树何() {
      long a = 树友树何树何友何树何.a ^ 71815374959001L;
      super();
      b<"Õ">(this, -1.0F, 5698564241029995465L, a);
      this.友树何友何友何友树树 = 16.0F;
      this.友友何树树树何何何友 = 10.0F;
      b<"Õ">(this, 0L, 5699090381712975667L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(8322036005503389163L, -9041191968079969905L, MethodHandles.lookup().lookupClass()).a(112367838773550L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 90884528317229L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 16;
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "3e\u0099(ÊÔ\u0005PÛ@È\u0096¯À\u0090\"\u0010\u0098\u0013)hX¬\u0007g|¼\u000fÁe\u0002¬Ð".substring(++var4, var4 + var5).getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 33) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "3e\u0099(ÊÔ\u0005PÛ@È\u0096¯À\u0090\"\u0010\u0098\u0013)hX¬\u0007g|¼\u000fÁe\u0002¬Ð".charAt(var4);
      }
   }

   public void V(double mouseX, float valueX, float valueWidth, NumberValue numberValue) {
      long a = 树友树何树何友何树何.a ^ 1032813117221L;
      double minVal = numberValue.b().doubleValue();
      double maxVal = numberValue.p().doubleValue();
      BigDecimal stepBigDecimal = BigDecimal.valueOf(numberValue.I().doubleValue());
      b<"¥">(-4491939569605303203L, a);
      BigDecimal rawValueBigDecimal = BigDecimal.valueOf(minVal + (maxVal - minVal) * Mth.clamp((mouseX - valueX) / 106.0, 0.0, 1.0));
      BigDecimal roundedValueBigDecimal = rawValueBigDecimal.divide(stepBigDecimal, 0, b<"u">(-4491582152778062849L, a)).multiply(stepBigDecimal);
      if (numberValue.getValue() instanceof Double) {
         numberValue.J(roundedValueBigDecimal.doubleValue());
      }

      if (numberValue.getValue() instanceof Float) {
         numberValue.J(roundedValueBigDecimal.floatValue());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友树何树何友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private void b(NumberValue nv) {
      long a = 树友树何树何友何树何.a ^ 31136447778275L;
      float min = nv.b().floatValue();
      b<"¥">(8317990608316274331L, a);
      float max = nv.p().floatValue();
      float curr = nv.getValue().floatValue();
      float progress = max - min == 0.0F ? 0.0F : (curr - min) / (max - min);
      if (b<"í">(this, 8317868125304858547L, a) == -1.0F) {
         b<"Õ">(this, progress, 8317868125304858547L, a);
         b<"Õ">(this, System.currentTimeMillis(), 8317411291452529481L, a);
      } else {
         long currentTime = System.currentTimeMillis();
         long deltaTime = currentTime - b<"í">(this, 8317411291452529481L, a);
         b<"Õ">(this, currentTime, 8317411291452529481L, a);
         if (Math.abs(b<"í">(this, 8317868125304858547L, a) - progress) > 0.001F) {
            float diff = progress - b<"í">(this, 8317868125304858547L, a);
            float interpolationFactor = (float)deltaTime / 150.0F * 2.0F;
            if (interpolationFactor >= 1.0F) {
               b<"Õ">(this, progress, 8317868125304858547L, a);
            }

            b<"Õ">(this, b<"í">(this, 8317868125304858547L, a) + diff * interpolationFactor, 8317868125304858547L, a);
            b<"Õ">(this, Mth.clamp(b<"í">(this, 8317868125304858547L, a), 0.0F, 1.0F), 8317868125304858547L, a);
         }
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void n() {
      long a = 树友树何树何友何树何.a ^ 85055643599161L;
      b<"Õ">(this, 0.0F, -21020499893834903L, a);
      b<"Õ">(this, System.currentTimeMillis(), -20494301647775853L, a);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 237 && var8 != 213 && var8 != 'u' && var8 != 196) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 214) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 165) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 237) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 213) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20575;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树友树何树何友何树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      e[0] = "}g|GRDr'1LXYwz:\nHB0栘厙可叶栺栏栘桃栵佨";
      e[1] = boolean.class;
      f[1] = "java/lang/Boolean";
      e[2] = "b0.\t}\u0004\u007f%v+<\tg#";
      e[3] = "mBr\b\nQb\u0002?\u0003\u0000Lg_4E\u0010W 栽厗伾桴佫栟佹厗厠厮";
      e[4] = "d\tL\\?;kI\u0001W5&n\u0014\n\u0011&5k\u0012\u0007\u001199w\u000bLq%9e\u0002\u0010i18r\u0002";
      e[5] = "eRQ\u001eG^j\u0012\u001c\u0015MCoO\u0017S]X(栭厴桬佽栠体号伪桬佽";
      e[6] = "/83\u0010KP$7\"_7I+-,\u001c\u0000y=: \u0001\u0011U*7";
      e[7] = "\\]\tsT|S\u001dDx^aV@O>Nz\u0011司佲佅株变佪佦佲佅株";
      e[8] = float.class;
      f[8] = "java/lang/Float";
      e[9] = "Iu$3i0F5i8c-Chb~s6\u0004栊叁伅体厔栻栊栛桁体";
      e[10] = int.class;
      f[10] = "java/lang/Integer";
      e[11] = long.class;
      f[11] = "java/lang/Long";
      e[12] = "(5f\u0012a0# x]\u001d27:t\u001a!:\u000f;t\u0016";
      e[13] = "-\u001b}c\u0018h&\u0014l,yf-\u001fhv";
      e[14] = "]\u001fm\u007f9\u0019\u0005\u001cl\u0018桅佹厥似反叛企栽伻桸\u000e!aV\u0019\u0001vbe\u0019\b";
      e[15] = "n5\u001feH\u000166\u001e\u0002叮佡桌伖伡佟佰叿桌厈|;M\u0003o+\u0005\u007fHC>";
      e[16] = "s$^Mx;. U\u001c\u0002优厊原栭厳佟桜伔桅号p89/ HAh~w\"";
      e[17] = "\u000b\u001a\u000elQ\u007fJ\u001d\u0017c6叅右桤桭叟佫佛佭传桭\u001c\u0006?BE\u0004uGzSG";
      e[18] = "uZ!Aj\u0003-Y &佒栧桗佹厁栿双栧伓佹B\u001fo\u0001tD;[jA%";
      e[19] = "w|bC\u0007.6{{L`>L'&B\u00195,f(M]Wp%iJ\u000271+f\u000e`";
      e[20] = "\u001aBa<g%GFjm\u001d厘口栣栒参叞桂佽栣栒\u0001&%C]n<~&B";
      e[21] = "#\u0017\u000b^g\b{\u0014\n9佟叶叛伴厫栠佟栬栁伴h\u00049\u000b'\fW\u0001sUv";
      e[22] = "\u0013B:1n\u0012]Yjc\u0013oj`\u001a\bNw#\u001421}R\u001eZ)a/";
      e[23] = "8\u001b\u001ei.y`\u0018\u001f\u000e厈伙栚伸厾栗厈厇佞伸}43.>\u001f\u0003i7%o";
      e[24] = "|-f\u007f|5=*\u007fp\u001b桕厄众栅佒但休桞桓栅\u000f&<++zjf>*8";
      e[25] = "FW6Ht\u001dA\u0002#SM\u0005x\u0001 \u0013t^\u001dU+T5d";
      e[26] = "\n?s@]f\rjf[dP4ie\u001b]%Q=n\\\u001c\u001f";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 28;
               case 1 -> 19;
               case 2 -> 32;
               case 3 -> 13;
               case 4 -> 43;
               case 5 -> 22;
               case 6 -> 55;
               case 7 -> 31;
               case 8 -> 25;
               case 9 -> 9;
               case 10 -> 10;
               case 11 -> 20;
               case 12 -> 27;
               case 13 -> 50;
               case 14 -> 51;
               case 15 -> 12;
               case 16 -> 23;
               case 17 -> 14;
               case 18 -> 62;
               case 19 -> 42;
               case 20 -> 38;
               case 21 -> 15;
               case 22 -> 45;
               case 23 -> 29;
               case 24 -> 40;
               case 25 -> 6;
               case 26 -> 21;
               case 27 -> 47;
               case 28 -> 5;
               case 29 -> 18;
               case 30 -> 17;
               case 31 -> 49;
               case 32 -> 37;
               case 33 -> 35;
               case 34 -> 7;
               case 35 -> 54;
               case 36 -> 56;
               case 37 -> 24;
               case 38 -> 52;
               case 39 -> 11;
               case 40 -> 53;
               case 41 -> 30;
               case 42 -> 58;
               case 43 -> 34;
               case 44 -> 16;
               case 45 -> 4;
               case 46 -> 41;
               case 47 -> 44;
               case 48 -> 60;
               case 49 -> 59;
               case 50 -> 57;
               case 51 -> 48;
               case 52 -> 63;
               case 53 -> 0;
               case 54 -> 33;
               case 55 -> 8;
               case 56 -> 36;
               case 57 -> 61;
               case 58 -> 26;
               case 59 -> 1;
               case 60 -> 2;
               case 61 -> 3;
               case 62 -> 39;
               default -> 46;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友树何树何友何树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @Override
   public 友树何树友友何树友友 o(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      long a = 树友树何树何友何树何.a ^ 68453958658935L;
      b<"¥">(1584011993370515902L, a);
      NumberValue nv = (NumberValue)value;
      float sliderClickY = vy + 3.0F;
      if (mx >= vx && mx <= vx + vw && my >= sliderClickY && my <= sliderClickY + 10.0F) {
         b<"Õ">(panel, nv, 1583362393717235239L, a);
         b<"Õ">(b<"í">(panel, 1583041825877016858L, a), panel, 1583263335656895537L, a);
         this.V(mx, vx, vw, nv);
      }

      return null;
   }

   @Override
   public float t(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value) {
      return 16.0F;
   }

   @Override
   public void v(GuiGraphics g, 树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      long a = 树友树何树何友何树何.a ^ 132124208532789L;
      b<"¥">(-5496339776215263667L, a);
      NumberValue nv = (NumberValue)value;
      this.b(nv);
      float sliderBarY = valy + 3.0F;
      RenderUtils.drawRectangle(
         g.pose(),
         valx,
         sliderBarY,
         valw,
         10.0F,
         b<"í">(panel, -5495976699665586344L, a).Z(b<"í">(b<"í">(panel, -5495976699665586344L, a), -5495350224208155535L, a), alpha).getRGB()
      );
      RenderUtils.drawRectangle(
         g.pose(),
         valx,
         sliderBarY,
         valw * b<"í">(this, -5496251341842159771L, a),
         10.0F,
         b<"í">(panel, -5495976699665586344L, a).Z(HUD.instance.getColor(4), alpha).getRGB()
      );
      String valueText = String.format(
         nv.I().doubleValue() % 1.0 == 0.0 ? a<"u">(5689, 6675948551012185561L ^ a) : a<"u">(5587, 8432835258398766642L ^ a), nv.getValue().doubleValue()
      );
      String text = (b<"í">(b<"í">(panel, -5495976699665586344L, a), -5495285783234480290L, a) ? nv.v() : nv.W()) + " " + valueText;
      b<"í">(b<"í">(panel, -5495976699665586344L, a), -5496033927971002283L, a)
         .m(
            g.pose(),
            text,
            valx + 2.0F,
            sliderBarY + 5.0F - b<"í">(b<"í">(panel, -5495976699665586344L, a), -5496033927971002283L, a).K() / 2.0F,
            b<"í">(panel, -5495976699665586344L, a).Z(b<"í">(b<"í">(panel, -5495976699665586344L, a), -5495569715058938412L, a), alpha).getRGB()
         );
      if (b<"í">(panel, -5495660527950628763L, a) == nv && b<"í">(b<"í">(panel, -5495976699665586344L, a), -5495895723488767373L, a) == panel) {
         this.V(mousex, valx, valw, nv);
      }
   }

   private static String HE_DA_WEI() {
      return "刘凤楠230622109211173513";
   }
}
