package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树何何树树树树树友 implements IWrapper, 何树友 {
   public static int 树何树友树友何树友何;
   public static int 何树友何友树友友友何;
   public static long 友树友友树友何友树友;
   public static long 友何何树树树友友何何;
   public static boolean 何何何友何友何何友何;
   private static Module[] 何何树树树树友树友何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Long[] g;
   private static final Map h;
   private static final Object[] i = new Object[24];
   private static final String[] j = new String[24];
   private static String LIU_YA_FENG;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(2211411293768561231L, -2882202448919936390L, MethodHandles.lookup().lookupClass()).a(271488028758100L);
      // $VF: monitorexit
      a = var10000;
      a();
      d(null);
      Cipher var11;
      Cipher var21 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(27738636956331L << var12 * 8 >>> 56);
      }

      var21.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[9];
      int var16 = 0;
      String var15 = "8w\\«lKS&\u008e=TÑØÌN%\u0010\u0013z\u009f*«\u0089\u0081Z·g-îg{Ãt\u0010\u0012Ô\u0083PF´QKëÁ|\u0087\"¥û^\u0010óÙ¤a\u0019V\u00ad\u0019\u00825½Ó³\u0005ÇH\u0010Zõì \u001e<\u001fË\u0012b<ö\u0089å];\u0010\u0093vÆwÙËAg\u008a{%'nõRc \u000fÃ¶Ste¸Fâ¯£\u0004ONÖØ#,#\u0080\f]\u0018¡\u0016\u00916È|¸õO";
      short var17 = 134;
      char var14 = 16;
      int var20 = -1;

      label45:
      while (true) {
         String var22 = var15.substring(++var20, var20 + var14);
         int var10001 = -1;

         while (true) {
            String var31 = b(var11.doFinal(var22.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var31;
                  if ((var20 += var14) >= var17) {
                     b = var18;
                     c = new String[9];
                     h = new HashMap(13);
                     Cipher var0;
                     Cipher var24 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(27738636956331L << var1 * 8 >>> 56);
                     }

                     var24.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     int var3 = 0;
                     byte var2 = 0;

                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = "\u0092Û} <m\u009dSù|õ\r\u007fÃÂ\u0005·\u0089\u00adX%t[\u0099".substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var36 = -1;
                        var6[var10001] = var10004;
                     } while (var2 < 24);

                     f = var6;
                     g = new Long[3];
                     树何树友树友何树友何 = 0;
                     何树友何友树友友友何 = 0;
                     友何何树树树友友何何 = 0L;
                     何何何友何友何何友何 = false;
                     友树友友树友何友树友 = System.currentTimeMillis();
                     return;
                  }

                  var14 = var15.charAt(var20);
                  break;
               default:
                  var18[var16++] = var31;
                  if ((var20 += var14) < var17) {
                     var14 = var15.charAt(var20);
                     continue label45;
                  }

                  var15 = "\u009eõgP?2\u0089fÒø\u0096õ\u009aªá\u0090íµ6DÇ\u008e\nÏ EYf¹¾Á\u0096\u001d-Ö(\u001a4U4Ãs\u0098Ág\u0082ðÑ/Ô.ëüI¿b\u0087";
                  var17 = 57;
                  var14 = 24;
                  var20 = -1;
            }

            var22 = var15.substring(++var20, var20 + var14);
            var10001 = 0;
         }
      }
   }

   public static void J() {
      t();
      if (mc.level != null && mc.player != null) {
         if (何何何友何友何何友何) {
            return;
         }

         友树友友树友何友树友 = System.currentTimeMillis();
         何何何友何友何何友何 = true;
      }

      if (何何何友何友何何友何) {
         友何何树树树友友何何 = 友何何树树树友友何何 + (System.currentTimeMillis() - 友树友友树友何友树友);
         何何何友何友何何友何 = false;
      }
   }

   public static String V(long milliseconds) {
      long seconds = milliseconds / 1000L;
      long minutes = seconds / 60L;
      t();
      long hours = minutes / 60L;
      seconds %= 60L;
      minutes %= 60L;
      if (hours > 0L) {
         return String.format("%dh %dm %ds", hours, minutes, seconds);
      } else if (minutes > 0L) {
         return String.format("%dm %ds", minutes, seconds);
      } else {
         String var10000 = String.format("%ds", seconds);
         if (Module.Z() == null) {
            d(new Module[5]);
         }

         return var10000;
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (j[var4] != null) {
         return var4;
      } else {
         Object var5 = i[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 11;
               case 1 -> 49;
               case 2 -> 46;
               case 3 -> 3;
               case 4 -> 34;
               case 5 -> 27;
               case 6 -> 30;
               case 7 -> 56;
               case 8 -> 41;
               case 9 -> 15;
               case 10 -> 17;
               case 11 -> 1;
               case 12 -> 6;
               case 13 -> 40;
               case 14 -> 63;
               case 15 -> 55;
               case 16 -> 54;
               case 17 -> 16;
               case 18 -> 43;
               case 19 -> 36;
               case 20 -> 39;
               case 21 -> 31;
               case 22 -> 44;
               case 23 -> 23;
               case 24 -> 33;
               case 25 -> 14;
               case 26 -> 48;
               case 27 -> 28;
               case 28 -> 57;
               case 29 -> 20;
               case 30 -> 52;
               case 31 -> 4;
               case 32 -> 32;
               case 33 -> 42;
               case 34 -> 24;
               case 35 -> 47;
               case 36 -> 26;
               case 37 -> 62;
               case 38 -> 25;
               case 39 -> 29;
               case 40 -> 9;
               case 41 -> 21;
               case 42 -> 7;
               case 43 -> 37;
               case 44 -> 12;
               case 45 -> 0;
               case 46 -> 59;
               case 47 -> 10;
               case 48 -> 35;
               case 49 -> 61;
               case 50 -> 60;
               case 51 -> 38;
               case 52 -> 8;
               case 53 -> 51;
               case 54 -> 45;
               case 55 -> 50;
               case 56 -> 2;
               case 57 -> 5;
               case 58 -> 19;
               case 59 -> 58;
               case 60 -> 13;
               case 61 -> 22;
               case 62 -> 53;
               default -> 18;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            j[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6115;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])h.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            h.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/何树何何树树树树树友", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树何何树树树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 199 && var8 != 'g' && var8 != 220 && var8 != 229) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 165) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Y') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 199) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'g') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 220) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   public static void x(PoseStack poseStack, float x, float y) {
      友树何友何友何树树树 fontManager = Cherish.instance.t();
      J();
      c<"Y">(-2328996368322197535L, 72173378396072L);
      String playerName = mc.player.getDisplayName().getString();
      String playerText = "Player: " + playerName;
      String killsText = "Kills: " + c<"Ü">(-2329484392716672202L, 72173378396072L);
      String winsText = "Wins: " + c<"Ü">(-2329190133682235376L, 72173378396072L);
      String timeText = "Time: ," + V(P());
      float titleHeight = fontManager.C(20).x();
      float lineHeight = fontManager.C(18).x();
      String killsWinsText = killsText + "" + winsText;
      float maxWidth = Math.max(
         Math.max(fontManager.C(20).D("Session Info"), fontManager.C(18).D(playerText)),
         Math.max(fontManager.C(18).D(killsWinsText), fontManager.C(18).D(timeText))
      );
      float totalWidth = maxWidth + 24.0F + 30.0F;
      float totalHeight = titleHeight + lineHeight * 3.0F + 12.0F + 24.0F;
      Color glassColor = new Color(0, 0, 0, 80);
      Color borderColor = new Color(255, 255, 255, 100);
      ShaderUtils.M(132138673613539L, poseStack, x, y, totalWidth, totalHeight, 6.0F, 1.0F, borderColor, glassColor, 10.0F);
      float textX = x + 12.0F;
      float textY = y + 12.0F;
      fontManager.C(20).q(poseStack, "Session Info", textX, textY, c<"Ü">(-2329253809982724824L, 72173378396072L).getRGB());
      textY += titleHeight + 4.0F;
      fontManager.C(18).q(poseStack, playerText, textX, textY, c<"Ü">(-2329253809982724824L, 72173378396072L).getRGB());
      textY += lineHeight + 4.0F;
      fontManager.C(18).q(poseStack, killsText, textX, textY, c<"Ü">(-2329253809982724824L, 72173378396072L).getRGB());
      float winsX = textX + fontManager.C(18).D(killsText) + 40.0F;
      fontManager.C(18).q(poseStack, winsText, winsX, textY, c<"Ü">(-2329253809982724824L, 72173378396072L).getRGB());
      textY += lineHeight + 4.0F;
      fontManager.C(18).q(poseStack, timeText, textX, textY, c<"Ü">(-2329253809982724824L, 72173378396072L).getRGB());
      c<"Y">(new Module[1], -2329309918931901039L, 72173378396072L);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树何何树树树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static void h() {
      树何树友树友何树友何++;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         i[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = i[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   public static void d(Module[] var0) {
      何何树树树树友树友何 = var0;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28904;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何树何何树树树树树友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树何何树树树树树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      i[0] = "\u0004Tk\u0015\b\n\u000b\u0014&\u001e\u0002\u0017\u000eI-X\u0012\fI佯桔伣伲桴桶栫桔桧厬";
      i[1] = int.class;
      j[1] = "java/lang/Integer";
      i[2] = "\u0001\u0012$<VS\n\u001d5s*J\u0005\u0007;0\u001dz\u0013\u00107-\fV\u0004\u001d";
      i[3] = "\u000bFD\u001eKB?eK^\u0006I5xN\u0003\r\u000f=eC\u0005\tD~GH\u0014\u0010M51";
      i[4] = "\t6t\t&j\u0006v9\u0002,w\u0003+2D$j\u000e-6\u000fgH\u0005</\u0006,";
      i[5] = "w/|U&2C\fs\u0015k9I\u0011vH`\u007fA\f{Nd4\u0002.p_}=IX";
      i[6] = "\u001f2\u001bO_{\u0002'Cm\u001ev\u001a!";
      i[7] = "\t1C]\u001a\u0000=\u0012L\u001dW\u000b7\u000fI@\\M?\u0012DFX\u0006|0OWA\u000f7F";
      i[8] = void.class;
      j[8] = "java/lang/Void";
      i[9] = "uw\bT[pAT\u0007\u0014\u0016{KI\u0002I\u001d=CT\u000fO\u0019v\u0000v\u0004^\u0000\u007fK\u0000";
      i[10] = long.class;
      j[10] = "java/lang/Long";
      i[11] = boolean.class;
      j[11] = "java/lang/Boolean";
      i[12] = "4\b18\u0000b?\u0007 wal4\f$-";
      i[13] = "vkq\t$>#-wj原桋厌取桐厩企厑桖取IU9;=s(\u0017>* ";
      i[14] = "']\u0007\u0017j\nz\\E\u0002\u000e=\u001c\t\u0013\u0010dV\u007fO\u0001Plo";
      i[15] = "f4!Ttw3r'7佑但伂厉佄叴佑但厜众\u0019\u0007<v82dP2$<";
      i[16] = ")#cA<6|ee\"厇伇位桄桂栻厇厙位伀[\u001d!3b;:_&\"\u007f";
      i[17] = "vi\u0010_3\f#/\u0016<桒伽桖叔栱叿伖桹厌佊(Fz\u000b5wVC6P";
      i[18] = "B4D`O#\u0005eQz?\u0015>J|\\?vAoQaV1\u0010zK";
      i[19] = "\u001a&a6\u001eZG'##za!ru1\u0010\u0006B4gq\u0018?\u001c4{)BX]4e&z";
      i[20] = "y\t+)4L,O-J% y\t#'&Ap\t\u007f5L\u0019>G~ -\u0010>\u001blJ";
      i[21] = "TO$N\u001bp\u0001\t\"-伾栅厮佬叟栴厠叟厮佬\u001cWRw\u0017QbR\u001e,";
      i[22] = "a\u001f\u0010L$\u00074Y\u0016/0kf\bTEe\b \u001a\u0014M\\V \u0006L\u0017;\u0017 \u0018C/";
      i[23] = "o\u00051FnS:C7%j?h\u0012uO/\\.\u00005G\u0016";
   }

   public static Module[] t() {
      return 何何树树树树友树友何;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = i[var4];
      if (var5 instanceof String) {
         String var6 = j[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         i[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void q() {
      树何树友树友何树友何 = 0;
      何树友何友树友友友何 = 0;
      友何何树树树友友何何 = 0L;
      友树友友树友何友树友 = System.currentTimeMillis();
   }

   public static long P() {
      t();
      long currentSessionTime = 0L;
      if (何何何友何友何何友何 && mc.level != null && mc.player != null) {
         currentSessionTime = System.currentTimeMillis() - 友树友友树友何友树友;
      }

      return 友何何树树树友友何何 + currentSessionTime;
   }

   private static String HE_WEI_LIN() {
      return "何炜霖黑水";
   }

   public static void O() {
      何树友何友树友友友何++;
   }
}
