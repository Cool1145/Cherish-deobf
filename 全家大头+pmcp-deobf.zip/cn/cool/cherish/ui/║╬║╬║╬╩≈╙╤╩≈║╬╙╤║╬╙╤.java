package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.render.Render2DEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class 何何何树友树何友何友 implements IWrapper, 何树友 {
   private static final int 友树树树树树树何何树;
   private static final int 树树何友何树何树何树;
   private static final int 何何友树树树友树何树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[27];
   private static final String[] g = new String[27];
   private static String HE_DA_WEI;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-9087256920858042243L, 5090646823238959919L, MethodHandles.lookup().lookupClass()).a(172517956862679L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var11 = a ^ 1591739162250L;
      Cipher var13;
      Cipher var23 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(var11 << var14 * 8 >>> 56);
      }

      var23.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[8];
      int var18 = 0;
      String var17 = "Ín\u000f\"\u0082(ç\u00adê¦óX\u0084\u0012ðÍiR\u008bü\u0012¡cPM\u0094a` Ô\u0012v\u0010&\u0091GØØsJ\u000e¼\u00ad\u0089\u00109¡ÿr =¢F&\u001e6ä-\u009a\u0086XÉSÛç²M\u0000\u0095#àëD\u0081'\u0087i ä\u001e\u001e!\u0010\u009eBå!H\u001bw\u0013\u008f×%k\u008b\r\r\u008a \u0085å\u001c2±\u0084GîZAè.\u008e(9\u0015e\u0017ü(7úCë©\u007f©?×go\u0004 \u0096ûÜ¢\u0011¿\nâÇÆsz\u001dU\u0018S2[\u0099US\u001b8c\u0012\u009fSñä1\u0085Ï";
      short var19 = 165;
      char var16 = ' ';
      int var22 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var22, var22 + var16);
         int var10001 = -1;

         while (true) {
            String var33 = b(var13.doFinal(var24.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var22 += var16) >= var19) {
                     b = var20;
                     c = new String[8];
                     Cipher var1;
                     Cipher var26 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)(var11 >>> 56), 0, 0, 0, 0, 0, 0, 0};

                     for (int var2 = 1; var2 < 8; var2++) {
                        var10003[var2] = (byte)(var11 << var2 * 8 >>> 56);
                     }

                     var26.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var0 = new long[3];
                     int var4 = 0;
                     byte var3 = 0;

                     do {
                        var10001 = var3;
                        var3 += 8;
                        byte[] var7 = "idDÉ\u0092eq\u009e!¶\u0005\u0011ìK.\u0016\u001eÕ®\u0089;\u0087\u008c\u007f"
                           .substring(var10001, var3)
                           .getBytes("ISO-8859-1");
                        var10001 = var4++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var1.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        byte var38 = -1;
                        var0[var10001] = var10004;
                     } while (var3 < 24);

                     友树树树树树树何何树 = (int)var0[1];
                     树树何友何树何树何树 = (int)var0[2];
                     何何友树树树友树何树 = (int)var0[0];
                     return;
                  }

                  var16 = var17.charAt(var22);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var22 += var16) < var19) {
                     var16 = var17.charAt(var22);
                     continue label45;
                  }

                  var17 = "Óa\u0090\u009e\u008686r\u007f½.\u0090ì\u0087n\u0017\u0015µ}å\"/ÿ\u001b(©N£ÀÚÕ'Bd0ÜÂ_\u0084µN¶\u0099d\u007fÈT\u001eyý\u0098óí\u0087y\béU@/Ýh8åÛ";
                  var19 = 65;
                  var16 = 24;
                  var22 = -1;
            }

            var24 = var17.substring(++var22, var22 + var16);
            var10001 = 0;
         }
      }
   }

   public static void D(Render2DEvent event, float x, float y, float width, float height) {
      long a = 何何何树友树何友何友.a ^ 73819088743937L;
      long ax = a ^ 85726493502558L;
      long axx = a ^ 109667719489169L;
      b<"í">(5626289310382337813L, (long)a);
      友何何树友何何何何树 titleFont = Cherish.instance.h().z(20);
      友何何树友何何何何树 statusFont = Cherish.instance.h().n(16);
      float adjustedWidth = width + 13.0F;
      float adjustedHeight = height - 15.0F;
      float totalHeight = adjustedHeight + 22.0F + 16.0F;
      Color glassColor = new Color(0, 0, 0, 60);
      Color borderColor = new Color(255, 255, 255, 120);
      event.poseStack();
      ShaderUtils.e((PoseStack)ax, y, (long)adjustedWidth, totalHeight, 8.0F, 1.5F, (float)borderColor, (float)glassColor, 12.0F);
      float titleX = x
         + adjustedWidth / 2.0F
         - titleFont.A(
               b<"j">(HUD.instance, 5626733676908226108L, (long)a).C(a<"s">(6311, 3195622829939007077L ^ a))
                  ? a<"s">(10951, 7828594298289531904L ^ a)
                  : a<"s">(8279, 634742971207100052L ^ a)
            )
            / 2.0F;
      float titleY = y + 8.0F + 2.0F;
      titleFont.c(
         event.poseStack(),
         b<"j">(HUD.instance, 5626733676908226108L, (long)a).C(a<"s">(22861, 8178935045922250637L ^ a))
            ? a<"s">(12301, 1913523258240317132L ^ a)
            : a<"s">(30283, 166801933058437262L ^ a),
         titleX,
         titleY,
         b<"Í">(5626593543117382387L, (long)a).getRGB()
      );
      event.poseStack();
      float var10003 = x + 8.0F;
      float var10004 = titleY + titleFont.K() + 4.0F;
      float var10005 = adjustedWidth - 16.0F;
      float var10007 = 1.0F;
      ShaderUtils.h((int)0.5F, (long)(new Color(255, 255, 255, 80)));
      if (event.side() == b<"Í">(5626163787196662499L, (long)a)) {
         i(event.guiGraphics(), x + 8.0F, y + 8.0F + 22.0F - 3.0F, x, y, adjustedWidth, statusFont);
      }

      b<"í">(!b<"í">(5626814984858707177L, (long)a), 5626498739860703483L, (long)a);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 10;
               case 1 -> 42;
               case 2 -> 20;
               case 3 -> 55;
               case 4 -> 34;
               case 5 -> 12;
               case 6 -> 50;
               case 7 -> 44;
               case 8 -> 32;
               case 9 -> 54;
               case 10 -> 23;
               case 11 -> 26;
               case 12 -> 9;
               case 13 -> 14;
               case 14 -> 13;
               case 15 -> 46;
               case 16 -> 8;
               case 17 -> 7;
               case 18 -> 61;
               case 19 -> 29;
               case 20 -> 25;
               case 21 -> 43;
               case 22 -> 52;
               case 23 -> 15;
               case 24 -> 24;
               case 25 -> 59;
               case 26 -> 19;
               case 27 -> 57;
               case 28 -> 36;
               case 29 -> 33;
               case 30 -> 40;
               case 31 -> 58;
               case 32 -> 3;
               case 33 -> 31;
               case 34 -> 4;
               case 35 -> 21;
               case 36 -> 6;
               case 37 -> 1;
               case 38 -> 56;
               case 39 -> 37;
               case 40 -> 39;
               case 41 -> 60;
               case 42 -> 63;
               case 43 -> 35;
               case 44 -> 51;
               case 45 -> 62;
               case 46 -> 48;
               case 47 -> 45;
               case 48 -> 16;
               case 49 -> 5;
               case 50 -> 22;
               case 51 -> 2;
               case 52 -> 11;
               case 53 -> 28;
               case 54 -> 38;
               case 55 -> 17;
               case 56 -> 30;
               case 57 -> 49;
               case 58 -> 27;
               case 59 -> 0;
               case 60 -> 41;
               case 61 -> 47;
               case 62 -> 53;
               default -> 18;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void i(GuiGraphics graphics, float startX, float startY, float moduleX, float moduleY, float moduleWidth, 友何何树友何何何何树 statusFont) {
      long a = 何何何树友树何友何友.a ^ 77219763541868L;
      b<"í">(-614286933057202568L, a);
      if (mc.player != null) {
         boolean hasStacks = false;
         int i = 9;
         Slot slot = b<"j">(mc.player, -614189523084588998L, a).getSlot(9);
         ItemStack stack = slot.getItem();
         if (!stack.isEmpty()) {
            hasStacks = true;
         }

         i++;
         if (hasStacks) {
            i = 9;
            slot = b<"j">(mc.player, -614189523084588998L, a).getSlot(9);
            stack = slot.getItem();
            int itemX = (int)startX + 0;
            int itemY = (int)startY + 0;
            graphics.pose().pushPose();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            graphics.renderItem(stack, itemX, itemY);
            graphics.renderItemDecorations(b<"j">(mc, -614496132315788722L, a), stack, itemX, itemY);
            graphics.pose().popPose();
            i++;
         }

         String statusText = "";
         if (b<"j">(mc, -613684270983683434L, a) instanceof InventoryScreen) {
            statusText = a<"s">(20470, 8446376972003799135L ^ a);
         }

         if (!hasStacks) {
            statusText = a<"s">(3630, 3779783811893997957L ^ a);
         }

         if (!statusText.isEmpty()) {
            float statusX = moduleX + moduleWidth / 2.0F - statusFont.A(statusText) / 2.0F;
            float statusY = startY + (hasStacks ? 65 : 15);
            statusFont.c(graphics.pose(), statusText, statusX, statusY, new Color(255, 255, 255, 180).getRGB());
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'j' && var8 != 'o' && var8 != 205 && var8 != 170) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'P') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 237) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'j') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'o') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 205) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何何树友树何友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 18643;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何何何树友树何友何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何何树友树何友何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      f[0] = "D\u0017\u007f?\u0017&KW24\u001d;N\n9r\u0015&C\f=9V\u0004H\u001d$0\u001d";
      f[1] = boolean.class;
      g[1] = "java/lang/Boolean";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = "RGtos\u0016]\u00079dy\u000bXZ2\"q\u0016U\\6i2\u0010\\Y6\"x\u0010BY6meWy|\u001e";
      f[4] = ".Kro#`!\u000b?d)}$V4\":n!P9\"%b=IrA#k(s=`9j";
      f[5] = "!\u0006\u0017dm6.FZog++\u001bQ)g/'\u0006M)g/'\u0006Mt,\u001c4\rWs&\n+\f\\";
      f[6] = "7O4CDR8\u000fyHNO=Rr\u000e^Tz只栋叫栺佨原栰发併佾";
      f[7] = "9\u0006H(H\f2\tYg5\u0014!\u000eP.";
      f[8] = "\\(4\u0014t\u0003Shy\u001f~\u001eV5rYn\u0005\u0011伓住伢栊厧栮伓发伢叐";
      f[9] = "sl\t\u00051:xc\u0018JM#wy\u0016\tz\u0013an\u001a\u0014k?vc";
      f[10] = "E\u0014%1<\bX\u0001}\u0013}\u0005@\u0007";
      f[11] = "^`$X.\f^`3\u0004\"\u0003D+3\u001a*\u0000^q~;*\u000bUf\"\u0017%\u0011";
      f[12] = "\u0005h`]s1\u0005hw\u0001\u007f>\u001f#w\u001fw=\u0005y:\u0014k1E~w\u0001{=\u0005~: }*\u000ehz";
      f[13] = "\u0016i{\"\rE\u0016il~\u0001J\f\"l`\tI\u0016x!|\fM\u0001i}\",C\u001bmc\\\fM\u0001i}";
      f[14] = "<6QOka<6F\u0013gn&}R\u000etd6}L\u000fpm<'J\u0013\u007f&\u001b=S\u0004h|=!\\,cf'";
      f[15] = "u\u0014m\u001b\\\bu\u0014zGP\u0007o_zYX\u0004u\u00057RD\b57v[E";
      f[16] = "#J0\u0003\tw(E!Lhy#N%\u0016";
      f[17] = "hf9LK9l!*\u0014p\u0002\u0013\u0006\u0018pLa)a\u007f\u0013H&:9";
      f[18] = "Fmt\"a\u0012\u0010~:7_F ;:qn\u0015 \u0000588RFf5s3C";
      f[19] = ")\u0016\\e[\u001fl\u0011Lz$\u001b\u0015OQbO\u001e-\u001fLfJg";
      f[20] = "RlXM\f)\u0002k\u0003!\"IBuW\u001c\u0006tE:W!R7F<[\u001cR'E>g";
      f[21] = "6RW2V\u0010qJV;/A\u000b\u001e\u0001=F\u0019u@\u000e-Q(5N\u0004?\u001eVkA\u0014(/";
      f[22] = "A;1KF\u0017\u000f$'\u0019~I)us\u001a@\u001d)D#_\u0013F\u001d%7\u001b\u0004X";
      f[23] = "0Zav/cjMjeO\u0006OpGDOfdKdiu<s@w";
      f[24] = "Z\u000f&Kp+\n\b}'zKJ\u0016)\u001azvMY)'";
      f[25] = "OU\u0007\u0011b\u0013\u000bU\u0006\\\u001e厹伨栩桸叮叝厹伨右桸-$\u0001\b\u000e\u0013\u0012#\u0019\rT";
      f[26] = "\u0001{!\u0002\u001aROd7P\"\fi5cS\u0012Zi\u0004j\u001b\u0018\u000fSzb\u0013\u001f\u0013";
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String LIU_YA_FENG() {
      return "何大伟为什么要诈骗何炜霖";
   }
}
