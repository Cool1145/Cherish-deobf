package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.impl.树友何友何何友树树友;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 友何何友树何树树树何 implements 友树何树友友树树何树<树友何友何何友树树友>, IWrapper,  {
   private static final float 友何树友何树何树友树 = 7.0F;
   private static final float 友友树友树何友树友何 = 10.0F;
   private static final float 友树何何友何友友树何 = 10.0F;
   private static final float 友何何树友友友何树友 = 100.0F;
   private static final float 树何树何树友友何友何 = 100.0F;
   private static final float 友何何树树何何树树友 = 10.0F;
   private static final float 友树友何友树何友树何 = 4.0F;
   private static final float 树何何何何友何友何友 = 3.0F;
   private static boolean 何友树何树友友友友何;
   private static final long a;
   private static final Object[] b = new Object[31];
   private static final String[] c = new String[31];
   private static int _何树友为什么濒天了 _;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(5299777894832436836L, 9023019961603037713L, MethodHandles.lookup().lookupClass()).a(216984823800029L);
      // $VF: monitorexit
      a = var10000;
      long var0 = a ^ 118218070567733L;
      a();
      if (!a<"d">(-4113299319075937330L, var0)) {
         a<"d">(true, -4111855713620836679L, var0);
      }
   }

   public static boolean C() {
      return 何友树何树友友友友何;
   }

   public void S(树友何友何何友树树友 setting, double mouseX, double mouseY, int button, 友树友树何树友友友树 componentsInstance) {
      long a = 友何何友树何树树树何.a ^ 75123825148929L;
      a<"d">(7628692977047358714L, a);
      if (a<"o">(componentsInstance, 7627889028800549931L, a) == setting) {
         a<"ÿ">(componentsInstance, null, 7627889028800549931L, a);
         a<"ÿ">(componentsInstance, null, 7626985603638199410L, a);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 32;
               case 1 -> 56;
               case 2 -> 16;
               case 3 -> 48;
               case 4 -> 35;
               case 5 -> 43;
               case 6 -> 39;
               case 7 -> 2;
               case 8 -> 14;
               case 9 -> 5;
               case 10 -> 60;
               case 11 -> 0;
               case 12 -> 1;
               case 13 -> 27;
               case 14 -> 25;
               case 15 -> 45;
               case 16 -> 3;
               case 17 -> 26;
               case 18 -> 11;
               case 19 -> 41;
               case 20 -> 61;
               case 21 -> 19;
               case 22 -> 59;
               case 23 -> 31;
               case 24 -> 53;
               case 25 -> 52;
               case 26 -> 55;
               case 27 -> 37;
               case 28 -> 46;
               case 29 -> 13;
               case 30 -> 63;
               case 31 -> 7;
               case 32 -> 10;
               case 33 -> 29;
               case 34 -> 38;
               case 35 -> 12;
               case 36 -> 4;
               case 37 -> 30;
               case 38 -> 58;
               case 39 -> 6;
               case 40 -> 21;
               case 41 -> 36;
               case 42 -> 8;
               case 43 -> 15;
               case 44 -> 40;
               case 45 -> 23;
               case 46 -> 18;
               case 47 -> 17;
               case 48 -> 34;
               case 49 -> 33;
               case 50 -> 28;
               case 51 -> 42;
               case 52 -> 9;
               case 53 -> 51;
               case 54 -> 49;
               case 55 -> 54;
               case 56 -> 22;
               case 57 -> 57;
               case 58 -> 62;
               case 59 -> 50;
               case 60 -> 24;
               case 61 -> 47;
               case 62 -> 44;
               default -> 20;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   public float b(树友何友何何友树树友 setting, 友树友树何树友友友树 componentsInstance) {
      long a = 友何何友树何树树树何.a ^ 98095628900813L;
      a<"d">(-5471149258489458378L, a);
      float animation = a<"o">(componentsInstance, -5470599089115432625L, a).getOrDefault(setting, 0.0F);
      return animation > 0.01F ? 108.0F * animation : 0.0F;
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'o' && var8 != 255 && var8 != 254 && var8 != 236) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'e') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'd') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'o') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 255) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 254) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private void n(GuiGraphics guiGraphics, 树友何友何何友树树友 setting, float x, float y, float width, float height) {
      long a = 友何何友树何树树树何.a ^ 47620885981659L;
      long ax = a ^ 80875783984487L;
      long axx = a ^ 110892021987229L;
      友何何友树何树树树何.树树何树何何树友何树 hsb = new 友何何友树何树树树何.树树何树何何树友何树(setting.getValue());
      a<"d">(-4322082607056854752L, a);
      Color baseColor = Color.getHSBColor(a<"o">(hsb, -4323093456950383102L, a), a<"o">(hsb, -4322139629165880409L, a), a<"o">(hsb, -4323352840115068732L, a));
      int var10006 = a<"þ">(-4323453486848437311L, a).getRGB();
      int var10007 = a<"þ">(-4322337350289164570L, a).getRGB();
      Object[] var10010 = new Object[]{null, null, null, null, null, null, null, null, ax};
      var10010[7] = var10007;
      var10010[6] = var10006;
      var10010[5] = 4.0F;
      var10010[4] = height;
      var10010[3] = 10.0F;
      var10010[2] = y;
      var10010[1] = x;
      var10010[0] = guiGraphics;
      RenderUtils.H(var10010);
      int i = 0;
      if (0.0F < height) {
         float alpha = 1.0F - 0.0F / height;
         Color alphaColor = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), (int)(alpha * 255.0F));
         PoseStack var10000 = guiGraphics.pose();
         float var10001 = (int)x;
         float var10002 = (int)(y + 0.0F);
         float var10003 = (int)(x + width);
         float var10004 = (int)(y + 0.0F + 1.0F);
         Object[] var10008 = new Object[]{null, null, null, null, null, null, alphaColor.getRGB()};
         var10008[5] = axx;
         var10008[4] = var10004;
         var10008[3] = var10003;
         var10008[2] = var10002;
         var10008[1] = var10001;
         var10008[0] = var10000;
         RenderUtils.E(var10008);
         i++;
      }

      float indicatorY = y + (1.0F - a<"o">(hsb, -4323280149941058655L, a) / 255.0F) * height;
      PoseStack var21 = guiGraphics.pose();
      float var22 = (int)(x - 1.0F);
      float var23 = (int)(indicatorY - 1.0F);
      float var24 = (int)(x + width + 1.0F);
      float var25 = (int)(indicatorY + 1.0F);
      Object[] var26 = new Object[]{null, null, null, null, null, null, a<"þ">(-4323453486848437311L, a).getRGB()};
      var26[5] = axx;
      var26[4] = var25;
      var26[3] = var24;
      var26[2] = var23;
      var26[1] = var22;
      var26[0] = var21;
      RenderUtils.E(var26);
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友何何友树何树树树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = "P+0e\u0013i_k}n\u0019tZ6v(\to\u001d厎佋体厷栗佦桔栏栗伩";
      b[1] = "X3~\f+yS<oCW`\\&a\u0000`PJ1m\u001dq|]<";
      b[2] = boolean.class;
      c[2] = "java/lang/Boolean";
      b[3] = "8vd\u0001+L%c<#jA=e";
      b[4] = "\u0017{7\u0016?\r\u0018;z\u001d5\u0010\u001dfq[%\u000bZ叞栈厾桁伷桥叞叒厾桁";
      b[5] = "U)\f\tNgZiA\u0002Dz_4JDTa\u0018厌栳厡栰佝栧厌叩厡栰,栧桖栳伿佴參叽伒佷厡";
      b[6] = "z8\u000f\u0011hGd0\u0015^\u000eSc14\u00116";
      b[7] = "\u000fg)!`)\u0000'd*j4\u0005zoly'\u0000|blf+\u001ce)桓叄伓厧作佒厉栞桗厧";
      b[8] = "+\u0011J_$t$Q\u0007T.i!\f\f\u0012>rf厴伱佩厀栊伝桮桵栭伞?桙桮伱栭伞低桙厴伱栭";
      b[9] = float.class;
      c[9] = "java/lang/Float";
      b[10] = int.class;
      c[10] = "java/lang/Integer";
      b[11] = void.class;
      c[11] = "java/lang/Void";
      b[12] = "\u0000n$Q\"\u001c\u000ba5\u001eC\u0012\u0000j1D";
      b[13] = "+c\u001d0\"\u0004.fHBu97|\u001e|v\u0007r0\bBgE%>\u001d|\"\t3\u0000";
      b[14] = "\u001b5w*Rs\u00183c>3栍句伎反桕台栍栿桊栗L\r%H!n1\\-\u0018n";
      b[15] = "n\n2&\"Dk\u000fgT[y0\u0015:,lB{\b!.\u001c";
      b[16] = "&dDs?\u0014x>DvR厹栃桄校伒厑伧佇伀叻OnCfaU!0\u0019fd";
      b[17] = ".wiZ/Q+r<(ZlphaPaW;uzR\u0011";
      b[18] = "%6E#\b=dl\\4h\u0011EBoERcdm^&\u00139}z";
      b[19] = "^CS\u0003,+\u001f\u0019J\u0014L\f%1h9\u001b\u0007>7yevu\u001f\u0018H\u00067/\u0006\u000f";
      b[20] = " QJ)lX\u007f\\\u001a0S栾栂桴厸桎厐佺栂桴桢Wo\u001egQ\u001691DgT";
      b[21] = "RW>F|$\f\r>C\u0011桓厭伳伟档叒厉伳厭厁z-s\u0012R/\u0014s)\u0012W";
      b[22] = "\u0012cM}g?L9Mx\n案叭伇栨厂叉案佳厙佬A6hRf\\/h2Rc";
      b[23] = "T@\"kI5\u000bMrrv众厬桥栊栌厵厉厬伡叐\u0015J'VDtdN;\u0013\u0007";
      b[24] = "\b=YHS?W0\tQl厃株作桱栯伱桙佮栘厫6P-\n9\u000fGT1Oz";
      b[25] = "C}:<.\u0017@{.(O桩桧变伞桃伒厳桧变厀ZqA\u0010i#' I@&";
      b[26] = "j+&\u0004i\no.sv-744.\u000e'\f\u007f)5\fW\u0007321N>\u000ef/2v";
      b[27] = "\u0013m\u0003\u0018uJL`S\u0001J佨栱案叱厥桓叶栱厒栫fw^\u00140Y] H\u00192";
      b[28] = "Vfr\u0002jr\u0017<k\u0015\nN,\u001aU)\n+Q o\u0004ij\u000b9x";
      b[29] = "~\u001b\u0013U}a}\u001d\u0007A\u001c栟桚传伷佮栅佛伞厾桳3\"7-\u000f\nNs?}@";
      b[30] = "r#s4\u0013~q%g r佄桖历栓伏伯叚伒桜叉RM#qxs3Lu\u007f#";
   }

   public boolean p(
      树友何友何何友树树友 setting, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 友树友树何树友友友树 componentsInstance
   ) {
      long a = 友何何友树何树树树何.a ^ 102468305106532L;
      a<"d">(-2613329428999536993L, a);
      if (button == 0) {
         float previewX = x + width - 17.0F;
         float previewY = middleY - 5.0F;
         if (mouseX >= previewX && mouseX <= previewX + 10.0F && mouseY >= previewY && mouseY <= previewY + 10.0F) {
            boolean currentExpanded = a<"o">(componentsInstance, -2612569537073423920L, a).getOrDefault(setting, false);
            a<"o">(componentsInstance, -2612569537073423920L, a).put(setting, !currentExpanded);
            if (!currentExpanded) {
               a<"ÿ">(componentsInstance, null, -2612459647885040050L, a);
            }

            return true;
         }

         boolean isExpanded = a<"o">(componentsInstance, -2612569537073423920L, a).getOrDefault(setting, false);
         float expandAnimation = a<"o">(componentsInstance, -2612788058944006426L, a).getOrDefault(setting, 0.0F);
         if (isExpanded && expandAnimation > 0.8F) {
            float startY = y + height + 3.0F;
            float pickerBgX = previewX - 100.0F - 20.0F - 12.0F - 3.0F;
            if (mouseX >= pickerBgX && mouseX <= pickerBgX + 100.0F && mouseY >= startY && mouseY <= startY + 100.0F * expandAnimation) {
               a<"ÿ">(componentsInstance, setting, -2612459647885040050L, a);
               a<"ÿ">(componentsInstance, a<"þ">(-2612877053531211847L, a), -2612818281142471145L, a);
               this.z(setting, (int)mouseX, (int)mouseY, pickerBgX, startY, 100.0F, 100.0F * expandAnimation, 0.0F, 0.0F, 0.0F, componentsInstance);
               return true;
            }

            float hueX = pickerBgX + 100.0F + 4.0F;
            if (mouseX >= hueX && mouseX <= hueX + 10.0F && mouseY >= startY && mouseY <= startY + 100.0F * expandAnimation) {
               a<"ÿ">(componentsInstance, setting, -2612459647885040050L, a);
               a<"ÿ">(componentsInstance, a<"þ">(-2612689059745297457L, a), -2612818281142471145L, a);
               this.z(setting, (int)mouseX, (int)mouseY, pickerBgX, startY, 100.0F, 100.0F * expandAnimation, hueX, 0.0F, 10.0F, componentsInstance);
               return true;
            }

            float alphaX = hueX + 10.0F + 4.0F;
            if (mouseX >= alphaX && mouseX <= alphaX + 10.0F && mouseY >= startY && mouseY <= startY + 100.0F * expandAnimation) {
               a<"ÿ">(componentsInstance, setting, -2612459647885040050L, a);
               a<"ÿ">(componentsInstance, a<"þ">(-2613090821391518641L, a), -2612818281142471145L, a);
               this.z(setting, (int)mouseX, (int)mouseY, pickerBgX, startY, 100.0F, 100.0F * expandAnimation, hueX, alphaX, 10.0F, componentsInstance);
               return true;
            }
         }
      }

      return false;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public boolean U(树友何友何何友树树友 setting, char chr, int modifiers, 友树友树何树友友友树 componentsInstance) {
      return false;
   }

   private void z(
      树友何友何何友树树友 setting,
      int mouseX,
      int mouseY,
      float sqX,
      float sqY,
      float sqSize,
      float sqHeight,
      float hueX,
      float alphaX,
      float sliderWidth,
      友树友树何树友友友树 componentsInstance
   ) {
      long a = 友何何友树何树树树何.a ^ 111347444726215L;
      a<"d">(6059785499175219516L, a);
      友何何友树何树树树何.树树何树何何树友何树 hsb = new 友何何友树何树树树何.树树何树何何树友何树(setting.getValue());
      if (a<"o">(componentsInstance, 6061387602883623348L, a) == a<"þ">(6061293543246149658L, a)) {
         float newSat = Mth.clamp((mouseX - sqX) / 100.0F, 0.0F, 1.0F);
         float newBri = 1.0F - Mth.clamp((mouseY - sqY) / sqHeight, 0.0F, 1.0F);
         a<"ÿ">(hsb, newSat, 6059842761818917819L, a);
         a<"ÿ">(hsb, newBri, 6060740596050325720L, a);
      }

      if (a<"o">(componentsInstance, 6061387602883623348L, a) == a<"þ">(6061534281713026156L, a)) {
         float hue = Mth.clamp((mouseY - sqY) / sqHeight, 0.0F, 1.0F);
         a<"ÿ">(hsb, hue, 6061008839698136606L, a);
      }

      if (a<"o">(componentsInstance, 6061387602883623348L, a) == a<"þ">(6061660152771214316L, a)) {
         float alphaPercent = 1.0F - Mth.clamp((mouseY - sqY) / sqHeight, 0.0F, 1.0F);
         a<"ÿ">(hsb, (int)(alphaPercent * 255.0F), 6060949621370885053L, a);
      }

      setting.g(hsb.g());
   }

   public static void r(boolean var0) {
      何友树何树友友友友何 = var0;
   }

   public boolean E(树友何友何何友树树友 setting, int keyCode, int scanCode, int modifiers, 友树友树何树友友友树 componentsInstance) {
      return false;
   }

   public void M(
      GuiGraphics guiGraphics,
      树友何友何何友树树友 value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      友何何树友何何何何树 settingNameFont,
      友何何树友何何何何树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      友树友树何树友友友树 componentsInstance
   ) {
      long a = 友何何友树何树树树何.a ^ 18482848062972L;
      long ax = a ^ 104847835513786L;
      float previewX = x + width - 17.0F;
      float previewY = middleY - 5.0F;
      PoseStack var10000 = guiGraphics.pose();
      float var10001 = (int)previewX;
      float var10002 = (int)previewY;
      float var10003 = (int)(previewX + 10.0F);
      float var10004 = (int)(previewY + 10.0F);
      Object[] var10008 = new Object[]{null, null, null, null, null, null, value.getValue().getRGB()};
      var10008[5] = ax;
      var10008[4] = var10004;
      var10008[3] = var10003;
      var10008[2] = var10002;
      var10008[1] = var10001;
      var10008[0] = var10000;
      RenderUtils.E(var10008);
      RenderUtils.drawRectangle(guiGraphics.pose(), previewX - 1.0F, previewY - 1.0F, 12.0F, 1.0F, a<"þ">(3469095029869317069L, a).getRGB());
      a<"d">(3469026813079294898L, a);
      RenderUtils.drawRectangle(guiGraphics.pose(), previewX - 1.0F, previewY + 10.0F, 12.0F, 1.0F, a<"þ">(3469095029869317069L, a).getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), previewX - 1.0F, previewY, 1.0F, 10.0F, a<"þ">(3469095029869317069L, a).getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), previewX + 10.0F, previewY, 1.0F, 10.0F, a<"þ">(3469095029869317069L, a).getRGB());
      a<"o">(componentsInstance, 3469465130813731400L, a).getOrDefault(value, false);
      float expandAnimation = a<"o">(componentsInstance, 3469406567080164734L, a).getOrDefault(value, 0.0F);
      if (Math.abs(expandAnimation - 1.0F) > 0.001F) {
         float var35 = expandAnimation + (1.0F - expandAnimation) * 0.2F * partialTicks * 5.0F;
         expandAnimation = Math.max(0.0F, Math.min(1.0F, var35));
         a<"o">(componentsInstance, 3469406567080164734L, a).put(value, expandAnimation);
      }

      if (expandAnimation > 0.01F) {
         float startY = y + height + 3.0F;
         float pickerBgX = previewX - 132.0F - 3.0F;
         RenderUtils.drawRoundedRect(guiGraphics.pose(), pickerBgX - 4.0F, startY - 4.0F, 140.0, 108.0F * expandAnimation, 3.0, new Color(0, 0, 0, 200));
         if (expandAnimation > 0.8F) {
            this.O(guiGraphics, value, pickerBgX, startY, 100.0F * expandAnimation);
            float hueX = pickerBgX + 100.0F + 4.0F;
            this.O(guiGraphics, value, hueX, startY, 10.0F, 100.0F * expandAnimation);
            float alphaX = hueX + 10.0F + 4.0F;
            this.n(guiGraphics, value, alphaX, startY, 10.0F, 100.0F * expandAnimation);
            if (a<"o">(componentsInstance, 3469707077763452374L, a) == value && a<"o">(componentsInstance, 3469225693800422799L, a) != null) {
               this.z(value, mouseX, mouseY, pickerBgX, startY, 100.0F, 100.0F * expandAnimation, hueX, alphaX, 10.0F, componentsInstance);
            }
         }
      }
   }

   public void P(树友何友何何友树树友 setting, 友树友树何树友友友树 componentsInstance) {
      long a = 友何何友树何树树树何.a ^ 96706279974681L;
      a<"d">(-3836729629657962153L, a);
      a<"o">(componentsInstance, -3836148665854900051L, a).putIfAbsent(setting, false);
      a<"o">(componentsInstance, -3836915289822820453L, a).putIfAbsent(setting, 0.0F);
      if (a<"o">(componentsInstance, -3836038773576091853L, a) == setting) {
         a<"ÿ">(componentsInstance, null, -3836038773576091853L, a);
         a<"ÿ">(componentsInstance, null, -3836946656918427798L, a);
      }
   }

   private void O(GuiGraphics guiGraphics, 树友何友何何友树树友 setting, float x, float y, float size) {
      long a = 友何何友树何树树树何.a ^ 46995909570744L;
      long ax = a ^ 111233211887358L;
      友何何友树何树树树何.树树何树何何树友何树 hsb = new 友何何友树何树树树何.树树何树何何树友何树(setting.getValue());
      Color hueColor = Color.getHSBColor(a<"o">(hsb, 2117334585378928481L, a), 1.0F, 1.0F);
      a<"d">(2118909768054323267L, a);
      PoseStack var10001 = guiGraphics.pose();
      float var10002 = (int)x;
      float var10003 = (int)y;
      float var10004 = (int)(x + size);
      float var10005 = (int)(y + size);
      Object[] var10009 = new Object[]{null, null, null, null, null, null, hueColor.getRGB()};
      var10009[5] = ax;
      var10009[4] = var10005;
      var10009[3] = var10004;
      var10009[2] = var10003;
      var10009[1] = var10002;
      var10009[0] = var10001;
      RenderUtils.E(var10009);
      int i = 0;
      if (0.0F < size) {
         float alpha = 0.0F / size;
         int whiteColor = new Color(1.0F, 1.0F, 1.0F, alpha).getRGB();
         PoseStack var10000 = guiGraphics.pose();
         float var25 = (int)(x + size - 0.0F - 1.0F);
         var10002 = (int)y;
         var10003 = (int)(x + size - 0.0F);
         var10004 = (int)(y + size);
         Object[] var10008 = new Object[]{null, null, null, null, null, null, whiteColor};
         var10008[5] = ax;
         var10008[4] = var10004;
         var10008[3] = var10003;
         var10008[2] = var10002;
         var10008[1] = var25;
         var10008[0] = var10000;
         RenderUtils.E(var10008);
         i++;
      }

      i = 0;
      if (0.0F < size) {
         float alpha = 0.0F / size;
         int blackColor = new Color(0.0F, 0.0F, 0.0F, alpha).getRGB();
         PoseStack var23 = guiGraphics.pose();
         float var26 = (int)x;
         var10002 = (int)(y + 0.0F);
         var10003 = (int)(x + size);
         var10004 = (int)(y + 0.0F + 1.0F);
         Object[] var37 = new Object[]{null, null, null, null, null, null, blackColor};
         var37[5] = ax;
         var37[4] = var10004;
         var37[3] = var10003;
         var37[2] = var10002;
         var37[1] = var26;
         var37[0] = var23;
         RenderUtils.E(var37);
         i++;
      }

      float markX = x + a<"o">(hsb, 2118852475311948484L, a) * size;
      float markY = y + (1.0F - a<"o">(hsb, 2117638018805479847L, a)) * size;
      PoseStack var24 = guiGraphics.pose();
      float var27 = (int)(markX - 2.0F);
      var10002 = (int)(markY - 2.0F);
      var10003 = (int)(markX + 3.0F);
      var10004 = (int)(markY + 3.0F);
      Object[] var38 = new Object[]{null, null, null, null, null, null, a<"þ">(2117536268433312418L, a).getRGB()};
      var38[5] = ax;
      var38[4] = var10004;
      var38[3] = var10003;
      var38[2] = var10002;
      var38[1] = var27;
      var38[0] = var24;
      RenderUtils.E(var38);
   }

   private void O(GuiGraphics guiGraphics, 树友何友何何友树树友 setting, float x, float y, float width, float height) {
      long a = 友何何友树何树树树何.a ^ 131473658965108L;
      long ax = a ^ 61605112410674L;
      a<"d">(-9102880002217663942L, a);
      友何何友树何树树树何.树树何树何何树友何树 hsb = new 友何何友树何树树树何.树树何树何何树友何树(setting.getValue());
      int indicatorY = 0;
      if (0.0F < height) {
         float hue = 0.0F / height;
         int rgb = Color.HSBtoRGB(hue, 1.0F, 1.0F);
         PoseStack var10000 = guiGraphics.pose();
         float var10001 = (int)x;
         float var10002 = (int)(y + 0.0F);
         float var10003 = (int)(x + 10.0F);
         float var10004 = (int)(y + 0.0F + 1.0F);
         Object[] var10008 = new Object[]{null, null, null, null, null, null, rgb};
         var10008[5] = ax;
         var10008[4] = var10004;
         var10008[3] = var10003;
         var10008[2] = var10002;
         var10008[1] = var10001;
         var10008[0] = var10000;
         RenderUtils.E(var10008);
         indicatorY++;
      }

      float indicatorYx = y + a<"o">(hsb, -9102313902507856979L, a) * height;
      PoseStack var18 = guiGraphics.pose();
      float var19 = (int)(x - 1.0F);
      float var20 = (int)(indicatorYx - 1.0F);
      float var21 = (int)(x + width + 1.0F);
      float var22 = (int)(indicatorYx + 1.0F);
      Object[] var23 = new Object[]{null, null, null, null, null, null, a<"þ">(-9101953889737189778L, a).getRGB()};
      var23[5] = ax;
      var23[4] = var22;
      var23[3] = var21;
      var23[2] = var20;
      var23[1] = var19;
      var23[0] = var18;
      RenderUtils.E(var23);
   }

   public static boolean O() {
      C();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static String HE_SHU_YOU() {
      return "何炜霖黑水";
   }

   private static class 树树何树何何树友何树 implements 何树友 {
      public float 树树友何树何友树友友;
      public float 树友何友树友树树树树;
      public float 树树何何何树何何友树;
      public int 何树友树何何友何树友;
      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static int _何炜霖大狗叫 _;

      public 树树何树何何树友何树(Color color) {
         long a = 友何何友树何树树树何.树树何树何何树友何树.a ^ 36569849179755L;
         super();
         float[] hsbValues = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
         a<"k">(this, hsbValues[0], -2174613298282151264L, a);
         a<"k">(this, hsbValues[1], -2174538620606527646L, a);
         a<"k">(this, hsbValues[2], -2174437218519332687L, a);
         a<"k">(this, color.getAlpha(), -2174508565256322358L, a);
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-1307227976694371202L, -6132798392150205018L, MethodHandles.lookup().lookupClass()).a(114163644637806L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'K' && var8 != 'k' && var8 != 'F' && var8 != 'b') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 237) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 196) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'K') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 'k') {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'F') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/友何何友树何树树树何$树树何树何何树友何树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 17;
                  case 1 -> 49;
                  case 2 -> 42;
                  case 3 -> 41;
                  case 4 -> 30;
                  case 5 -> 24;
                  case 6 -> 36;
                  case 7 -> 3;
                  case 8 -> 11;
                  case 9 -> 54;
                  case 10 -> 31;
                  case 11 -> 52;
                  case 12 -> 6;
                  case 13 -> 56;
                  case 14 -> 13;
                  case 15 -> 19;
                  case 16 -> 32;
                  case 17 -> 34;
                  case 18 -> 10;
                  case 19 -> 51;
                  case 20 -> 44;
                  case 21 -> 50;
                  case 22 -> 60;
                  case 23 -> 55;
                  case 24 -> 9;
                  case 25 -> 18;
                  case 26 -> 21;
                  case 27 -> 46;
                  case 28 -> 26;
                  case 29 -> 59;
                  case 30 -> 45;
                  case 31 -> 47;
                  case 32 -> 1;
                  case 33 -> 37;
                  case 34 -> 0;
                  case 35 -> 53;
                  case 36 -> 8;
                  case 37 -> 29;
                  case 38 -> 57;
                  case 39 -> 20;
                  case 40 -> 16;
                  case 41 -> 62;
                  case 42 -> 14;
                  case 43 -> 28;
                  case 44 -> 40;
                  case 45 -> 2;
                  case 46 -> 5;
                  case 47 -> 58;
                  case 48 -> 7;
                  case 49 -> 12;
                  case 50 -> 15;
                  case 51 -> 25;
                  case 52 -> 23;
                  case 53 -> 43;
                  case 54 -> 38;
                  case 55 -> 63;
                  case 56 -> 61;
                  case 57 -> 33;
                  case 58 -> 4;
                  case 59 -> 35;
                  case 60 -> 27;
                  case 61 -> 39;
                  case 62 -> 22;
                  default -> 48;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static void a() {
         b[0] = "|\u0010\u0003\u0010TTsPN\u001b^Iv\rE]NR1厵佸伦台株佊桯格桢佮\u001f栎桯佸桢佮佮栎厵佸桢";
         b[1] = float.class;
         c[1] = "java/lang/Float";
         b[2] = int.class;
         c[2] = "java/lang/Integer";
         b[3] = ">hS\u0012X(5gB]9&>lF\u0007";
         b[4] = "\u000f7[H!I\t)Ps桓叭佨厖栮厰桓样栬桌7\u000e'CI3\f\u001f&H";
         b[5] = "\u000b`S\u0017W\u000e\r~X,栥桰史佟栦佱叿桰史叁?QQ\u0004Md\u0004@P\u000f";
         b[6] = "\u0010AV^NR\u0016_]e格栬佷佾佧桼佸佨叩栺:\u0018HXVE\u0001\tIS";
         b[7] = "&\u0017ThTe \t_S佢栛叟桬佥伎叼佟栅厶8jE9&MU.\u0001o|";
      }

      public Color g() {
         long a = 友何何友树何树树树何.树树何树何何树友何树.a ^ 77663286117915L;
         int rgb = Color.HSBtoRGB(a<"K">(this, -8529149900371842352L, a), a<"K">(this, -8529224758432420078L, a), a<"K">(this, -8529044470680903487L, a));
         return new Color(rgb >> 16 & 0xFF, rgb >> 8 & 0xFF, rgb & 0xFF, a<"K">(this, -8528990741529089350L, a));
      }

      private static String HE_SHU_YOU() {
         return "何树友被何大伟克制了";
      }
   }
}
