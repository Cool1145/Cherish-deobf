package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import cn.cool.cherish.value.impl.树友何何树树何友友何;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class 何树何友友何何友友树 extends Screen implements IWrapper, 何树友 {
   public static final 何树何友友何何友友树 树树友树友树何友友何;
   private boolean 树树树何何友何何友友 = false;
   private float 树友何树何何何树树何 = 0.0F;
   private long 树何树树树何友何树友;
   private final List<树树树友何何树何友何> 友友友树树树树树友友 = new ArrayList<>();
   private 树树树友何何树何友何 何何何树树何何友何何 = null;
   private float 友树友何何何友友树树;
   private float 友何友友何树树何何树;
   public final float 树树树何友何何树友何 = 110.0F;
   public final float 树友友友何何友友树何 = 20.0F;
   public final float 何友何树何何何友友友 = 18.0F;
   public final float 何何何树树树友何友何 = 16.0F;
   public final float 何树树树树树友友何树 = 2.0F;
   final float 树友何树何树何友何树 = 3.0F;
   final float 友何友树树树树树何何 = 300.0F;
   public final Color 树友友何何树友友树树 = new Color(30, 30, 30);
   public final Color 友友友何树友何友树树 = new Color(40, 40, 40);
   public final Color 树何何树何树何树何友 = new Color(45, 45, 45);
   public final Color 树树树友树何友何何树 = new Color(55, 55, 55);
   public final Color 树友何何友树友友何树 = new Color(200, 200, 200);
   public final Color 友树树友何树友友树友 = Color.WHITE;
   public final Color 何友友何树树树何友友 = new Color(25, 25, 25);
   public final Color 何树何友何何树树树友 = new Color(35, 35, 35);
   public final Color 友树何何何友友何树何 = new Color(100, 100, 120);
   public boolean 树树何树友树何树友树;
   public 何何友友树何树何友树 树何树树树何何树何树;
   public 何何友友树何树何友树 何何友何树何友树何何;
   public 何何友友树何树何友树 友何何何何树友树何树;
   public 何何友友树何树何友树 树何何友何树何树友树;
   public 何何友友树何树何友树 友何友树树友何友树友;
   public 何何友友树何树何友树 树友何何何树何友树树;
   public 何何友友树何树何友树 友友友何友何树何树何;
   public 何何何友友何树何何何 友树树友何友树树友树 = null;
   public 树树树友何何树何友何 友何树友友何友何友何 = null;
   private static Module[] 友友友何何何树友友友;
   private static final long a;
   private static final String b;
   private static final long c;
   private static final Object[] e = new Object[55];
   private static final String[] f = new String[55];
   private static String HE_SHU_YOU;

   protected 何树何友友何何友友树() {
      super(Component.nullToEmpty("DSJ List GUI"));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6367628982574290770L, 6583303662783302519L, MethodHandles.lookup().lookupClass()).a(200951840138585L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (G() == null) {
         S(new Module[3]);
      }

      Cipher var5;
      Cipher var7 = var5 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(107321743799745L << var6 * 8 >>> 56);
      }

      var7.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var10 = b(var5.doFinal("Pdè'ê²\u00920Åö'\u0006£ÕÙ\u0096".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      b = var10;
      Cipher var0;
      Cipher var8 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(107321743799745L << var1 * 8 >>> 56);
      }

      var8.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var4 = var0.doFinal(new byte[]{71, -23, -123, 73, -91, -87, -3, -77});
      long var12 = (var4[0] & 255L) << 56
         | (var4[1] & 255L) << 48
         | (var4[2] & 255L) << 40
         | (var4[3] & 255L) << 32
         | (var4[4] & 255L) << 24
         | (var4[5] & 255L) << 16
         | (var4[6] & 255L) << 8
         | var4[7] & 255L;
      var10001 = -1;
      c = var12;
      树树友树友树何友友何 = new 何树何友友何何友友树();
   }

   public static void S(Module[] var0) {
      友友友何何何树友友友 = var0;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 42;
               case 2 -> 4;
               case 3 -> 30;
               case 4 -> 46;
               case 5 -> 63;
               case 6 -> 35;
               case 7 -> 18;
               case 8 -> 3;
               case 9 -> 61;
               case 10 -> 19;
               case 11 -> 54;
               case 12 -> 21;
               case 13 -> 49;
               case 14 -> 57;
               case 15 -> 58;
               case 16 -> 48;
               case 17 -> 55;
               case 18 -> 32;
               case 19 -> 28;
               case 20 -> 33;
               case 21 -> 26;
               case 22 -> 45;
               case 23 -> 60;
               case 24 -> 31;
               case 25 -> 7;
               case 26 -> 17;
               case 27 -> 53;
               case 28 -> 0;
               case 29 -> 44;
               case 30 -> 20;
               case 31 -> 29;
               case 32 -> 62;
               case 33 -> 51;
               case 34 -> 1;
               case 35 -> 41;
               case 36 -> 14;
               case 37 -> 12;
               case 38 -> 11;
               case 39 -> 56;
               case 40 -> 24;
               case 41 -> 23;
               case 42 -> 52;
               case 43 -> 2;
               case 44 -> 27;
               case 45 -> 9;
               case 46 -> 39;
               case 47 -> 25;
               case 48 -> 43;
               case 49 -> 5;
               case 50 -> 47;
               case 51 -> 13;
               case 52 -> 37;
               case 53 -> 10;
               case 54 -> 22;
               case 55 -> 38;
               case 56 -> 40;
               case 57 -> 59;
               case 58 -> 6;
               case 59 -> 36;
               case 60 -> 8;
               case 61 -> 16;
               case 62 -> 15;
               default -> 34;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'i' && var8 != 251 && var8 != 'n' && var8 != 203) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 't') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 's') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'i') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      e[0] = "wpi`Epx0$kOm}m/-_v:佋桖佖叡叔佁佋厌又栻";
      e[1] = float.class;
      f[1] = "java/lang/Float";
      e[2] = "=F,\u0010)[2\u0006a\u001b#F7[j]0U2]g]/Y.D,伦伓佡厕口佗桢伓佡伋";
      e[3] = "\u0014\u0006[\u0001Nz\u001bF\u0016\nDg\u001e\u001b\u001dLT|Y桹桤桳只佀伢桹传厩佴";
      e[4] = "\u000b!\u001c\u0006\u001fx\u00164D$^u\u000e2";
      e[5] = boolean.class;
      f[5] = "java/lang/Boolean";
      e[6] = "+J\u001aN|\"5B\u0000\u0001\u001e>2_";
      e[7] = "VHPM!\u007f]GA\u0002]fR]OAjVDJC\\{zSG";
      e[8] = "\u000f46i\u0017D;\u00179)ZO1\n<tQ\t9\u00171rUBz5:cLK1C";
      e[9] = long.class;
      f[9] = "java/lang/Long";
      e[10] = "\u001d_kH2X\u0012\u001f&C8E\u0017B-\u00050X\u001aD)Ns栦伫叺厎佾桌叼厵佤伐";
      e[11] = "]Vb+qtR\u0016/ {iWK$fkr\u0010佭伙厃叕栊佫栩伙厃栏";
      e[12] = int.class;
      f[12] = "java/lang/Integer";
      e[13] = "ii\u0019&G\u0015f)T-M\bct_k^\u001bfrRkA\u0017zk\u0019\u000b]\u0017hbE\u0013I\u0016\u007fb";
      e[14] = "1T0,]k/\\*c>\u007f+";
      e[15] = "U\u007fB\nS&a\\MJ\u001e-kAH\u0017\u0015kc\\E\u0011\u0011  ~N\u0000\b)k\b";
      e[16] = void.class;
      f[16] = "java/lang/Void";
      e[17] = "\u0005\n\u001eH@\u0015\u000e\u0005\u000f\u0007!\u001b\u0005\u000e\u000b]";
      e[18] = "\u0015{\u0014\u0017^\tCu\u0013Ig叶栳厉栵桫桾叶佷厉栵rX\u0004\u0012/\u0015N\u000e\n\u0015q";
      e[19] = "E\u001eUw^3\u0015\u001bT,9栒伢厳佯栌叺栒伢桩栫\u0015\u0002wO\u001fU$S5\u0015\t";
      e[20] = " Z_-y\u001cp_^v\u001e栽叙栭校厌叝叧叙号校O`H`H\u0004p\"D&";
      e[21] = "\\!\u0017?`\u000b\b|\u001cA原伿叵桔桩厂企厡栯厎pqm_[0\u0014-e\u0004K";
      e[22] = "\u001b[\u0016[sxO\u0006\u001d%!F@\tL\u0019sFq\u0007\u0003N!.\u0013N\u0015D&";
      e[23] = "\u0016\u0002($\u0012\u0006F\u0007)\u007fu叽栵桵伒伛伨栧佱厯桖FLPJ\u0010>(\u0010P\u0017\u0006";
      e[24] = "\u0002\"8[p:R'9\u0000\u0017叁叻厏框佤佊栛叻桕伂9&zY=a\u0003omR#";
      e[25] = "DG\bj:J\u0010\u001a\u0003\u0014]#GOWlt\\\u0013T\u0013q\u0006IBF\u0014+x\\W\u0011Q\u0014";
      e[26] = "@\u0002fE:\t\u0014_m;叅厣叩伳参佦栟伽栳伳\u0001\u000b7]G\u0013eW?\u0006W";
      e[27] = "\f$*\u0001`NXy!\u007f5'[ps\u0014.\u001bYv6\u0010\\\u001a^v&\r`\u0018X3\"\u007f";
      e[28] = "\u00058u\u000bh-U=tP\u000f佈栦桏发伴双佈佢桏住i>m^',SwzU9";
      e[29] = "\u000f|!^\u000b)[!* 栮伝桼栉桟佽佪桙伸栉F\u0010\u0006}\bm\"L\u000e&\u0018";
      e[30] = "J\t(t`L\u001eT#\n\u0013%I\u0001wr.Z\u001d\u001a3o\\";
      e[31] = "Q5B\bQc\u0005hIv\u0003]\ng\u0018JV];iW\u001d\u00035Y A\u0017\u0004";
      e[32] = "\t)z\u0017=}]tqi栘栍桺优佀厪作佉厠历\u001dR}$\f\",\u0003?~\u001a";
      e[33] = "\u00046t7\fDPk\u007fI栩栴伳桃叐桐佭栴厭桃\u0013rL\u001d\u0001=\"#\u000eG\u0017";
      e[34] = "\u000e{\u0010\ro\u0019Z&\u001bs厐厳厧栎桮桪桊桩厧叔wO0\n\u001dk\u0006\u001fn\u000e^";
      e[35] = "fa\u000e\u0016kV2<\u0005h桎叼叏佐伴桱厔叼栕栔iR+_2\u007fU\u00186A3";
      e[36] = "N\u001cq-9\u001c\u001aAzS栜厶佹伭佋桊佘厶栽桩\u0016c4HI\rr?<\u0013Y";
      e[37] = "Q`6{\u0017T\u0005==\u0005佶你司佑案佘叨栤佦佑Q5\u001a\u0000Vq5i\u0012[F";
      e[38] = "tm9S*O 02-叕栿叝作伃佰叕句标栘^Sz\\b=a\u0011v\u001a";
      e[39] = "\u0006\u0016\u0000t5\u0003RK\u000b\n及伷厯厹伺栓栐伷伱档gte\u0010\u0010FX6iV";
      e[40] = "{O0Y\u0015\u001d+J1\u0002r另厂佼厔佦桫佸伜核桎;\u0018I&_kRL\u0014-";
      e[41] = "10n%7neme[又佚伆企佔桂又栞伆桅\tk::6!m72a&";
      e[42] = "\fIG;a/X\u0014LE桄厅伻格佽优伀桟桿佸 ;1<\u001a\u0019\u001fy=z";
      e[43] = "uyF`vk%|G;\u0011伎伒佊叢佟栈桊桖佊佼\u0002o?5k\u001d=-3s";
      e[44] = "B0^b\u001a\u000e\u00125_9}栯桡厝栠佝桤佫去厝佤\u0000L_\u00118^g\u0019X\u001f8";
      e[45] = "TqG^+\r\u0004tF\u0005L叶伳佂根栥厏栬桷佂佽<}M\u000fn\u001e\u00064Z\u0004p";
      e[46] = "_*\u0015`]P\u000bw\u001e\u001e厢栠栬厅伯叝桸栠叶桟r'\u000f_I7\u001c{\u000f\u0002_";
      e[47] = "2Pv6\u0002\u0003f\r}H叽伷桁叿叒伕叽伷厛佡\u0011rP\r:[)\"U\fa";
      e[48] = "{u3\u00036\u0015/(8}栓伡佌叚伉桤佗桥叒栀TM;A|d0\u00113\u001al";
      e[49] = "z_!\u0003l=0B?\u0002\u001e^\u0000b\u001dp\u001e;<C\u007fO\"q!]~";
      e[50] = "\u0015:{$6KE?z\u007fQ伮栶厗栅伛厒厰佲桍叟Fj\u000f\u001f;{w;ME-";
      e[51] = ".RXg\u000e\u0010~WY<i栱栍栥叼栜桰栱受栥佢\u0005V\u0019,Y\u00069\u0000\u0017+\u0007";
      e[52] = "[?6>c\u001b\u000fb=@伂伯佬桊案伝伂厱佬伎Qz1\u0015S4i*4\u0014\b";
      e[53] = "d\fC\u0005B80QH{桧伌栗桹栽伦厽伌栗厣$E\u0011iq\u0007H\t\u001b)r";
      e[54] = "q}\u0011\u001aYp!x\u0010A>桑厈叐桯桡叽桑伖栊伫x\u00054{|\u0011ITv!j";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树何友友何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public Color o(Color color, int alpha) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.min(Math.max(0, alpha), color.getAlpha()));
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public boolean g(double mouseX, double mouseY, float rectX, float rectY, float rectWidth, float rectHeight) {
      G();
      return mouseX >= rectX && mouseX <= rectX + rectWidth && mouseY >= rectY && mouseY <= rectY + rectHeight;
   }

   private void L() {
      G();
      long time = System.currentTimeMillis();
      float elapsed = (float)(time - this.树何树树树何友何树友);
      if (this.树树树何何友何何友友) {
         this.树友何树何何何树树何 = Math.max(0.0F, 1.0F - elapsed / 200.0F);
         if (this.树友何树何何何树树何 != 0.0F) {
            return;
         }

         super.onClose();
      }

      this.树友何树何何何树树何 = Math.min(1.0F, elapsed / 200.0F);
   }

   private float T(float progress) {
      G();
      if (progress >= 1.0F) {
         return 1.0F;
      } else if (progress <= 0.0F) {
         return 0.0F;
      } else {
         return progress < 0.5F ? 4.0F * progress * progress * progress : 1.0F - (float)Math.pow(-2.0F * progress + 2.0F, 3.0) / 2.0F;
      }
   }

   public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      G();
      if (mc != null) {
         this.L();
         if (!(this.树友何树何何何树树何 <= 0.001F) || !this.树树树何何友何何友友) {
            float mainGuiAnimScale = this.T(this.树友何树何何何树树何);
            int mainGuiActualAlpha = (int)(255.0F * mainGuiAnimScale);
            guiGraphics.fill(0, 0, super.width, super.height, this.o(this.树友友何何树友友树树, (int)(mainGuiActualAlpha * 0.85F)).getRGB());
            Iterator var10 = this.友友友树树树树树友友.iterator();
            if (var10.hasNext()) {
               树树树友何何树何友何 panel = (树树树友何何树何友何)var10.next();
               panel.O();
               panel.I(guiGraphics, mouseX, mouseY, mainGuiActualAlpha);
            }

            if (this.何何何树树何何友何何 != null) {
               this.何何何树树何何友何何.何何何友何树树树何何 = mouseX - this.友树友何何何友友树树;
               this.何何何树树何何友何何.树友树树友友友友友树 = mouseY - this.友何友友何树树何何树;
            }
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "刘凤楠230622109211173513";
   }

   public boolean isPauseScreen() {
      return false;
   }

   public static Module[] G() {
      return 友友友何何何树友友友;
   }

   public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
      G();
      if (keyCode == 256) {
         if (this.友树树友何友树树友树 != null) {
            this.友树树友何友树树友树 = null;
            if (this.友何树友友何友何友何 != null) {
               this.友何树友友何友何友何.友树树何何何树何友树 = null;
            }

            this.友何树友友何友何友何 = null;
            return true;
         } else {
            boolean settingsWereExpanded = false;
            Iterator var8 = this.友友友树树树树树友友.iterator();
            if (var8.hasNext()) {
               树树树友何何树何友何 panel = (树树树友何何树何友何)var8.next();
               if (!panel.友友友树何何树友树何.isEmpty()) {
                  Iterator var10 = new ArrayList<>(panel.友友友树何何树友树何.keySet()).iterator();
                  if (var10.hasNext()) {
                     Module m = (Module)var10.next();
                     if (panel.友友友树何何树友树何.getOrDefault(m, false)) {
                        panel.友友友树何何树友树何.put(m, false);
                        panel.友何何树树友树树何何.put(m, System.currentTimeMillis() - 16L);
                        settingsWereExpanded = true;
                     }
                  }
               }

               if (panel.树何友何树友树何树树) {
                  panel.树何友何树友树何树树 = false;
               }
            }

            if (settingsWereExpanded) {
               return true;
            } else {
               this.树树树何何友何何友友 = true;
               this.树何树树树何友何树友 = System.currentTimeMillis();
               return true;
            }
         }
      } else if (this.友何树友友何友何友何 != null && this.友树树友何友树树友树 != null) {
         return this.友何树友友何友何友何.L(keyCode, scanCode, modifiers, this.友树树友何友树树友树);
      } else {
         return this.友何树友友何友何友何 != null && this.友何树友友何友何友何.树树树友树树树友树何 == 树何友友何树友友何何.友树友树树树友何友树 && this.友何树友友何友何友何.树何友何树友树何树树
            ? this.友何树友友何友何友何.L(keyCode, scanCode, modifiers, null)
            : super.keyPressed(keyCode, scanCode, modifiers);
      }
   }

   public void onClose() {
      this.树树树何何友何何友友 = true;
      this.树何树树树何友何树友 = System.currentTimeMillis();
   }

   protected void init() {
      G();
      super.init();
      if (!this.Q(new Object[]{52406761729175L})) {
         this.树树树何何友何何友友 = false;
         this.树友何树何何何树树何 = 0.0F;
         this.树何树树树何友何树友 = System.currentTimeMillis();
         this.树树何树友树何树友树 = ClientUtils.D(131325480669526L);
         this.树友何何何树何友树树 = this.树树何树友树何树友树 ? Cherish.instance.t().C(16) : Cherish.instance.t().H(16);
         this.树何树树树何何树何树 = this.树树何树友树何树友树 ? Cherish.instance.t().C(14) : Cherish.instance.t().H(14);
         this.何何友何树何友树何何 = Cherish.instance.t().H(14);
         this.友何何何何树友树何树 = Cherish.instance.t().H(12);
         this.树何何友何树何树友树 = Cherish.instance.t().H(12);
         this.友何友树树友何友树友 = Cherish.instance.t().V(18);
         this.友友友何友何树何树何 = Cherish.instance.t().Q(24);
         this.友友友树树树树树友友.clear();
         float currentX = 30.0F;
         float currentY = 30.0F;
         树何友友何树友友何何[] configPanel = 树何友友何树友友何何.M();
         int var11 = configPanel.length;
         int var12 = 0;
         if (0 < var11) {
            树何友友何树友友何何 cat = configPanel[0];
            if (cat == 树何友友何树友友何何.友树友树树树友何友树) {
            }

            树树树友何何树何友何 panel = new 树树树友何何树何友何(cat, 30.0F, 30.0F, this);
            this.友友友树树树树树友友.add(panel);
            currentX = 150.0F;
            if (260.0F > super.width - 30.0F) {
               currentX = 30.0F;
               currentY = 370.0F;
            }

            var12++;
         }

         树树树友何何树何友何 configPanelx = new 树树树友何何树何友何(树何友友何树友友何何.友树友树树树友何友树, currentX, currentY, this);
         this.友友友树树树树树友友.add(configPanelx);
         this.何何何树树何何友何何 = null;
         this.友树树友何友树树友树 = null;
         this.友何树友友何友何友何 = null;
      }
   }

   public boolean mouseReleased(double mouseX, double mouseY, int button) {
      G();
      if (button == 0) {
         if (this.何何何树树何何友何何 != null) {
            this.何何何树树何何友何何.何树友树何友友何树友 = false;
            this.何何何树树何何友何何 = null;
         }

         Iterator var9 = this.友友友树树树树树友友.iterator();
         if (var9.hasNext()) {
            树树树友何何树何友何 panel = (树树树友何何树何友何)var9.next();
            if (panel.树树友树何树何友友何 != null) {
               panel.树树友树何树何友友何 = null;
            }

            if (panel.何树树友何友何何树何 != null) {
               Iterator var11 = panel.何树树友何友何何树何.values().iterator();
               if (var11.hasNext()) {
                  友友何何何树友友何树 handler = (友友何何何树友友何树)var11.next();
                  if (handler instanceof 树友何友树友何友何友) {
                     ((树友何友树友何友何友)handler).x();
                  }
               }
            }
         }
      }

      return super.mouseReleased(mouseX, mouseY, button);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaYmouse) {
      G();
      if (this.何何何树树何何友何何 != null && button == 0) {
         this.何何何树树何何友何何.何何何友何树树树何何 = (float)mouseX - this.友树友何何何友友树树;
         this.何何何树树何何友何何.树友树树友友友友友树 = (float)mouseY - this.友何友友何树树何何树;
         return true;
      } else {
         Iterator var13 = this.友友友树树树树树友友.iterator();
         if (var13.hasNext()) {
            树树树友何何树何友何 panel = (树树树友何何树何友何)var13.next();
            if (panel.树树友树何树何友友何 != null) {
               if (panel.F(panel.树树友树何树何友友何) instanceof 友友何友树友树树何树 numberHandler) {
                  float valueX = panel.何何何友何树树树何何 + 2.0F;
                  Objects.requireNonNull(panel.友友何友何树何何树树);
                  Objects.requireNonNull(panel.友友何友何树何何树树);
                  numberHandler.E(mouseX, valueX, 106.0F, panel.树树友树何树何友友何);
               }

               return true;
            }

            if (panel.何树树友何友何何树何 != null && panel.友友友树何何树友树何 != null) {
               Iterator handler = panel.友友友树何何树友树何.keySet().iterator();
               if (handler.hasNext()) {
                  Module module = (Module)handler.next();
                  if (panel.友友友树何何树友树何.getOrDefault(module, false)) {
                     Iterator valueX = module.P().iterator();
                     if (valueX.hasNext()) {
                        树何何树何友树何何树<?> val = (树何何树何友树何何树<?>)valueX.next();
                        if (val instanceof 树友何何树树何友友何) {
                           友友何何何树友友何树 handlerx = panel.F(val);
                           if (handlerx instanceof 树友何友树友何友何友) {
                           }
                        }
                     }
                  }
               }
            }
         }

         return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaYmouse);
      }
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
      G();
      if (this.树友何树何何何树树何 < 1.0F) {
         return false;
      } else {
         int i = this.友友友树树树树树友友.size() - 1;
         树树树友何何树何友何 panel = this.友友友树树树树树友友.get(i);
         if (panel.G(mouseX, mouseY)) {
            panel.u(delta);
            return true;
         } else {
            i--;
            return super.mouseScrolled(mouseX, mouseY, delta);
         }
      }
   }

   public boolean charTyped(char typedChar, int modifiers) {
      G();
      return this.友何树友友何友何友何 != null && this.友树树友何友树树友树 != null
         ? this.友何树友友何友何友何.Z(typedChar, modifiers, this.友树树友何友树树友树)
         : super.charTyped(typedChar, modifiers);
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      G();
      if (this.树友何树何何何树树何 < 0.95F && !this.树树树何何友何何友友) {
         return false;
      } else {
         this.何何何树树何何友何何 = null;
         this.友树树友何友树树友树 = null;
         this.友何树友友何友何友何 = null;
         int i = this.友友友树树树树树友友.size() - 1;
         树树树友何何树何友何 panel = this.友友友树树树树树友友.get(i);
         何何何友友何树何何何 newlyFocusedInPanel = panel.L(mouseX, mouseY, button);
         this.友树树友何友树树友树 = newlyFocusedInPanel;
         this.友何树友友何友何友何 = panel;
         if (panel.何树友树何友友何树友) {
            this.何何何树树何何友何何 = panel;
            this.友树友何何何友友树树 = (float)mouseX - panel.何何何友何树树树何何;
            this.友何友友何树树何何树 = (float)mouseY - panel.树友树树友友友友友树;
         }

         return true;
      }
   }
}
