package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何何友树树何友何;
import cn.cool.cherish.value.impl.BooleanValue;
import cn.cool.cherish.value.impl.友树何树友友何树友友;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;
import net.minecraft.client.gui.GuiGraphics;

public class 树何友树树何何树何友 implements 何树树友树树友友何何, 何树友 {
   private float 何何树树何树友何何树;
   private boolean 何友树何友树何何树友;
   private long 友树何友树树树友何友;
   private static final long a;
   private static final Object[] b = new Object[25];
   private static final String[] c = new String[25];
   private static String HE_DA_WEI;

   public 树何友树树何何树何友() {
      long a = 树何友树树何何树何友.a ^ 88881243997562L;
      super();
      a<"Ô">(this, 0.0F, -65395424644964565L, a);
      a<"Ô">(this, false, -67272615246751315L, a);
      a<"Ô">(this, 0L, -65560608864014266L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(2850831583628980291L, -7863850434293572296L, MethodHandles.lookup().lookupClass()).a(174365064837240L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'H' && var8 != 212 && var8 != 241 && var8 != 207) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 164) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 234) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'H') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 241) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何友树树何何树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 54;
               case 1 -> 21;
               case 2 -> 25;
               case 3 -> 31;
               case 4 -> 63;
               case 5 -> 13;
               case 6 -> 53;
               case 7 -> 59;
               case 8 -> 0;
               case 9 -> 48;
               case 10 -> 41;
               case 11 -> 30;
               case 12 -> 50;
               case 13 -> 24;
               case 14 -> 33;
               case 15 -> 43;
               case 16 -> 46;
               case 17 -> 32;
               case 18 -> 17;
               case 19 -> 18;
               case 20 -> 36;
               case 21 -> 23;
               case 22 -> 2;
               case 23 -> 15;
               case 24 -> 3;
               case 25 -> 14;
               case 26 -> 60;
               case 27 -> 38;
               case 28 -> 58;
               case 29 -> 11;
               case 30 -> 26;
               case 31 -> 37;
               case 32 -> 35;
               case 33 -> 27;
               case 34 -> 52;
               case 35 -> 12;
               case 36 -> 49;
               case 37 -> 39;
               case 38 -> 20;
               case 39 -> 4;
               case 40 -> 40;
               case 41 -> 56;
               case 42 -> 55;
               case 43 -> 6;
               case 44 -> 57;
               case 45 -> 19;
               case 46 -> 45;
               case 47 -> 7;
               case 48 -> 61;
               case 49 -> 5;
               case 50 -> 29;
               case 51 -> 8;
               case 52 -> 9;
               case 53 -> 51;
               case 54 -> 22;
               case 55 -> 47;
               case 56 -> 10;
               case 57 -> 28;
               case 58 -> 1;
               case 59 -> 42;
               case 60 -> 16;
               case 61 -> 44;
               case 62 -> 34;
               default -> 62;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "b<\u0010f\u0004am|]m\u000e|h!V+\u001eg/桃佫収桺栟佔伇栯佐厠";
      b[1] = boolean.class;
      c[1] = "java/lang/Boolean";
      b[2] = long.class;
      c[2] = "java/lang/Long";
      b[3] = float.class;
      c[3] = "java/lang/Float";
      b[4] = "=fs1W\u00166ib~+\u000f9sl=\u001c?/d` \r\u00138i";
      b[5] = "PVZqI\u0010_\u0016\u0017zC\rZK\u001c<S\u0016\u001d栩县佇佳厴栢栩桥栃佳";
      b[6] = int.class;
      c[6] = "java/lang/Integer";
      b[7] = "7\f\u0004tIF8LI\u007fC[=\u0011B9S@z桳叡叜叭核桅桳栻栆佳";
      b[8] = "kl\u0013 J\u0003d,^+@\u001eaqUmP\u0005&叉佨伖栴厧佝佗佨伖栴";
      b[9] = "m\u007f!`!^pjyB`Shl";
      b[10] = "H\u001e\u0002R)\u0004G^OY#\u0019B\u0003D\u001f3\u0002\u0005桡叧佤桗伾栺伥叧叺厍";
      b[11] = "pC\n`B{{L\u001b/#upG\u001fu";
      b[12] = "3SI|\u0010ndTIap伃栗叽栲叞桩桇体佣叨\u001dNd\u007fCU`H12S";
      b[13] = "\tDI\u007fU}^CIb5桔号栰叨标叶桔佩佴佶\u001e\u000b$V\u0017F&Dw\u0004W";
      b[14] = "]%\u0001)6\u000e\n\"\u00014V栧伽压伾压厕佣桹伕桺HoT\u0012.\u0013x'Z\u000bs";
      b[15] = "k\"rB$Ed'5?伐叽栘伙厎栦伐佣栘厇M\u0006'Lg4}N)U:";
      b[16] = "!BIm\u000fV.G\u000e\u0010厥栴伖叧桯栉桿叮伖叧v)\u0000H9\u001d\u0011+\u0004\u001dp";
      b[17] = "S\u0015\"}lNW@\u007fo\u001e厼厯栲栋叕叝桦伱栲栋\u0016#\u0012\u000eJr&t\u0015\u000eW";
      b[18] = "\u0014f\u0006UMW\u001bcA(佹佱桧栙佤栱叧佱伣栙9\u0012FBAqDGE\u001c\u0013";
      b[19] = ",O\b\t~r{H\b\u0014\u001e厁叒使厩桱佃厁佌栻桳h x`_\u0014\u0015&--O";
      b[20] = "\u0007\u0002\u0014,r\u0002P\u0005\u00141\u0012佯叹厬伫厎栋佯栣桶伫M,\bK\u0012\b0*]\u0006\u0002";
      b[21] = "WW^C5_XR\u0019>5$\u0006\u000b\u001e@b\\Q\r\u0018R\\\u001f\u0007N\u001f\u0000$H\u0001H\r>";
      b[22] = "^7\u001c&<\u0005\t0\u001c;\\叶厠厙厽会桅栬桺桃桧Gb\\\u0001d\u0013\u007f-\u000fS$";
      b[23] = "V*>\u001b\t*\u0000snOd*j-:\u0017\u001f5\tk#\f\u0007K";
      b[24] = "\u000b\u0002P;bv][\u0000o\u000fX7\u0005T7tiTCM,l\u0017";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @Override
   public 友树何树友友何树友友 o(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      long a = 树何友树树何何树何友.a ^ 95047145369492L;
      a<"ê">(1583905966108144807L, a);
      BooleanValue bv = (BooleanValue)value;
      bv.g(!bv.getValue());
      return null;
   }

   private void k(boolean currentValue) {
      long a = 树何友树树何何树何友.a ^ 130640733187292L;
      a<"ê">(-7588298668433272086L, a);
      if (currentValue != a<"H">(this, -7586636902315560949L, a)) {
         a<"Ô">(this, System.currentTimeMillis(), -7588227829265753632L, a);
         a<"Ô">(this, currentValue, -7586636902315560949L, a);
      }

      long elapsed = System.currentTimeMillis() - a<"H">(this, -7588227829265753632L, a);
      if (currentValue) {
         if ((float)elapsed < 200.0F) {
            a<"Ô">(this, (float)elapsed / 200.0F, -7588128649700788595L, a);
         }

         a<"Ô">(this, 1.0F, -7588128649700788595L, a);
      }

      if ((float)elapsed < 200.0F) {
         a<"Ô">(this, 1.0F - (float)elapsed / 200.0F, -7588128649700788595L, a);
      }

      a<"Ô">(this, 0.0F, -7588128649700788595L, a);
      a<"Ô">(this, Math.max(0.0F, Math.min(1.0F, a<"H">(this, -7588128649700788595L, a))), -7588128649700788595L, a);
   }

   @Override
   public float t(树友何树何树何友友友 panel, 树何何何友树树何友何<?> value) {
      long a = 树何友树树何何树何友.a ^ 91152726309804L;
      a<"ê">(126996356114309279L, a);
      String valueName = a<"H">(a<"H">(panel, 126499258514410940L, a), 127993817213110447L, a) ? value.v() : value.W();
      float nameWidth = a<"H">(a<"H">(panel, 126499258514410940L, a), 126118092893725472L, a).A(valueName);
      Objects.requireNonNull(a<"H">(panel, 126499258514410940L, a));
      float availableWidthForControl = 106.0F - nameWidth - 4.0F;
      if (!(nameWidth > 58.300003F) && availableWidthForControl < 26.5F) {
      }

      return 28.8F;
   }

   @Override
   public void v(GuiGraphics g, 树友何树何树何友友友 panel, 树何何何友树树何友何<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      long a = 树何友树树何何树何友.a ^ 17701140531670L;
      BooleanValue bv = (BooleanValue)value;
      a<"ê">(-5495917286382880800L, a);
      this.k(bv.getValue());
      String valueName = a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495241138719573291L, a) ? value.v() : value.W();
      float nameWidth = a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495995446079745702L, a).A(valueName);
      boolean dsj = nameWidth > valw * 0.55F || valw - nameWidth - 4.0F < valw * 0.25F;
      float currentYOffset = valy;
      float textRenderX = valx + 2.0F;
      a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495995446079745702L, a)
         .m(
            g.pose(),
            valueName,
            textRenderX,
            valy + 8.0F - a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495995446079745702L, a).K() / 2.0F,
            a<"H">(panel, -5495754279661289530L, a).Z(a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495855826448343429L, a), alpha).getRGB()
         );
      if (dsj) {
         currentYOffset = valy + 12.8F;
      }

      float checkMarkSize = a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495378328217864118L, a).K();
      float squareSize = checkMarkSize + 4.0F;
      float squareX = valx + valw - squareSize - 2.0F;
      float squareY = currentYOffset + 8.0F - squareSize / 2.0F;
      RenderUtils.drawRectangle(
         g.pose(),
         squareX,
         squareY,
         squareSize,
         squareSize,
         a<"H">(panel, -5495754279661289530L, a).Z(a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495453945164376855L, a), (int)(alpha * 0.7F)).getRGB()
      );
      if (a<"H">(this, -5495539460616383609L, a) > 0.01F) {
         float iconX = squareX + squareSize / 2.0F - a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495646676016418861L, a).A("\ueb53") / 2.0F;
         float iconY = squareY + squareSize / 2.0F - a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495646676016418861L, a).K() / 2.0F;
         int animatedCheckMarkAlpha = (int)(alpha * a<"H">(this, -5495539460616383609L, a));
         a<"H">(a<"H">(panel, -5495754279661289530L, a), -5495646676016418861L, a)
            .m(g.pose(), "\ueb53", iconX, iconY, a<"H">(panel, -5495754279661289530L, a).Z(HUD.instance.getColor(1), animatedCheckMarkAlpha).getRGB());
      }
   }

   private static String LIU_YA_FENG() {
      return "何树友，和树做朋友";
   }
}
