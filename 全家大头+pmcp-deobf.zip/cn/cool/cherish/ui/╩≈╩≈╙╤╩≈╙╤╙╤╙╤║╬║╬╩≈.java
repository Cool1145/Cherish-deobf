package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.player.RotationUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

public class 树树友树友友友何何树 implements 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[20];
   private static final String[] f = new String[20];
   private static String HE_DA_WEI;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-6080139487305943311L, -2420724107409518987L, MethodHandles.lookup().lookupClass()).a(62773737681813L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(74752169134574L << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 16;
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "*\u009dÄÎíW)\u0080\u0087®DjûhzY Ò\u0099\u0005òëç©¬\u001dö<\u0091y´\u0017¯\u009dÉ@.\u0004\u0084¤\u0013Ò\u001co`\u0097\u0091\u0085ñ"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 49) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "*\u009dÄÎíW)\u0080\u0087®DjûhzY Ò\u0099\u0005òëç©¬\u001dö<\u0091y´\u0017¯\u009dÉ@.\u0004\u0084¤\u0013Ò\u001co`\u0097\u0091\u0085ñ"
            .charAt(var4);
      }
   }

   public static void i(PoseStack poseStack, LivingEntity target, int x, int y) {
      友树何友何友何树树树 fontManager = Cherish.instance.t();
      何树友友友何树何何何.v();
      float x2 = x + 40.0F;
      int minHealth = (int)target.getHealth();
      int maxHealth = (int)target.getMaxHealth();
      String name = "HP: " + minHealth + " | Dist:" + Math.round(RotationUtils.i(target, 55874601829708L));
      RenderUtils.drawRectangle(poseStack, x, y, 140.0F, 50.0F, new Color(0, 0, 0).getRGB());
      RenderUtils.drawRectangle(poseStack, x + 0.5F, y + 0.5F, 139.0F, 49.0F, new Color(60, 60, 60).getRGB());
      RenderUtils.drawRectangle(poseStack, x + 1.5F, y + 1.5F, 137.0F, 47.0F, new Color(0, 0, 0).getRGB());
      RenderUtils.drawRectangle(poseStack, x + 2, y + 2, 136.0F, 46.0F, new Color(25, 25, 24).getRGB());
      fontManager.w().A(poseStack, target.getName().getString(), x + 40, y + 6, Color.WHITE.getRGB());
      poseStack.pushPose();
      poseStack.scale(0.7F, 0.7F, 0.7F);
      fontManager.w().A(poseStack, name, (x + 40.0F) * 1.4285715F, (y + 17.0F) * 1.4285715F, Color.WHITE.getRGB());
      poseStack.popPose();
      RenderUtils.drawRectangle(poseStack, x2, y + 25, 91 * (minHealth / maxHealth), 6.0F, 何树友友树树友何树何.V(target, 132587739379361L).getRGB());
      RenderUtils.drawRectangle(poseStack, x2, y + 25, 91.0F, 1.0F, new Color(0, 0, 0).getRGB());
      RenderUtils.drawRectangle(poseStack, x2, y + 30, 91.0F, 1.0F, new Color(0, 0, 0).getRGB());
      int i = 0;
      RenderUtils.drawRectangle(poseStack, x2 + 0.0F, y + 25, 1.0F, 6.0F, new Color(0, 0, 0).getRGB());
      i++;
      Module.V(new Module[4]);
      RenderUtils.J(93908985785544L, poseStack, x2, y + 31, target.getMainHandItem());
      RenderUtils.J(93908985785544L, poseStack, x2 + 15.0F, y + 31, target.getItemBySlot(EquipmentSlot.HEAD));
      RenderUtils.J(93908985785544L, poseStack, x2 + 30.0F, y + 31, target.getItemBySlot(EquipmentSlot.CHEST));
      RenderUtils.J(93908985785544L, poseStack, x2 + 45.0F, y + 31, target.getItemBySlot(EquipmentSlot.LEGS));
      RenderUtils.J(93908985785544L, poseStack, x2 + 60.0F, y + 31, target.getItemBySlot(EquipmentSlot.FEET));
      poseStack.pushPose();
      poseStack.scale(0.4F, 0.4F, 0.4F);
      poseStack.translate((x + 20) * 2.5, (y + 44) * 2.5, 100.0);
      RenderUtils.U(poseStack, target.getYRot(), target.getXRot(), 57061602846276L, target);
      poseStack.popPose();
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树友树友友友何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 254 && var8 != '$' && var8 != 194 && var8 != 252) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 208) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 206) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 254) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == '$') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 194) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树树友树友友友何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 56;
               case 1 -> 47;
               case 2 -> 33;
               case 3 -> 5;
               case 4 -> 54;
               case 5 -> 48;
               case 6 -> 53;
               case 7 -> 46;
               case 8 -> 25;
               case 9 -> 9;
               case 10 -> 6;
               case 11 -> 16;
               case 12 -> 38;
               case 13 -> 28;
               case 14 -> 57;
               case 15 -> 49;
               case 16 -> 51;
               case 17 -> 62;
               case 18 -> 55;
               case 19 -> 14;
               case 20 -> 39;
               case 21 -> 7;
               case 22 -> 13;
               case 23 -> 12;
               case 24 -> 29;
               case 25 -> 34;
               case 26 -> 4;
               case 27 -> 1;
               case 28 -> 40;
               case 29 -> 18;
               case 30 -> 3;
               case 31 -> 2;
               case 32 -> 44;
               case 33 -> 42;
               case 34 -> 8;
               case 35 -> 22;
               case 36 -> 17;
               case 37 -> 26;
               case 38 -> 0;
               case 39 -> 32;
               case 40 -> 30;
               case 41 -> 43;
               case 42 -> 27;
               case 43 -> 59;
               case 44 -> 35;
               case 45 -> 41;
               case 46 -> 37;
               case 47 -> 50;
               case 48 -> 36;
               case 49 -> 24;
               case 50 -> 23;
               case 51 -> 31;
               case 52 -> 11;
               case 53 -> 15;
               case 54 -> 58;
               case 55 -> 21;
               case 56 -> 61;
               case 57 -> 19;
               case 58 -> 45;
               case 59 -> 52;
               case 60 -> 10;
               case 61 -> 63;
               case 62 -> 60;
               default -> 20;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      e[0] = "\u0012zP\u000bX^\u0012zGWTQ\b1SJG[\u00181AKA^\bf\n`DB\u0015oI@[C/sKQ";
      e[1] = "W\u0006YQTyXF\u0014Z^d]\u001b\u001f\u001cVyP\u001d\u001bW\u0015[[\f\u0002^^";
      e[2] = "g\b\u0015S`JS+\u001a\u0013-AY6\u001fN&\u0007Q+\u0012H\"L\u0012\t\u0019Y;EY\u007f";
      e[3] = "!!6\fM\u0001.a{\u0007G\u001c+<pAW\u0007l桞栉厤栳厥厉厄位伺栳";
      e[4] = "I\u001e\b\u0014ZuB\u0011\u0019[&lM\u000b\u0017\u0018\u0011\\[\u001c\u001b\u0005\u0000pL\u0011";
      e[5] = "~p\u0018u=\\q0U~7Atm^8'Z3佋栧叝厙司佈栏佣佃伇";
      e[6] = boolean.class;
      f[6] = "java/lang/Boolean";
      e[7] = "t|400\biil\u0012q\u0005qo";
      e[8] = "$\\\u0012\fLB\u0010\u007f\u001dL\u0001I\u001ab\u0018\u0011\n\u000f\u0012\u007f\u0015\u0017\u000eDQ]\u001e\u0006\u0017M\u001a+";
      e[9] = void.class;
      f[9] = "java/lang/Void";
      e[10] = "iGa\u0006vvbHpI\u0017xiCt\u0013";
      e[11] = ":ts4BL%o-Q=g\u0010OB4\u0019\u001b:/$+\u0002E";
      e[12] = ";t1\b1 $oomA\u0006\u0013O\\mo&oq;\u000bp=1";
      e[13] = "<\u0012]RL\u0016#\t\u000379=\u0014.lR\u0017A<I\nM\f\u001f";
      e[14] = "\u00151u3J\u0006\u0016ps'&m,?1tOGC;??G?";
      e[15] = "1eeI\b_n/cNw_\u000booL\u0014D4m%\u0018\u001961'&\u0014\u0005\t3mr\u0019w";
      e[16] = "A\u007f=#\u0003gG?n/rhz2`>IdFq}&H\u0016";
      e[17] = "\u0016\u001emU\u007f\u001f\u0011\u0012p]\u001a2j.]w\u001aQ[\u0003n_hVW\u001ef";
      e[18] = "A\f;\u007fi\fBM=k\u0005kx\u0002\u007f8lM\u0017\u0006qsd5FW==z[\u0003\rxm\u0005";
      e[19] = "~2l\u000frxa)2j\tSR\u001e]\u000f)/~i;\u00102q";
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9923;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树树友树友友友何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String HE_DA_WEI() {
      return "刘凤楠230622109211173513";
   }
}
