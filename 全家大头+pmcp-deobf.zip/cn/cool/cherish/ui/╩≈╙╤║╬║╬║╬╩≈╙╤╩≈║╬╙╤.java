package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.友树何友友何树何友何;
import cn.cool.cherish.utils.何友友何树何树何树友;
import cn.cool.cherish.utils.animations.何何何何何友树树树友;
import cn.cool.cherish.utils.animations.何友友何何友何友友何;
import cn.cool.cherish.utils.animations.友何树友树何何友树树;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.render.何树友友树树友何树何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树友何何何树友树何友 implements IWrapper, 何树友 {
   private static final CopyOnWriteArrayList<树友何何何树友树何友> 友友何树何树树友树友;
   private static final 友树何友何友何树树树 何树友友树何树树何何;
   private final 何树友友何友友何树树 友树友友树树友树何友;
   private static float 树树树友树友何树友树;
   private final 何何何何何友树树树友 树友何何友树树树树何;
   private final String 树何何树友何何树树友;
   private final 何友友何树何树何树友 友友何友友树树树树友;
   private final String 树树何友树何何友何何;
   private final float 友树何树树友树友友何;
   private static String[] 树友何树树友树友树何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[44];
   private static final String[] g = new String[44];
   private static int _何大伟为什么要诈骗何炜霖 _;

   public 树友何何何树友树何友(何树友友何友友何树树 notificationType, String title, String description, float time) {
      this.树树何友树何何友何何 = title;
      this.树何何树友何何树树友 = description;
      何树友友何友友何树树.q();
      this.友树何树树友树友友何 = (float)((long)(time * 1000.0F));
      this.友友何友友树树树树友 = new 何友友何树何树何树友(51913986529303L);
      this.友树友友树树友树何友 = notificationType;
      this.树友何何友树树树树何 = new 何友友何何友何友友何(500, 16923, 1.0, 47854, '溑');
      Module.V(new Module[1]);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(3305016567407002748L, -7413484062574677590L, MethodHandles.lookup().lookupClass()).a(28260918029143L);
      // $VF: monitorexit
      a = var10000;
      a();
      String[] var10 = new String[4];
      k(var10);
      Cipher var0;
      Cipher var11 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(32946564240219L << var1 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[15];
      int var5 = 0;
      String var4 = "\u0006-\u008f,Ý\u009fKçSµÜúÇ|\u0089ärÏDEÄn\u009bÒ4iåßLØ\u000b1\u0010o\u0014U\u0082BØºqm²\u0093w^#0ß ôñ$k\u008d79¼zT\u009a\u001a\u0013´\u009bw©$\u009a\u008c¥\u00ad¸J\u0093Ü¨þÖ\u0098\u0014\u0095 ºp¤°\u0016\u008b\u0001y=\u0092\u008e\u0098Ð<½ö\u001dÑÍ>\u0003\u0018Ð\u001a\u008dà\u009cP^\u0000þ2\u0010AU\u0016ô'uî_<<\n$Á\u0001\u0000Á\u0010hd\u0019\u0083GH³\u0098\u009e\u0014\u0097X.\u0019¥ç\u0010\u0082Lì\u009aM¡]¬]~Æ×ô'\u0013Ò\u0010\u0088v\u0010ÓkÞà«£x°\u001aõú)¾ fÌ\u0005\\\u0010+½\u009fj\u0012¶õÝ)W#¼§®¯2\u0005\u001e\u0088\u0000úôú\u008cF\\0\u0010l\u008dîb\u007fÂ?ö#WÛÈ\u0099À$\u007f\u0010\u008a+oÞä\u0012dÊá\u001a\u008cÐ\u0015\u0094\b\f\u0010|\u00adÎèõ¦b\nl\u009c\u009f\u00adþ\u0088ÿÃ\u0010\u0004\u001d2Ëîfõ³\nY1ï\u0004MÍG";
      short var6 = 284;
      char var3 = ' ';
      int var9 = -1;

      label27:
      while (true) {
         String var12 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var18 = b(var0.doFinal(var12.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var18;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[15];
                     友友何树何树树友树友 = new CopyOnWriteArrayList<>();
                     何树友友树何树树何何 = Cherish.instance.t();
                     树树树友树友何树友树 = 2.0F;
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var18;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "ÐÑUýGd¢¡3\u0004È¦ú\u001d©-\u0010\u009dûG#`p\f½üZ\u000b\rÆl\u0006~";
                  var6 = 33;
                  var3 = 16;
                  var9 = -1;
            }

            var12 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public static String[] Z() {
      return 树友何树树友树友树何;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 45;
               case 1 -> 22;
               case 2 -> 5;
               case 3 -> 2;
               case 4 -> 40;
               case 5 -> 9;
               case 6 -> 21;
               case 7 -> 44;
               case 8 -> 43;
               case 9 -> 25;
               case 10 -> 38;
               case 11 -> 46;
               case 12 -> 51;
               case 13 -> 31;
               case 14 -> 13;
               case 15 -> 18;
               case 16 -> 50;
               case 17 -> 41;
               case 18 -> 20;
               case 19 -> 6;
               case 20 -> 14;
               case 21 -> 10;
               case 22 -> 63;
               case 23 -> 58;
               case 24 -> 19;
               case 25 -> 33;
               case 26 -> 39;
               case 27 -> 17;
               case 28 -> 29;
               case 29 -> 26;
               case 30 -> 61;
               case 31 -> 62;
               case 32 -> 47;
               case 33 -> 15;
               case 34 -> 55;
               case 35 -> 28;
               case 36 -> 8;
               case 37 -> 3;
               case 38 -> 48;
               case 39 -> 0;
               case 40 -> 11;
               case 41 -> 52;
               case 42 -> 24;
               case 43 -> 37;
               case 44 -> 42;
               case 45 -> 34;
               case 46 -> 23;
               case 47 -> 36;
               case 48 -> 57;
               case 49 -> 1;
               case 50 -> 56;
               case 51 -> 4;
               case 52 -> 35;
               case 53 -> 49;
               case 54 -> 16;
               case 55 -> 59;
               case 56 -> 60;
               case 57 -> 12;
               case 58 -> 32;
               case 59 -> 53;
               case 60 -> 7;
               case 61 -> 27;
               case 62 -> 54;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何何何树友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 170 && var8 != 'u' && var8 != 246 && var8 != 212) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 229) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'i') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 170) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 246) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private void n(PoseStack poseStack, float x, float y, float width, float height) {
      何树友友何友友何树树.q();
      float percentage = Math.min((float)this.友友何友友树树树树友.F(79314830707009L) / this.友树何树树友树友友何, 1.0F);
      boolean isEnglish = ClientUtils.D(131325480669526L);
      String var15 = 友树何友友何树何友何.何何树树树友友树树树.getValue();
      byte var16 = -1;
      switch (var15.hashCode()) {
         case -1887554740:
            if (!var15.equals("Cherish")) {
               break;
            }

            var16 = 0;
         case -352259601:
            if (!var15.equals("Exhibition")) {
               break;
            }

            var16 = 1;
         case 63055923:
            if (!var15.equals("Xylitol")) {
               break;
            }

            var16 = 2;
         case 1712985934:
            if (var15.equals("Novoline")) {
               var16 = 3;
            }
      }

      switch (var16) {
         case 0:
            this.G(poseStack, x, y, width, height, isEnglish);
         case 1:
            this.q(poseStack, x, y, width, height, percentage, isEnglish);
         case 2:
            this.r(poseStack, x, y, width, height, percentage);
         case 3:
            this.h(poseStack, x, y, width, height, percentage, isEnglish);
      }
   }

   private void h(PoseStack poseStack, float x, float y, float width, float height, float percentage, boolean isEnglish) {
      Color typeColor = this.友树友友树树友树何友.U();
      Color bgColor = new Color(0, 0, 0, 110);
      Color textColor = Color.WHITE;
      Color descColor = new Color(200, 200, 200, 255);
      float timeRemaining = (this.友树何树树友树友友何 - (float)this.友友何友友树树树树友.F(79314830707009L)) / 1000.0F;
      String timeDisplay = String.format("", Math.max(0.0F, timeRemaining));
      RenderUtils.drawRectangle(poseStack, x, y, width, height, bgColor.getRGB());
      float progressWidth = width * (1.0F - percentage);
      RenderUtils.drawRectangle(poseStack, x, y + height - 1.0F, progressWidth, 1.0F, typeColor.getRGB());
      何树友友树何树树何何.r(30).q(poseStack, this.友树友友树树友树何友.t(), x + 6.5F, y + 6.5F, typeColor.getRGB());
      何树友友树何树树何何.w().A(poseStack, this.树树何友树何何友何何, x + 25.0F, y + 2.0F, textColor.getRGB());
      何树友友树何树树何何.w().A(poseStack, this.树何何树友何何树树友 + " " + timeDisplay, x + 25.0F, y + 12.5F, descColor.getRGB());
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "\b\u000bYa\t=\u0007K\u0014j\u0003 \u0002\u0016\u001f,\u0013;E桴厼佗伳伇桺厮桦佗厭";
      f[1] = "\\tt$zeS49/pxVi2i`c\u0011住桋厌叞佟叴发伏桖栄";
      f[2] = "\u001ar7;+V\u00152z0!K\u0010oqv1PW受栈伍厏佬厲佉栈桉桕";
      f[3] = "o){\u0002!\"d&jM\\:w!c\u0004";
      f[4] = "\u001d6f,6\u0010\u00169wcJ\t\u0019#y }9\u000f4u=l\u0015\u00189";
      f[5] = boolean.class;
      g[5] = "java/lang/Boolean";
      f[6] = "\u0000X\u0013]F+\u000f\u0018^VL6\nEU\u0010D+\u0007CQ[\u0007-\u000eFQ\u0010M-\u0010FQ_Pj厨栧佨叵叢休桲佣叶佫";
      f[7] = "w\u0010\u000faaLxPBjkQ}\rI,xBx\u000bD,gNd\u0012\u000fOaGq(@n{F";
      f[8] = "H\u0004_,\u0004+U\u0011\u0007\u000eE&M\u0017";
      f[9] = float.class;
      g[9] = "java/lang/Float";
      f[10] = "$\u007fubH\u0015+?8iB\b.b3/J\u0015#d7d\t7(u.mB";
      f[11] = "X\u001c`\u0015|\u000fl?oU1\u0004f\"j\b:Bn?g\u000e>\t-\u001dl\u001f'\u0000fk";
      f[12] = "e~\"#f\u001bQ]-c+\u0010[@(> VS]%8$\u001d\u0010\u007f.)=\u0014[\t";
      f[13] = void.class;
      g[13] = "java/lang/Void";
      f[14] = "c=\t[U%\u0016\u001d\u0002TDjk\u0005\u0011SM#\u0003";
      f[15] = "P\u0019<vA\u0005_Yq}K\u0018Z\u0004z;[\u001eZ\u001ba;佻厡司伢栃佀栿伿栢厼";
      f[16] = "i-\f`u8w%\u0016/8\"m/\u000fs)(m8TB4=z\u0003\u0014V)$w);s),z\u0000\u0013r/";
      f[17] = "sXn\u001c_M|\u0018#\u0017UPyE(QEVyZ3QQLy[!\u000bYM~En厴佥栳叛栧伕伪叻栳栁";
      f[18] = "\u001b5\u0006`.Z\u0014uKk$G\u0011(@-4A\u00117[- [\u00116Iw(Z\u0016(\u0006佖伔你伭伎口栒桐栤厳";
      f[19] = "(p\u001fh#+#\u007f\u000e'B%(t\n}";
      f[20] = "4j#\u001aLxkn6wB\u0019d8mK]zocj\u0016!(2u0FCz69.w";
      f[21] = "-R4(TxrV!E叺栀佉栨桟历栠叚受佬F{D~.]><\bg+";
      f[22] = "\u001d\u0012L|q\u0001B\u0016Y\u0011叟桹叧厲栧栈叟桹佹厲>(!\u001b\u0019\u001aF{'PT";
      f[23] = "b\u001d`Q=?=\u0002mG\u0006佚伃伧栛佧佛叄桇伧佟:;6f\u000bpPll.\u0010";
      f[24] = "&ca\u000e\u001b\rygtc厵厯佂參叐桺桯桵栆參\u0013\n\r\u001du:\u007f\n\u000b\u0001b";
      f[25] = "ottS:K0pa>厔叩伋栎佛栧桎叩桏叔\u0006T:N8.8[o\u0011:";
      f[26] = "!T\u0013Fm`~P\u0006+佝栘叛叴桸佶栙栘佅佪a\u0012p8 ^PKn8v";
      f[27] = "c!r03)0'9}X Z'lh'8$abp#Qk#uli39'9rX";
      f[28] = "*+\u001fB\u0015lu/\n/桡栔栊压桴召伥栔叐桑m\u0011\u0005j)$\u0015VIs,";
      f[29] = "hWg*\u0002)7Hj<9栈伉佭栜桘佤栈厗佭佘A\u0004 lAw+Sz$Z";
      f[30] = "\u007f\u0017AW\u000b\u0017 \u0013T:桿伫伛桭台佧伻桯桟厷3\u0000\u0000\u00168\n_A\u0002\u0013\u007f";
      f[31] = "cV\u001dTt&<R\b9栀桞伇叶桶佤佄厄伇佨o\u0003\u007f'$K\u0003B}\"c";
      f[32] = "/\u001b\u001eu2-,DUkJ\u0000Uo$VJt,W\u000fm-ws\u001c\u0011";
      f[33] = "{\n#(\u0016($\u000e6E\u0012IyX=%\u0011t,\u001b44{rs\u00051/F'0\f E";
      f[34] = "\\B@\u000fD\"\u000fD\u000bB/#eD^WP3\u001b\u0002POTZ";
      f[35] = "t\u0004\u000fo92'\u0002D\"R厉厎栠桭桋桋众伐叺厷Rkw6\u0004\u001f*8q}I";
      f[36] = "\t !`[\u0017\u0007!<#*桤桺厘桅变佷桤厠伆企\u001b@\u0006\u001e -qN\u0007\u0003c";
      f[37] = "\u0017Glu\u007fpHCy\u0018栋叒佳佹叝栁栋栈样佹\u001esva\u0016T/)u)N";
      f[38] = "~\\W\u00057#x\u0000\u0016\u0006P\u0014A\t\u0000\u0006/v EU\u0011(F";
      f[39] = " v\u0006z\u001a\u0016#)Mdb.^\n+WbO#:\u0017b\u0005L|q\t";
      f[40] = "_\u0012W\u000e\u0016`YN\u0016\rq[`G\u0000\r\u000e5\u0001\u000bU\u001a\t\u0005QH\u0017\t@g\u0003L[\u0017q";
      f[41] = "_4B6\u0013hQ5_ub栛栬伒栦伐桻佟佨厌叼M\byH4N'\u0006xUw";
      f[42] = " hcIb&\u007fwn_Y佃佁栖栘栻厚叝栅栖栘\"d/$~sH3ule";
      f[43] = "C]HeS\r\u001cBEsh佨厼栣叩栗伵佨桦栣栳\u000eU\u0004GKXd\u0002^\u000fP";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树友何何何树友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7344;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/树友何何何树友树何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[ÂöÍç\u0086eî5öÒ=Ï \t\u0084\u0091,")[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public static void m(PoseStack poseStack) {
      Window window = mc.getWindow();
      float height = 0.0F;
      float width = 0.0F;
      何树友友何友友何树树.q();
      T(2.0F);
      Iterator var25 = 友友何树何树树友树友.iterator();
      if (var25.hasNext()) {
         树友何何何树友树何友 notification = (树友何何何树友树何友)var25.next();
         何何何何何友树树树友 animation = notification.树友何何友树树树树何;
         animation.n(
            notification.友友何友友树树树树友.A((long)notification.友树何树树友树友友何, 118344821288830L) ? 友何树友树何何友树树.树树友树友何树友何何 : 友何树友树何何友树树.树树何树何树何何友友, 59020024422499L
         );
         if (animation.A(14032659181055L, 友何树友树何何友树树.树树友树友何树友何何)) {
            友友何树何树树友树友.remove(notification);
         }

         animation.w(21852481901325L, 400);
         float actualOffset = 友树何友友何树何友何.何何何树何何友树何何.K("White") ? 0.0F : 3.0F;
         if (ClientUtils.D(131325480669526L)) {
            String var28 = 友树何友友何树何友何.何何树树树友友树树树.getValue();
            byte var29 = -1;
            switch (var28.hashCode()) {
               case -1887554740:
                  if (!var28.equals("Cherish")) {
                     break;
                  }

                  var29 = 0;
               case -352259601:
                  if (!var28.equals("Exhibition")) {
                     break;
                  }

                  var29 = 1;
               case 63055923:
                  if (!var28.equals("Xylitol")) {
                     break;
                  }

                  var29 = 2;
               case 1712985934:
                  if (var28.equals("Novoline")) {
                     var29 = 3;
                  }
            }
            width = switch (var29) {
               case 0 -> {
                  height = 31.0F;
                  yield Math.max(100, Math.max(何树友友树何树树何何.C(20).D(notification.树何何树友何何树树友), 何树友友树何树树何何.H(18).D(notification.树树何友树何何友何何)) + 38);
               }
               case 1 -> {
                  height = 27.0F;
                  yield Math.max(100, Math.max(何树友友树何树树何何.H(18).D(notification.树树何友树何何友何何) + 4, 何树友友树何树树何何.H(14).D(notification.树何何树友何何树树友) + 26));
               }
               case 2 -> {
                  height = 23.0F;
                  yield 何树友友树何树树何何.H(18).D(notification.树何何树友何何树树友) + 25;
               }
               case 3 -> {
                  height = 24.0F;
                  String timeDisplay = String.format("(%.1fs)", (notification.友树何树树友树友友何 - (float)notification.友友何友友树树树树友.F(79314830707009L)) / 1000.0F);
                  float titleWidth = 何树友友树何树树何何.w().Y(notification.树树何友树何何友何何);
                  float descWidth = 何树友友树何树树何何.w().Y(notification.树何何树友何何树树友 + " " + timeDisplay);
                  yield Math.max(120.0F, Math.max(titleWidth, descWidth) + 30.0F);
               }
               default -> 0.0F;
            };
         }

         String var34 = 友树何友友何树何友何.何何树树树友友树树树.getValue();
         byte var35 = -1;
         switch (var34.hashCode()) {
            case -1887554740:
               if (!var34.equals("Cherish")) {
                  break;
               }

               var35 = 0;
            case -352259601:
               if (!var34.equals("Exhibition")) {
                  break;
               }

               var35 = 1;
            case 63055923:
               if (!var34.equals("Xylitol")) {
                  break;
               }

               var35 = 2;
            case 1712985934:
               if (var34.equals("Novoline")) {
                  var35 = 3;
               }
         }
         width = switch (var35) {
            case 0 -> {
               height = 31.0F;
               yield Math.max(100, Math.max(何树友友树何树树何何.H(20).D(notification.树何何树友何何树树友), 何树友友树何树树何何.H(18).D(notification.树树何友树何何友何何)) + 38);
            }
            case 1 -> {
               height = 27.0F;
               yield Math.max(100, Math.max(何树友友树何树树何何.H(18).D(notification.树树何友树何何友何何) + 4, 何树友友树何树树何何.H(14).D(notification.树何何树友何何树树友) + 26));
            }
            case 2 -> {
               height = 23.0F;
               yield 何树友友树何树树何何.H(18).D(notification.树何何树友何何树树友) + 25;
            }
            case 3 -> {
               height = 24.0F;
               String timeDisplay = String.format("(%.1fs)", (notification.友树何树树友树友友何 - (float)notification.友友何友友树树树树友.F(79314830707009L)) / 1000.0F);
               float titleWidth = 何树友友树何树树何何.w().Y(notification.树树何友树何何友何何);
               float descWidth = 何树友友树何树树何何.w().Y(notification.树何何树友何何树树友 + " " + timeDisplay);
               yield Math.max(120.0F, Math.max(titleWidth, descWidth) + 30.0F);
            }
            default -> width;
         };
         if (友树何友友何树何友何.树何何树树何树友何何.K("Center")) {
            float var40 = (float)((window.getGuiScaledWidth() / 2.0 + width / 2.0F - width) / animation.D(124111691745592L));
            var40 = window.getGuiScaledHeight() / 2.0F + 0.0F + 15.0F;
         }

         float x = (float)(window.getGuiScaledWidth() - width * animation.D(124111691745592L));
         float y = window.getGuiScaledHeight() - 0.0F - height - 33.0F;
         poseStack.pushPose();
         if (友树何友友何树何友何.何友树友树何何树树树.K("Zoom")) {
            poseStack.translate((x + width / 2.0) * (1.0 - animation.D(124111691745592L)), (y + height / 2.0) * (1.0 - animation.D(124111691745592L)), 0.0);
            poseStack.scale((float)animation.D(124111691745592L), (float)animation.D(124111691745592L), 0.0F);
         }

         if (友树何友友何树何友何.何何树树树友友树树树.K("Xylitol")) {
            notification.n(poseStack, x - 5.0F, y, width, height);
         }

         notification.n(poseStack, x, y, width, height);
         poseStack.popPose();
         float var42 = 0.0F + (float)((height + actualOffset) * animation.D(124111691745592L));
      }

      if (Module.Z() == null) {
         何树友友何友友何树树.y(false);
      }
   }

   public static void k(String[] var0) {
      树友何树树友树友树何 = var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private void q(PoseStack poseStack, float x, float y, float width, float height, float percentage, boolean isEnglish) {
      何树友友何友友何树树.q();
      float finalX = this.友树友友树树友树何友 == 何树友友何友友何树树.友友树树树树何何友友 ? x + 3.0F : x;
      Color bgColor = 友树何友友何树何友何.何何何树何何友树何何.K("White") ? Color.WHITE : (友树何友友何树何友何.何何何树何何友树何何.K("Alpha") ? new Color(0, 0, 0, 75) : Color.BLACK);
      Color fontColor = 友树何友友何树何友何.何何何树何何友树何何.K("White") ? Color.BLACK : Color.WHITE;
      Color iconcolor = 何树友友树树友何树何.j(this.友树友友树树友树何友.U(), 70.0F);
      RenderUtils.drawRoundedRect(poseStack, x, y, width, height, 0.0, bgColor);
      RenderUtils.drawRoundedRect(poseStack, x, y + height - 1.0F, width * percentage, 1.0, 0.0, this.友树友友树树友树何友.U());
      何树友友树何树树何何.r(35).q(poseStack, this.友树友友树树友树何友.t(), finalX + 5.0F, y + 7.0F, iconcolor.getRGB());
      何树友友树何树树何何.H(18).q(poseStack, this.树树何友树何何友何何, x + 22.0F, y + 4.5F, fontColor.getRGB());
      何树友友树何树树何何.H(14).q(poseStack, this.树何何树友何何树树友, x + 22.0F, y + 17.0F, fontColor.getRGB());
   }

   public static void z(何树友友何友友何树树 notificationType, String title, String description) {
      友友何树何树树友树友.add(new 树友何何何树友树何友(notificationType, title, description, 树树树友树友何树友树));
   }

   private void r(PoseStack poseStack, float x, float y, float width, float height, float percentage) {
      Color color = 何树友友树树友何树何.j(何树友友树树友何树何.p(Color.BLACK, this.友树友友树树友树何友.U(), 0.65F), 70.0F);
      Color iconColor = 何树友友树树友何树何.j(this.友树友友树树友树何友.U(), 70.0F);
      Color textColor = 何树友友树树友何树何.j(Color.WHITE, 80.0F);
      RenderUtils.drawRectangle(poseStack, x, y, width + 4.75F, height, new Color(0, 0, 0, 70).getRGB());
      RenderUtils.drawRectangle(poseStack, x, y, width * percentage, height, color.getRGB());
      何树友友树何树树何何.r(30).q(poseStack, this.友树友友树树友树何友.t(), x + 5.0F, y + 7.0F, iconColor.getRGB());
      何树友友树何树树何何.H(18).q(poseStack, this.树何何树友何何树树友, x + 21.0F, y + 8.65F, textColor.getRGB());
   }

   public static void E(何树友友何友友何树树 notificationType, String title, String description, float time) {
      友友何树何树树友树友.add(new 树友何何何树友树何友(notificationType, title, description, time));
   }

   public static void T(float toggleTime) {
      树树树友树友何树友树 = 2.0F;
   }

   private static String HE_WEI_LIN() {
      return "刘凤楠230622109211173513";
   }

   private void G(PoseStack poseStack, float x, float y, float width, float height, boolean isEnglish) {
      RenderUtils.k(poseStack, new Color(20, 20, 20, 80), x, y, x + width, y + height, 8.0, 36.0, 3609919736005L);
      RenderUtils.k(poseStack, new Color(20, 20, 20, 40), x + 4.0F, y + 4.0F, x + height - 4.0F, y + height - 4.0F, 4.0, 36.0, 3609919736005L);
      何树友友何友友何树树.q();
      何树友友树何树树何何.r(30).q(poseStack, this.友树友友树树友树何友.t(), x + 9.5F, y + 11.0F, new Color(200, 200, 200, 255).getRGB());
      if (isEnglish) {
         何树友友树何树树何何.C(20).q(poseStack, this.树树何友树何何友何何, x + 30.0F, y + 4.0F, new Color(200, 200, 200, 255).getRGB());
         何树友友树何树树何何.H(18).q(poseStack, this.树何何树友何何树树友, x + 30.0F, y + 17.0F, new Color(200, 200, 200, 255).getRGB());
      }

      何树友友树何树树何何.H(20).q(poseStack, this.树树何友树何何友何何, x + 30.0F, y + 4.0F, new Color(200, 200, 200, 255).getRGB());
      何树友友树何树树何何.H(18).q(poseStack, this.树何何树友何何树树友, x + 30.0F, y + 17.0F, new Color(200, 200, 200, 255).getRGB());
   }
}
