package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.value.树何何树何友树何何树;
import cn.cool.cherish.value.impl.何何何友友何树何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;

public class 树何何何友何树何何何 implements 友友何何何树友友何树, 何树友 {
   private static final long a;
   private static final long[] b;
   private static final Long[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[20];
   private static final String[] f = new String[20];
   private static String LIU_YA_FENG;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(1639032925125733342L, -379675116127407427L, MethodHandles.lookup().lookupClass()).a(12270167059221L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var13 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(94714254007836L << var3 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      int var5 = 0;
      byte var4 = 0;

      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = "\u0013x#¬\u009bïÕàç^ÚÁy´B9".substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         byte var15 = -1;
         var8[var10001] = var10004;
      } while (var4 < 16);

      b = var8;
      c = new Long[2];
   }

   @Override
   public float Z(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value) {
      Objects.requireNonNull(panel.友友何友何树何何树树);
      Objects.requireNonNull(panel.友友何友何树何何树树);
      树友树树何友何何树友.树何何何友友何友友友 layout = 树友树树何友何何树友.何友何友友友何树树何.k(panel, value, 0.0F, 0.0F, 106.0F);
      return 16.0F + layout.d();
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何何友何树何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static long a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = a(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 234 && var8 != 'Y' && var8 != 243 && var8 != 165) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 225) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'm') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 234) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Y') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 243) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   @Override
   public void a(GuiGraphics g, 树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, float valx, float valy, float valw, int mousex, int mousey, int alpha) {
      树友树树何友何何树友.树何何何友友何友友友 layout = 树友树树何友何何树友.何友何友友友何树树何.k(panel, value, valx, valy, valw);
      何何何友友何树何何何 tv = (何何何友友何树何何何)value;
      b<"m">(2572080730873245730L, 53303731626931L);
      b<"ê">(b<"ê">(panel, 2571753397390537565L, 53303731626931L), 2571786304527504394L, 53303731626931L)
         .s(
            g.pose(),
            layout.Z(),
            layout.A(),
            layout.K(),
            b<"ê">(panel, 2571753397390537565L, 53303731626931L)
               .o(b<"ê">(b<"ê">(panel, 2571753397390537565L, 53303731626931L), 2571989579060527400L, 53303731626931L), alpha)
               .getRGB()
         );
      Objects.requireNonNull(b<"ê">(panel, 2571753397390537565L, 53303731626931L));
      float boxY = layout.H() + 8.0F - 6.4F;
      boolean isFocused = b<"ê">(b<"ê">(panel, 2571753397390537565L, 53303731626931L), 2573671833090919877L, 53303731626931L) == tv
         && b<"ê">(b<"ê">(panel, 2571753397390537565L, 53303731626931L), 2573737383607871464L, 53303731626931L) == panel;
      RenderUtils.drawRectangle(
         g.pose(), layout.n(), boxY, layout.P(), 12.8F, b<"ê">(panel, 2571753397390537565L, 53303731626931L).o(HUD.instance.getColor(4), alpha).getRGB()
      );
      String displayText = tv.getValue();
      if (isFocused && System.currentTimeMillis() / a<"e">(24674, 5294225308643752815L) % a<"e">(12315, 1248326270223133463L) == 0L) {
         displayText = displayText + "_";
      }

      if (b<"ê">(b<"ê">(panel, 2571753397390537565L, 53303731626931L), 2571670063676398580L, 53303731626931L).D(displayText) > layout.P() - 4.0F
         && !displayText.isEmpty()) {
         displayText = displayText.endsWith("_") ? displayText.substring(1, displayText.length() - 1) + "_" : displayText.substring(1);
      }

      if (tv.getValue().endsWith("_") && !displayText.endsWith("_") && !displayText.isEmpty() && isFocused) {
         displayText = displayText.substring(0, displayText.length() - 1) + "_";
      }

      b<"ê">(b<"ê">(panel, 2571753397390537565L, 53303731626931L), 2571670063676398580L, 53303731626931L)
         .s(
            g.pose(),
            displayText,
            layout.n() + 2.0F,
            boxY + 6.4F - b<"ê">(b<"ê">(panel, 2571753397390537565L, 53303731626931L), 2571670063676398580L, 53303731626931L).x() / 2.0F,
            b<"ê">(panel, 2571753397390537565L, 53303731626931L)
               .o(b<"ê">(b<"ê">(panel, 2571753397390537565L, 53303731626931L), 2571989579060527400L, 53303731626931L), alpha)
               .getRGB()
         );
   }

   private static long a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6925;
      if (c[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = b[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])d.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/树何何何友何树何何何", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         c[var3] = var15;
      }

      return c[var3];
   }

   private static void a() {
      e[0] = "-=09f;\"}}2l&' vt|=`桂栏桋参企伛桂佋厑作";
      e[1] = "z\u001e `A<u^mkK!p\u0003f-[:7伥栟佖句厘佌伥叅又栿";
      e[2] = "\u000fz*81S\u0012or\u001ap^\ni";
      e[3] = "3&z,T'<f7'^:9;<aN!~伝企厄台桙伅桙企厄株";
      e[4] = "\u0017Bbr.2\u0018\u0002/y$/\u001d_$?7<\u0018Y)?(0\u0004@b佄伔伈县叧伙栀伔伈伡";
      e[5] = "r?g\rH\u0007}\u007f*\u0006B\u001ax\"!@R\u0001?桀厂桿栶伽叚伄伜桿召";
      e[6] = int.class;
      f[6] = "java/lang/Integer";
      e[7] = "5^u\u0000S\\:\u001e8\u000bYA?C3MIZx校伎伶佩司伃校伎伶佩";
      e[8] = "\u0019\u0006KP^e\u0012\tZ\u001f\"|\u001d\u0013T\\\u0015L\u000b\u0004XA\u0004`\u001c\t";
      e[9] = "\n\u0005lAF\"\u0001\n}\u000e',\n\u0001yT";
      e[10] = "y]s=\rby\ba>2栁厃伻佀厇栫叛厃伻栄D\u000bb>\u0019c-Mi*\u001b";
      e[11] = "\u0002\u0017VGZtS]M_*U9QQXVbC\u001dYYZ\u0004";
      e[12] = "*TImO\u000e*\u0001[np桭低伲栾佉桩伩栊伲古\u0014I\u000em\u0010Y}\u000f\u0005y\u0012";
      e[13] = "f\n_tvjf_MwI栉伂佬史佐桐位框史栨\rs*\"[V54*e^";
      e[14] = "Wl\"-\u0013v\u0015h/Q厼厏伶受低案伢休桲栍\u0013hD\"\u0012+ih\u00110\u0011";
      e[15] = "\u0012\u0005\u0001\u007ft\u007f\u0012P\u0013|K叆佶佣伲佛桒叆栲佣桶\u0006q?VT\b>6?\u0011Q";
      e[16] = "(\tP\u000f\u0013.-\u000b\t\u0014r7\u0015Z\u001c\u001f\u0003a*\u0006\u000f\u0000\b^(\u0017\u000e\fMat\u0004\u0011\u0007r";
      e[17] = "q{+|x>3\u007f&\u0000受栝桔佞佇佝栍余厎栚\u001a;z<(m*9k{1";
      e[18] = "<E\r_a\u0002<\u0010\u001f\\^去栜桧厠佻厝桡栜厽桺&e\u0016=\u001b\r\u0016g\u0007z\u0002";
      e[19] = "=LbdB:=\u0019pg}厃余桮叏叞传厃余厴佑\u001dA85\u000b`'\u0003<8";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 14;
               case 1 -> 13;
               case 2 -> 17;
               case 3 -> 52;
               case 4 -> 20;
               case 5 -> 16;
               case 6 -> 1;
               case 7 -> 53;
               case 8 -> 10;
               case 9 -> 54;
               case 10 -> 28;
               case 11 -> 38;
               case 12 -> 41;
               case 13 -> 22;
               case 14 -> 0;
               case 15 -> 32;
               case 16 -> 18;
               case 17 -> 27;
               case 18 -> 8;
               case 19 -> 31;
               case 20 -> 39;
               case 21 -> 51;
               case 22 -> 47;
               case 23 -> 3;
               case 24 -> 56;
               case 25 -> 12;
               case 26 -> 40;
               case 27 -> 21;
               case 28 -> 25;
               case 29 -> 36;
               case 30 -> 49;
               case 31 -> 58;
               case 32 -> 50;
               case 33 -> 42;
               case 34 -> 7;
               case 35 -> 55;
               case 36 -> 60;
               case 37 -> 23;
               case 38 -> 61;
               case 39 -> 35;
               case 40 -> 24;
               case 41 -> 59;
               case 42 -> 62;
               case 43 -> 37;
               case 44 -> 9;
               case 45 -> 6;
               case 46 -> 11;
               case 47 -> 15;
               case 48 -> 48;
               case 49 -> 43;
               case 50 -> 29;
               case 51 -> 26;
               case 52 -> 46;
               case 53 -> 33;
               case 54 -> 34;
               case 55 -> 2;
               case 56 -> 44;
               case 57 -> 57;
               case 58 -> 4;
               case 59 -> 5;
               case 60 -> 19;
               case 61 -> 63;
               case 62 -> 30;
               default -> 45;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何何何友何树何何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @Override
   public 何何何友友何树何何何 K(树树树友何何树何友何 panel, 树何何树何友树何何树<?> value, double mx, double my, int btn, float vx, float vy, float vw) {
      树友树树何友何何树友.Y();
      树友树树何友何何树友.树何何何友友何友友友 layout = 树友树树何友何何树友.何友何友友友何树树何.k(panel, value, vx, vy, vw);
      Objects.requireNonNull(panel.友友何友何树何何树树);
      if (panel.友友何友何树何何树树.g(mx, my, layout.n(), layout.H() + 8.0F - 6.4F, layout.P(), 12.8F)) {
         panel.友树树何何何树何友树 = (何何何友友何树何何何)value;
         return (何何何友友何树何何何)value;
      } else {
         return null;
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖国企上班";
   }
}
