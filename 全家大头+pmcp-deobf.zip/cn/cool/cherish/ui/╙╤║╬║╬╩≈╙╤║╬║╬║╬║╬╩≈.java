package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.render.友树友友友何友友友何;
import cn.lzq.injection.asm.invoked.render.ModernFontTextEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;

public final class 友何何树友何何何何树 implements AutoCloseable, 何树友 {
   private static final FontRenderContext 树树树友树何友友何树;
   private final Map<Character, 友何何树友何何何何树.友何友树树友何树友树> 友友树树树树树树友树;
   private static final Map<Integer, Font> 何何何友树友友树树树;
   private static final int[] 树树树树树友何友何树;
   private final FontMetrics 树何友树何何树何友树;
   private final boolean 何树何友何树友树何友;
   private final int 友何树树友友何友何友;
   private final int 友友树树何友何何树何;
   private final Font 何树何何友友友树何树;
   private final Font 树友何何友树何树何何;
   private static String[] 友友树友树树何何何何;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[78];
   private static final String[] i = new String[78];
   private static String HE_JIAN_GUO;

   public 友何何树友何何何何树(Font font, boolean antiAliasing) {
      long a = 友何何树友何何何何树.a ^ 52538645041364L;
      super();
      c<"Ö">(1297014765350704081L, a);
      this.友友树树树树树树友树 = new ConcurrentHashMap<>();
      this.树友何何友树何树何何 = font;
      this.友何树树友友何友何友 = font.getSize();
      this.友友树树何友何何树何 = O(font.getSize() * 2 + 8);
      this.何树何友何树友树何友 = antiAliasing;
      this.何树何何友友友树何树 = this.O();
      this.树何友树何何树何友树 = new Canvas().getFontMetrics(font);
      if (!c<"Ö">(1289894050060134785L, a)) {
         c<"Ö">(new String[2], 1290123384831952799L, a);
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7037091014093056507L, 9204832040609539337L, MethodHandles.lookup().lookupClass()).a(102497727770935L);
      // $VF: monitorexit
      a = var10000;
      long a = 友何何树友何何何何树.a ^ 139166858657316L;
      a();
      c<"Ö">(null, -65547141929522833L, a);
      Cipher ax;
      Cipher var28 = ax = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(a >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int axx = 1; axx < 8; axx++) {
         var10003[axx] = (byte)(a << axx * 8 >>> 56);
      }

      var28.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] axx = new String[2];
      int axxx = 0;
      int axxxx = ' ';
      int axxxxx = -1;

      while (true) {
         String var33 = a(
               ax.doFinal(
                  " íR\u00ad\u0005\u008eUÍËw«\u0019\u0097\u0097¿\u0081Ë\u001d\u00ad\bÒõ ®F-ñ¿\u0004\u0087\u0001¬(_\u008c\u0015\u0019\u0088\u001eLú7Ò\u0006,^\u0007¤\u0089LP¦\u001c þ!\t<ôÜÂ¢È\u008b\u0000´éD\u000bÂ\u0016\u0010("
                     .substring(++axxxxx, axxxxx + axxxx)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         int var10001 = -1;
         axx[axxx++] = var33;
         if ((axxxxx += axxxx) >= 73) {
            b = axx;
            c = new String[2];
            g = new HashMap(13);
            Cipher axxxxxx;
            Cipher var29 = axxxxxx = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)(a >>> 56), 0, 0, 0, 0, 0, 0, 0};

            for (int axxxxxxx = 1; axxxxxxx < 8; axxxxxxx++) {
               var10003[axxxxxxx] = (byte)(a << axxxxxxx * 8 >>> 56);
            }

            var29.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] axxxxxxx = new long[3];
            int axxxxxxxx = 0;
            int axxxxxxxxx = 0;

            do {
               var10001 = axxxxxxxxx;
               axxxxxxxxx += 8;
               byte[] axxxxxxxxxx = "g¡\u0000dÂ®\u0019ù¿æN5³ºïF\u0089,É$íc|<".substring(var10001, axxxxxxxxx).getBytes("ISO-8859-1");
               var10001 = axxxxxxxx++;
               long axxxxxxxxxxx = (axxxxxxxxxx[0] & 255L) << 56
                  | (axxxxxxxxxx[1] & 255L) << 48
                  | (axxxxxxxxxx[2] & 255L) << 40
                  | (axxxxxxxxxx[3] & 255L) << 32
                  | (axxxxxxxxxx[4] & 255L) << 24
                  | (axxxxxxxxxx[5] & 255L) << 16
                  | (axxxxxxxxxx[6] & 255L) << 8
                  | axxxxxxxxxx[7] & 255L;
               byte[] axxxxxxxxxxxx = axxxxxx.doFinal(
                  new byte[]{
                     (byte)(axxxxxxxxxxx >>> 56),
                     (byte)(axxxxxxxxxxx >>> 48),
                     (byte)(axxxxxxxxxxx >>> 40),
                     (byte)(axxxxxxxxxxx >>> 32),
                     (byte)(axxxxxxxxxxx >>> 24),
                     (byte)(axxxxxxxxxxx >>> 16),
                     (byte)(axxxxxxxxxxx >>> 8),
                     (byte)axxxxxxxxxxx
                  }
               );
               long var10004 = (axxxxxxxxxxxx[0] & 255L) << 56
                  | (axxxxxxxxxxxx[1] & 255L) << 48
                  | (axxxxxxxxxxxx[2] & 255L) << 40
                  | (axxxxxxxxxxxx[3] & 255L) << 32
                  | (axxxxxxxxxxxx[4] & 255L) << 24
                  | (axxxxxxxxxxxx[5] & 255L) << 16
                  | (axxxxxxxxxxxx[6] & 255L) << 8
                  | axxxxxxxxxxxx[7] & 255L;
               byte var37 = -1;
               axxxxxxx[var10001] = var10004;
            } while (axxxxxxxxx < 24);

            e = axxxxxxx;
            f = new Integer[3];
            树树树友树何友友何树 = new FontRenderContext(new AffineTransform(), true, true);
            何何何友树友友树树树 = new HashMap<>();
            树树树树树友何友何树 = new int[32];

            for (int i = 0; i < c<"p">(-68757420518078959L, a).length; i++) {
               int offset = (i >> 3 & 1) * 85;
               int red = (i >> 2 & 1) * 170 + offset;
               int green = (i >> 1 & 1) * 170 + offset;
               int blue = (i & 1) * 170 + offset;
               if (i == 6) {
                  red += 85;
               }

               if (i >= 16) {
                  red /= 4;
                  green /= 4;
                  blue /= 4;
               }

               c<"p">(-68757420518078959L, a)[i] = (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
            }

            return;
         }

         axxxx = " íR\u00ad\u0005\u008eUÍËw«\u0019\u0097\u0097¿\u0081Ë\u001d\u00ad\bÒõ ®F-ñ¿\u0004\u0087\u0001¬(_\u008c\u0015\u0019\u0088\u001eLú7Ò\u0006,^\u0007¤\u0089LP¦\u001c þ!\t<ôÜÂ¢È\u008b\u0000´éD\u000bÂ\u0016\u0010("
            .charAt(axxxxx);
      }
   }

   private static void B(Graphics2D g, boolean antiAliasing) {
      long a = 友何何树友何何何何树.a ^ 87782403879471L;
      c<"Ö">(8287903215981965610L, a);
      g.setRenderingHint(c<"p">(8288572641743239403L, a), c<"p">(8288858167335073702L, a));
      g.setRenderingHint(c<"p">(8287595191296328771L, a), c<"p">(8289952937995982689L, a));
      g.setRenderingHint(c<"p">(8287595191296328771L, a), c<"p">(8288749257093562124L, a));
      g.setRenderingHint(c<"p">(8294780208548452851L, a), c<"p">(8287750300119099794L, a));
      g.setRenderingHint(c<"p">(8289463623646450207L, a), c<"p">(8287302840959986940L, a));
      g.setRenderingHint(c<"p">(8289710274913477184L, a), c<"p">(8287145847128437823L, a));
      g.setRenderingHint(c<"p">(8287398883016633713L, a), c<"p">(8295483927204376681L, a));
      g.setRenderingHint(c<"p">(8294609712787010386L, a), c<"p">(8287829555075008585L, a));
      g.setRenderingHint(c<"p">(8287005938933137735L, a), c<"p">(8288483516518490715L, a));
   }

   private static void C(int color) {
      float alpha = (color >> 24 & 0xFF) / 255.0F;
      float red = (color >> 16 & 0xFF) / 255.0F;
      float green = (color >> 8 & 0xFF) / 255.0F;
      float blue = (color & 0xFF) / 255.0F;
      RenderSystem.setShaderColor(red, green, blue, alpha);
   }

   public int D(PoseStack poseStack, String s, int x, int y, int color) {
      return this.W(poseStack, s, x, y, color, false);
   }

   public static void D(String[] var0) {
      友友树友树树何何何何 = var0;
   }

   public String D(String text, int width) {
      return this.s(text, 112, false);
   }

   private void S(PoseStack poseStack, List<友何何树友何何何何树.友树何树树何何友友树> lines) {
      long a = 友何何树友何何何何树.a ^ 40859286656848L;
      c<"Ö">(1620142407106974805L, a);
      if (!lines.isEmpty()) {
         RenderSystem.setShaderTexture(0, 0);
         RenderSystem.setShader(GameRenderer::getPositionShader);
         Map<Integer, List<友何何树友何何何何树.友树何树树何何友友树>> colorGroups = new LinkedHashMap<>();
         Iterator matrix = lines.iterator();
         if (matrix.hasNext()) {
            友何何树友何何何何树.友树何树树何何友友树 line = (友何何树友何何何何树.友树何树树何何友友树)matrix.next();
            colorGroups.computeIfAbsent(c<"$">(line, 1620848508085082322L, a), k -> new ArrayList<>()).add(line);
         }

         Matrix4f matrixx = poseStack.last().pose();
         Iterator var14 = colorGroups.entrySet().iterator();
         if (var14.hasNext()) {
            Entry<Integer, List<友何何树友何何何何树.友树何树树何何友友树>> entry = (Entry<Integer, List<友何何树友何何何何树.友树何树树何何友友树>>)var14.next();
            C(entry.getKey());
            BufferBuilder builder = Tesselator.getInstance().getBuilder();
            builder.begin(c<"p">(1619176212684310622L, a), c<"p">(1619788459487898752L, a));
            Iterator var11 = entry.getValue().iterator();
            if (var11.hasNext()) {
               友何何树友何何何何树.友树何树树何何友友树 line = (友何何树友何何何何树.友树何树树何何友友树)var11.next();
               builder.vertex(matrixx, (float)c<"$">(line, 1612674398243122561L, a), (float)c<"$">(line, 1620375931686884727L, a), 0.0F).endVertex();
               builder.vertex(matrixx, (float)c<"$">(line, 1612720781686626114L, a), (float)c<"$">(line, 1620375931686884727L, a), 0.0F).endVertex();
               builder.vertex(matrixx, (float)c<"$">(line, 1612720781686626114L, a), (float)c<"$">(line, 1619340629455209337L, a), 0.0F).endVertex();
               builder.vertex(matrixx, (float)c<"$">(line, 1612674398243122561L, a), (float)c<"$">(line, 1619340629455209337L, a), 0.0F).endVertex();
            }

            BufferUploader.drawWithShader(builder.end());
         }
      }
   }

   public static String[] Z() {
      return 友友树友树树何何何何;
   }

   public void e(PoseStack poseStack, String s, double x, double y, int color, boolean shadow) {
      long a = 友何何树友何何何何树.a ^ 107464573578931L;
      c<"Ö">(-5793702270544122442L, a);
      if (shadow) {
         this.y(poseStack, s, x + 0.5, y + 0.5, this.G(color), true);
      }

      this.y(poseStack, s, x, y, color, false);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 28299;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().getId();
         Object[] var10000 = (Object[])g.get(var8);

         byte[] var10;
         try {
            Object[] var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            g.put(var8, var9);
            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("cn/cool/cherish/ui/友何何树友何何何何树", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友何何树友何何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   public String s(String text, int width, boolean reverse) {
      long a = 友何何树友何何何何树.a ^ 42958396351850L;
      StringBuilder stringbuilder = new StringBuilder();
      c<"Ö">(2612620859002087023L, a);
      int j = reverse ? -1 : 1;
      if (0 < text.length() && 0.0F < width) {
         char c0 = text.charAt(0);
         if (c0 == 167) {
         }

         友何何树友何何何何树.友何友树树友何树友树 glyph = this.w(c0);
         float f1 = c<"$">(glyph, 2618882847299218821L, a) * 0.5F;
         if (f1 < 0.0F) {
         }

         if (0.0F + f1 > width) {
         }

         if (reverse) {
            stringbuilder.insert(0, c0);
         }

         stringbuilder.append(c0);
         int var10000 = 0 + j;
      }

      return stringbuilder.toString();
   }

   public int c(PoseStack poseStack, String s, float x, float y, int color) {
      return this.y(poseStack, s, x, y, -1, false);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public int c(PoseStack poseStack, String s, double x, double y, int color) {
      return this.y(poseStack, s, x, y, color, false);
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友何何树友何何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void l() {
      long a = 友何何树友何何何何树.a ^ 124698405697597L;
      c<"Ö">(-5109700259794060488L, a);
      if (c<"$">(this, -5109647251044769347L, a).size() > 1024) {
         c<"$">(this, -5109647251044769347L, a).entrySet().removeIf(entry -> {
            long ax = 友何何树友何何何何树.a ^ 102926474958057L;
            c<"Ö">(1567989731031406572L, ax);
            return Math.random() < 0.1;
         });
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != '$' && var8 != 246 && var8 != 'p' && var8 != 212) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'g') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 214) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == '$') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 246) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'p') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void a() {
      h[0] = "g2np\"!hr#{(<m/(=8'*厗伕但桜厅佑伉伕但桜";
      h[1] = "Dc\t8)71C\u000278xL[\u0011011$";
      h[2] = "UjF\u000e\":H\u007f\u001e=i5[nB\u0006b<wb^\u001b\u007f";
      h[3] = "WE`sCAJP8@\bNYAd{\u0003GuMxf\u001e\u0004vAo";
      h[4] = "MHQ6\u00111FG@yp?MLD#";
      h[5] = "\u0014\u0002>\b0b\u001f\r/GL{\u0010\u0017!\u0004{K\u0006\u0000-\u0019jg\u0011\r";
      h[6] = "7~7.`p)v-a\u0003d-";
      h[7] = "\u000b=^\u0002K>\u0004}\u0013\tA#\u0001 \u0018OQ8F厘伥伴栵厚伽伆伥伴栵u伽厘桡桰可伄伽厘桡桰";
      h[8] = double.class;
      i[8] = "java/lang/Double";
      h[9] = boolean.class;
      i[9] = "java/lang/Boolean";
      h[10] = "x`R[z#w \u001fPp>r}\u0014\u0016`%5叅伩佭栄厇低佛伩佭栄h叐佛厷栩栄厇低栟厷栩";
      h[11] = int.class;
      i[11] = "java/lang/Integer";
      h[12] = "\u0004%f-.1\r+edm<\u000b+qfp:I<nq7;\u001fdOf%?\u0012&\u007fU&,\u0013/sE,,\n+\u007f";
      h[13] = "M\u000bEb AD\u0005F+cLB\u0005R)~J\u0000\u0012M>9KVJ~)?ZK\u001cn#?CO\u0010";
      h[14] = "$%3&J7-+0o\t:++$m\u0014<i<;zS=?d\bmU,\"2\u0018gU5&>zEH<\"";
      h[15] = "7\u007fx\n\u0000\u000fB_s\u0005\u0011@?G`\u0002\u0018\tW";
      h[16] = void.class;
      i[16] = "java/lang/Void";
      h[17] = "~&;y:Eqfvr0Xt;}48Ey=y\u007f{gr,`v0";
      h[18] = "\u0005N\u001cUN_\n\u000eQ^DB\u000fSZ\u0018TYH叫佧佣栰叻伳併佧佣栰\u0014厭栱佧栧栰佥伳叫叹栧";
      h[19] = "O-";
      h[20] = "\u001ebR *\u0007\u0003w\n\u0013a\u0005\u0000bJ&h\u0003";
      h[21] = "|Xo8\u0003UaM7\u001fBZb";
      h[22] = "M(Y\u0010]2P=\u0001\u0017\u001c=Sgi\u001e\u001d'u,A\u0015\u0016!d&A\u0005\u0016+S";
      h[23] = "\u0011\u0017\u001eO}\u0003\f\u0002Fm<\u000e\u0014\u0004";
      h[24] = "&\u007f<H&\u0010;jdog\u001f8S/]z\u0018/m";
      h[25] = "<<`r[0<\u007fh\u007f8JKUQIuOJI\\R~F\u0006>i(J6ev<nT";
      h[26] = "\u001aa\u0004O~\u000e\u001a\"\fB\u001dtm\b5uAmg\u001a/yVpf\u00058iY7\u001a6Y\\\"TRc\u001fB";
      h[27] = "f<\u0007\u000bSd<\u007fR:伶桄伂厂伾栣厨桄伂厂c\u0004\u0005$#x\u0019\u000b\n;8";
      h[28] = "^}Es\u001bNRyVx`@_cKt\u001c \rzU%\u000fI^:A}";
      h[29] = "fs\u0004(Ug<0Q\u0019估伃伂反桹叚厮桇框栗`%\u0002:4q\u0012f\u001c3?";
      h[30] = "\u0010k\u001d\u0018pq\u0010(\u0015\u0015\u0013\u0016c\u0017&4D\u0014g\u0003'.Z\u000ev\u00122=R\u0001q\u0004?2_\u001fj\t43\u0013s\u0011:\u0006\u001a+sE9\u0000";
      h[31] = "i;jN\u001d'<8e\r,伊伋厒栂伫可伊桏厒变v\u0013/'`t\u001f@o38";
      h[32] = "hW\u0015r\u0000\u000bh\u0014\u001d\u007fcl\u001b+.^4y\u0015+4I4h\u001f)?^9e\u000b2:W\"n\u0003oH(\nO1WH|\tI";
      h[33] = "\u000b4-t}N\u000bw%y\u001e)xH\u0016XI9kE\u0000I_0wE\u000fPS+kM\u0000NI0w\fp.w\nR4pzt\f";
      h[34] = "\u0000Z2\u000b&9Z\u0019g:叝參栠栾桏栣标栙叺栾V\u0006qdRX$EomY";
      h[35] = ":DFzz]`\u0007\u0013K\u0010djTN!!\bbW^%B";
      h[36] = "3\\ _YR?X3T\"C>O=X\"\u0003'RpWKPgF(";
      h[37] = "0[\u0002r!Fj\u0018WC佄桦佔佻厥厀叚桦佔栿f-'CfY\u0004:i\u001d8";
      h[38] = ":d9\u0004]\u0005wb(\u00057[]7j\f\u000e\t]\u0007fYIYgx)NJS";
      h[39] = "x=aiV/.0 hg伖历厓佇桀厤厈优伍佇YY%<,##V*#7";
      h[40] = "o\u0007dmh\u001d}Y0<\u000f桶栝厢叉伀栖伲栝厢栓]2\fdXa'kW>\u0004";
      h[41] = "0\u0006Y5}#jE\f\u0004,\u001a2\u0004_i}p`\nZuE!v\u0019P</sx\u001cL\u0004";
      h[42] = "\u007f>>Wbh\u007f}6Z\u0001\u0012\bW\u000f\u007fG\r\u0004O\u001cwH\n\u0004@\u00176;>~tgUsk8j";
      h[43] = "\u0006W\u000fSq~\u0006\u0014\u0007^\u0012\u0019u+4\u007fE\u000ex7){E\u0006z3$hJ\u0000x&5sU\u0001k64{V\u0006`>i\t).A\fQ\t}-G";
      h[44] = ")mR$TCdkC%>\u001dN>\u0001,\u0007LN\u000e\ry@\u001ftqBnC\u0015";
      h[45] = "\u0004\u0018x\u001f6\u0004W[,O\f$0i\u000fy\f\u0014U\u001b~\u0018uG\u0016O.";
      h[46] = "{N9p\u0016/{\r1}uH\b2\u0002\\\"_\u0007*\u001eX1W\b-\bV3\u0016zM6l\u0016.z\u00195j";
      h[47] = "\u000e\u001d%\u001a5w\u000e^-\u0017V\u0010}a\u001e6\u0001\u0012yu\u001f,\u001f\bhd\n?\u0017\u0007or\u0004=Vu\u000fL>\u0018nu[O8";
      h[48] = "F\u0004\t\u007f\u0018\u0015V\u0013Q`~4i*7T~\u0004F\t\r\u007f\u0000\u0014QQ\u0012";
      h[49] = "#kzM28y(/|栓参佇佋叝桥佗栘佇佋\u001e\u00124=ui|\u0005zc+";
      h[50] = "\u0014whf_^N4=W桾伺叮栓佑伊桾伺叮栓\f8\u001f\u001a\u0014dqi\b^\u0013";
      h[51] = "\u000e\u00067#A$TEb\u0012桠栄栮桢桊发伤叞佪桢S~\u0012gY\u0014>i\u0019d\u000f";
      h[52] = "5d\u001fSX+5'\u0017^;QB\r.{\u007fJO\u0015.s}NB\u0006!u\u007f[S\u001d>t;(`g\u000b\rX`5!\u0015";
      h[53] = "~\u00053\r\u0011xl[g\\v佗取厠厞叾厵佗佈桺厞=IrdR2T\u001a2p\n";
      h[54] = "K='\r\f=K~/\u0000oZ8A\u001c!8_-_\u0006/\"S)X\u001b!o?Jl<\u000fW?\u001eo:";
      h[55] = "o_0\u0006_t9Rq\u0007n位伏佯桒栯桷叓伏叱伖6Qh#\u0003$_\u0002(7[";
      h[56] = "eg=qdqe$5|\u0007\u0016\u0016\u001b\u0006]P\u0012\u0012\u0019\u0017]]\u001f\u0006\u0002\u0012TF\u0014\u000e_`+n5<g`\u007fm3";
      h[57] = "p\u0019[\"MI&\u0014\u001a#|叮桔伩口住伡叮厎伩口\u0012BC4\b\u0019hML+\u0013";
      h[58] = "rq]:zcr2U7\u0019\u0019\u0005\u0018l\u001a_\u0006\u0005\u0013c\u001c]\u0013\u0014\b|\u001d\u0019`'rIdz(r4W";
      h[59] = "J$]\u0015\fy\u0010g\b$号厃桪桀佤叧佩伝桪伄9\u001bL1B6PH\f%\u001a";
      h[60] = "\u0016\u001fpn3\b\u0016\\xcPravAS\u001dapp_I\fpecWF\u000bpjh\u00165?\n^\u0018u}jL@";
      h[61] = "JD\u000e\u0016\ni\u001fG\u0001U;佄桬叭厼样司佄厶样厼.\u0004a\u0004\u001f\u0010GW!\u0010G";
      h[62] = "]\u0014Ax=*OJ\u0015)Z伅叵厱栶桑伇伅栯桫佲Hg;VKD2>`\f\u0017";
      h[63] = "#\t1g\u0013\u0013u\u0004pf\"伪标桽桓厔栻厴标桽众W\u001f\u0014~]!-FO$\u0001";
      h[64] = "Na\u0003/,\u0014N\"\u000b\"On9\b2\u0005\bi3\u00032\u0014\u0002k8\u0014?\u000f\tbtc\nu=\u0012\u0017+_3#";
      h[65] = "!\u001dCpD\u0001{^\u0016A08q\rK+\u001fTy\u000e[/|Ra\u0004N~BCu^VA";
      h[66] = "8GmO'G8\u0004eBD=O.\\`\u001e7I#Ji\u00027F:Fr\u001e?I$\u000b\u0014+Ep@h\\~\u0003n";
      h[67] = "\u001aQtJj\u0003L\\5K[伺栾佡双档伆桾古叿双zd\rV\u0004>\n1\u000eYG";
      h[68] = "\f\u0007ZBHRY\u0004U\u0001y栻株桴佶厹伤叡佮厮叨zFZB\\D\u0013\u0015\u001aV\u0004";
      h[69] = "\u000e\u0019XS~\u0004[\u001aW\u0010O伩栨桪只厨桖桭佬桪只kp\f@BF\u0002#LT\u001a";
      h[70] = "L)p\u0013\u001b\u000eY8g\u0017i\u0002&fgS\u0015V\\ihL\u000eo";
      h[71] = "<\u0014t<qzj\u00195=@标作伤佒叏桙佃作桠双\f}}a@dv$&;\u001c";
      h[72] = "\u001fs+\u001dytJp$^H余口叚厙格压栝佽佄桃%w|Q(5L$<Ep";
      h[73] = "dmC(SMv3\u0017y4栦双又叮叛佩栦佒又佰\u0018\t\\o2FbP\u00075n";
      h[74] = "o4UQ9\u007f}j\u0001\u0000^栔余厑栢似厝栔余桋佦acndkP\u001b:5>7";
      h[75] = "}I\\T&J'\n\te标桪桝号校伸叝厰伙栭8\u000be\u001e6YA\u0015pN ";
      h[76] = "if_\u0019$\u001fi%W\u0014Gx\u001a\u001ad5\u0010g\u0015\u0002t\"\u001fa\u0017\u0017e9\u0000`\u0004\u0014x3\u001al\u0012\u00159C|O.=\u0001C(L(";
      h[77] = "\u00065 S(\u001f\\vub叓佻栦桑厇厡位句佢压D]hW\u000e'-\u000e(CV";
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友何何树友何何何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2353;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友何何树友何何何何树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 26;
               case 1 -> 19;
               case 2 -> 57;
               case 3 -> 49;
               case 4 -> 25;
               case 5 -> 3;
               case 6 -> 34;
               case 7 -> 11;
               case 8 -> 30;
               case 9 -> 22;
               case 10 -> 53;
               case 11 -> 55;
               case 12 -> 35;
               case 13 -> 47;
               case 14 -> 63;
               case 15 -> 48;
               case 16 -> 18;
               case 17 -> 56;
               case 18 -> 4;
               case 19 -> 33;
               case 20 -> 7;
               case 21 -> 31;
               case 22 -> 46;
               case 23 -> 10;
               case 24 -> 59;
               case 25 -> 40;
               case 26 -> 20;
               case 27 -> 21;
               case 28 -> 60;
               case 29 -> 28;
               case 30 -> 17;
               case 31 -> 50;
               case 32 -> 45;
               case 33 -> 52;
               case 34 -> 27;
               case 35 -> 39;
               case 36 -> 42;
               case 37 -> 43;
               case 38 -> 54;
               case 39 -> 36;
               case 40 -> 13;
               case 41 -> 12;
               case 42 -> 15;
               case 43 -> 9;
               case 44 -> 38;
               case 45 -> 44;
               case 46 -> 14;
               case 47 -> 32;
               case 48 -> 37;
               case 49 -> 61;
               case 50 -> 23;
               case 51 -> 8;
               case 52 -> 29;
               case 53 -> 51;
               case 54 -> 58;
               case 55 -> 1;
               case 56 -> 5;
               case 57 -> 62;
               case 58 -> 41;
               case 59 -> 24;
               case 60 -> 16;
               case 61 -> 2;
               case 62 -> 0;
               default -> 6;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   public void m(PoseStack poseStack, String s, double x, double y, int color) {
      this.y(poseStack, s, x + 0.5, y + 0.5, this.G(color), true);
      this.y(poseStack, s, x, y, color, false);
   }

   private void m(PoseStack poseStack, int textureId, List<友何何树友何何何何树.何友树树友何何友树树> glyphs) {
      long a = 友何何树友何何何何树.a ^ 126452961776610L;
      c<"Ö">(5965493537854329063L, a);
      Matrix4f matrix = poseStack.last().pose();
      RenderSystem.setShader(GameRenderer::getPositionTexShader);
      RenderSystem.setShaderTexture(0, textureId);
      Map<Integer, List<友何何树友何何何何树.何友树树友何何友树树>> colorGroups = new LinkedHashMap<>();
      Iterator var9 = glyphs.iterator();
      if (var9.hasNext()) {
         友何何树友何何何何树.何友树树友何何友树树 info = (友何何树友何何何何树.何友树树友何何友树树)var9.next();
         colorGroups.computeIfAbsent(c<"$">(info, 5966347393451135860L, a), k -> new ArrayList<>()).add(info);
      }

      var9 = colorGroups.entrySet().iterator();
      if (var9.hasNext()) {
         Entry<Integer, List<友何何树友何何何何树.何友树树友何何友树树>> entry = (Entry<Integer, List<友何何树友何何何何树.何友树树友何何友树树>>)var9.next();
         C(entry.getKey());
         BufferBuilder builder = Tesselator.getInstance().getBuilder();
         builder.begin(c<"p">(5965631253760036076L, a), c<"p">(5965710448350900807L, a));
         Iterator var12 = entry.getValue().iterator();
         if (var12.hasNext()) {
            友何何树友何何何何树.何友树树友何何友树树 info = (友何何树友何何何何树.何友树树友何何友树树)var12.next();
            if (c<"$">(info, 5967017585256483488L, a)) {
               this.N(
                  builder,
                  matrix,
                  c<"$">(info, 5967697037491169094L, a),
                  c<"$">(info, 5967459551954145298L, a) + 1.0,
                  c<"$">(info, 5966871541914536644L, a),
                  c<"$">(info, 5965221931221701793L, a)
               );
            }

            this.N(
               builder,
               matrix,
               c<"$">(info, 5967697037491169094L, a),
               c<"$">(info, 5967459551954145298L, a),
               c<"$">(info, 5966871541914536644L, a),
               c<"$">(info, 5965221931221701793L, a)
            );
         }

         BufferUploader.drawWithShader(builder.end());
      }
   }

   @Override
   public void close() {
      long a = 友何何树友何何何何树.a ^ 32868325318806L;
      c<"$">(this, -6792116081699129066L, a).values().forEach(glyph -> {
         long ax = 友何何树友何何何何树.a ^ 92149017970404L;
         RenderSystem.deleteTexture(c<"$">(glyph, -4053035906889982552L, ax));
      });
      c<"$">(this, -6792116081699129066L, a).clear();
   }

   private 友何何树友何何何何树.友何友树树友何树友树 w(char c) {
      long a = 友何何树友何何何何树.a ^ 76158219883834L;
      return c<"$">(this, -3165512874854150982L, a).computeIfAbsent(c, this::H);
   }

   public int y(PoseStack poseStack, String s, double x, double y, int color, boolean shadow) {
      long a = 友何何树友何何何何树.a ^ 120584524683509L;
      c<"Ö">(1864119083175140336L, a);
      ModernFontTextEvent modernFontTextEvent = new ModernFontTextEvent(s);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(modernFontTextEvent);
      }

      if (modernFontTextEvent.isCancelled()) {
         return (int)x;
      } else {
         s = modernFontTextEvent.getText();
         if (s != null && !s.isEmpty()) {
            poseStack.pushPose();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            poseStack.scale(0.5F, 0.5F, 1.0F);

            try {
               Map<Integer, List<友何何树友何何何何树.何友树树友何何友树树>> glyphGroups = new LinkedHashMap<>();
               List<友何何树友何何何何树.友树何树树何何友友树> lines = new ArrayList<>();
               x = Math.round(x * 2.0);
               y = Math.round((y - 2.0) * 2.0);
               boolean bold = false;
               boolean italic = false;
               boolean strikethrough = false;
               boolean underline = false;
               int currentColor = -1;
               int i = 0;
               if (0 < s.length()) {
                  char c = s.charAt(0);
                  if (c == 167 && 1 < s.length()) {
                     char formatCode = s.charAt(++i);
                     int colorIndex = a<"m">(16382, 2013885101016362776L ^ a).indexOf(formatCode);
                     switch (colorIndex) {
                        case 16:
                        case 17:
                        case 18:
                        case 19:
                        case 20:
                        case 21:
                           bold = false;
                           italic = false;
                           underline = false;
                           strikethrough = false;
                           currentColor = color;
                        default:
                           if (colorIndex >= 0) {
                              int finalColor = c<"p">(1862988605118996672L, a)[colorIndex];
                              currentColor = color & b<"w">(22209, 3106126479866831261L ^ a) | finalColor & b<"w">(23507, 8445511570024279180L ^ a);
                           }
                     }
                  }

                  友何何树友何何何何树.友何友树树友何树友树 glyph = this.w(c);
                  glyphGroups.computeIfAbsent(c<"$">(glyph, 1860416786329142201L, a), k -> new ArrayList<>())
                     .add(new 友何何树友何何何何树.何友树树友何何友树树(glyph, x, y, bold, italic, currentColor));
                  if (strikethrough) {
                     double mid = y + c<"$">(glyph, 1862530086042282773L, a) * 0.5;
                     lines.add(new 友何何树友何何何何树.友树何树树何何友友树(x, mid - 0.5, x + c<"$">(glyph, 1857575053098749978L, a), mid + 0.5, currentColor));
                  }

                  if (underline) {
                     lines.add(
                        new 友何何树友何何何何树.友树何树树何何友友树(
                           x,
                           y + c<"$">(glyph, 1862530086042282773L, a) - 1.0,
                           x + c<"$">(glyph, 1857575053098749978L, a),
                           y + c<"$">(glyph, 1862530086042282773L, a),
                           currentColor
                        )
                     );
                  }

                  double var10000 = x + c<"$">(glyph, 1857575053098749978L, a);
                  i++;
               }

               Iterator var34 = glyphGroups.entrySet().iterator();
               if (var34.hasNext()) {
                  Entry<Integer, List<友何何树友何何何何树.何友树树友何何友树树>> entry = (Entry<Integer, List<友何何树友何何何何树.何友树树友何何友树树>>)var34.next();
                  this.m(poseStack, entry.getKey(), entry.getValue());
               }

               this.S(poseStack, lines);
            } finally {
               poseStack.popPose();
               RenderSystem.disableBlend();
               RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            }

            return this.A(s);
         } else {
            return 0;
         }
      }
   }

   public int A(String s) {
      long a = 友何何树友何何何何树.a ^ 111347148837278L;
      c<"Ö">(-8019320478933134693L, a);
      ModernFontTextEvent modernFontTextEvent = new ModernFontTextEvent(s);
      if (Cherish.instance != null && Cherish.instance.getEventManager() != null) {
         Cherish.instance.getEventManager().call(modernFontTextEvent);
      }

      if (modernFontTextEvent.isCancelled()) {
         return 0;
      } else {
         s = modernFontTextEvent.getText();
         if (s != null && !s.isEmpty()) {
            float ret = 0.0F;
            int i = 0;
            if (0 < s.length()) {
               char c = s.charAt(0);
               if (c == 167 && 1 < s.length()) {
                  i++;
               }

               ret = 0.0F + c<"$">(this.w(c), -8021924385468802703L, a);
               i++;
            }

            return Math.round(ret * 0.5F);
         } else {
            return 0;
         }
      }
   }

   public void L(PoseStack poseStack, String s, double x, double y, int color) {
      this.c(poseStack, s, x - this.A(s) / 2.0, y, color);
   }

   private void N(BufferBuilder builder, Matrix4f matrix, 友何何树友何何何何树.友何友树树友何树友树 glyph, double x, double y, boolean italic) {
      long a = 友何何树友何何何何树.a ^ 128279764511938L;
      float invSize = 1.0F / c<"$">(this, -1301662000915133265L, a);
      float u1 = c<"$">(glyph, -1300564953393324849L, a) * invSize;
      float v1 = c<"$">(glyph, -1301501181272925700L, a) * invSize;
      float u2 = (c<"$">(glyph, -1300564953393324849L, a) + c<"$">(glyph, -1301408713577470931L, a)) * invSize;
      float v2 = (c<"$">(glyph, -1301501181272925700L, a) + c<"$">(glyph, -1302085381875900638L, a)) * invSize;
      builder.vertex(matrix, (float)(x + 2.0), (float)y, 0.0F).uv(u1, v1).endVertex();
      builder.vertex(matrix, (float)(x - 2.0), (float)(y + c<"$">(glyph, -1302085381875900638L, a)), 0.0F).uv(u1, v2).endVertex();
      builder.vertex(matrix, (float)(x + c<"$">(glyph, -1301408713577470931L, a) - 2.0), (float)(y + c<"$">(glyph, -1302085381875900638L, a)), 0.0F)
         .uv(u2, v2)
         .endVertex();
      builder.vertex(matrix, (float)(x + c<"$">(glyph, -1301408713577470931L, a) + 2.0), (float)y, 0.0F).uv(u2, v1).endVertex();
   }

   public void N(PoseStack poseStack, String s, double x, double y, int color, boolean shadow, double shadowOffSet) {
      long a = 友何何树友何何何何树.a ^ 6789289330267L;
      c<"Ö">(-8687226068102167202L, a);
      if (shadow) {
         this.y(poseStack, s, x + 0.5, y + shadowOffSet, this.G(color), true);
      }

      this.y(poseStack, s, x, y, color, false);
   }

   public int W(PoseStack poseStack, String s, int x, int y, int color, boolean shadow) {
      return this.y(poseStack, s, x, y, color, false);
   }

   private 友何何树友何何何何树.友何友树树友何树友树 H(char c) {
      long a = 友何何树友何何何何树.a ^ 54880639439312L;
      long ax = a ^ 44880354143259L;
      this.l();
      c<"Ö">(-7999534025735089451L, a);
      String s = String.valueOf(c);
      Font renderFont = c<"$">(this, -7998536378552729509L, a).canDisplay(c) ? c<"$">(this, -7998536378552729509L, a) : c<"$">(this, -7999979611759950240L, a);
      Rectangle bounds = renderFont.getStringBounds(s, c<"p">(-8006858838536013493L, a)).getBounds();
      int charWidth = Math.max(1, c<"$">(bounds, -8000059536502178409L, a));
      int charHeight = Math.max(1, c<"$">(bounds, -8001706198936399822L, a));
      int u = (c<"$">(this, -7999004214848441923L, a) - charWidth) / 2;
      int v = (c<"$">(this, -7999004214848441923L, a) - charHeight) / 2;
      BufferedImage image = new BufferedImage(c<"$">(this, -7999004214848441923L, a), c<"$">(this, -7999004214848441923L, a), 2);
      Graphics2D g = image.createGraphics();
      B(g, c<"$">(this, -8001217833587744091L, a));
      g.setColor(new Color(0, 0, 0, 0));
      g.fillRect(0, 0, c<"$">(this, -7999004214848441923L, a), c<"$">(this, -7999004214848441923L, a));
      g.setFont(renderFont);
      g.setColor(c<"p">(-7998653508446090671L, a));
      FontMetrics fm = g.getFontMetrics();
      g.drawString(s, u, v + fm.getAscent());
      g.dispose();
      int textureId = 友树友友友何友友友何.C(ax, image);
      RenderSystem.bindTexture(textureId);
      if (c<"$">(this, -8007266043795087546L, a) <= 12) {
         RenderSystem.texParameter(3553, 10241, 9728);
         RenderSystem.texParameter(3553, 10240, 9728);
      }

      RenderSystem.texParameter(3553, 10241, 9729);
      RenderSystem.texParameter(3553, 10240, 9729);
      return new 友何何树友何何何何树.友何友树树友何树友树(textureId, charWidth, charHeight, u, v);
   }

   private int G(int color) {
      long a = 友何何树友何何何何树.a ^ 103996013181147L;
      int alpha = color >> 24 & 0xFF;
      return alpha << 24 | b<"w">(32101, 3498107990422465046L ^ a);
   }

   public float Q(float boxHeight) {
      return 15.0F - this.K() / 2.0F;
   }

   private static int O(int value) {
      long a = 友何何树友何何何何树.a ^ 132122823568415L;
      c<"Ö">(7869121071270276890L, a);
      byte power = 1;
      if (1 < value) {
         power = 2;
      }

      return power;
   }

   private Font O() {
      long a = 友何何树友何何何何树.a ^ 18997137004060L;
      return c<"p">(1673201396578560596L, a).computeIfAbsent(c<"$">(this, 1669807813067888778L, a), k -> {
         long ax = 友何何树友何何何何树.a ^ 50624900950556L;
         return new Font(a<"m">(29385, 7004276891953778887L ^ ax), 0, c<"$">(this, -6112398340988345206L, ax));
      });
   }

   public int K() {
      long a = 友何何树友何何何何树.a ^ 139879253681220L;
      return c<"$">(this, 7308190672524734065L, a).getAscent() / 2;
   }

   private static String LIU_YA_FENG() {
      return "我是何树友";
   }

   private record 何友树树友何何友树树(友何何树友何何何何树.友何友树树友何树友树 何树何友树何树友友友, double 树何何何友树何何树友, double 何树树树友树友树树何, boolean 友树何友何何友友何友, boolean 何友友何树友友何何何, int 何何何树树树友何友何)
      implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[12];
      private static final String[] c = new String[12];
      private static String HE_SHU_YOU;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-754975933785412514L, 1707110405056186033L, MethodHandles.lookup().lookupClass()).a(197741606106294L);
         // $VF: monitorexit
         a = var10000;
         b();
      }

      public boolean V() {
         long a = 友何何树友何何何何树.何友树树友何何友树树.a ^ 23471185191766L;
         return a<"f">(this, -8382450948378886750L, a);
      }

      private static void b() {
         b[0] = "~BJBJ\u0004q\u0002\u0007I@\u0019t_\f\u000fP\u00023叧伱佴栴厠佈佹伱佴栴O佈叧桵栰叮伾佈叧桵栰";
         b[1] = double.class;
         c[1] = "java/lang/Double";
         b[2] = int.class;
         c[2] = "java/lang/Integer";
         b[3] = "\u0010i\u0002\u000b\b\u000e\u001f)O\u0000\u0002\u0013\u001atDF\u0012\b]双佹伽桶厪伦佒佹伽桶E厸佒叧桹桶厪伦栖叧桹";
         b[4] = boolean.class;
         c[4] = "java/lang/Boolean";
         b[5] = "?n\u0015|M34a\u00043,=?j\u0000i";
         b[6] = "\u0019%W7L\u0012\u0002*&伓栱桢桰变栿厍栱桢伴\u001b\u001f~C\u001eSgX.R\u001c";
         b[7] = "E\u001f,lIS^\u0010]栌佰佧佨叢桄佈佰栣叶!d%F_\u000f]#uW]";
         b[8] = "9I)\u0003<V\"FX伧厛叼伔桮厛厹伅佢伔wc\u00157Ns\u0018!\u001c:V";
         b[9] = "k2JsG8p=;佗栺伌变栕佦栓叠厒变\f\u0001:S4'oYiR+";
         b[10] = "\u001b\u0002\b\u0012%I\u0000\ry伶伜佽桲栥桠厨伜口伶<@\u0010$[[\rH\t0J";
         b[11] = "y3$$\ndb<U厞桷佐及佐伈厞厭佐及\rn2\u0001|3b,;\fd";
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 'f' && var8 != 206 && var8 != 198 && var8 != 240) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 220) {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 228) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 'f') {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 206) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 198) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public 友何何树友何何何何树.友何友树树友何树友树 a() {
         long a = 友何何树友何何何何树.何友树树友何何友树树.a ^ 62070350944641L;
         return a<"f">(this, 8177426034906307194L, a);
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 46;
                  case 1 -> 19;
                  case 2 -> 3;
                  case 3 -> 59;
                  case 4 -> 42;
                  case 5 -> 32;
                  case 6 -> 17;
                  case 7 -> 55;
                  case 8 -> 49;
                  case 9 -> 28;
                  case 10 -> 18;
                  case 11 -> 0;
                  case 12 -> 52;
                  case 13 -> 9;
                  case 14 -> 34;
                  case 15 -> 16;
                  case 16 -> 25;
                  case 17 -> 37;
                  case 18 -> 15;
                  case 19 -> 14;
                  case 20 -> 26;
                  case 21 -> 24;
                  case 22 -> 53;
                  case 23 -> 5;
                  case 24 -> 45;
                  case 25 -> 20;
                  case 26 -> 27;
                  case 27 -> 33;
                  case 28 -> 4;
                  case 29 -> 61;
                  case 30 -> 60;
                  case 31 -> 43;
                  case 32 -> 50;
                  case 33 -> 8;
                  case 34 -> 12;
                  case 35 -> 29;
                  case 36 -> 48;
                  case 37 -> 30;
                  case 38 -> 31;
                  case 39 -> 36;
                  case 40 -> 41;
                  case 41 -> 63;
                  case 42 -> 7;
                  case 43 -> 51;
                  case 44 -> 54;
                  case 45 -> 22;
                  case 46 -> 10;
                  case 47 -> 56;
                  case 48 -> 11;
                  case 49 -> 57;
                  case 50 -> 44;
                  case 51 -> 2;
                  case 52 -> 6;
                  case 53 -> 21;
                  case 54 -> 47;
                  case 55 -> 39;
                  case 56 -> 40;
                  case 57 -> 35;
                  case 58 -> 38;
                  case 59 -> 1;
                  case 60 -> 58;
                  case 61 -> 62;
                  case 62 -> 13;
                  default -> 23;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/友何何树友何何何何树$何友树树友何何友树树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      public int g() {
         long a = 友何何树友何何何何树.何友树树友何何友树树.a ^ 124440092324546L;
         return a<"f">(this, -2720273995127444239L, a);
      }

      public double A() {
         long a = 友何何树友何何何何树.何友树树友何何友树树.a ^ 112229327052847L;
         return a<"f">(this, 5247191819324796168L, a);
      }

      public double M() {
         long a = 友何何树友何何何何树.何友树树友何何友树树.a ^ 33228350893957L;
         return a<"f">(this, 5150950213511911914L, a);
      }

      public boolean H() {
         long a = 友何何树友何何何何树.何友树树友何何友树树.a ^ 33270084220736L;
         return a<"f">(this, 6898763794444017882L, a);
      }

      private static String HE_SHU_YOU() {
         return "何建国230622195906030014";
      }
   }

   public record 友何友树树友何树友树(int 何何友树何友何树友友, int 树树树何友何友何友友, int 何树友友树友何友树友, int 何友友友树友树何何树, int 何树树友友树树何树友) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[8];
      private static final String[] c = new String[8];
      private static String HE_WEI_LIN;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(-4114674276383650332L, 8760443001455455912L, MethodHandles.lookup().lookupClass()).a(71640699997503L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      public int e() {
         long a = 友何何树友何何何何树.友何友树树友何树友树.a ^ 108609220751340L;
         return a<"À">(this, -5094756079058730493L, a);
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public int n() {
         long a = 友何何树友何何何何树.友何友树树友何树友树.a ^ 25858845279L;
         return a<"À">(this, -4829585706537092759L, a);
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 192 && var8 != 235 && var8 != 238 && var8 != 'E') {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'o') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 209) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 192) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 235) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 238) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/友何何树友何何何何树$友何友树树友何树友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 63;
                  case 1 -> 50;
                  case 2 -> 35;
                  case 3 -> 38;
                  case 4 -> 3;
                  case 5 -> 42;
                  case 6 -> 48;
                  case 7 -> 31;
                  case 8 -> 27;
                  case 9 -> 22;
                  case 10 -> 33;
                  case 11 -> 44;
                  case 12 -> 57;
                  case 13 -> 41;
                  case 14 -> 10;
                  case 15 -> 24;
                  case 16 -> 1;
                  case 17 -> 12;
                  case 18 -> 2;
                  case 19 -> 11;
                  case 20 -> 19;
                  case 21 -> 51;
                  case 22 -> 8;
                  case 23 -> 32;
                  case 24 -> 45;
                  case 25 -> 56;
                  case 26 -> 6;
                  case 27 -> 46;
                  case 28 -> 54;
                  case 29 -> 52;
                  case 30 -> 0;
                  case 31 -> 30;
                  case 32 -> 18;
                  case 33 -> 7;
                  case 34 -> 5;
                  case 35 -> 9;
                  case 36 -> 58;
                  case 37 -> 47;
                  case 38 -> 43;
                  case 39 -> 49;
                  case 40 -> 21;
                  case 41 -> 4;
                  case 42 -> 62;
                  case 43 -> 39;
                  case 44 -> 25;
                  case 45 -> 29;
                  case 46 -> 40;
                  case 47 -> 60;
                  case 48 -> 23;
                  case 49 -> 28;
                  case 50 -> 53;
                  case 51 -> 15;
                  case 52 -> 37;
                  case 53 -> 20;
                  case 54 -> 55;
                  case 55 -> 14;
                  case 56 -> 34;
                  case 57 -> 16;
                  case 58 -> 13;
                  case 59 -> 26;
                  case 60 -> 17;
                  case 61 -> 59;
                  case 62 -> 61;
                  default -> 36;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "=;oD`d2{\"Ojy7&)\tzbp厞伔佲栞叀伋伀伔佲栞/厕伀厊栶栞叀伋桄厊栶";
         b[1] = int.class;
         c[1] = "java/lang/Integer";
         b[2] = "wS\u0010OzF|\\\u0001\u0000\u001bHwW\u0005Z";
         b[3] = "\u0017N#Y*{\u001aDyf伔变厺叢桑厥桐但伤核H\u0018s#\u0015C#\u001a)a";
         b[4] = "TW5X\u0002@Y]og似佽叹校伃厤似根叹叻^\u0019[\u0018VZ5\u001b\u0001Z";
         b[5] = "L@\u0013sgsAJIL栝栊栻佲去休叇低叡召x2>+NM\u00130di";
         b[6] = ":\u00057t$=7\u000fmK会桄厗厩桅厈会厞桍厩\\5}e8\b77''";
         b[7] = "\u0006r\u0006n\u0011$\u000bx\\Q伯桝桱叞厮案桫伙桱叞m/H|\u0004\u007f\u0006-\u0012>";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public int o() {
         long a = 友何何树友何何何何树.友何友树树友何树友树.a ^ 25730909968572L;
         return a<"À">(this, -8207141646360000567L, a);
      }

      public int g() {
         long a = 友何何树友何何何何树.友何友树树友何树友树.a ^ 28059686896150L;
         return a<"À">(this, -7732474284409643950L, a);
      }

      public int H() {
         long a = 友何何树友何何何何树.友何友树树友何树友树.a ^ 60171497535634L;
         return a<"À">(this, 7940996541191366825L, a);
      }

      private static String HE_SHU_YOU() {
         return "何炜霖诈骗";
      }
   }

   private record 友树何树树何何友友树(double 树友友友友何树何友何, double 树树友友何树何树友树, double 树何友树何友树何树何, double 何友友树树何何树树何, int 何友友友友友何何树友) implements 何树友 {
      private static final long a;
      private static final Object[] b = new Object[9];
      private static final String[] c = new String[9];
      private static String HE_WEI_LIN;

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何友友树友何友何何何.a(2987607942110082717L, -9031488006421546485L, MethodHandles.lookup().lookupClass()).a(55597409078033L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      public double s() {
         long a = 友何何树友何何何何树.友树何树树何何友友树.a ^ 50965759074853L;
         return a<"è">(this, -140426410694188665L, a);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      public double d() {
         long a = 友何何树友何何何何树.友树何树树何何友友树.a ^ 121775102757808L;
         return a<"è">(this, -2910683862351382461L, a);
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 232 && var8 != 195 && var8 != 164 && var8 != 202) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'C') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 200) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 232) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 195) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 164) {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/ui/友何何树友何何何何树$友树何树树何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 32;
                  case 1 -> 51;
                  case 2 -> 11;
                  case 3 -> 7;
                  case 4 -> 38;
                  case 5 -> 33;
                  case 6 -> 44;
                  case 7 -> 40;
                  case 8 -> 45;
                  case 9 -> 19;
                  case 10 -> 50;
                  case 11 -> 58;
                  case 12 -> 35;
                  case 13 -> 24;
                  case 14 -> 6;
                  case 15 -> 18;
                  case 16 -> 4;
                  case 17 -> 57;
                  case 18 -> 28;
                  case 19 -> 63;
                  case 20 -> 8;
                  case 21 -> 60;
                  case 22 -> 53;
                  case 23 -> 39;
                  case 24 -> 15;
                  case 25 -> 27;
                  case 26 -> 2;
                  case 27 -> 9;
                  case 28 -> 48;
                  case 29 -> 37;
                  case 30 -> 25;
                  case 31 -> 3;
                  case 32 -> 42;
                  case 33 -> 20;
                  case 34 -> 0;
                  case 35 -> 52;
                  case 36 -> 59;
                  case 37 -> 46;
                  case 38 -> 17;
                  case 39 -> 47;
                  case 40 -> 12;
                  case 41 -> 21;
                  case 42 -> 36;
                  case 43 -> 43;
                  case 44 -> 62;
                  case 45 -> 30;
                  case 46 -> 54;
                  case 47 -> 41;
                  case 48 -> 26;
                  case 49 -> 1;
                  case 50 -> 14;
                  case 51 -> 61;
                  case 52 -> 16;
                  case 53 -> 13;
                  case 54 -> 55;
                  case 55 -> 10;
                  case 56 -> 5;
                  case 57 -> 23;
                  case 58 -> 49;
                  case 59 -> 22;
                  case 60 -> 29;
                  case 61 -> 34;
                  case 62 -> 31;
                  default -> 56;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static void a() {
         b[0] = "7ueN\u0012j85(E\u0018w=h#\u0003\blz叐伞佸桬収企低伞佸桬!原栊伞格桬佐企叐厀格";
         b[1] = double.class;
         c[1] = "java/lang/Double";
         b[2] = int.class;
         c[2] = "java/lang/Integer";
         b[3] = "kJ\u0018o\u0010G`E\t qIkN\rz";
         b[4] = "\u001e-up\u000f\u0000\u00191#\r桰厢厸厞叟佐桰似厸伀\u001c4V\u0004Kdf5\u0007\u0004D";
         b[5] = "\u001bA\u001fy3>\u001c]I\u0004桌框厽史伫栝伈框厽栨v=j:N\b\f<;:A";
         b[6] = "]\u0003GAz\u0004Z\u001f\u0011<佁厦叻厰叭叿佁伸校厰.\u0005~\\F\u001cL\u0004x\u0001\u0002";
         b[7] = "!g\u0019e|>&{O\u0018栃伂厇栎伭叛栃伂桝佊p!%:t.\n t:{";
         b[8] = "})x\u0017y\tz5.j佂厫叛桀栈伷佂桱栁伄\u0011S \r(`kRq\r'";
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public double Y() {
         long a = 友何何树友何何何何树.友树何树树何何友友树.a ^ 62341993164991L;
         return a<"è">(this, -6010930522709492895L, a);
      }

      public int L() {
         long a = 友何何树友何何何何树.友树何树树何何友友树.a ^ 40346344999665L;
         return a<"è">(this, 1646772523959661306L, a);
      }

      public double O() {
         long a = 友何何树友何何何何树.友树何树树何何友友树.a ^ 79832735823953L;
         return a<"è">(this, -1983151465550065653L, a);
      }

      private static String HE_DA_WEI() {
         return "何树友被何大伟克制了";
      }
   }
}
