package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.lzq.injection.asm.invoked.misc.TickEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class 何友何何何何树树何树 implements IWrapper, 何树友 {
   public static final 何友何何何何树树何树 何友何友树友友何友何 = new 何友何何何何树树何树();
   private 友友友树友何何何树何 友友何何友何友何何何;
   private boolean 何友何树树何树树何何;
   private static final long a;
   private static final Object[] b = new Object[15];
   private static final String[] c = new String[15];
   private static String HE_SHU_YOU;

   public 何友何何何何树树何树() {
      long a = 何友何何何何树树何树.a ^ 117282830050050L;
      super();
      a<"ë">(this, !a<"U">(-3614208951862229932L, a), -3614648056914496429L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(5285170452927088809L, 3714963883559805084L, MethodHandles.lookup().lookupClass()).a(152507684962244L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   public void J() {
      long a = 何友何何何何树树何树.a ^ 13186815978569L;
      a<"Ê">(-4423441331196241822L, a);
      a<"ë">(this, true, -4423289188953539816L, a);
      if (a<"Q">(mc, -4423176190961078315L, a) instanceof 友友友树友何何何树何) {
         mc.setScreen(null);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 47;
               case 1 -> 4;
               case 2 -> 24;
               case 3 -> 42;
               case 4 -> 57;
               case 5 -> 19;
               case 6 -> 31;
               case 7 -> 14;
               case 8 -> 54;
               case 9 -> 53;
               case 10 -> 8;
               case 11 -> 49;
               case 12 -> 29;
               case 13 -> 18;
               case 14 -> 40;
               case 15 -> 22;
               case 16 -> 37;
               case 17 -> 38;
               case 18 -> 13;
               case 19 -> 27;
               case 20 -> 0;
               case 21 -> 6;
               case 22 -> 33;
               case 23 -> 5;
               case 24 -> 16;
               case 25 -> 7;
               case 26 -> 62;
               case 27 -> 61;
               case 28 -> 46;
               case 29 -> 9;
               case 30 -> 51;
               case 31 -> 58;
               case 32 -> 63;
               case 33 -> 39;
               case 34 -> 25;
               case 35 -> 10;
               case 36 -> 26;
               case 37 -> 17;
               case 38 -> 20;
               case 39 -> 48;
               case 40 -> 50;
               case 41 -> 52;
               case 42 -> 1;
               case 43 -> 43;
               case 44 -> 3;
               case 45 -> 59;
               case 46 -> 21;
               case 47 -> 44;
               case 48 -> 41;
               case 49 -> 32;
               case 50 -> 56;
               case 51 -> 28;
               case 52 -> 12;
               case 53 -> 35;
               case 54 -> 2;
               case 55 -> 45;
               case 56 -> 15;
               case 57 -> 23;
               case 58 -> 55;
               case 59 -> 34;
               case 60 -> 36;
               case 61 -> 30;
               case 62 -> 60;
               default -> 11;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Q' && var8 != 235 && var8 != 'U' && var8 != 'q') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'i') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 202) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Q') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'U') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何友何何何何树树何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      b[0] = ")\u0006\u0000*\b`&FM!\u0002}#\u001bFg\u0012fd伽句伜伲佚伟桹栿伜桶";
      b[1] = ".D. \u0003D%K?o\u007f]*Q1,Hm<F=1YA+K";
      b[2] = "\u001ekoS?C\u0011+\"X5^\u0014v)\u001e%ES収厊叻桁叧伨佐伔校伅";
      b[3] = "}h.\n$\u000f\bH%\u00055@uP6\u0002<\t\u001d";
      b[4] = "a\u0003k\u0016\u00052a\u0003|J\t={H|T\u0001>a\u00121u\u00015j\u0005mY\u000e/";
      b[5] = ".[xVjU.[o\nfZ4\u0010o\u0014nY.J\"\u001frUnMo\nbY.M\"+dN%[b";
      b[6] = boolean.class;
      c[6] = "java/lang/Boolean";
      b[7] = "\u0019COm\u007f@\u0016\u0003\u0002fu]\u0013^\t SG\u001f_\b}x";
      b[8] = "\u0010PIi5(\u001b_X&T&\u0010T\\|";
      b[9] = "<RK\n\u0015c4XRf\u001f\u000f5I\u0007XG~`AM\bv6g\u0012\tW\u0007coXYf";
      b[10] = "\u0014thV4\u0018Ub6V\n\u0019RS7JK\u001eKr8R\nD\u0019u)\u0013s\u0005@`l";
      b[11] = "w:cdi:-t'r\u0019\u0019N~jmy,<} tdP";
      b[12] = "1X5(zR9R,D叚叽作併厊伙叚佣作併I}g\u0006oX#')By";
      b[13] = "'\u000b\u001e(\u0007\u001b/\u0001\u0007D伹厴佊桢桻伙桽桮佊伦bxT\u001dmF\u001b9\r\b(";
      b[14] = "0u/\u0010$%:p;\u0015X'\\{pKhq\\Jr\u000b4$:; M\",";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void X() {
      long a = 何友何何何何树树何树.a ^ 85627618362186L;
      if (a<"Ê">(3287488731060746081L, a) != null) {
         if (a<"Q">(this, 3287177071918841812L, a) == null) {
            a<"ë">(this, new 友友友树友何何何树何(), 3287177071918841812L, a);
         }

         Cherish.instance.getEventManager().register(this);
      }
   }

   @EventTarget
   public void N(TickEvent event) {
      long a = 何友何何何何树树何树.a ^ 9440289040025L;
      long ax = a ^ 28501980180838L;
      a<"Ê">(-8625302719849295182L, a);
      if (!this.w(new Object[]{ax})) {
         if (a<"Q">(this, -8625146998817721912L, a)) {
            Cherish.instance.getEventManager().unregister(this);
         } else {
            if (!(a<"Q">(mc, -8625031158840367867L, a) instanceof 友友友树友何何何树何)) {
               mc.setScreen(a<"Q">(this, -8625198866799371769L, a));
            }
         }
      }
   }

   private static String HE_SHU_YOU() {
      return "何炜霖黑水";
   }
}
