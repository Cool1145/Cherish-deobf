package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public enum 何树友友何友友何树树 implements  {
   树树友树友友友何何树,
   何友何友何何何友何树,
   树友友何树友树何何友,
   友友树树树树何何友友;

   private final Color 何友友何树树树何友友;
   private final String 友友何树友友何树树友;
   private static boolean 何何树友树树树友树友;
   private static final long a;
   private static final Object[] b = new Object[18];
   private static final String[] c = new String[18];
   private static String HE_JIAN_GUO;

   private 何树友友何友友何树树(Color color, String icon) {
      this.何友友何树树树何友友 = color;
      this.友友何树友友何树树友 = icon;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // $VF: Failed to inline enum fields
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8766889914110466373L, 2246056954580748493L, MethodHandles.lookup().lookupClass()).a(11346897706585L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (!q()) {
         y(true);
      }

      Cipher var1;
      Cipher var10 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(102529356668966L << var2 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[4];
      int var6 = 0;
      String var5 = "Ø`]/B\bk¶\b0æ\u001bt30 \\";
      byte var7 = 17;
      char var4 = '\b';
      int var9 = -1;

      label32:
      while (true) {
         String var11 = var5.substring(++var9, var9 + var4);
         byte var10001 = -1;

         while (true) {
            String var17 = a(var1.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var0[var6++] = var17;
                  if ((var9 += var4) >= var7) {
                     树树友树友友友何何树 = new 何树友友何友友何树树(new Color(0, 255, 0), "A");
                     何友何友何何何友何树 = new 何树友友何友友何树树(new Color(255, 0, 0), "B");
                     树友友何树友树何何友 = new 何树友友何友友何树树(Color.YELLOW, "C");
                     友友树树树树何何友友 = new 何树友友何友友何树树(Color.GRAY, "D");
                     return;
                  }

                  var4 = var5.charAt(var9);
                  break;
               default:
                  var0[var6++] = var17;
                  if ((var9 += var4) < var7) {
                     var4 = var5.charAt(var9);
                     continue label32;
                  }

                  var5 = "\u0019d÷U\u001e«3µ\b\u008eÇÌ1@\u000eÑá";
                  var7 = 17;
                  var4 = '\b';
                  var9 = -1;
            }

            var11 = var5.substring(++var9, var9 + var4);
            var10001 = 0;
         }
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static 何树友友何友友何树树 f(String name) {
      return Enum.valueOf(何树友友何友友何树树.class, name);
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static void a() {
      b[0] = "_&\n\ri'PfG\u0006c:U;L@s!\u0012伝栵厥反伝号厃佱桿栗";
      b[1] = "Lh\"\\\u0007\u0001xK-\u001cJ\nrV(AALbMo佧核厩叜佱厊叹佼桳栆\u001f";
      b[2] = "<3\u0016{Z~!&NY\u001bs9 ";
      b[3] = boolean.class;
      c[3] = "java/lang/Boolean";
      b[4] = void.class;
      c[4] = "java/lang/Void";
      b[5] = "5T\nN\u0019[>[\u001b\u0001dC-\\\u0012H";
      b[6] = "93A\u001cI{2<PS(u97T\t";
      b[7] = "HU.=R{\u0000H'W叮受桫栴桏桎佰佉厱叮VmUl\u0018R9%He";
      b[8] = " \\9(\u0013\u000e)]>fu'TxF^*v \\9(\u0013\u000e)]>f";
      b[9] = "\u0006F\u000eG\u0002{N[\u0007-\u0004\u0014\u0006D\u001bJ\u001dsX_N\u0010}";
      b[10] = "_R\u000eh7l\u0017O\u0007\u0002伕叀伸叩伫佟伕叀伸栳v80{\u000fU\u0019p-r";
      b[11] = "\bK\u0012nXI@V\u001b\u0004佺佻佯台厩余栾佻佯佮j=\u001d\u0018_]\n:A\u0019N";
      b[12] = "\u0012dqJ#TZyx 原司併栅及口企栢栱叟\t\u001b8YTy`J8\nG";
      b[13] = "&9!\t\u0017\u0002n$(c伵厮叟伜桀桺桱估叟厂YZ\bV-'!S\tQc";
      b[14] = "Zc[\u0005\u0013?\u0012~Ro\u001dPZaN\b\f7\u0004z\u001bRlk\n&H\u0012\u0013?\fqSo";
      b[15] = "\u007f\u007feZ.\u000e7bl0案厢历佚栄右案似优叄\u001d\n)\u0019/xrB4\u0010";
      b[16] = "VZ\u000b9mT\u001eG\u0002S栋栢厯栻厰厐发佦伱栻sijC\u0006]\u001c!wJ";
      b[17] = "\u0011`7DfD\u0018a0\n\u0000srI]u9\\\u00131j\r0]\u0014\u007f";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何树友友何友友何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 23;
               case 1 -> 34;
               case 2 -> 59;
               case 3 -> 54;
               case 4 -> 51;
               case 5 -> 40;
               case 6 -> 62;
               case 7 -> 15;
               case 8 -> 58;
               case 9 -> 26;
               case 10 -> 36;
               case 11 -> 43;
               case 12 -> 11;
               case 13 -> 30;
               case 14 -> 18;
               case 15 -> 6;
               case 16 -> 24;
               case 17 -> 63;
               case 18 -> 61;
               case 19 -> 45;
               case 20 -> 55;
               case 21 -> 31;
               case 22 -> 0;
               case 23 -> 7;
               case 24 -> 39;
               case 25 -> 35;
               case 26 -> 21;
               case 27 -> 50;
               case 28 -> 16;
               case 29 -> 2;
               case 30 -> 10;
               case 31 -> 25;
               case 32 -> 37;
               case 33 -> 17;
               case 34 -> 49;
               case 35 -> 28;
               case 36 -> 29;
               case 37 -> 41;
               case 38 -> 1;
               case 39 -> 56;
               case 40 -> 52;
               case 41 -> 32;
               case 42 -> 27;
               case 43 -> 5;
               case 44 -> 13;
               case 45 -> 42;
               case 46 -> 33;
               case 47 -> 57;
               case 48 -> 3;
               case 49 -> 4;
               case 50 -> 53;
               case 51 -> 44;
               case 52 -> 14;
               case 53 -> 20;
               case 54 -> 12;
               case 55 -> 46;
               case 56 -> 8;
               case 57 -> 22;
               case 58 -> 19;
               case 59 -> 60;
               case 60 -> 9;
               case 61 -> 38;
               case 62 -> 47;
               default -> 48;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != '$' && var8 != 212 && var8 != 239 && var8 != 222) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'a') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'T') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == '$') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 212) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public String t() {
      return this.友友何树友友何树树友;
   }

   public static 何树友友何友友何树树[] q() {
      return (何树友友何友友何树树[])何何何友友何树何何何.clone();
   }

   public static boolean q() {
      L();

      try {
         return true;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   public Color U() {
      return this.何友友何树树树何友友;
   }

   public static void y(boolean var0) {
      何何树友树树树友树友 = var0;
   }

   public static boolean L() {
      return 何何树友树树树友树友;
   }

   private static String HE_SHU_YOU() {
      return "解放村多种2队1144号";
   }
}
