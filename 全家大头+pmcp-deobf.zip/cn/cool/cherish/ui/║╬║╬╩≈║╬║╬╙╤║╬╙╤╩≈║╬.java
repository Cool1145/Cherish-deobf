package cn.cool.cherish.ui;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.impl.display.友友何何友何友树何树;
import cn.cool.cherish.utils.shader.ShaderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.mojang.blaze3d.vertex.PoseStack;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何何树何何友何友树何 implements IWrapper, 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[20];
   private static final String[] g = new String[20];
   private static String HE_WEI_LIN;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5409909733950499902L, 3048747552452241471L, MethodHandles.lookup().lookupClass()).a(204245613738960L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(100722426466253L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[7];
      int var7 = 0;
      String var6 = "\b¾\u0002sã=\t\u009d\u001e´èª¤]Pì\u0090Z\u0098d{P=}Ì\u00ad\u009f\t\u001d\u000b\u008b÷\u0018 Ó×´\u008bmÃø$ÿs\u0001åÐ\u0083Â\u0011¤\bx\u0012w\u007fN ä@&®·\u0099ÅËã¯²Á\u0081âé\u0014\u00837ç\u0019¹(è¹á#½\b@¾C\u0091 e`Y$\nÆ\u001ad\u0096<®b¿Öïåÿ}\u0016XA!~\"¡\u009c\u009c\u0082ïTs\t\u0010WÄÐYlÅº\u0004£rß=\u0096¼\u0014½";
      short var8 = 140;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = b(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     b = var9;
                     c = new String[7];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ST\u0010Ålê\u0005Vî E6\u008f_ºk\u0088\u0090%Nå°\u0099\u0082 ÚÖû\"¾Â\u0098Eý*pÑ!BÙ\u00043³TÚj\u009f\u0085\u000118\u0082cÛ\u0004\u0001(";
                  var8 = 57;
                  var5 = 24;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 10;
               case 2 -> 37;
               case 3 -> 32;
               case 4 -> 19;
               case 5 -> 40;
               case 6 -> 0;
               case 7 -> 9;
               case 8 -> 57;
               case 9 -> 20;
               case 10 -> 62;
               case 11 -> 30;
               case 12 -> 6;
               case 13 -> 12;
               case 14 -> 43;
               case 15 -> 36;
               case 16 -> 34;
               case 17 -> 1;
               case 18 -> 18;
               case 19 -> 38;
               case 20 -> 61;
               case 21 -> 35;
               case 22 -> 63;
               case 23 -> 54;
               case 24 -> 29;
               case 25 -> 15;
               case 26 -> 48;
               case 27 -> 26;
               case 28 -> 17;
               case 29 -> 21;
               case 30 -> 11;
               case 31 -> 59;
               case 32 -> 8;
               case 33 -> 13;
               case 34 -> 27;
               case 35 -> 25;
               case 36 -> 58;
               case 37 -> 24;
               case 38 -> 47;
               case 39 -> 52;
               case 40 -> 50;
               case 41 -> 53;
               case 42 -> 45;
               case 43 -> 16;
               case 44 -> 31;
               case 45 -> 3;
               case 46 -> 14;
               case 47 -> 2;
               case 48 -> 28;
               case 49 -> 7;
               case 50 -> 56;
               case 51 -> 23;
               case 52 -> 41;
               case 53 -> 39;
               case 54 -> 22;
               case 55 -> 55;
               case 56 -> 33;
               case 57 -> 4;
               case 58 -> 44;
               case 59 -> 60;
               case 60 -> 51;
               case 61 -> 46;
               case 62 -> 5;
               default -> 49;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public static void i(
      PoseStack poseStack,
      float x,
      float y,
      float width,
      float height,
      List<友友何何友何友树何树.树何树何友友树何何友> messages,
      float animationOutput,
      int fontSize,
      boolean textShadow,
      float messageSpacing,
      int backgroundAlpha,
      float cornerRadius,
      友友何何友何友树何树 instance
   ) {
      何何友友树何树何友树 font = Cherish.instance.t().H(fontSize);
      float alphaMultiplier = Math.max(0.0F, Math.min(1.0F, animationOutput));
      Color glassColor = new Color(0, 0, 0, (int)(backgroundAlpha * alphaMultiplier));
      树何树何何树树树树何.C();
      Color borderColor = new Color(255, 255, 255, (int)(100.0F * alphaMultiplier));
      ShaderUtils.M(132138673613539L, poseStack, x, y, width, height, cornerRadius, 1.0F, borderColor, glassColor, 10.0F);
      Iterator var25 = messages.iterator();
      if (var25.hasNext()) {
         友友何何友何友树何树.树何树何友友树何何友 message = (友友何何友何友树何树.树何树何友友树何何友)var25.next();
         String displayText = i(message);
         Color textColor = A(message.树何树何树何树友何何);
         float messageAlpha = Math.max(0.0F, 1.0F - (float)(System.currentTimeMillis() - message.树友何何何友树何何友) / 10000.0F);
         messageAlpha *= animationOutput;
         if (messageAlpha > 0.1F) {
            Color finalTextColor = new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), (int)(textColor.getAlpha() * messageAlpha));
            font.e(poseStack, displayText, x + 8.0F, y + 4.0F, finalTextColor.getRGB(), textShadow);
         }

         float var10000 = y + (font.x() + messageSpacing);
         Module.V(new Module[1]);
      }
   }

   private static String i(友友何何友何友树何树.树何树何友友树何何友 message) {
      String prefix = H(message.树何树何树何树友何何);
      return prefix + "->" + message.何何树友友友友树何友;
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 244 && var8 != 186 && var8 != 251 && var8 != 239) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'R') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'S') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 244) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 186) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 251) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何树何何友何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 32052;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/何何树何何友何友树何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static void a() {
      f[0] = "@VXb\u001f|O\u0016\u0015i\u0015aJK\u001e/\u0005z\r佭伣栐伥但叨佭厽栐伥";
      f[1] = "g>Kr\u001b\u001fl1Z=g\u0006c+T~P6u<XcA\u001ab1";
      f[2] = "w>\u0013\b!\u0007x~^\u0003+\u001a}#UE;\u0001:桁佨桺伛伽栅桁栬桺伛";
      f[3] = "\u001a| <n0o\\+3\u007f\u007f\u0012D84v6z";
      f[4] = "\u0015;A/\tp\u001a{\f$\u0003m\u001f&\u0007b\u000bp\u0012 \u0003)Hv\u001b%\u0003b\u0002v\u0005%\u0003-\u001f1厽厞伺伙厭佊厽桄伺桝B栎伣桄伺厇厭栎伣伀厤";
      f[5] = long.class;
      g[5] = "java/lang/Long";
      f[6] = "7\u001c-A+y8\\`J!d=\u0001k\f)y0\u0007oGj[;\u0016vN!";
      f[7] = "*mqh\u0019>\u001eN~(T5\u0014S{u_s\u001cNvs[8_l}bB1\u0014\u001a";
      f[8] = "Y?aN\u000eSm\u001cn\u000eCXg\u0001kSH\u001eo\u001cfULU,>mDU\\gH";
      f[9] = void.class;
      g[9] = "java/lang/Void";
      f[10] = int.class;
      g[10] = "java/lang/Integer";
      f[11] = "\u00136ah<2\u00189p'A*\u000b>yn";
      f[12] = "\fJ\u0006<wN\u0007E\u0017s\u0016@\fN\u0013)";
      f[13] = "(X!\u000f79.Y%\u0003P桁叐佫伜估厓桁低佫厂mk%n\u000b#Sj6p\r";
      f[14] = "B!K$@w\u00072\tgyI~bO2\u0012f\u001c9J&\u0012\u001b";
      f[15] = "B\rC5BP\u001dW\u0015QN9\u001c\u0004M8\u0016ABP\u0014h'\u0000\u001d[C`_^I\u0002\u0013Q";
      f[16] = "Tz')$\f\u0011iej\u001d>h9#?v\u001d\nb&+v`V\u007f$7q\u001a\u0018?y0\u001d";
      f[17] = "85H\u0001iH>4L\r\u000e栰佞桂併桺体栰叀伆併c1\u0018zcOXiM<1";
      f[18] = "Q}7cWIW|3o0併伷栊厔参右叫桳低厔\u0001\u000fU\ti;z\u0001\u0014R.";
      f[19] = "\u0016\nDCjwA\u0003\u0012A\u0017F/WAMtl\u0014\u0012\u0017C*\r";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/何何树何何友何友树何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Color A(int state) {
      return switch (state) {
         case 0, 1 -> new Color(170, 170, 170, 255);
         case 2 -> new Color(170, 0, 0, 255);
         case 3 -> new Color(85, 255, 85, 255);
         case 4, 5 -> new Color(255, 85, 85, 255);
         default -> new Color(255, 255, 255, 255);
      };
   }

   private static String H(int state) {
      return switch (state) {
         case 0, 1 -> "§7通知§r";
         case 2 -> "§4警告§r";
         case 3 -> "§a成功§r";
         case 4 -> "§c失败§r";
         case 5 -> "§c错误§r";
         default -> "§7消息§r";
      };
   }

   private static String HE_WEI_LIN() {
      return "何炜霖诈骗";
   }
}
