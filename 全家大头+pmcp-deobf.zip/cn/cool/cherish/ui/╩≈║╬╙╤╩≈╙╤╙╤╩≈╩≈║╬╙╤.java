package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import cn.cool.cherish.value.impl.NumberValue;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 树何友树友友树树何友 implements 友树何树友友树树何树<NumberValue>, IWrapper,  {
   private static final float 友树树树何树树树友何 = 7.0F;
   private static final float 树友何友何树树友树友 = 2.0F;
   private static final float 友何友树何树树何何树 = 35.0F;
   private static final float 友树友树何树何何何树 = 10.0F;
   private static final float 友树何树何何何树何友 = 70.0F;
   private static final long a;
   private static final String b;
   private static final Object[] c = new Object[23];
   private static final String[] e = new String[23];
   private static String HE_JIAN_GUO;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(4743625961741739577L, -7277518450425856125L, MethodHandles.lookup().lookupClass()).a(54703725137649L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 46310234282649L;
      Cipher var2;
      Cipher var4 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var4.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var5 = b(var2.doFinal("ÚØ½\taÔ¼@".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      b = var5;
   }

   public boolean B(NumberValue value, int keyCode, int scanCode, int modifiers, 友树友树何树友友友树 componentsInstance) {
      return false;
   }

   public void C(NumberValue value, double mouseX, double mouseY, int button, 友树友树何树友友友树 componentsInstance) {
      long a = 树何友树友友树树何友.a ^ 10103032948382L;
      a<"È">(6185232281981576217L, a);
      if (a<"ö">(componentsInstance, 6183682644976557549L, a) == value) {
         a<"í">(componentsInstance, null, 6183682644976557549L, a);
      }
   }

   public void I(
      GuiGraphics guiGraphics,
      NumberValue value,
      float x,
      float y,
      float width,
      float height,
      float middleY,
      int mouseX,
      int mouseY,
      float partialTicks,
      友何何树友何何何何树 valueNameFont,
      友何何树友何何何何树 valueDisplayFont,
      Color accentColor,
      Color disabledColor,
      Color darkBgColor,
      友树友树何树友友友树 componentsInstance
   ) {
      long a = 树何友树友友树树何友.a ^ 56761683804908L;
      float sliderX = x + width - 117.0F;
      a<"È">(-1035112429023067133L, a);
      float sliderY = middleY - 1.0F;
      double values = value.getValue().doubleValue();
      double minValue = value.b().doubleValue();
      double maxValue = value.p().doubleValue();
      float currentProgress = (float)((values - minValue) / (maxValue - minValue));
      if (maxValue - minValue == 0.0) {
         currentProgress = 0.0F;
      }

      float animatedProgress = componentsInstance.K(value, currentProgress, partialTicks);
      animatedProgress = Mth.clamp(animatedProgress, 0.0F, 1.0F);
      RenderUtils.drawRectangle(guiGraphics.pose(), sliderX, sliderY, 70.0F, 2.0F, darkBgColor.darker().getRGB());
      RenderUtils.drawRectangle(guiGraphics.pose(), sliderX, sliderY, 70.0F * animatedProgress, 2.0F, accentColor.getRGB());
      RenderUtils.drawRectangle(
         guiGraphics.pose(), sliderX + 70.0F * animatedProgress - 2.0F, sliderY + 1.0F - 2.0F, 4.0F, 4.0F, accentColor.brighter().getRGB()
      );
      String valueString = this.j(value.getValue(), value.I());
      float boxX = x + width - 42.0F;
      float boxY = middleY - 5.0F;
      RenderUtils.drawRoundedRect(guiGraphics.pose(), boxX, boxY, 35.0, 10.0, 2.0, darkBgColor);
      valueDisplayFont.L(
         guiGraphics.pose(), valueString, boxX + 17.5F, boxY + (10.0F - valueDisplayFont.K()) / 2.0F + 0.5F, a<"ü">(-1034271741236825635L, a).getRGB()
      );
      if (a<"ö">(componentsInstance, -1035018441974351457L, a) == value) {
         double mousePercent = Mth.clamp((mouseX - sliderX) / 70.0F, 0.0, 1.0);
         double newValue = minValue + (maxValue - minValue) * mousePercent;
         if (maxValue - minValue == 0.0) {
            newValue = minValue;
         }

         value.J(this.H(newValue, value.I().doubleValue(), (Class<? extends Number>)value.getValue().getClass()));
      }

      if (!a<"È">(-1034509060235292362L, a)) {
         a<"È">(false, -1034310297979298594L, a);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 62;
               case 1 -> 37;
               case 2 -> 50;
               case 3 -> 17;
               case 4 -> 55;
               case 5 -> 35;
               case 6 -> 32;
               case 7 -> 45;
               case 8 -> 16;
               case 9 -> 4;
               case 10 -> 22;
               case 11 -> 41;
               case 12 -> 36;
               case 13 -> 53;
               case 14 -> 28;
               case 15 -> 54;
               case 16 -> 2;
               case 17 -> 8;
               case 18 -> 0;
               case 19 -> 48;
               case 20 -> 39;
               case 21 -> 10;
               case 22 -> 34;
               case 23 -> 24;
               case 24 -> 7;
               case 25 -> 26;
               case 26 -> 20;
               case 27 -> 51;
               case 28 -> 12;
               case 29 -> 27;
               case 30 -> 19;
               case 31 -> 31;
               case 32 -> 57;
               case 33 -> 38;
               case 34 -> 23;
               case 35 -> 21;
               case 36 -> 5;
               case 37 -> 9;
               case 38 -> 46;
               case 39 -> 3;
               case 40 -> 52;
               case 41 -> 15;
               case 42 -> 25;
               case 43 -> 40;
               case 44 -> 42;
               case 45 -> 14;
               case 46 -> 30;
               case 47 -> 29;
               case 48 -> 33;
               case 49 -> 18;
               case 50 -> 61;
               case 51 -> 1;
               case 52 -> 47;
               case 53 -> 59;
               case 54 -> 63;
               case 55 -> 58;
               case 56 -> 49;
               case 57 -> 13;
               case 58 -> 11;
               case 59 -> 44;
               case 60 -> 56;
               case 61 -> 60;
               case 62 -> 43;
               default -> 6;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 246 && var8 != 237 && var8 != 252 && var8 != 229) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'm') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 200) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 246) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 237) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 252) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static void a() {
      c[0] = "EW%GQDJ\u0017hL[YOJc\nKB\b栨佞可栯叠叭栨栚佱叵";
      c[1] = "s33\u001aXYx<\"U$@w&,\u0016\u0013pa1 \u000b\u0002\\v<";
      c[2] = "?_\u0016\u000e,\u000b0\u001f[\u0005&\u00165BPC6\rr叺佭伸厈桵伉栠栩桼伖";
      c[3] = boolean.class;
      e[3] = "java/lang/Boolean";
      c[4] = "hs\u0000\u0013E&g3M\u0018O;bnF^_ %取栿去栻伜栚取句去栻";
      c[5] = "DV6S:;K\u0016{X0&NKp\u001e#5KM}\u001e桄企佲佭叓校桄企召佭";
      c[6] = "D\u0019k\u0017b\u0000KY&\u001ch\u001dN\u0004-Z`\u0000C\u0002)\u0011#\"H\u00130\u0018h";
      c[7] = void.class;
      e[7] = "java/lang/Void";
      c[8] = "P\u0013|t&\u0015M\u0006$Vg\u0018U\u0000";
      c[9] = "(#c\u0017\u00042#6}Xx07,q\u001fD8\u000f-q\u0013";
      c[10] = "\u0006xuWvT\u0018po\u0018\u0010@\u001fqNW(";
      c[11] = "F@7tDuMO&;%{FD\"a";
      c[12] = "W\u0015ro\u000fx\u0017@/-k栝厯桡桑叓桲余厯去伕\u0010Tf\u0001@!uSc\u0015\u001e";
      c[13] = "Br|=\u0019\\\u0003e YLlD!\">\u001e\u000bE%qi%UB&}bBTFu*Y";
      c[14] = "\u0011=4{;9W>4uZF(~9i;\u007fT;3(\"\u0001";
      c[15] = "t\u0016sP\u0003i4C.\u0012g佈桖桢伔佲伺栌桖伦伔/\\k-\u00024L]+p\u001a";
      c[16] = "\u0018=4A*#Xhi\u0003N伂栺厓体栧桗伂叠厓栗>q=Nhg[v8Z6";
      c[17] = "o\u001b\u001b\u0007;G)\u0018\u001b\tZ\u0005VX\u0016\u0015;\u0001*\u001d\u001cT\"\u007fk\\FW9\u0002:\u0012\u0017\u0000Z";
      c[18] = "CHf-\u0003\u001b\u0004\u001faky:=1\u0006[y[ELal\u0007\u001c\u0012K'";
      c[19] = "Y\u0003i;ab\u0019V4y\u0005佃伿桷桊桝叆叝伿伳桊D:|\u000fV:!=y\u001b\b";
      c[20] = "$;PQikg*\u0010PYVS\u0016oe\u0004N\u001alHC:&g/Y\u0003;";
      c[21] = "s\u0014mK\bx5\u0017mEi\u000bJW`Y\b>6\u0012j\u0018\u0011@";
      c[22] = "X\u0014\u000bYYc\u001eE\bI$gdN^CEt\u0018\u000bT\u0002\\\n";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/树何友树友友树树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private String j(Number value, Number increment) {
      long a = 树何友树友友树树何友.a ^ 140192603177149L;
      a<"È">(-867737547866193350L, a);
      String incrementString = Double.toString(Math.abs(increment.doubleValue()));
      int decimalPlaces = incrementString.contains(".") ? incrementString.length() - incrementString.indexOf(46) - 1 : 0;
      if (!(value instanceof Float) && !(value instanceof Double)) {
         return String.valueOf(value.intValue());
      } else {
         return decimalPlaces == 0 ? String.valueOf(value.intValue()) : String.format(b.formatted(decimalPlaces), value.doubleValue());
      }
   }

   public boolean N(
      NumberValue value, double mouseX, double mouseY, int button, float x, float y, float width, float height, float middleY, 友树友树何树友友友树 componentsInstance
   ) {
      long a = 树何友树友友树树何友.a ^ 6559520671208L;
      a<"È">(-5287130054460143761L, a);
      float sliderX = x + width - 117.0F;
      if (button == 0 && mouseX >= sliderX && mouseX <= sliderX + 70.0F && mouseY >= middleY - 1.0F - 3.0F && mouseY <= middleY + 1.0F + 3.0F) {
         a<"í">(componentsInstance, value, -5285301415944274277L, a);
         double minValue = value.b().doubleValue();
         double maxValue = value.p().doubleValue();
         double mousePercent = Mth.clamp((mouseX - sliderX) / 70.0, 0.0, 1.0);
         double newValue = minValue + (maxValue - minValue) * mousePercent;
         if (maxValue - minValue == 0.0) {
            newValue = minValue;
         }

         value.J(this.H(newValue, value.I().doubleValue(), (Class<? extends Number>)value.getValue().getClass()));
         return true;
      } else {
         return false;
      }
   }

   public float N(NumberValue value, 友树友树何树友友友树 componentsInstance) {
      return 0.0F;
   }

   private Number H(double value, double increment, Class<? extends Number> originalType) {
      long a = 树何友树友友树树何友.a ^ 77583224362815L;
      a<"È">(-6595780851936684616L, a);
      if (increment == 0.0) {
         return value;
      } else {
         BigDecimal bdValue = BigDecimal.valueOf(value);
         BigDecimal bdIncrement = BigDecimal.valueOf(increment);
         BigDecimal divided = bdValue.divide(bdIncrement, 0, a<"ü">(-6595710927601836239L, a));
         BigDecimal rounded = divided.multiply(bdIncrement);
         if (originalType == Double.class) {
            return rounded.doubleValue();
         } else if (originalType == Float.class) {
            return rounded.floatValue();
         } else if (originalType == Long.class) {
            return rounded.longValue();
         } else if (originalType == Integer.class) {
            return rounded.intValue();
         } else if (originalType == Short.class) {
            return rounded.shortValue();
         } else {
            return (Number)(originalType == Byte.class ? rounded.byteValue() : rounded.doubleValue());
         }
      }
   }

   public boolean R(NumberValue value, char chr, int modifiers, 友树友树何树友友友树 componentsInstance) {
      return false;
   }

   public void G(NumberValue value, 友树友树何树友友友树 componentsInstance) {
      long a = 树何友树友友树树何友.a ^ 29393549756041L;
      a<"È">(8485142847529239566L, a);
      double values = value.getValue().doubleValue();
      double minValue = value.b().doubleValue();
      double maxValue = value.p().doubleValue();
      float progress = 0.0F;
      if (maxValue - minValue != 0.0) {
         progress = (float)((values - minValue) / (maxValue - minValue));
      }

      a<"ö">(componentsInstance, 8485057955564574474L, a).putIfAbsent(value, progress);
      a<"ö">(componentsInstance, 8486785462915610347L, a).putIfAbsent(value, progress);
      a<"ö">(componentsInstance, 8484822314592076356L, a).putIfAbsent(value, new float[]{0.0F});
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖黑水";
   }
}
