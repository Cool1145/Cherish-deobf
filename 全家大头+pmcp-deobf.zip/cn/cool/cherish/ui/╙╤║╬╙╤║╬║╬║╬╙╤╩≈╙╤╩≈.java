package cn.cool.cherish.ui;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何友何何何友树友树 implements 何树友 {
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[19];
   private static final String[] f = new String[19];
   private static String HE_DA_WEI;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-7232808735809221341L, -6704622132334398509L, MethodHandles.lookup().lookupClass()).a(61767596166414L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 37847753042088L;
      Cipher var2;
      Cipher var11 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      int var7 = 0;
      char var5 = 16;
      int var4 = -1;

      while (true) {
         String var13 = a(
               var2.doFinal(
                  "NS#:>\u0098³8\u008fN¨Åë\u0092\u001af ¹²:6NÞ_\u001e\u001d\u0092Ü\u0084¢õH¨¡¹\u008eq\u0092\u0082\u009d7ÂLa{Ï\u0097\u0095ô"
                     .substring(++var4, var4 + var5)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var9[var7++] = var13;
         if ((var4 += var5) >= 49) {
            b = var9;
            c = new String[2];
            return;
         }

         var5 = "NS#:>\u0098³8\u008fN¨Åë\u0092\u001af ¹²:6NÞ_\u001e\u001d\u0092Ü\u0084¢õH¨¡¹\u008eq\u0092\u0082\u009d7ÂLa{Ï\u0097\u0095ô".charAt(var4);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友何友何何何友树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'M' && var8 != 229 && var8 != 'j' && var8 != 't') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 210) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'N') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'M') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 229) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'j') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友何友何何何友树友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 49;
               case 1 -> 40;
               case 2 -> 57;
               case 3 -> 41;
               case 4 -> 25;
               case 5 -> 4;
               case 6 -> 24;
               case 7 -> 44;
               case 8 -> 28;
               case 9 -> 12;
               case 10 -> 7;
               case 11 -> 16;
               case 12 -> 14;
               case 13 -> 27;
               case 14 -> 26;
               case 15 -> 34;
               case 16 -> 17;
               case 17 -> 32;
               case 18 -> 58;
               case 19 -> 35;
               case 20 -> 38;
               case 21 -> 15;
               case 22 -> 47;
               case 23 -> 22;
               case 24 -> 39;
               case 25 -> 56;
               case 26 -> 33;
               case 27 -> 3;
               case 28 -> 1;
               case 29 -> 43;
               case 30 -> 19;
               case 31 -> 55;
               case 32 -> 21;
               case 33 -> 63;
               case 34 -> 8;
               case 35 -> 46;
               case 36 -> 11;
               case 37 -> 62;
               case 38 -> 29;
               case 39 -> 10;
               case 40 -> 45;
               case 41 -> 59;
               case 42 -> 37;
               case 43 -> 9;
               case 44 -> 30;
               case 45 -> 31;
               case 46 -> 42;
               case 47 -> 18;
               case 48 -> 13;
               case 49 -> 2;
               case 50 -> 0;
               case 51 -> 20;
               case 52 -> 53;
               case 53 -> 23;
               case 54 -> 6;
               case 55 -> 61;
               case 56 -> 51;
               case 57 -> 5;
               case 58 -> 52;
               case 59 -> 60;
               case 60 -> 50;
               case 61 -> 36;
               case 62 -> 48;
               default -> 54;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      e[0] = "\u001dV4wOa\u001dV#+Cn\u0007\u001d76Pd\u0017\u001d%7Va\u0007Jn\u001cS}\u001aC-<L| _/-";
      e[1] = "h_+\u007f\u0006\rg\u001fft\f\u0010bBm2\u001c\u000b%栠佐佉似桳栚栠佐受似";
      e[2] = "\u00117X5=\bd\u0017S:,G\u0019\u000f@=%\u000eq";
      e[3] = "[\u0007F\u001a`1TG\u000b\u0011j,Q\u001a\u0000Wb1\\\u001c\u0004\u001c!\u0013W\r\u001d\u0015j";
      e[4] = boolean.class;
      f[4] = "java/lang/Boolean";
      e[5] = void.class;
      f[5] = "java/lang/Void";
      e[6] = "\u0019`P1,`\u0004u\b\u0013mm\u001cs";
      e[7] = "M-R[\t!Bm\u001fP\u0003<G0\u0014\u0016\u0013'\u0000厈伩右伳伛佻厈桭右桷";
      e[8] = "\u0002nw\u0013u\u0015\taf\\\t\f\u0006{h\u001f><\u0010ld\u0002/\u0010\u0007a";
      e[9] = "OO\u0005s\u0011dD@\u0014<pjOK\u0010f";
      e[10] = "}\r^De`$\u0012T']\u001dR'5A{;x\u0013\u0005\u0018d1";
      e[11] = ";kA\u000fcfbtKl_\u001b\u0012V*\n}=>u\u001aSb7";
      e[12] = "zkW\fD\fd-M3zc8sJCY\r:\u007fCN5";
      e[13] = "_!&E\u0000H\u00186/\u0007=hep}\tM^\u000b0,B\u0007!^0=\u0001\u0000_\u001a,!\u0018=";
      e[14] = "G\u000eWHw1\u001e\u0011]+ALl4<MijB\u0010\f\u0014v`";
      e[15] = "\u001b*\u0014\u0002<OC%M[\u0006\u007fg\n*w\u0006\u001cF)N\u0000iDIp\u0017";
      e[16] = "\u0019K\u001d\u0012j\u001b@T\u0017qYk2v*qtM\u0014N\u000eA-R\u001e";
      e[17] = ")}^Mf{d?M\u0015\u000bn\u0015<\u001c\u0012r|kr[\u0019d\u0007+:D\u000bpye}O\u001d\u000b";
      e[18] = "H3|\u00191S\u000f$u[\fWrb'U|E\u001c\"v\u001e6:";
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 31186;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/ui/友何友何何何友树友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String HE_WEI_LIN() {
      return "何建国230622195906030014";
   }
}
