package cn.cool.cherish.ui;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.树何友友何树友友何何;
import cn.cool.cherish.module.impl.display.HUD;
import cn.cool.cherish.utils.render.RenderUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import heilongjiang.zhaoyuan.何树友;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class 友树友树树何何友树友 implements IWrapper, 何树友 {
   public float 树友树树友树何树何树;
   public float 何何友友何树树树何树;
   public float 树树何友何树友树树何;
   public float 友友友友友树何树何树;
   public 树何友友何树友友何何 树友何友树友何友何友;
   public List<友友友何友友何何树树> 友友何友何友何友友友;
   private final HashMap<树何友友何树友友何何, 树树何树友何树树友树> 友友树树何树树树树何 = new HashMap<>();
   private float 何何何何树友树树何友 = 0.0F;
   private static final float 树树何树何树何树友何 = 2.0F;
   private static final float 何树树树友友友何树何 = 10.0F;
   private static final float 树何友何友树树友友树 = 15.0F;
   private static final float 何何树友树树何何树何 = 25.0F;
   private static final float 树树何友树友友树友何 = 40.0F;
   private static final float 何友树树何友友何树友 = 15.0F;
   private static final float 何友树友树何何树树树 = 0.02F;
   public boolean 友友友友友友友树何何;
   private boolean 何何何树树友树树友树 = false;
   private float 树友树何树树何何友树 = 0.0F;
   private static final long a;
   private static final Object[] b = new Object[31];
   private static final String[] c = new String[31];
   private static String HE_JIAN_GUO;

   public 友树友树树何何友树友() {
      for (树何友友何树友友何何 category : 树何友友何树友友何何.M()) {
         this.友友树树何树树树树何.put(category, new 树树何树友何树树友树());
      }

      this.友友树树何树树树树何.put(null, new 树树何树友何树树友树());
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(6615456799743537038L, -2147779707750336677L, MethodHandles.lookup().lookupClass()).a(261487137010884L);
      // $VF: monitorexit
      a = var10000;
      a();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 27;
               case 1 -> 48;
               case 2 -> 7;
               case 3 -> 44;
               case 4 -> 41;
               case 5 -> 20;
               case 6 -> 46;
               case 7 -> 59;
               case 8 -> 9;
               case 9 -> 12;
               case 10 -> 57;
               case 11 -> 52;
               case 12 -> 45;
               case 13 -> 14;
               case 14 -> 24;
               case 15 -> 18;
               case 16 -> 16;
               case 17 -> 26;
               case 18 -> 55;
               case 19 -> 51;
               case 20 -> 38;
               case 21 -> 1;
               case 22 -> 56;
               case 23 -> 11;
               case 24 -> 19;
               case 25 -> 33;
               case 26 -> 36;
               case 27 -> 10;
               case 28 -> 31;
               case 29 -> 37;
               case 30 -> 40;
               case 31 -> 39;
               case 32 -> 50;
               case 33 -> 28;
               case 34 -> 17;
               case 35 -> 2;
               case 36 -> 3;
               case 37 -> 58;
               case 38 -> 32;
               case 39 -> 43;
               case 40 -> 29;
               case 41 -> 61;
               case 42 -> 54;
               case 43 -> 49;
               case 44 -> 25;
               case 45 -> 21;
               case 46 -> 62;
               case 47 -> 42;
               case 48 -> 5;
               case 49 -> 15;
               case 50 -> 13;
               case 51 -> 47;
               case 52 -> 8;
               case 53 -> 34;
               case 54 -> 60;
               case 55 -> 30;
               case 56 -> 23;
               case 57 -> 6;
               case 58 -> 4;
               case 59 -> 53;
               case 60 -> 22;
               case 61 -> 63;
               case 62 -> 0;
               default -> 35;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   public void i(int keyCode, int scanCode, int modifiers) {
      何友友友树友何友树何.e();
      if (this.友友何友何友何友友友 != null && this.友友友友友友友树何何) {
         this.友友何友何友何友友友.forEach(moduleRect -> {
            何友友友树友何友树何.e();
            if (moduleRect.友树何友何树友友树树) {
               moduleRect.B(keyCode, scanCode, modifiers);
            }
         });
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'e' && var8 != 229 && var8 != 'X' && var8 != 234) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 's') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 204) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'e') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 229) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'X') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   public void c() {
      何友友友树友何友树何.e();
      if (this.树友何友树友何友何友 != null) {
         树树何树友何树树友树 moduleScroll = this.友友树树何树树树树何.get(this.树友何友树友何友何友);
         if (moduleScroll != null) {
            moduleScroll.M();
         }
      }
   }

   private boolean h(float x, float y, float width, float height, double mouseX, double mouseY) {
      何友友友树友何友树何.e();
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/ui/友树友树树何何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static void a() {
      b[0] = "\u0003Cfk\u001e}\f\u0003+`\u0014`\t^ &\u0004{N另桙參桠栃伵佸厃栙厺";
      b[1] = "oN{Lc\u0001dAj\u0003\u001f\u0018k[d@((}Lh]9\u0004jA";
      b[2] = "orxj\u000f)`25a\u00054eo>'\u0015/\"佉厝参厫桗叇佉厝栘伵";
      b[3] = "(\u001d";
      b[4] = "~5\f\u0001\"M`=\u0016N@Qg ";
      b[5] = boolean.class;
      c[5] = "java/lang/Boolean";
      b[6] = "\u001c\u0013^t\u0004z\u0013S\u0013\u007f\u000eg\u0016\u000e\u00189\u001e|Q厶去叜伾叞厴伨伥栆桺";
      b[7] = float.class;
      c[7] = "java/lang/Float";
      b[8] = "\t\u0017'<f2\u0017\u001f=s\u0000&\u0010\u001e\u001c<8";
      b[9] = "\u001f4jy\bK\u0010t'r\u0002V\u0015),4\nK\u0018/(\u007fI栵伩厑厏住桶可厷伏休";
      b[10] = "6ts)L7={bf-96pf<";
      b[11] = "\u00175dJpa\u0015;5)!\u0007Nh0Hry\u0015am\u0011H>Gcj\u00136eN>3)";
      b[12] = "8CD}X|:M\u0015\u001e桹栃伅叭佶标厣栃桁佳+#\\b>N\u0011r\u0006w9";
      b[13] = "NL3AL[LBb\"伩你叭叢企栻桭栤佳核\\\u001fHEHAfN\u0012PO";
      b[14] = "&O\u0014\u0005\u0014\u001f{\u0019\u0002A)桬栃格桽叹只厶佇佸伹:\u0014IbC\u0004\u0000E\u0013wD";
      b[15] = "S@nO\u0006|\u000e\u0016x\u000b;叕厬栳标桩栢栏伲佷叝p\u0006*\u0017L~JWp\u0002K";
      b[16] = "\u0016Qv+\u0002+K\u0007`o?桘叩佦叅栍佢伜佷司叅\u0014\u0002}R]f.S'GZ";
      b[17] = "GV\u0002\u0010M$\u0012F\u0011\u0015s*~\fQZL-\u0010]\fX\u0015G";
      b[18] = "p|\u001c\u0011!TrrMr叚叱栉栈伮桫栀栫栉佌sO\u007fC`/\u0013\u000ezOu";
      b[19] = "h.\u000e'<:5x\u0018c\u0001伍伉桝厽佅参厓伉伙伣\u0018<l,\"\u001e\"m69%";
      b[20] = "56QDRz78\u0000'桳叟桌伆栧栾伷佁厖桂>\u001aVd3;\u0004K\fq4";
      b[21] = "\u007f\u0018\u000bt~|\"N\u001d0C叕桚伯厸伖桚叕厀桫桢Kxk2\u001d\u001f\"~s1\u000e";
      b[22] = "\u001dUC\u001b\u0015|\u001f[\u0012x栴叙桤校可桡佰栃传校,E\u0011b\u001bX\u0016\u0014Kw\u001c";
      b[23] = "\u0010\u0007\u000bF.C\u0012\tZ%叕另伭厩伹另佋另厳厩d\u001e&L\u0000Z\u0005\u001dt\u0018\u001c";
      b[24] = "\\\u0017\u0000H\u0018\u0015^\u0019Q+口厰叿厹厬叨口桪佡伧o\u0010]\u0002S\u001e\u0006\u0016E\u0001@";
      b[25] = "Bj-\u0004b\u0012\u001f<;@_伥桧參桄栢框去厽參桄;bD\u0006f=\u00013\u001e\u0013a";
      b[26] = "n6\u0010\u0002\u000b/l8Aa株厊体厘桦厢佮厊体厘\u007f_I+nc\u0011\u000eM/h";
      b[27] = "|\u0019P5\u000e@~\u0017\u0001V佫佻佁桭栦厕栯栿叟桭?mKWs\u0010VkST`";
      b[28] = "\u0011<K'|\u0007\u00132\u001aD伙似伬伌栽厇桝桸伬厒$yx\u0019\u00171\u001e(\"\f\u0010";
      b[29] = "TU04+U\t\u0003&p\u0016栦厫叼厃佖叕叼桱栦厃\u000b+\u0003\u0010Y 1zY\u0005^";
      b[30] = "wX\u0015M)\tuVD.叒厬叔叶厹样佌桶佊栬z\u0013-\u0017qU@Bw\u0002v";
   }

   private float m() {
      何友友友树友何友树何.e();
      if (this.友友何友何友何友友友 == null) {
         return 0.0F;
      } else {
         float leftColumnHeight = 0.0F;
         float rightColumnHeight = 0.0F;
         int i = 0;
         if (0 < this.友友何友何友何友友友.size()) {
            友友友何友友何何树树 moduleRect = this.友友何友何友何友友友.get(0);
            leftColumnHeight = 0.0F + (moduleRect.友友树树树树树何何友 + 10.0F);
            rightColumnHeight = 0.0F + (moduleRect.友友树树树树树何何友 + 10.0F);
            i++;
         }

         return Math.max(leftColumnHeight, rightColumnHeight);
      }
   }

   private void o(GuiGraphics guiGraphics, float x, float y, float height, Color baseColor, float alpha) {
      Color color = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), (int)(255.0F * alpha));
      RenderUtils.drawRectangle(guiGraphics.pose(), x, y, 2.0F, height, color.getRGB());
      Color glowColor = new Color(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), (int)(120.0F * alpha));
      RenderUtils.drawRectangle(guiGraphics.pose(), x - 1.0F, y, 1.0F, height, glowColor.getRGB());
   }

   public void g(double mouseX, double mouseY, int button) {
      何友友友树友何友树何.e();
      if (this.树友何友树友何友何友 != null && this.友友何友何友何友友友 != null) {
         树树何树友何树树友树 moduleScroll = this.友友树树何树树树树何.get(this.树友何友树友何友何友);
         float totalContentHeight = this.m();
         float visibleHeight = this.友友友友友树何树何树;
         float maxScroll = Math.max(0.0F, totalContentHeight - visibleHeight);
         if (maxScroll > 0.0F && button == 0) {
            float scrollbarX = this.树友树树友树何树何树 + this.树树何友何树友树树何 + 1.0F - 2.0F - 2.0F;
            float contentRatio = visibleHeight / totalContentHeight;
            float scrollbarThumbHeight = Math.max(15.0F, visibleHeight * contentRatio);
            float currentScrollValue = moduleScroll.Y();
            currentScrollValue = Mth.clamp(currentScrollValue, -maxScroll, 0.0F);
            float scrollProgressForUI = maxScroll == 0.0F ? 0.0F : -currentScrollValue / maxScroll;
            float availableScrollTrackHeight = visibleHeight - 2.0F;
            float scrollbarThumbY = this.何何友友何树树树何树 + 1.0F + (availableScrollTrackHeight - scrollbarThumbHeight) * scrollProgressForUI;
            scrollbarThumbY = Mth.clamp(scrollbarThumbY, this.何何友友何树树树何树 + 1.0F, this.何何友友何树树树何树 + 1.0F + availableScrollTrackHeight - scrollbarThumbHeight);
            if (mouseX >= scrollbarX && mouseX <= scrollbarX + 2.0F && mouseY >= scrollbarThumbY && mouseY <= scrollbarThumbY + scrollbarThumbHeight) {
               this.何何何树树友树树友树 = true;
               this.树友树何树树何何友树 = (float)mouseY - scrollbarThumbY;
               return;
            }
         }

         if (mouseX >= this.树友树树友树何树何树 + 90.0F
            && mouseX <= this.树友树树友树何树何树 + this.树树何友何树友树树何 - 20.0F
            && mouseY >= this.何何友友何树树树何树
            && mouseY <= this.何何友友何树树树何树 + this.友友友友友树何树何树) {
         }

         Iterator var21 = this.友友何友何友何友友友.iterator();
         if (var21.hasNext()) {
            友友友何友友何何树树 moduleRect = (友友友何友友何何树树)var21.next();
            if (this.h(moduleRect.何何树友何友友何何何, moduleRect.树树树树友友友何何何, moduleRect.树友何友树何何何友友, moduleRect.友友树树树树树何何友, mouseX, mouseY)) {
               moduleRect.o(mouseX, mouseY, button);
               this.友友友友友友友树何何 = moduleRect.友树何友何树友友树树;
               return;
            }
         }

         this.q();
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void g() {
      何友友友树友何友树何.e();
      if (this.友友何友何友何友友友 != null) {
         this.友友何友何友何友友友.forEach(友友友何友友何何树树::K);
      }
   }

   public void q() {
      何友友友树友何友树何.e();
      if (this.友友何友何友何友友友 != null) {
         this.友友何友何友何友友友.forEach(友友友何友友何何树树::a);
      }

      this.友友友友友友友树何何 = false;
   }

   private void z(float partialTicks) {
      何友友友树友何友树何.e();
      this.何何何何树友树树何友 += 0.02F * partialTicks;
      if (this.何何何何树友树树何友 > 1.0F) {
         this.何何何何树友树树何友--;
      }
   }

   public void z(List<友友友何友友何何树树> moduleRects) {
      this.友友何友何友何友友友 = moduleRects;
   }

   public void E(double mouseX, double mouseY, double delta) {
      何友友友树友何友树何.e();
      if (this.树友何友树友何友何友 != null) {
         if (mouseX >= this.树友树树友树何树何树 + 90.0F
            && mouseX <= this.树友树树友树何树何树 + this.树树何友何树友树树何 - 20.0F
            && mouseY >= this.何何友友何树树树何树
            && mouseY <= this.何何友友何树树树何树 + this.友友友友友树何树何树) {
         }

         树树何树友何树树友树 moduleScroll = this.友友树树何树树树树何.get(this.树友何友树友何友何友);
         if (moduleScroll != null) {
            moduleScroll.O((float)delta * 30.0F);
         }
      }
   }

   public void L(double mouseX, double mouseY, int button) {
      何友友友树友何友树何.e();
      if (button == 0 && this.何何何树树友树树友树) {
         this.何何何树树友树树友树 = false;
      }

      if (this.友友何友何友何友友友 != null) {
         this.友友何友何友何友友友.forEach(moduleRect -> moduleRect.r(mouseX, mouseY, button));
      }
   }

   public void H(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
      何友友友树友何友树何.e();
      this.友友友友友友友树何何 = false;
      if (this.树友何友树友何友何友 != null && this.友友何友何友何友友友 != null) {
         树树何树友何树树友树 moduleScroll = this.友友树树何树树树树何.get(this.树友何友树友何友何友);
         if (moduleScroll == null) {
            moduleScroll = new 树树何树友何树树友树();
            this.友友树树何树树树树何.put(this.树友何友树友何友何友, moduleScroll);
         }

         moduleScroll.W();
         this.z(partialTicks);
         float totalContentHeight = this.m();
         float visibleHeight = this.友友友友友树何树何树;
         float maxScroll = Math.max(0.0F, totalContentHeight - visibleHeight);
         moduleScroll.J(maxScroll);
         guiGraphics.enableScissor(
            (int)(this.树友树树友树何树何树 + 95.0F),
            (int)this.何何友友何树树树何树 + 1,
            (int)(this.树友树树友树何树何树 + this.树树何友何树友树树何 - 18.0F),
            (int)(this.何何友友何树树树何树 + this.友友友友友树何树何树)
         );
         int count = 0;
         Iterator scrollbarWidth = this.友友何友何友何友友友.iterator();
         if (scrollbarWidth.hasNext()) {
            友友友何友友何何树树 moduleRect = (友友友何友友何何树树)scrollbarWidth.next();
            moduleRect.树友何友树何何何友友 = (this.树树何友何树友树树何 - 130.0F) / 2.0F;
            moduleRect.何树友树树树友友友树 = this.树树何友何树友树树何;
            moduleRect.树友友友何友友树树友 = this.友友友友友树何树何树;
            moduleRect.何何树友何友友何何何 = this.树友树树友树何树何树 + 100.0F + (moduleRect.树友何友树何何何友友 + 10.0F);
            moduleRect.树树树树友友友何何何 = this.何何友友何树树树何树 + 10.0F + 0.0F + moduleScroll.Y();
            if (moduleRect.树树树树友友友何何何 + moduleRect.友友树树树树树何何友 >= this.何何友友何树树树何树 && moduleRect.树树树树友友友何何何 <= this.何何友友何树树树何树 + this.友友友友友树何树何树) {
               moduleRect.a(guiGraphics, mouseX, mouseY, partialTicks);
            }

            if (moduleRect.友树何友何树友友树树) {
               this.友友友友友友友树何何 = true;
            }

            float var10000 = 0.0F + (moduleRect.友友树树树树树何何友 + 10.0F);
            count++;
         }

         guiGraphics.disableScissor();
         if (maxScroll > 0.0F) {
            float scrollbarX = this.树友树树友树何树何树 + this.树树何友何树友树树何 + 1.0F - 2.0F - 2.0F;
            float contentRatio = visibleHeight / totalContentHeight;
            float scrollbarThumbHeight = Math.max(15.0F, visibleHeight * contentRatio);
            float currentScrollValue = moduleScroll.Y();
            currentScrollValue = Mth.clamp(currentScrollValue, -maxScroll, 0.0F);
            float scrollProgressForUI = maxScroll == 0.0F ? 0.0F : -currentScrollValue / maxScroll;
            float availableScrollTrackHeight = visibleHeight - 2.0F;
            float scrollbarThumbY = this.何何友友何树树树何树 + 1.0F + (availableScrollTrackHeight - scrollbarThumbHeight) * scrollProgressForUI;
            scrollbarThumbY = Mth.clamp(scrollbarThumbY, this.何何友友何树树树何树 + 1.0F, this.何何友友何树树树何树 + 1.0F + availableScrollTrackHeight - scrollbarThumbHeight);
            RenderUtils.drawRectangle(guiGraphics.pose(), scrollbarX, scrollbarThumbY, 2.0F, scrollbarThumbHeight, new Color(255, 255, 255, 180).getRGB());
         }

         guiGraphics.enableScissor(
            (int)(this.树友树树友树何树何树 + this.树树何友何树友树树何 - 10.0F - 2.0F - 5.0F),
            (int)this.何何友友何树树树何树 + 1,
            (int)(this.树友树树友树何树何树 + this.树树何友何树友树树何),
            (int)(this.何何友友何树树树何树 + this.友友友友友树何树何树)
         );
         guiGraphics.disableScissor();
      }
   }

   private void T(GuiGraphics guiGraphics) {
      Color accentColor = HUD.instance.getColor(0);
      何友友友树友何友树何.e();
      float decorX = this.树友树树友树何树何树 + this.树树何友何树友树树何 - 10.0F;
      int repetitions = (int)Math.ceil(this.友友友友友树何树何树 / 125.0F) + 1;
      float startOffset = -125.0F * this.何何何何树友树树何友;
      int i = 0;
      if (0 < repetitions) {
         float currentY = this.何何友友何树树树何树 + startOffset + 0.0F;
         this.o(guiGraphics, decorX, currentY, 40.0F, accentColor, 1.0F);
         currentY += 55.0F;
         this.o(guiGraphics, decorX, currentY, 25.0F, accentColor, 0.8F);
         currentY += 40.0F;
         this.o(guiGraphics, decorX, currentY, 15.0F, accentColor, 0.6F);
         float var10000 = currentY + 30.0F;
         i++;
      }
   }

   private static String HE_WEI_LIN() {
      return "行走的50万——何炜霖";
   }

   public void G(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      何友友友树友何友树何.e();
      if (button == 0 && this.何何何树树友树树友树) {
         树树何树友何树树友树 var10000 = this.友友树树何树树树树何.get(this.树友何友树友何友何友);
      }
   }

   public void O(char chr, int modifiers) {
      何友友友树友何友树何.e();
      if (this.友友何友何友何友友友 != null && this.友友友友友友友树何何) {
         this.友友何友何友何友友友.forEach(moduleRect -> {
            何友友友树友何友树何.e();
            if (moduleRect.友树何友何树友友树树) {
               moduleRect.F(chr, modifiers);
            }
         });
      }
   }
}
