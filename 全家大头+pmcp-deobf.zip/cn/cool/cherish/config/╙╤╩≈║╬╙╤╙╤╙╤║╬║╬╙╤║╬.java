package cn.cool.cherish.config;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.module.友友友何树友何树树树;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import heilongjiang.zhaoyuan.何树友;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.Iterator;

public class 友树何友友友何何友何 extends 何友何何何树友友友树 implements 何树友 {
   private static final long b;
   private static final Object[] c = new Object[19];
   private static final String[] d = new String[19];
   private static String HE_JIAN_GUO;

   public 友树何友友友何何友何(File file) {
      super(file);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(7206670171536674239L, -4278673337894646569L, MethodHandles.lookup().lookupClass()).a(144663480344085L);
      // $VF: monitorexit
      b = var10000;
      b();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (d[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 7;
               case 2 -> 24;
               case 3 -> 53;
               case 4 -> 49;
               case 5 -> 41;
               case 6 -> 11;
               case 7 -> 51;
               case 8 -> 52;
               case 9 -> 13;
               case 10 -> 1;
               case 11 -> 46;
               case 12 -> 55;
               case 13 -> 25;
               case 14 -> 16;
               case 15 -> 0;
               case 16 -> 3;
               case 17 -> 22;
               case 18 -> 63;
               case 19 -> 4;
               case 20 -> 35;
               case 21 -> 42;
               case 22 -> 36;
               case 23 -> 50;
               case 24 -> 44;
               case 25 -> 48;
               case 26 -> 45;
               case 27 -> 15;
               case 28 -> 6;
               case 29 -> 43;
               case 30 -> 19;
               case 31 -> 56;
               case 32 -> 14;
               case 33 -> 34;
               case 34 -> 21;
               case 35 -> 59;
               case 36 -> 12;
               case 37 -> 40;
               case 38 -> 58;
               case 39 -> 54;
               case 40 -> 38;
               case 41 -> 5;
               case 42 -> 33;
               case 43 -> 28;
               case 44 -> 57;
               case 45 -> 23;
               case 46 -> 17;
               case 47 -> 2;
               case 48 -> 31;
               case 49 -> 18;
               case 50 -> 8;
               case 51 -> 61;
               case 52 -> 30;
               case 53 -> 27;
               case 54 -> 20;
               case 55 -> 39;
               case 56 -> 60;
               case 57 -> 47;
               case 58 -> 10;
               case 59 -> 29;
               case 60 -> 26;
               case 61 -> 62;
               case 62 -> 9;
               default -> 32;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            d[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void b() {
      c[0] = "2#C\u0003\u0006;=c\u000e\b\f&8>\u0005N\n;?+\u0004\u0007G原伄优厦桱厢桅伄桜桼";
      c[1] = "l#=Xd\u0018\u0019\u00036WuWd\u001b%P|\u001e\f";
      c[2] = "P\u0015=#n2_Up(d/Z\b{nb2]\u001dz'/厖栢伮变压及伈佦厰但";
      c[3] = "Y0i4\u0007?R?x{};A>h4K?V";
      c[4] = ";S\u001bB;f4\u0013VI1{1N]\u000f7f6[\\Fz作厓佨你佴桅参厓叶栤";
      c[5] = "z[\u001e'\"N\u007f\u0014./`B";
      c[6] = "{Z\u001d\u001f\u0002at\u001aP\u0014\b|qG[R\u000eavRZ\u001bCMwZU\u0015\nCyZR\u001b\b|";
      c[7] = "nl\u0019\u001e^1bd\u0018U\u00179~l\u001a\u001e~-bm";
      c[8] = "Tc\\6X+[#\u0011=R6^~\u001a{Z+Sx\u001e0\u0019\tXi\u00079R";
      c[9] = "\\FvSG#hey\u0013\n(bx|N\u0001njeqH\u0005%)GzY\u001c,b1";
      c[10] = "\u0012wM\tU8&TBI\u00183,IG\u0014\u0013u$TJ\u0012\u0017>gvA\u0003\u000e7,\u0000";
      c[11] = void.class;
      d[11] = "java/lang/Void";
      c[12] = "OJn^\u0010YDE\u007f\u0011qWON{K";
      c[13] = ":?;\b8Fia'\u0011J(\u00049r\u0014%A~w:Q1z";
      c[14] = "m,\n\u0000\u0001=n}\u0000g\u0007\u00023|_\f\rae~\r\u001bl";
      c[15] = "{\u0016\bsU\u007f=H\u000el(fBI\u0016pIv3\u0015OjX\u000fx\u0016\u0013qQ~$O\t`(";
      c[16] = "-7^\u001b5ZjfT\u0011M厢佋叄史桩厎似佋佚佬pv\u000egj[K,^fb";
      c[17] = "5/'J!\u0012fq;SSp\u000b)nV<\u0015qg&\u0013(.;,4U8Ma&-GS";
      c[18] = "6b?)#\u001d4}znH桦栓佐佚伋桑厼佗栔栞Vu\u001ehmz4:\u00120h";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'e' && var8 != 'S' && var8 != 'q' && var8 != 238) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'E') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 209) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'e') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'S') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'q') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/友树何友友友何何友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @Override
   public void k() throws Throwable {
      友何何友树友树何树树.c();
      if (super.友何友友树友何何何何.exists()) {
         JsonObject hudConfig = (JsonObject)JsonParser.parseString(Files.readString(super.友何友友树友何何何何.toPath()));
         if (Cherish.instance == null) {
            return;
         }

         Iterator var5 = Cherish.instance.getModuleManager().p().iterator();
         if (var5.hasNext()) {
            Module module = (Module)var5.next();
            if (module instanceof 友友友何树友何树树树 drag) {
               String name = module.A();
               if (hudConfig.has(name)) {
                  JsonObject singleHUD = hudConfig.getAsJsonObject(name);
                  if (singleHUD.has("X")) {
                     drag.u(singleHUD.get("X").getAsFloat());
                  }

                  if (singleHUD.has("Y")) {
                     drag.N(singleHUD.get("Y").getAsFloat());
                  }
               }
            }

            Module.V(new Module[3]);
         }
      }

      this.A();
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   public boolean A() throws Throwable {
      友何何友树友树何树树.c();
      JsonObject hudConfig = new JsonObject();
      if (Cherish.instance == null) {
         return false;
      } else {
         Iterator bufferedWriter = Cherish.instance.getModuleManager().p().iterator();
         if (bufferedWriter.hasNext()) {
            Module module = (Module)bufferedWriter.next();
            if (module instanceof 友友友何树友何树树树 drag) {
               JsonObject singleHUD = new JsonObject();
               singleHUD.addProperty("X", drag.N());
               singleHUD.addProperty("Y", drag.C());
               hudConfig.add(module.A(), singleHUD);
            }
         }

         try (BufferedWriter bufferedWriterx = new BufferedWriter(new FileWriter(super.友何友友树友何何何何))) {
            ConfigManager.树树何何何树友何树树.toJson(hudConfig, bufferedWriterx);
         }

         return true;
      }
   }

   private static String HE_SHU_YOU() {
      return "行走的50万——何炜霖";
   }
}
