package cn.cool.cherish.config;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.value.树何何树何友树何何树;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import heilongjiang.zhaoyuan.何树友;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何何友树友树何树树 extends 何友何何何树友友友树 implements 何树友 {
   private static String[] 友友树友何友树友树友;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[18];
   private static final String[] i = new String[18];
   private static String HE_JIAN_GUO;

   public 友何何友树友树何树树(File file) {
      super(file);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-8476265660690464587L, -3830730890280293479L, MethodHandles.lookup().lookupClass()).a(148783143490661L);
      // $VF: monitorexit
      b = var10000;
      b();
      String[] var10 = new String[3];
      x(var10);
      Cipher var0;
      Cipher var11 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(77178080447563L << var1 * 8 >>> 56);
      }

      var11.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[6];
      int var5 = 0;
      String var4 = "\bº3\u0014û^\u0098v\n'¡5åX\u0011Õ\u0010Ö~\u0000¤5I´ß(\u0010 ÂêZRÍ\u0010\u0089ReN*ÓÏ\u007f\u0000\u001f|rbÌ»d\u0010¿!¢ü{¸Wvý.\nøÄ\"-\u0094";
      byte var6 = 67;
      char var3 = 16;
      int var9 = -1;

      label27:
      while (true) {
         String var12 = var4.substring(++var9, var9 + var3);
         byte var10001 = -1;

         while (true) {
            String var18 = b(var0.doFinal(var12.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var18;
                  if ((var9 += var3) >= var6) {
                     c = var7;
                     d = new String[6];
                     return;
                  }

                  var3 = var4.charAt(var9);
                  break;
               default:
                  var7[var5++] = var18;
                  if ((var9 += var3) < var6) {
                     var3 = var4.charAt(var9);
                     continue label27;
                  }

                  var4 = "O/ü`\t@/\u0082$ëN\u001bHu7,\u0010\u0099\u008e3¨Y'È\u0093!=\u0094ß\u0007\u008fÇq";
                  var6 = 33;
                  var3 = 16;
                  var9 = -1;
            }

            var12 = var4.substring(++var9, var9 + var3);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 33;
               case 1 -> 30;
               case 2 -> 23;
               case 3 -> 31;
               case 4 -> 32;
               case 5 -> 36;
               case 6 -> 15;
               case 7 -> 28;
               case 8 -> 10;
               case 9 -> 11;
               case 10 -> 0;
               case 11 -> 56;
               case 12 -> 26;
               case 13 -> 29;
               case 14 -> 4;
               case 15 -> 54;
               case 16 -> 20;
               case 17 -> 60;
               case 18 -> 61;
               case 19 -> 63;
               case 20 -> 24;
               case 21 -> 7;
               case 22 -> 40;
               case 23 -> 62;
               case 24 -> 42;
               case 25 -> 5;
               case 26 -> 17;
               case 27 -> 41;
               case 28 -> 6;
               case 29 -> 53;
               case 30 -> 57;
               case 31 -> 9;
               case 32 -> 55;
               case 33 -> 37;
               case 34 -> 46;
               case 35 -> 13;
               case 36 -> 14;
               case 37 -> 35;
               case 38 -> 22;
               case 39 -> 2;
               case 40 -> 58;
               case 41 -> 48;
               case 42 -> 18;
               case 43 -> 52;
               case 44 -> 34;
               case 45 -> 51;
               case 46 -> 12;
               case 47 -> 25;
               case 48 -> 59;
               case 49 -> 47;
               case 50 -> 49;
               case 51 -> 45;
               case 52 -> 19;
               case 53 -> 8;
               case 54 -> 38;
               case 55 -> 21;
               case 56 -> 3;
               case 57 -> 39;
               case 58 -> 27;
               case 59 -> 43;
               case 60 -> 16;
               case 61 -> 50;
               case 62 -> 44;
               default -> 1;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static void b() {
      h[0] = "[\u001aYR\tlTZ\u0014Y\u0003qQ\u0007\u001f\u001f\u0005lV\u0012\u001eVH又佭伡厼栠厭栒佭桥桦";
      h[1] = "OjEb d:JNm1+GR]j8b/";
      h[2] = void.class;
      i[2] = "java/lang/Void";
      h[3] = "\u0012\u0010!V pg0*Y1?\u001a(9^8vr";
      h[4] = "}$+`^drdfkTyw9m-\\dz?if\u001fFq.poT";
      h[5] = "\"YO6c\u0017\u0016z@v.\u001c\u001cgE+%Z\u0014zH-!\u0011WXC<8\u0018\u001c.";
      h[6] = "T\u001cRd}y[\\\u001fowd^\u0001\u0014)qyY\u0014\u0015`<佃叼伧伩佒栃叝叼厹桭";
      h[7] = "\u000eB\u0016!?\u007f\u000b\r&)}s";
      h[8] = "2@%[^99O4\u0014$=*N$[\u00129=";
      h[9] = "\u0017\u000eC(hE\u0018N\u000e#bX\u001d\u0013\u0005edE\u001a\u0006\u0004,)i\u001b\u000e\u000b\"`g\u0015\u000e\f,bX";
      h[10] = "\u00016+@\nW\r>*\u000bC_\u00116(@*K\r7";
      h[11] = "P/1puk[  ?\u0014eP+$e";
      h[12] = "}pS@x\u0015-p\rCF8G6\u0012Mz\u0000zi\u000b\u00177j";
      h[13] = "O\t\u0003\u0013\u00109\u0012\r\u0002#E\u0003IJIRSx\u0012T\u0015\u001a.";
      h[14] = "\rLsj~+PHrZ0\u0011\u000b\u000f9+=jP\u0011ec@(\\\u001c~\"$vS\u000b8Z";
      h[15] = "ujk00\u001aq{{:\u0001厧伔发叇桄参伹伔住余]<^ tg1<\u000b8b";
      h[16] = "\u0012x\u0003Rz-\u0011kA\f\u0001栎栵佉伥佬栘叔佱栍桡1>w]wIMx-Nj";
      h[17] = "\u001adLP\b\u0006G`M`_<\u001b.\u0003\u001e[^J<\u0002\u00066\u0001VaB\rTPD`Z`";
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'Y' && var8 != 'k' && var8 != 255 && var8 != 'e') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'U') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'S') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'Y') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'k') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 255) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static void x(String[] var0) {
      友友树友何友树友树友 = var0;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public static String[] c() {
      return 友友树友何友树友树友;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/友何何友树友树何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 18628;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/config/友何何友树友树何树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = ((Object[])"[ïPW\u008d\u0086ñu³, e¶)\u0094\u0001ÏÊC, ÌUpèô!Ï<, (\\Èµ>nfÆ, ¯ÈDø\u009a5³!, þù")[var5].getBytes("ISO-8859-1");
         d[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/友何何友树友树何树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   @Override
   public void k() throws Throwable {
      c();
      if (super.友何友友树友何何何何.exists()) {
         JsonObject moduleConfig = (JsonObject)JsonParser.parseString(Files.readString(super.友何友友树友何何何何.toPath()));
         if (Cherish.instance == null) {
            return;
         }

         Iterator var7 = Cherish.instance.getModuleManager().p().iterator();
         if (var7.hasNext()) {
            Module module = (Module)var7.next();
            String name = module.A();
            if (moduleConfig.has(name)) {
               JsonObject singleModule = moduleConfig.getAsJsonObject(name);
               if (singleModule.has("State")) {
                  if (ClientUtils.g(module, 126743405834954L)) {
                     module.J(false);
                  }

                  module.J(singleModule.get("State").getAsBoolean());
               }

               if (singleModule.has("KeyBind")) {
                  module.g(singleModule.get("KeyBind").getAsInt());
               }

               if (singleModule.has("Values")) {
                  JsonObject valuesConfig = singleModule.get("Values").getAsJsonObject();
                  Iterator var12 = module.P().iterator();
                  if (var12.hasNext()) {
                     树何何树何友树何何树<?> setting = (树何何树何友树何何树<?>)var12.next();
                     if (valuesConfig.has(setting.r())) {
                        setting.C(valuesConfig.get(setting.r()));
                     }
                  }
               }
            }
         }
      }

      this.A();
      if (Module.Z() == null) {
         x(new String[3]);
      }
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   public boolean A() throws Throwable {
      c();
      JsonObject moduleConfig = new JsonObject();
      if (Cherish.instance == null) {
         return false;
      } else {
         Iterator bufferedWriter = Cherish.instance.getModuleManager().p().iterator();
         if (bufferedWriter.hasNext()) {
            Module module = (Module)bufferedWriter.next();
            JsonObject singleModule = new JsonObject();
            singleModule.addProperty("State", module.isEnabled());
            singleModule.addProperty("KeyBind", module.r());
            JsonObject settingConfig = new JsonObject();
            Iterator var9 = module.P().iterator();
            if (var9.hasNext()) {
               树何何树何友树何何树<?> setting = (树何何树何友树何何树<?>)var9.next();
               setting.L(settingConfig);
            }

            singleModule.add("Values", settingConfig);
            moduleConfig.add(module.A(), singleModule);
         }

         try (BufferedWriter bufferedWriterx = new BufferedWriter(new FileWriter(super.友何友友树友何何何何))) {
            ConfigManager.树树何何何树友何树树.toJson(moduleConfig, bufferedWriterx);
         }

         return true;
      }
   }

   private static String HE_WEI_LIN() {
      return "职业技术教育中心学校";
   }
}
