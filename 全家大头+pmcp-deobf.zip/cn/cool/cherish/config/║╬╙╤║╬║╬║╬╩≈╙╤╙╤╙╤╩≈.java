package cn.cool.cherish.config;

import cn.cool.cherish.module.何树何何树何友何何何;
import furry.obf.ClassObfuscator;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

@ClassObfuscator
public abstract class 何友何何何树友友友树 implements 何树友 {
   protected final File 友何友友树友何何何何;
   public static String[] 友友树友友友何何友友;
   private static String 友何友友树何何树友友;
   private static final long a;
   private static final Object[] f = new Object[10];
   private static final String[] g = new String[10];
   private static String HE_JIAN_GUO;

   public 何友何何何树友友友树(File file) {
      this.友何友友树友何何何何 = file;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-799643371036587770L, 4244941990600582179L, MethodHandles.lookup().lookupClass()).a(38158153543527L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (g() == null) {
         k("v2VoQb");
      }

      Cipher a;
      Cipher var37 = a = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int ax = 1; ax < 8; ax++) {
         var10003[ax] = (byte)(82330564408152L << ax * 8 >>> 56);
      }

      var37.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] ax = new String[6];
      int axx = 0;
      String axxx = "ðSXí y\u0095;\b£\u0098\büh1|\u0080\u0084D%7\u0003jg\u0010\u0084\u0087¢\u0016¤ÃÞå\u0010W\u009fJ{\u0001Ö'\u0010µ½*\u0099ªÞ\u000b\u0086¿\u000bÙ+jø\u0089º\u0018÷ú\u0098\u0003\u0094×þðÙ\u0006\u000bóèv7Du\u00ad¢Ã\u009c^}Ð";
      int axxxx = 83;
      int axxxxx = 24;
      int var16 = -1;

      label86:
      while (true) {
         String var38 = axxx.substring(++var16, var16 + axxxxx);
         byte var10001 = -1;

         while (true) {
            String var44 = a(a.doFinal(var38.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  ax[axx++] = var44;
                  if ((var16 += axxxxx) >= axxxx) {
                     友友树友友友何何友友 = new String[]{"", "", "", "", "", "", "", "", ""};

                     for (char c : ax[0].toCharArray()) {
                        友友树友友友何何友友[0] = 友友树友友友何何友友[0] + (char)(c ^ 6);
                     }

                     for (char c : ax[2].toCharArray()) {
                        友友树友友友何何友友[1] = 友友树友友友何何友友[1] + (char)(c ^ '\b');
                     }

                     for (char c : ax[5].toCharArray()) {
                        友友树友友友何何友友[2] = 友友树友友友何何友友[2] + (char)(c ^ 6);
                     }

                     for (char c : ax[4].toCharArray()) {
                        友友树友友友何何友友[3] = 友友树友友友何何友友[3] + (char)(c ^ '\b');
                     }

                     for (char c : ax[3].toCharArray()) {
                        友友树友友友何何友友[4] = 友友树友友友何何友友[4] + (char)(c ^ 6);
                     }

                     for (char c : ax[1].toCharArray()) {
                        友友树友友友何何友友[5] = 友友树友友友何何友友[5] + (char)(c ^ '\b');
                     }

                     return;
                  }

                  axxxxx = axxx.charAt(var16);
                  break;
               default:
                  ax[axx++] = var44;
                  if ((var16 += axxxxx) < axxxx) {
                     axxxxx = axxx.charAt(var16);
                     continue label86;
                  }

                  axxx = "Ô\u0011\u009c\u009c-¬\u001eXÃ\r¿\u0081JÙ\u0015§\b\u000bq/\u0012ÿà;û";
                  axxxx = 25;
                  axxxxx = 16;
                  var16 = -1;
            }

            var38 = axxx.substring(++var16, var16 + axxxxx);
            var10001 = 0;
         }
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/何友何何何树友友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 206 && var8 != 254 && var8 != 'n' && var8 != 'o') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'J') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 224) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 206) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 254) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'n') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 37;
               case 1 -> 15;
               case 2 -> 19;
               case 3 -> 59;
               case 4 -> 47;
               case 5 -> 2;
               case 6 -> 39;
               case 7 -> 6;
               case 8 -> 20;
               case 9 -> 57;
               case 10 -> 4;
               case 11 -> 55;
               case 12 -> 18;
               case 13 -> 35;
               case 14 -> 31;
               case 15 -> 63;
               case 16 -> 50;
               case 17 -> 30;
               case 18 -> 54;
               case 19 -> 58;
               case 20 -> 14;
               case 21 -> 32;
               case 22 -> 38;
               case 23 -> 17;
               case 24 -> 49;
               case 25 -> 5;
               case 26 -> 45;
               case 27 -> 7;
               case 28 -> 60;
               case 29 -> 40;
               case 30 -> 8;
               case 31 -> 41;
               case 32 -> 27;
               case 33 -> 46;
               case 34 -> 0;
               case 35 -> 36;
               case 36 -> 16;
               case 37 -> 48;
               case 38 -> 44;
               case 39 -> 24;
               case 40 -> 9;
               case 41 -> 43;
               case 42 -> 23;
               case 43 -> 3;
               case 44 -> 34;
               case 45 -> 52;
               case 46 -> 21;
               case 47 -> 53;
               case 48 -> 51;
               case 49 -> 25;
               case 50 -> 11;
               case 51 -> 28;
               case 52 -> 1;
               case 53 -> 13;
               case 54 -> 10;
               case 55 -> 33;
               case 56 -> 29;
               case 57 -> 22;
               case 58 -> 26;
               case 59 -> 61;
               case 60 -> 12;
               case 61 -> 62;
               case 62 -> 56;
               default -> 42;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      f[0] = "m^\u0001\n!Zb\u001eL\u0001+GgCGG-Z`VF\u000e`你叅佥佺似桟叾叅叻栾";
      f[1] = "g\u001do2Q_\u0012=d=@\u0010o%w:IY\u0007";
      f[2] = "d]y\u0019\u0007Ka\u0012I\u0011EG";
      f[3] = "b\u00138\u000f)5i\u001c)@T-z\u001b \t";
      f[4] = void.class;
      g[4] = "java/lang/Void";
      f[5] = "~l\u007f[\u001bjucn\u0014zd~hjN";
      f[6] = "f#\u0000\u000fvi!+\u0016qmWa&\b\u001db;;)\t\u0013\u000el2*\tIs;$-\u001fq";
      f[7] = "\u001b\u0000#&qA\\\b5Xf\u007f\u001c\u0005+4e\u0013F\n*:\t";
      f[8] = "\u0012G\u007f_\rMUOi!厶伮召叧栟叢伨伮佲佹\u0006\u0018\u0004\u0002Q\u0014?EOHF";
      f[9] = "V\u0019t\r. \u0011\u0011bs厕叝桲厹収厰伋佃厨厹\rJ<z\u0017\u0016p\u00131s\u0006";
   }

   public static Object o() {
      try {
         return Class.forName(友友树友友友何何友友[0]).getMethod(友友树友友友何何友友[1], String.class);
      } catch (Exception var0) {
         return null;
      }
   }

   public abstract void k() throws Throwable;

   public static void k(String var0) {
      友何友友树何何树友友 = var0;
   }

   public static String g() {
      return 友何友友树何何树友友;
   }

   public File y() {
      return this.友何友友树友何何何何;
   }

   public abstract boolean A() throws Throwable;

   private static String HE_DA_WEI() {
      return "何树友，和树做朋友";
   }
}
