package cn.cool.cherish.config;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.cool.cherish.value.树何何何友树树何友何;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import heilongjiang.zhaoyuan.何树友;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 友何友树树树友树何友 extends 友何友树何何友友树树 implements 何树友 {
   private static int 树何友树何友树友树树;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[18];
   private static final String[] i = new String[18];
   private static String LIU_YA_FENG;

   public 友何友树树树友树何友(File file) {
      super(file);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(7734069101650830855L, 170996723748354447L, MethodHandles.lookup().lookupClass()).a(35368147356989L);
      // $VF: monitorexit
      b = var10000;
      long var9 = b ^ 90220660203733L;
      c();
      c<"É">(0, 5205983892599385119L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[6];
      int var5 = 0;
      String var4 = "ÇCë\u0018\u001aL³u't\u0088\u0096\u009e\u0097C¬\u0010;\u001eU\u0005p6bÒôu|\u009eÍruá\u0010\u0086î\u0015´A\u0092\u0093¼Ú'S³\fÕüµ\u0010RDB\u0090¨ÁZ\u0007ùxË:LÓ¬F";
      byte var6 = 67;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = b(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     c = var7;
                     d = new String[6];
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "6\u001dþä\u007f²/)a?\u0012\u0089j¶9d\u0010«Ø\u0090\u008br\u0014=pÞÝ¹\u008c\u0089ºì÷";
                  var6 = 33;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 18;
               case 2 -> 15;
               case 3 -> 58;
               case 4 -> 12;
               case 5 -> 6;
               case 6 -> 10;
               case 7 -> 0;
               case 8 -> 38;
               case 9 -> 24;
               case 10 -> 5;
               case 11 -> 8;
               case 12 -> 29;
               case 13 -> 7;
               case 14 -> 2;
               case 15 -> 61;
               case 16 -> 30;
               case 17 -> 44;
               case 18 -> 19;
               case 19 -> 4;
               case 20 -> 39;
               case 21 -> 60;
               case 22 -> 33;
               case 23 -> 49;
               case 24 -> 57;
               case 25 -> 21;
               case 26 -> 27;
               case 27 -> 25;
               case 28 -> 36;
               case 29 -> 43;
               case 30 -> 41;
               case 31 -> 22;
               case 32 -> 32;
               case 33 -> 14;
               case 34 -> 48;
               case 35 -> 13;
               case 36 -> 11;
               case 37 -> 54;
               case 38 -> 47;
               case 39 -> 42;
               case 40 -> 17;
               case 41 -> 37;
               case 42 -> 31;
               case 43 -> 52;
               case 44 -> 35;
               case 45 -> 55;
               case 46 -> 1;
               case 47 -> 62;
               case 48 -> 20;
               case 49 -> 23;
               case 50 -> 34;
               case 51 -> 28;
               case 52 -> 3;
               case 53 -> 45;
               case 54 -> 51;
               case 55 -> 53;
               case 56 -> 9;
               case 57 -> 40;
               case 58 -> 56;
               case 59 -> 63;
               case 60 -> 46;
               case 61 -> 59;
               case 62 -> 16;
               default -> 26;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 231 && var8 != 'o' && var8 != 'u' && var8 != 'O') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'Z') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 201) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 231) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'o') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'u') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static String b(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   public static void s(int var0) {
      树何友树何友树友树树 = var0;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static void c() {
      h[0] = "\u00150\tRW\u001c\u001apDY]\u0001\u001f-O\u001f[\u001c\u00188NV\u0016厸伣厕栶栠栩厸桧伋召";
      h[1] = int.class;
      i[1] = "java/lang/Integer";
      h[2] = void.class;
      i[2] = "java/lang/Void";
      h[3] = "S\u00116nc\u0013\\Q{ei\u000eY\fp#o\u0013^\u0019qj\"?_\u0011~dk1Q\u0011yji\u000e";
      h[4] = "q\u0005$?|^}\r%t5Va\u0005'?\\B}\u0004";
      h[5] = "S?i\\\u000eq\\\u007f$W\u0004lY\"/\u0011\u0002q^7.XO叕佥厚桖佪伴叕叻桀桖";
      h[6] = "\u0006\u001a#g}E\u0003U\u0013o?I";
      h[7] = ">\u000ePE'\u000f5\u0001A\n]\u000b&\u0000QEk\u000f1";
      h[8] = "\f\u00195E \u0017\u0003YxN*\n\u0006\u0004s\b\"\u0017\u000b\u0002wCa5\u0000\u0013nJ*";
      h[9] = boolean.class;
      i[9] = "java/lang/Boolean";
      h[10] = "\u0001rE5|\u0013\n}Tz\u001d\u001d\u0001vP ";
      h[11] = "v}R(&>vbE\u0019\u0013\u0005.#Cd%;txAd\\";
      h[12] = "\u007f\u001d#}ov7\u00103{\u0017桕历厾厐余栎桕桜桤厐\u0004,'.\u0000hf}+>M";
      h[13] = "^J\u0006)p3\u0006\f\u001c0H厝桻厵厴桊桑伃桻桯厴St'\t\u0007O+:&\u0006\b";
      h[14] = "n0G J2n/P\u0011^\t6nVlI7l5Tl0";
      h[15] = ",D\u0005&-c,[\u0012\u0017>XpJI|,(*LOiWe$\u001e\u001fl'?\"\u0018\n\u0017";
      h[16] = "D{Y<&\"Dp^3O(y?T=!\"\u0002`\u000ez&E";
      h[17] = "x/(\u0005_:x0?4^\u0001 q9I\\?z*;I%8|3\"K\u0018<g(84";
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/友何友树树树友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   @Override
   public boolean h() throws Throwable {
      long a = b ^ 2689412420136L;
      c<"É">(-4988703015107838706L, a);
      JsonObject moduleConfig = new JsonObject();
      if (Cherish.instance == null) {
         return false;
      } else {
         Iterator bufferedWriter = Cherish.instance.getModuleManager().k().iterator();
         if (bufferedWriter.hasNext()) {
            Module module = (Module)bufferedWriter.next();
            JsonObject singleModule = new JsonObject();
            singleModule.addProperty(a<"j">(13561, 4786767474642475001L ^ a), module.isEnabled());
            singleModule.addProperty(a<"j">(9862, 9183239482067862917L ^ a), module.W());
            JsonObject settingConfig = new JsonObject();
            Iterator var9 = module.q().iterator();
            if (var9.hasNext()) {
               树何何何友树树何友何<?> setting = (树何何何友树树何友何<?>)var9.next();
               setting.a(settingConfig);
            }

            singleModule.add(a<"j">(27893, 7271920378031935476L ^ a), settingConfig);
            moduleConfig.add(module.i(), singleModule);
         }

         try (BufferedWriter bufferedWriterx = new BufferedWriter(new FileWriter(c<"ç">(this, -4988532409585954001L, a)))) {
            c<"u">(-4988488051747789657L, a).toJson(moduleConfig, bufferedWriterx);
         }

         return true;
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static int f() {
      G();

      try {
         return 110;
      } catch (RuntimeException var0) {
         throw a(var0);
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   @Override
   public void a() throws Throwable {
      long a = b ^ 22478423375273L;
      long ax = a ^ 46890422859407L;
      int axx = c<"É">(-3079063126757695114L, a);
      if (c<"ç">(this, -3079272234245456722L, a).exists()) {
         JsonObject moduleConfig = (JsonObject)JsonParser.parseString(Files.readString(c<"ç">(this, -3079272234245456722L, a).toPath()));
         if (Cherish.instance == null) {
            return;
         }

         Iterator var7 = Cherish.instance.getModuleManager().k().iterator();
         if (var7.hasNext()) {
            Module module = (Module)var7.next();
            String name = module.i();
            if (moduleConfig.has(name)) {
               JsonObject singleModule = moduleConfig.getAsJsonObject(name);
               if (singleModule.has(a<"j">(20950, 6944001477238021457L ^ a))) {
                  if (ClientUtils.a(new Object[]{ax, module})) {
                     module.y(false);
                  }

                  module.y(singleModule.get(a<"j">(20950, 6944001477238021457L ^ a)).getAsBoolean());
               }

               if (singleModule.has(a<"j">(15684, 6559850755839177159L ^ a))) {
                  module.E(singleModule.get(a<"j">(15684, 6559850755839177159L ^ a)).getAsInt());
               }

               if (singleModule.has(a<"j">(28352, 5047230959196758598L ^ a))) {
                  JsonObject valuesConfig = singleModule.get(a<"j">(28352, 5047230959196758598L ^ a)).getAsJsonObject();
                  Iterator var12 = module.q().iterator();
                  if (var12.hasNext()) {
                     树何何何友树树何友何<?> setting = (树何何何友树树何友何<?>)var12.next();
                     if (valuesConfig.has(setting.v())) {
                        setting.Z(valuesConfig.get(setting.v()));
                     }
                  }
               }
            }
         }
      }

      this.h();
      if (!c<"É">(-3079480819801549376L, a)) {
         c<"É">(++axx, -3079590528336187037L, a);
      }
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 22981;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/config/友何友树树树友树何友", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/友何友树树树友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static int G() {
      return 树何友树何友树友树树;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖国企变私企";
   }
}
