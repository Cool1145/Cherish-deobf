package cn.cool.cherish.config;

import cn.cool.cherish.Cherish;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.树树友树友友何友友树;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import heilongjiang.zhaoyuan.何树友;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.Iterator;

public class 何何友何何何友树何友 extends 友何友树何何友友树树 implements 何树友 {
   private static final long b;
   private static final Object[] c = new Object[18];
   private static final String[] d = new String[18];
   private static int _何大伟：我要教育何炜霖 _;

   public 何何友何何何友树何友(File file) {
      super(file);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(6492533366497104578L, 7425752635226119006L, MethodHandles.lookup().lookupClass()).a(264215469242864L);
      // $VF: monitorexit
      b = var10000;
      c();
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (d[var4] != null) {
         return var4;
      } else {
         Object var5 = c[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 26;
               case 1 -> 22;
               case 2 -> 45;
               case 3 -> 29;
               case 4 -> 17;
               case 5 -> 32;
               case 6 -> 11;
               case 7 -> 25;
               case 8 -> 36;
               case 9 -> 62;
               case 10 -> 56;
               case 11 -> 15;
               case 12 -> 52;
               case 13 -> 41;
               case 14 -> 6;
               case 15 -> 5;
               case 16 -> 39;
               case 17 -> 44;
               case 18 -> 20;
               case 19 -> 30;
               case 20 -> 28;
               case 21 -> 46;
               case 22 -> 40;
               case 23 -> 4;
               case 24 -> 54;
               case 25 -> 18;
               case 26 -> 16;
               case 27 -> 19;
               case 28 -> 34;
               case 29 -> 14;
               case 30 -> 55;
               case 31 -> 48;
               case 32 -> 59;
               case 33 -> 57;
               case 34 -> 47;
               case 35 -> 63;
               case 36 -> 7;
               case 37 -> 9;
               case 38 -> 58;
               case 39 -> 49;
               case 40 -> 33;
               case 41 -> 43;
               case 42 -> 23;
               case 43 -> 60;
               case 44 -> 24;
               case 45 -> 12;
               case 46 -> 61;
               case 47 -> 27;
               case 48 -> 8;
               case 49 -> 35;
               case 50 -> 0;
               case 51 -> 42;
               case 52 -> 53;
               case 53 -> 51;
               case 54 -> 3;
               case 55 -> 1;
               case 56 -> 38;
               case 57 -> 10;
               case 58 -> 13;
               case 59 -> 50;
               case 60 -> 2;
               case 61 -> 21;
               case 62 -> 37;
               default -> 31;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            d[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'M' && var8 != 246 && var8 != 164 && var8 != 206) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'a') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 214) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'M') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 246) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 164) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static void c() {
      c[0] = "O\u0007\\\u0006c0@G\u0011\ri-E\u001a\u001aKa0H\u001c\u001e\u0000\"\u0012C\r\u0007\ti";
      c[1] = boolean.class;
      d[1] = "java/lang/Boolean";
      c[2] = void.class;
      d[2] = "java/lang/Void";
      c[3] = "*\u007f8GJC%?uL@^ b~\nFC'w\u007fC\u000b佹伜叚佃佱佰叧桘佄叝";
      c[4] = "!|L&R&*s]i(\"9rM&\u001e&.";
      c[5] = "Z\u000b0@wkUK}K}vP\u0016v\r{kW\u0003wD6叏佬厮栏佶位叏史桴栏";
      c[6] = "^.2b]q[a\u0002j\u001f}";
      c[7] = "*&R\u001a|O%f\u001f\u0011vR ;\u0014WpO'.\u0015\u001e=叫伜厃桭桨栂叫桘伝厷";
      c[8] = int.class;
      d[8] = "java/lang/Integer";
      c[9] = "f:Rzv\u0016iz\u001fq|\u000bl'\u00147z\u0016k2\u0015~7:j:\u001ap~4d:\u001d~|\u000b";
      c[10] = "9G:Iv\u00155O;\u0002?\u001d)G9IV\t5F";
      c[11] = "\u0007'9_7\u0012\f((\u0010V\u001c\u0007#,J";
      c[12] = "R,J\u0013B\r\u0003j\u001eN\u007f厱桰厕厸栴桦伯桰桏厸-C\u000b\u0011-\u0004\u001cA\t\u000ej";
      c[13] = "Se<;\u0019T\f&>hs栬厮厗叆伉桪栬桴桍叆TLU\u000f9:,C[\u00071";
      c[14] = "\u000fD\u001a\u0012\u0019eUG\u0010ym\n\u000b\u001e\u0018B\u0019w\u000bIN\u0018$3JC\rFKr\u0003V\u0019y";
      c[15] = "13Z9y\trpMu\u0000\u0015\f4S,:@}fK\"g{";
      c[16] = "Hqh\u0019\u001e\f\tkw\u001bw\u0000r/=L\u0018\u0016\u0017d6\u001f\u001biI.9\u001d\b\f\u0002%j\u001ew";
      c[17] = "H]U\"\u0016n\u0012^_IF\u0001L\u0007Wr\u0016|LP\u0001(+";
   }

   @Override
   public boolean h() throws Throwable {
      long a = b ^ 136666769246951L;
      a<"Ö">(-4988433061913219617L, a);
      JsonObject hudConfig = new JsonObject();
      if (Cherish.instance == null) {
         return false;
      } else {
         Iterator bufferedWriter = Cherish.instance.getModuleManager().k().iterator();
         if (bufferedWriter.hasNext()) {
            Module module = (Module)bufferedWriter.next();
            if (module instanceof 树树友树友友何友友树 drag) {
               JsonObject singleHUD = new JsonObject();
               singleHUD.addProperty("X", drag.r());
               singleHUD.addProperty("Y", drag.v());
               hudConfig.add(module.i(), singleHUD);
            }
         }

         try (BufferedWriter bufferedWriterx = new BufferedWriter(new FileWriter(a<"M">(this, -4988449026491862315L, a)))) {
            a<"¤">(-4988580583790920695L, a).toJson(hudConfig, bufferedWriterx);
         }

         return true;
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         c[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = c[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/config/何何友何何何友树何友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   @Override
   public void a() throws Throwable {
      long a = b ^ 116890507912550L;
      a<"Ö">(-3079177310590385570L, a);
      if (a<"M">(this, -3079215256710980268L, a).exists()) {
         JsonObject hudConfig = (JsonObject)JsonParser.parseString(Files.readString(a<"M">(this, -3079215256710980268L, a).toPath()));
         if (Cherish.instance == null) {
            return;
         }

         Iterator var5 = Cherish.instance.getModuleManager().k().iterator();
         if (var5.hasNext()) {
            Module module = (Module)var5.next();
            if (module instanceof 树树友树友友何友友树 drag) {
               String name = module.i();
               if (hudConfig.has(name)) {
                  JsonObject singleHUD = hudConfig.getAsJsonObject(name);
                  if (singleHUD.has("X")) {
                     drag.p(singleHUD.get("X").getAsFloat());
                  }

                  if (singleHUD.has("Y")) {
                     drag.a(singleHUD.get("Y").getAsFloat());
                  }
               }
            }

            a<"Ö">(!a<"Ö">(-3079567327275415862L, a), -3079108156579907878L, a);
         }
      }

      this.h();
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = c[var4];
      if (var5 instanceof String) {
         String var6 = d[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         c[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖诈骗";
   }
}
