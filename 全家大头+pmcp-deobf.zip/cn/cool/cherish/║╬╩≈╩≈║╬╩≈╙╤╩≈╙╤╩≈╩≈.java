package cn.cool.cherish;

import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.module.impl.display.何树何友友何树何何树;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树树何树友树友树树 extends 友树树友树树友友何何 implements 何树友 {
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[9];
   private static final String[] i = new String[9];
   private static String HE_WEI_LIN;

   public 何树树何树友树友树树() {
      long a = b ^ 104123878633905L;
      super(a<"v">(13414, 6610695467916105026L ^ a), a<"v">(20023, 6906663903628390161L ^ a));
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-4721196216247119419L, -1337671721238331296L, MethodHandles.lookup().lookupClass()).a(147604214374935L);
      // $VF: monitorexit
      b = var10000;
      b();
      long var0 = b ^ 87261837408745L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[4];
      int var7 = 0;
      String var6 = "t\u0096»\u0010ü\u0082é\u0098\u008f/\u008a8\u0011ì*\u009a/E<Bþ\f&Ur\u001a\u001e-g¤\u009f^ÆA\u0086\u0002ï\bò/\u0012\u007f\b\u0081\u0011YºçLO{\u0097}.\u0006\u008cb\u0001V °\u009bðÄ\u0010\u0084³\u000evä\u0081\u0000\u0086ìãò\u009a2\u0017\t\f";
      byte var8 = 81;
      char var5 = '@';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     c = var9;
                     d = new String[4];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "éÞÐj¼Àq\u0089;-\u0095ñ§%¤4ÓkU\u0011\u00190sÕ¤ûð\b¹íªiy'Ì_Ö¤{GÓ\u008dv´ßØÈ\t 5\u000f\u001a\u0095\u008bªv(-\u008a©á(¿Æ!@\u009dõ\u0014¡Lú\u0087óúÒ,ºS^r";
                  var8 = 81;
                  var5 = '0';
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 57;
               case 1 -> 62;
               case 2 -> 26;
               case 3 -> 46;
               case 4 -> 39;
               case 5 -> 32;
               case 6 -> 31;
               case 7 -> 43;
               case 8 -> 18;
               case 9 -> 55;
               case 10 -> 63;
               case 11 -> 61;
               case 12 -> 19;
               case 13 -> 2;
               case 14 -> 30;
               case 15 -> 25;
               case 16 -> 60;
               case 17 -> 3;
               case 18 -> 9;
               case 19 -> 12;
               case 20 -> 38;
               case 21 -> 11;
               case 22 -> 41;
               case 23 -> 34;
               case 24 -> 0;
               case 25 -> 6;
               case 26 -> 24;
               case 27 -> 29;
               case 28 -> 52;
               case 29 -> 58;
               case 30 -> 54;
               case 31 -> 49;
               case 32 -> 21;
               case 33 -> 13;
               case 34 -> 5;
               case 35 -> 4;
               case 36 -> 44;
               case 37 -> 53;
               case 38 -> 33;
               case 39 -> 23;
               case 40 -> 40;
               case 41 -> 22;
               case 42 -> 27;
               case 43 -> 47;
               case 44 -> 48;
               case 45 -> 15;
               case 46 -> 36;
               case 47 -> 56;
               case 48 -> 35;
               case 49 -> 50;
               case 50 -> 59;
               case 51 -> 51;
               case 52 -> 20;
               case 53 -> 37;
               case 54 -> 42;
               case 55 -> 17;
               case 56 -> 14;
               case 57 -> 7;
               case 58 -> 8;
               case 59 -> 28;
               case 60 -> 45;
               case 61 -> 1;
               case 62 -> 16;
               default -> 10;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 213 && var8 != 'Z' && var8 != 'r' && var8 != 201) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 205) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 245) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 213) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'Z') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'r') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static void b() {
      h[0] = "[9!7\u001b=Tyl<\u0011 Q$gz伡桃栩伂栞原桥厙栩框";
      h[1] = "9\u0004q\u0012h*2\u000b`]\u00143=\u0011n\u001e#\u0003+\u0006b\u00032/<\u000b";
      h[2] = "{|X\u00120\u000bt<\u0015\u0019:\u0016qa\u001e_2\u000b|g\u001a\u0014q\rub\u001a_;\rkb\u001a\u0010&J位栃伣厺厔伱栉佇伣桠";
      h[3] = "\t0B\u007fFv\u0006p\u000ftLk\u0003-\u00042核佌桻厕桽佉佼叒厡桏";
      h[4] = "U#7e\u001bIa\u00008%VBk\u001d=x]\u0004c\u00000~YO \";o@FkT";
      h[5] = "}d\u001fyN`vk\u000e6/n}`\nl";
      h[6] = "\u001b\u000f$\u0011\"nA\u0004wRN栛核叶栌栴桗栛佼栬栌-t8\u0010\tyA.3CJ";
      h[7] = "\u007fK\u0017Y@@&I\u00138@p&NMWV\be\u0014OC)I#H\u0018GQ\nyJ\f8";
      h[8] = "\t\u0010jhw\u001eL\u0012:3\u001a\u00063Hknf\u0004B\u000flsv{";
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何树树何树友树友树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21949;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/何树树何树友树友树树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何树树何树友树友树树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   @Override
   public void W(String[] params) {
      long a = b ^ 36223751939438L;
      long ax = a ^ 10841031461261L;
      c<"õ">(6937573467445149403L, a);
      何树何友友何树何何树 fontSettings = c<"r">(6936831038729557355L, a);
      if (fontSettings != null) {
         fontSettings.G();
         ClientUtils.e(new Object[]{a<"v">(19243, 3562350655357124307L ^ a), ax});
      }

      ClientUtils.e(new Object[]{a<"v">(14774, 6801961137255058508L ^ a), ax});
   }

   private static String HE_JIAN_GUO() {
      return "何树友被何大伟克制了";
   }
}
