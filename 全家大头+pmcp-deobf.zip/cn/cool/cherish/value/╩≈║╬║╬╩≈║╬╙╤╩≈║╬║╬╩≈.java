package cn.cool.cherish.value;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.function.Supplier;

public abstract class 树何何树何友树何何树<T> implements  {
   private final String 友何友何树友树树何友;
   private final String 树树树树树树友何友何;
   private Supplier<Boolean> 友何何树何何友树友友 = () -> true;
   private final float 何友树树友树友友树何 = 22.0F;
   private final float 友何树友树树何何友友 = 0.0F;
   private final float 友树何树友何何友友何 = 0.0F;
   private T 友树树树树树树何何树;
   private static int 友友何何何何友何友何;
   private static final long a;
   private static final Object[] g = new Object[20];
   private static final String[] h = new String[20];
   private static String LIU_YA_FENG;

   public 树何何树何友树何何树(String name, String cnName, T value) {
      this.友何友何树友树树何友 = name;
      this.树树树树树树友何友何 = "";
      this.友树树树树树树何何树 = value;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(832755488953534092L, 6319822638621084021L, MethodHandles.lookup().lookupClass()).a(237124729870779L);
      // $VF: monitorexit
      a = var10000;
      c();
      if (Y() == 0) {
         i(119);
      }
   }

   public abstract void C(JsonElement var1);

   public float F() {
      return 22.0F;
   }

   public String V() {
      return this.树树树树树树友何友何;
   }

   public T getValue() {
      return this.友树树树树树树何何树;
   }

   public static void i(int var0) {
      友友何何何何友何友何 = var0;
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/树何何树何友树何何树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException b(RuntimeException var0) {
      return var0;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = g[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(h[var4]);
            g[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public static int x() {
      return 友友何何何何友何友何;
   }

   private static void c() {
      g[0] = "wBU^\u007ffx\u0002\u0018Uu{}_\u0013\u0013fhxY\u001e\u0013栁作佁栽伮叶栁作佁栽";
      g[1] = int.class;
      h[1] = "java/lang/Integer";
      g[2] = "Yz\u0000`e`Ru\u0011/\u0019y]o\u001fl.IKx\u0013q?e\\u";
      g[3] = "'\u0017e\u0015&<9\u001f\u007fZn<#\u0015g\u001dg'c%f\u0004x%$\u0013a";
      g[4] = "'\u001e|/~v(^1$tk-\u0003:b|v \u0005>)?T+\u0014' t";
      g[5] = "D\u0004o\u00038hp'`Cucz:e\u001e~%r'h\u0018zn1\u0005c\tcgzs";
      g[6] = "\"\u0000\u000bu\u0000y\u0016#\u00045Mr\u001c>\u0001hF4\u0014#\fnB\u007fW\u0001\u0007\u007f[v\u001cw";
      g[7] = void.class;
      h[7] = "java/lang/Void";
      g[8] = ".\u0002[j\u0007\u001b%\rJ%z\u00036\nCl";
      g[9] = "\u000fb 1f\u001c\u0004m1~\u0007\u0012\u000ff5$";
      g[10] = "\u0003B|7=9\u0001Z+N?HWM!\u007f%p\u0011H{'O";
      g[11] = "S\u000fz{\n\r\u0016A7 {8iLy/\t\u0018S\n'b\u0019j";
      g[12] = "Le\u000b.g^N}\\W取栶核栘栨桎栌佲佼栘1irB\u001djSfpW\u0019";
      g[13] = "^ I\f\u0007_\\8\u001eu\u001f.\t|\u0018\u0016\u0019\u0015A(\u0013\ru\u0014\u000b/\u0010\u0019N\\_$\u000bu";
      g[14] = "R\u001f[Z\t|\u0017Q\u0016\u0001xEh\\X\u000e\niR\u001a\u0006C\u001a\u001bU[VX\u0003|\u0002\u0012[Cx";
      g[15] = "P\"M\u0001\r\u0019R:\u001ax厼伵你桟伪伥厼桱叾厅wB@V]<NG\u0003\u0019\f";
      g[16] = "E2q\u0000<\"G*&y厍伎叫伋桒厺桗桊併厕KD(#\u0017kuC5?\u0016";
      g[17] = ",*S\"HD.2\u0004[k5x%\u000ejP\r> T2:";
      g[18] = "\u001eo8<\u0018O\u001cwoE桳栧桪栒栛桜厩佣厰佖\u0002x\fNL6<\u007f\u0011RM";
      g[19] = "4V\u00043FJ6NSJU;`YY{^\u0003&\\\u0003#4\u0006b\u0002W1SQ+\u000fLJ";
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = g[var4];
      if (var5 instanceof String) {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         g[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = g[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = h[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         g[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (h[var4] != null) {
         return var4;
      } else {
         Object var5 = g[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 29;
               case 1 -> 61;
               case 2 -> 35;
               case 3 -> 34;
               case 4 -> 13;
               case 5 -> 44;
               case 6 -> 30;
               case 7 -> 48;
               case 8 -> 33;
               case 9 -> 25;
               case 10 -> 32;
               case 11 -> 58;
               case 12 -> 39;
               case 13 -> 5;
               case 14 -> 31;
               case 15 -> 57;
               case 16 -> 46;
               case 17 -> 40;
               case 18 -> 60;
               case 19 -> 20;
               case 20 -> 23;
               case 21 -> 55;
               case 22 -> 14;
               case 23 -> 50;
               case 24 -> 7;
               case 25 -> 12;
               case 26 -> 52;
               case 27 -> 42;
               case 28 -> 27;
               case 29 -> 43;
               case 30 -> 19;
               case 31 -> 36;
               case 32 -> 53;
               case 33 -> 18;
               case 34 -> 37;
               case 35 -> 6;
               case 36 -> 10;
               case 37 -> 8;
               case 38 -> 11;
               case 39 -> 59;
               case 40 -> 26;
               case 41 -> 15;
               case 42 -> 21;
               case 43 -> 63;
               case 44 -> 2;
               case 45 -> 38;
               case 46 -> 1;
               case 47 -> 4;
               case 48 -> 17;
               case 49 -> 49;
               case 50 -> 24;
               case 51 -> 28;
               case 52 -> 45;
               case 53 -> 62;
               case 54 -> 0;
               case 55 -> 51;
               case 56 -> 22;
               case 57 -> 9;
               case 58 -> 16;
               case 59 -> 41;
               case 60 -> 56;
               case 61 -> 54;
               case 62 -> 47;
               default -> 3;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            h[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'G' && var8 != 239 && var8 != 225 && var8 != 213) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 162) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'Z') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'G') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 239) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 225) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public float j() {
      return 0.0F;
   }

   public float q() {
      return 0.0F;
   }

   public String r() {
      return this.友何友何树友树树何友;
   }

   public <V extends 树何何树何友树何何树<T>> V A(Supplier<Boolean> condition) {
      this.友何何树何何友树友友 = condition;
      return (V)this;
   }

   public static int Y() {
      x();

      try {
         return 70;
      } catch (RuntimeException var0) {
         throw b(var0);
      }
   }

   public abstract void L(JsonObject var1);

   public Supplier<Boolean> P() {
      return this.友何何树何何友树友友;
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖大狗叫";
   }

   public void G(T value) {
      this.友树树树树树树何何树 = value;
   }

   public boolean O() {
      x();
      boolean var10000 = !this.友何何树何何友树友友.get();
      Module.V(new Module[2]);
      return var10000;
   }
}
