package cn.cool.cherish.value.impl;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.value.树何何树何友树何何树;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树友何何树树何友友何 extends 树何何树何友树何何树<Color> implements  {
   private static Module[] 友友何树树友友树树树;
   private static final long b;
   private static final String c;
   private static final Object[] d = new Object[17];
   private static final String[] e = new String[17];
   private static String HE_SHU_YOU;

   public 树友何何树树何友友何(String name, Color value) {
      super(name, "", value);
   }

   public 树友何何树树何友友何(String name, String cnName, Color value) {
      super(name, cnName, value);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-7312737327003593899L, 4498534010704243782L, MethodHandles.lookup().lookupClass()).a(11448074581530L);
      // $VF: monitorexit
      b = var10000;
      a();
      if (U() == null) {
         v(new Module[3]);
      }

      Cipher var0;
      Cipher var2 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(139456323406810L << var1 * 8 >>> 56);
      }

      var2.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String var3 = a(var0.doFinal("X\u0094µ@£÷à\u0097".getBytes("ISO-8859-1"))).intern();
      byte var10001 = -1;
      c = var3;
   }

   @Override
   public void C(JsonElement element) {
      BooleanValue.F();
      if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
         int argb = element.getAsInt();
         this.G(new Color(argb, true));
      }
   }

   public float[] I() {
      float[] hsbValues = new float[3];
      BooleanValue.F();
      int cMax = Math.max(this.H() >>> 16 & 0xFF, this.H() >>> 8 & 0xFF);
      if ((this.H() & 0xFF) > cMax) {
         cMax = this.H() & 0xFF;
      }

      int cMin = Math.min(this.H() >>> 16 & 0xFF, this.H() >>> 8 & 0xFF);
      if ((this.H() & 0xFF) < cMin) {
         cMin = this.H() & 0xFF;
      }

      float brightness = cMax / 255.0F;
      float saturation = cMax != 0 ? (float)(cMax - cMin) / cMax : 0.0F;
      if (saturation == 0.0F) {
         Module.V(new Module[1]);
      }

      float redC = (float)(cMax - (this.H() >>> 16 & 0xFF)) / (cMax - cMin);
      float greenC = (float)(cMax - (this.H() >>> 8 & 0xFF)) / (cMax - cMin);
      float blueC = (float)(cMax - (this.H() & 0xFF)) / (cMax - cMin);
      float hue = ((this.H() >>> 16 & 0xFF) == cMax ? blueC - greenC : ((this.H() >>> 8 & 0xFF) == cMax ? 2.0F + redC - blueC : 4.0F + greenC - redC)) / 6.0F;
      if (hue < 0.0F) {
         hue++;
      }

      hsbValues[0] = hue;
      hsbValues[1] = saturation;
      hsbValues[2] = brightness;
      return hsbValues;
   }

   public Color Z() {
      return this.getValue() == null ? null : new Color(this.getValue().getRGB(), true);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (e[var4] != null) {
         return var4;
      } else {
         Object var5 = d[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 23;
               case 1 -> 39;
               case 2 -> 9;
               case 3 -> 14;
               case 4 -> 27;
               case 5 -> 55;
               case 6 -> 32;
               case 7 -> 15;
               case 8 -> 3;
               case 9 -> 56;
               case 10 -> 36;
               case 11 -> 62;
               case 12 -> 59;
               case 13 -> 42;
               case 14 -> 49;
               case 15 -> 5;
               case 16 -> 47;
               case 17 -> 57;
               case 18 -> 7;
               case 19 -> 1;
               case 20 -> 26;
               case 21 -> 24;
               case 22 -> 16;
               case 23 -> 20;
               case 24 -> 51;
               case 25 -> 18;
               case 26 -> 53;
               case 27 -> 52;
               case 28 -> 34;
               case 29 -> 19;
               case 30 -> 30;
               case 31 -> 4;
               case 32 -> 60;
               case 33 -> 29;
               case 34 -> 63;
               case 35 -> 40;
               case 36 -> 44;
               case 37 -> 0;
               case 38 -> 37;
               case 39 -> 41;
               case 40 -> 10;
               case 41 -> 38;
               case 42 -> 58;
               case 43 -> 6;
               case 44 -> 45;
               case 45 -> 11;
               case 46 -> 13;
               case 47 -> 54;
               case 48 -> 12;
               case 49 -> 22;
               case 50 -> 33;
               case 51 -> 28;
               case 52 -> 50;
               case 53 -> 48;
               case 54 -> 35;
               case 55 -> 8;
               case 56 -> 25;
               case 57 -> 46;
               case 58 -> 2;
               case 59 -> 43;
               case 60 -> 17;
               case 61 -> 31;
               case 62 -> 61;
               default -> 21;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            e[var4] = new String(var12);
            return var4;
         }
      }
   }

   public int i() {
      return this.getValue().getRed();
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'C' && var8 != 'P' && var8 != 'J' && var8 != 'n') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 193) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == '$') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'C') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'P') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'J') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = d[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         d[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = d[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(e[var4]);
            d[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   public int l() {
      return this.getValue().getGreen();
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static void a() {
      d[0] = "1V\u0003-\\B>\u0016N&V_;KE`EL>MH`Z@\"T\u0003桟司佸伇栩格伛司另伇";
      d[1] = "JE\u001bs]\u001aAJ\n<!\u0003NP\u0004\u007f\u00163XG\bb\u0007\u001fOJ";
      d[2] = "\u0010\u0000\"\u0007}x\u001f@o\fwe\u001a\u001ddJdv\u001f\u001biJ{z\u0003\u0002\"&}x\u001f\u000bm\nDv\u001f\u001bi";
      d[3] = "/%";
      d[4] = "v9L\tr\u0006yy\u0001\u0002x\u001b|$\nDp\u0006q\"\u000e\u000f3$z3\u0017\u0006x";
      d[5] = "!\u0007xGlY\u0015$w\u0007!R\u001f9rZ*\u0014\u0017$\u007f\\._T\u0006tM7V\u001fp";
      d[6] = "~4\\\u00028\u0001J\u0017SBu\n@\nV\u001f~LH\u0017[\u0019z\u0007\u000b5P\bc\u000e@C";
      d[7] = void.class;
      e[7] = "java/lang/Void";
      d[8] = "w\u0001rb!\u001dC\"}\"l\u0016I?x\u007fgPA\"uyc\u001b\u0002\u0000~hz\u0012Iv";
      d[9] = ">v\u0018\u0010\u0015\b\nU\u0017PX\u0003\u0000H\u0012\rSE\bU\u001f\u000bW\u000eKw\u0014\u001aN\u0007\u0000\u0001";
      d[10] = "\u001e\"m$\u0014p\u0015-|ku~\u001e&x1";
      d[11] = "\u0019\u000bQ\u0018\u0016\"[]\u001d\u0006}\u0010\"\u0004C\tD\u007f\u0018C\u001c\u001c\u001bB";
      d[12] = "\u0006\tL9\rc\u0002\fN\u0007aR\u0003RD>\u0001hD\rQa<";
      d[13] = "\nqS&\b\u0000K;\u0010f6439\u0016|X\u001b\t3CcKz";
      d[14] = "t\u0010G~}p6F\u000b`\u0016NO\u001fUo/-uX\nzp\u0010rJ\u000e{j!3\u001dSx\u0016";
      d[15] = "+-\u0011\u0017?d/(\u0013)gU),\u0010Uv;-q\u001cL\u000el(t\fQ`hux\u0015)";
      d[16] = ",/\u001d{\u001b0(*\u001fET\u0001)t\u0015|\u0017;n+\u0000#*<|/\u00019\u001b}+r\u0002E";
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/树友何何树树何友友何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   public String m() {
      return String.format("#%08X", this.getValue().getRGB());
   }

   public void k(int r, int g, int b) {
      this.N(r, g, b, 255);
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = d[var4];
      if (var5 instanceof String) {
         String var6 = e[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         d[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static void v(Module[] var0) {
      友友何树树友友树树树 = var0;
   }

   public static Module[] U() {
      return 友友何树树友友树树树;
   }

   @Override
   public void L(JsonObject object) {
      object.addProperty(this.r(), this.getValue().getRGB());
   }

   public int L() {
      return this.getValue().getBlue();
   }

   public void N(int r, int g, int b, int a) {
      this.G(new Color(Math.max(0, Math.min(255, r)), Math.max(0, Math.min(255, g)), Math.max(0, Math.min(255, b)), Math.max(0, Math.min(255, 255))));
   }

   public int H() {
      return this.getValue().getRGB();
   }

   public int K() {
      return this.getValue().getAlpha();
   }

   private static String LIU_YA_FENG() {
      return "何树友，和树做朋友";
   }

   public int O() {
      return this.getValue().getRGB();
   }
}
