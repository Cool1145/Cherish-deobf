package cn.cool.cherish.value.impl;

import cn.cool.cherish.module.何树何何树何友何何何;
import cn.cool.cherish.value.树何何树何友树何何树;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class ModeValue extends 树何何树何友树何何树<String> implements  {
   private static final Pattern 树友何友友树友树何友;
   private final String[] 何何树树树友何树友树;
   private static int[] 何友友何何树树何树友;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[14];
   private static final String[] i = new String[14];
   private static int _何建国230622195906030014 _;

   public ModeValue(String name, String[] values, String value) {
      super("Mode", "", value);
      this.何何树树树友何树友树 = values;
   }

   public ModeValue(String name, String cnName, String[] values, String value) {
      super(name, cnName, value);
      this.何何树树树友何树友树 = values;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(5682163367529009324L, -5674231629429238908L, MethodHandles.lookup().lookupClass()).a(212364988456329L);
      // $VF: monitorexit
      b = var10000;
      a();
      int[] var9 = new int[5];
      k(var9);
      Cipher var0;
      Cipher var10 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{0, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(72838148824690L << var1 * 8 >>> 56);
      }

      var10.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[3];
      int var5 = 0;
      char var3 = '(';
      int var2 = -1;

      while (true) {
         String var12 = a(
               var0.doFinal(
                  "¥:\u0081eÀBJa÷õ\u000fù²\u008dµe:`Í¦¢¶g\u0080©¿\tBV~ÇD«Ø¶Èg´85\u0010\bû|çB¸4ðâ/ü\u0099+îT¬\u0010L\u007fk,ì_\u0006GÖä\rX t\u0088\u0098"
                     .substring(++var2, var2 + var3)
                     .getBytes("ISO-8859-1")
               )
            )
            .intern();
         byte var10001 = -1;
         var7[var5++] = var12;
         if ((var2 += var3) >= 74) {
            c = var7;
            d = new String[3];
            树友何友友树友树何友 = Pattern.compile("\\\\u([0-9a-fA-F]{4})");
            return;
         }

         var3 = "¥:\u0081eÀBJa÷õ\u000fù²\u008dµe:`Í¦¢¶g\u0080©¿\tBV~ÇD«Ø¶Èg´85\u0010\bû|çB¸4ðâ/ü\u0099+îT¬\u0010L\u007fk,ì_\u0006GÖä\rX t\u0088\u0098"
            .charAt(var2);
      }
   }

   public static String B(String input) {
      BooleanValue.F();
      return null;
   }

   @Override
   public void C(JsonElement element) {
      BooleanValue.F();
      if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
         String jsonValue = element.getAsString();
         String decodedValue = B(jsonValue);
         this.G(decodedValue);
      }
   }

   public void V() {
      int index = this.T();
      index = (index - 1 + this.何何树树树友何树友树.length) % this.何何树树树友何树友树.length;
      this.G(this.何何树树树友何树友树[index]);
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 11;
               case 1 -> 5;
               case 2 -> 15;
               case 3 -> 52;
               case 4 -> 28;
               case 5 -> 59;
               case 6 -> 17;
               case 7 -> 50;
               case 8 -> 45;
               case 9 -> 22;
               case 10 -> 0;
               case 11 -> 47;
               case 12 -> 53;
               case 13 -> 25;
               case 14 -> 27;
               case 15 -> 33;
               case 16 -> 12;
               case 17 -> 7;
               case 18 -> 56;
               case 19 -> 10;
               case 20 -> 3;
               case 21 -> 31;
               case 22 -> 42;
               case 23 -> 41;
               case 24 -> 60;
               case 25 -> 44;
               case 26 -> 51;
               case 27 -> 18;
               case 28 -> 48;
               case 29 -> 23;
               case 30 -> 62;
               case 31 -> 21;
               case 32 -> 38;
               case 33 -> 40;
               case 34 -> 9;
               case 35 -> 37;
               case 36 -> 57;
               case 37 -> 8;
               case 38 -> 14;
               case 39 -> 63;
               case 40 -> 30;
               case 41 -> 55;
               case 42 -> 13;
               case 43 -> 36;
               case 44 -> 39;
               case 45 -> 54;
               case 46 -> 2;
               case 47 -> 32;
               case 48 -> 49;
               case 49 -> 16;
               case 50 -> 43;
               case 51 -> 20;
               case 52 -> 6;
               case 53 -> 61;
               case 54 -> 1;
               case 55 -> 29;
               case 56 -> 46;
               case 57 -> 4;
               case 58 -> 24;
               case 59 -> 19;
               case 60 -> 34;
               case 61 -> 35;
               case 62 -> 26;
               default -> 58;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   public static int[] b() {
      return 何友友何何树树何树友;
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 218 && var8 != 245 && var8 != 235 && var8 != 163) {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 223) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'f') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 218) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 245) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 235) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/ModeValue" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   public String[] n() {
      return this.何何树树树友何树友树;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/value/impl/ModeValue" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static void a() {
      f[0] = "(>\u0010$b/'~]/h2\"#Vi{!'%[id-;<\u0010\nb$.\u0006_+x%";
      f[1] = "9T";
      f[2] = void.class;
      i[2] = "java/lang/Void";
      f[3] = "V\u001ek3qu#>`<`:^&s;is6";
      f[4] = "\u0018\u001bysZT\u0017[4xPI\u0012\u0006?>CZ\u0017\u00002>\\V\u000b\u0019yRZT\u0017\u00106~cZ\u0017\u00002";
      f[5] = "Jj";
      f[6] = "\u0004\u0003a ,*\u000f\fpoP3\u0000\u0016~,g\u0003\u0016\u0001r1v/\u0001\f";
      f[7] = "r\u0013\u00158KBl\u001b\u000fw\u0017R\u007f\u0017\u001bw5Vl\u0006\u0006+\u000b";
      f[8] = "\u007fc~\u0004a!tloK\u0000/\u007fgk\u0011";
      f[9] = "|Mx[I3mQrg使伋栊栵栌厤使桏叐栵\u0015]Zk(S$\nZ<r";
      f[10] = "c\u0006\u0016Z,0r\u001a\u001cf$U0[\u0018\u0005}mrV\u000bZGli\u001aJ\u0002~+i]\u000bf";
      f[11] = "C0iK[>\u0019k#\u00169Mx2mHZ9@p`[\u0005\u0003";
      f[12] = "\u000frc\u0006b \u001eni:栐历伽叐反栣及桜伽叐\u000e\u0006{9\u0000\u007f>\u0007b4[";
      f[13] = "\u0000\u007f\u0013hH\u0003\u0011c\u0019TJfSbA(AV\u0000.@9#Z\u0013!\u00026\u0013\t_ \u0013T";
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19095;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/value/impl/ModeValue", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public static void k(int[] var0) {
      何友友何何树树何树友 = var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void z() {
      int index = this.T();
      index = (index + 1) % this.何何树树树友何树友树.length;
      this.G(this.何何树树树友何树友树[index]);
   }

   @Override
   public void L(JsonObject object) {
      BooleanValue.F();
      String value = this.getValue();
      object.addProperty(this.r(), W(value));
      object.addProperty(this.r(), (String)null);
   }

   public static String W(String input) {
      BooleanValue.F();
      return null;
   }

   private int T() {
      BooleanValue.F();
      int i = 0;
      if (0 < this.何何树树树友何树友树.length) {
         if (this.何何树树树友何树友树[0].equalsIgnoreCase(this.getValue())) {
            return 0;
         }

         i++;
      }

      return 0;
   }

   public boolean K(String mode) {
      return Objects.equals(this.getValue(), mode);
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖黑水";
   }

   public String O() {
      return this.getValue();
   }
}
