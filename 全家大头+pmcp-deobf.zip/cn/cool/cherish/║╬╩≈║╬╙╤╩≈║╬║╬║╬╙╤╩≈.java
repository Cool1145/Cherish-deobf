package cn.cool.cherish;

import cn.cool.cherish.module.何友友树友何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 何树何友树何何何友树 implements 何树友 {
   private final Set<String> 友何何树友何树何何树;
   private final File 友友何树树树友何何何;
   private static int[] 何友树友友树友友友树;
   private static final long a;
   private static final String[] b;
   private static final String[] c;
   private static final Map d = new HashMap(13);
   private static final Object[] e = new Object[17];
   private static final String[] f = new String[17];
   private static String LIU_YA_FENG;

   public 何树何友树何何何友树() {
      long a = 何树何友树何何何友树.a ^ 90908589399354L;
      b<"w">(-8772827671278744974L, a);
      super();
      this.友何何树友何树何何树 = new HashSet<>();
      this.友友何树树树友何何何 = new File(Cherish.getConfigManager().getMainFile().getAbsolutePath() + File.separator + a<"y">(12785, 9126619508042266593L ^ a));
      File parentDir = b<"m">(this, -8772466896429157197L, a).getParentFile();
      if (!parentDir.exists()) {
         if (!parentDir.mkdirs()) {
            null.println(a<"y">(20421, 8211848731585186259L ^ a) + parentDir.getAbsolutePath());
            b<"w">(!b<"w">(-8770999305247034058L, a), -8772929173048622299L, a);
         }

         null.println(a<"y">(2395, 6767190489376935752L ^ a) + parentDir.getAbsolutePath());
      }

      if (!b<"m">(this, -8772466896429157197L, a).exists()) {
         try {
            if (b<"m">(this, -8772466896429157197L, a).createNewFile()) {
               null.println(a<"y">(26700, 4601360580769721950L ^ a) + b<"m">(this, -8772466896429157197L, a).getAbsolutePath());
            }

            null.println(a<"y">(21681, 1980178564813001382L ^ a) + b<"m">(this, -8772466896429157197L, a).getAbsolutePath());
         } catch (IOException var6) {
            null.println(a<"y">(22366, 3113038098025877839L ^ a) + var6.getMessage());
            var6.printStackTrace();
         }
      }

      this.A();
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-5998255230191271212L, 6520358641551159567L, MethodHandles.lookup().lookupClass()).a(118495759824386L);
      // $VF: monitorexit
      a = var10000;
      long var9 = a ^ 127117854502813L;
      a();
      int[] var13 = new int[2];
      b<"w">(var13, -799653939854715594L, var9);
      Cipher var0;
      Cipher var14 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var14.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[6];
      int var5 = 0;
      String var4 = "\u0096Å]ð5ÊÂ2>Zõ2Ç5\u0091ÑG9\u0085\b\u000b$\u0088tn\u0003î>\u0007\u008e¿~àP\u009b»\u0096\u0098 \u00048ã§\u0014ìÿö{3\u009a\u00adðý\u0099\u0001\u001f1¯ô\u0088\tA\u0011á\u0087\u001c\u0095k\u0094\u001bÃ\u000f$7FÌj\u009d0ð\r¯\u0098O»Ûê3þ/C«àE3\tÐ \bà©â£X=å¼%«\u008e\u009dFE9rÄ|Ñ:Á\u0092 *ßð\u008f\u0006\u0084ßë8\u0019p Ã»^Ãsæuìë\u009a\u0003\u009cµ\u0086Ñ#Ídã\u0093-.±¼÷zläÚÖ\u0007Ëó1Z¦®y>\u0019CºL<ú\u0097P#\b4÷m\u0094";
      short var6 = 187;
      char var3 = '(';
      int var12 = -1;

      label27:
      while (true) {
         String var15 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var21 = a(var0.doFinal(var15.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var21;
                  if ((var12 += var3) >= var6) {
                     b = var7;
                     c = new String[6];
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var21;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "Þ\u000f*Ýä´ÑW\u009foÈwºûFa Á©\rj¼º[5 \u0006BÅi÷íQ\u0018\u000eCh^\"\u009bÒ\u0014çE\u001dèÿJóµi,&©\f¸\u0000@/z\u0095[²\u00100 \u0083;j´©¸`\u0085z¼½\u0004ü|º\u00ad¤ô3\u001d\u0090\u0083-±nÉP]»ýVº¾%0IÜcï\u0082\u0004A\u0013AeE\u0094";
                  var6 = 113;
                  var3 = '@';
                  var12 = -1;
            }

            var15 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   public Set<String> B() {
      long a = 何树何友树何何何友树.a ^ 117971096247346L;
      return new HashSet<>(b<"m">(this, 525151295153548306L, a));
   }

   public static int[] I() {
      return 何友树友友树友友友树;
   }

   public boolean J(String name) {
      long a = 何树何友树何何何友树.a ^ 75122716492511L;
      return b<"m">(this, -2763915721625079041L, a).contains(name.toLowerCase());
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = e[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(f[var4]);
            e[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何树何友树何何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (var5 instanceof String) {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         e[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public void l(String name) {
      long a = 何树何友树何何何友树.a ^ 121958007443525L;
      b<"m">(this, 810282838527680613L, a).remove(name.toLowerCase());
      b<"w">(810537927542900493L, a);
      this.v();
      if (!b<"w">(808425680409131081L, a)) {
         b<"w">(new int[4], 810387954706819822L, a);
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = e[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = f[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         e[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (f[var4] != null) {
         return var4;
      } else {
         Object var5 = e[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 60;
               case 1 -> 4;
               case 2 -> 54;
               case 3 -> 51;
               case 4 -> 33;
               case 5 -> 12;
               case 6 -> 57;
               case 7 -> 61;
               case 8 -> 42;
               case 9 -> 13;
               case 10 -> 44;
               case 11 -> 48;
               case 12 -> 47;
               case 13 -> 35;
               case 14 -> 11;
               case 15 -> 62;
               case 16 -> 31;
               case 17 -> 36;
               case 18 -> 5;
               case 19 -> 23;
               case 20 -> 50;
               case 21 -> 27;
               case 22 -> 17;
               case 23 -> 8;
               case 24 -> 1;
               case 25 -> 26;
               case 26 -> 10;
               case 27 -> 45;
               case 28 -> 59;
               case 29 -> 49;
               case 30 -> 22;
               case 31 -> 32;
               case 32 -> 3;
               case 33 -> 18;
               case 34 -> 38;
               case 35 -> 43;
               case 36 -> 0;
               case 37 -> 7;
               case 38 -> 37;
               case 39 -> 15;
               case 40 -> 63;
               case 41 -> 34;
               case 42 -> 2;
               case 43 -> 58;
               case 44 -> 29;
               case 45 -> 16;
               case 46 -> 52;
               case 47 -> 14;
               case 48 -> 46;
               case 49 -> 55;
               case 50 -> 20;
               case 51 -> 39;
               case 52 -> 19;
               case 53 -> 53;
               case 54 -> 6;
               case 55 -> 28;
               case 56 -> 24;
               case 57 -> 21;
               case 58 -> 25;
               case 59 -> 9;
               case 60 -> 56;
               case 61 -> 41;
               case 62 -> 40;
               default -> 30;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            f[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      e[0] = "?C\u0015\u0016|g0\u0003X\u001dvz5^S[但栙伉另株传但佝厗格";
      e[1] = "/\nOv\u001f01\u0002U9b 1";
      e[2] = "\rw";
      e[3] = void.class;
      f[3] = "java/lang/Void";
      e[4] = "X{@B\t\u001eStQ\rs\u001a@uABE\u001eW";
      e[5] = "ul";
      e[6] = "x\u0001bt7;wA/\u007f=&r\u001c$95;\u007f\u001a rv\u0019t\u000b9{=";
      e[7] = boolean.class;
      f[7] = "java/lang/Boolean";
      e[8] = "! 0l, $o\u0000dn,";
      e[9] = "nx/XW;ew>\u001765n|:M";
      e[10] = "X[%f(0XB6^厍伜伹格厏伃桗伜伹格L$5\u007f\u001cY g6%";
      e[11] = "\u000f\u000e'\u000e^B\u000f\u001746叻台佮桩桗栯叻佮佮伭N\u000bCBT\u00121\tWCN";
      e[12] = "SCE\\Y?SZVd]NT]J\u0019['\u0002DO\u001d?tSZF\u0003N)\u0012Z\u0012d";
      e[13] = "\u001f9\u0006\u0015vF[d\u0003\bGj#b\u0015\u001b\"C\u001d'\u0018A<#\u0019c\u001c\u001b RD\"\u001cOG";
      e[14] = "Ya7Ug[Yx$m@*^\u007f8\u0010eC\bf=\u0014\u0001";
      e[15] = "A82\u0007LmA!!?C\u001cF)9\u0002\u0014y\u001e =\u0003*'\u0012$f\u0001O\u007f\u001b g?";
      e[16] = "(Er2\u0010Ul\u0018w/!]\u0014\u001ea<DP*[lfZ0";
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'm' && var8 != 241 && var8 != 202 && var8 != 224) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 226) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'w') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'm') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 241) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 202) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16465;
      if (c[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])d.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            d.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/何树何友树何何何友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = b[var5].getBytes("ISO-8859-1");
         c[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return c[var5];
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何树何友树何何何友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public void p(String name) {
      long a = 何树何友树何何何友树.a ^ 73547605756996L;
      b<"m">(this, 6286919515877276772L, a).add(name.toLowerCase());
      this.v();
   }

   public void k() {
      long a = 何树何友树何何何友树.a ^ 38591424783026L;
      b<"m">(this, 8775824625357935250L, a).clear();
      this.v();
   }

   private void v() {
      long a = 何树何友树何何何友树.a ^ 87832991520904L;
      b<"w">(4896181331464638400L, a);

      try {
         File parentDir = b<"m">(this, 4896523964900749569L, a).getParentFile();
         if (!parentDir.exists()) {
            parentDir.mkdirs();
         }

         try (PrintWriter writer = new PrintWriter(new FileWriter(b<"m">(this, 4896523964900749569L, a)))) {
            b<"m">(this, 4896418828495218856L, a).forEach(writer::println);
         }
      } catch (IOException var10) {
         var10.printStackTrace();
      }
   }

   public static void j(int[] var0) {
      何友树友友树友友友树 = var0;
   }

   private void A() {
      long a = 何树何友树何何何友树.a ^ 70606637932488L;
      b<"w">(-8884839899031041920L, a);
      if (b<"m">(this, -8884479123057510847L, a).exists()) {
         try {
            Files.readAllLines(b<"m">(this, -8884479123057510847L, a).toPath()).forEach(line -> {
               long ax = 何树何友树何何何友树.a ^ 30544697334746L;
               b<"w">(-9178073397655073646L, ax);
               if (!line.trim().isEmpty()) {
                  b<"m">(this, -9177835904987157510L, ax).add(line.trim().toLowerCase());
               }
            });
         } catch (IOException var5) {
            var5.printStackTrace();
         }
      }
   }

   private static String HE_WEI_LIN() {
      return "何树友为什么濒天了";
   }
}
