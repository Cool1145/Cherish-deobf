package cn.cool.cherish;

import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class 何何何何何何何友树友 implements 何树友 {
   private final String[] 树树友树友友友树友树;
   private static String[] 树友树树友树何树何树;
   private static final long a;
   private static final Object[] f = new Object[9];
   private static final String[] g = new String[9];
   private static String HE_SHU_YOU;

   public 何何何何何何何友树友(String... name) {
      this.树树友树友友友树友树 = name;
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-1937162019394860579L, -5747072778452073883L, MethodHandles.lookup().lookupClass()).a(130304406597105L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (l() == null) {
         s(new String[5]);
      }
   }

   public String[] V() {
      return this.树树友树友友友树友树;
   }

   public abstract void i(String[] var1);

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = f[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/何何何何何何何友树友" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   public static void s(String[] var0) {
      树友树树友树何树何树 = var0;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (var5 instanceof String) {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         f[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static String[] l() {
      return 树友树树友树何树何树;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = g[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         f[var4] = var21;
         return var21;
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 's' && var8 != 223 && var8 != 'B' && var8 != 226) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'E') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 254) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 's') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 223) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'B') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (g[var4] != null) {
         return var4;
      } else {
         Object var5 = f[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 36;
               case 1 -> 1;
               case 2 -> 0;
               case 3 -> 38;
               case 4 -> 51;
               case 5 -> 25;
               case 6 -> 35;
               case 7 -> 50;
               case 8 -> 13;
               case 9 -> 21;
               case 10 -> 63;
               case 11 -> 15;
               case 12 -> 56;
               case 13 -> 30;
               case 14 -> 2;
               case 15 -> 46;
               case 16 -> 47;
               case 17 -> 55;
               case 18 -> 5;
               case 19 -> 37;
               case 20 -> 29;
               case 21 -> 48;
               case 22 -> 16;
               case 23 -> 49;
               case 24 -> 17;
               case 25 -> 44;
               case 26 -> 58;
               case 27 -> 53;
               case 28 -> 9;
               case 29 -> 57;
               case 30 -> 19;
               case 31 -> 7;
               case 32 -> 18;
               case 33 -> 39;
               case 34 -> 40;
               case 35 -> 62;
               case 36 -> 20;
               case 37 -> 54;
               case 38 -> 6;
               case 39 -> 8;
               case 40 -> 42;
               case 41 -> 52;
               case 42 -> 22;
               case 43 -> 14;
               case 44 -> 10;
               case 45 -> 60;
               case 46 -> 43;
               case 47 -> 32;
               case 48 -> 59;
               case 49 -> 27;
               case 50 -> 12;
               case 51 -> 11;
               case 52 -> 33;
               case 53 -> 4;
               case 54 -> 28;
               case 55 -> 23;
               case 56 -> 24;
               case 57 -> 26;
               case 58 -> 41;
               case 59 -> 34;
               case 60 -> 45;
               case 61 -> 61;
               case 62 -> 31;
               default -> 3;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            g[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      f[0] = "\u000eVyT\u0019G\u0001\u00164_\u0013Z\u0004K?\u0019伣佽伸佭伂佢伣口桼右";
      f[1] = "e\te\u000e\u0018x\u0010)n\u0001\t7m1}\u0006\u0000~\u0005";
      f[2] = "Z=.Lsw/\u001d%Cb8R\u00056Dkq:";
      f[3] = void.class;
      g[3] = "java/lang/Void";
      f[4] = "1\u0015q\u001dx{D5z\u0012i49-i\u0015`}Q";
      f[5] = "\u000bi_(^(\u0000fNg?&\u000bmJ=";
      f[6] = ";7y\u00140Lnu\u0002\u001f\u000e\u0015v(=\u000bbJj}pd4Dd!b\tp\u0015y5\u0002";
      f[7] = "cLz\u001fDg6\u000e\u0001\u000bz>.S>\u0000\u0016a2\u0006so";
      f[8] = "\u000e\u001fPl\rh[]+栅株又栨厦叨叟株又栨e\u0011nV4^\tNr\u0003y";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static String HE_SHU_YOU() {
      return "何炜霖国企上班";
   }
}
