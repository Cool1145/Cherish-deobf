package cn.cool.cherish.event.events.callables;

import cn.cool.cherish.event.events.Cancellable;
import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class EventCancellable implements Event, Cancellable, 何树友 {
   private boolean cancelled;
   private static Module[] 何树树何友何树树树树;
   private static final long a;
   private static final Object[] b = new Object[9];
   private static final String[] c = new String[9];
   private static int _何树友为什么濒天了 _;

   protected EventCancellable() {
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-6850796598043354960L, -6569114639844471325L, MethodHandles.lookup().lookupClass()).a(132578876019233L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (R() == null) {
         d(new Module[5]);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   public static void d(Module[] var0) {
      何树树何友何树树树树 = var0;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/event/events/callables/EventCancellable" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != '$' && var8 != 233 && var8 != 245 && var8 != 201) {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 254) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 205) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == '$') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 233) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 245) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 0;
               case 1 -> 17;
               case 2 -> 29;
               case 3 -> 40;
               case 4 -> 34;
               case 5 -> 8;
               case 6 -> 14;
               case 7 -> 38;
               case 8 -> 16;
               case 9 -> 37;
               case 10 -> 47;
               case 11 -> 56;
               case 12 -> 11;
               case 13 -> 24;
               case 14 -> 59;
               case 15 -> 25;
               case 16 -> 45;
               case 17 -> 33;
               case 18 -> 28;
               case 19 -> 55;
               case 20 -> 32;
               case 21 -> 46;
               case 22 -> 9;
               case 23 -> 60;
               case 24 -> 31;
               case 25 -> 3;
               case 26 -> 49;
               case 27 -> 21;
               case 28 -> 1;
               case 29 -> 51;
               case 30 -> 43;
               case 31 -> 10;
               case 32 -> 19;
               case 33 -> 30;
               case 34 -> 26;
               case 35 -> 41;
               case 36 -> 2;
               case 37 -> 48;
               case 38 -> 23;
               case 39 -> 57;
               case 40 -> 53;
               case 41 -> 4;
               case 42 -> 35;
               case 43 -> 61;
               case 44 -> 39;
               case 45 -> 20;
               case 46 -> 22;
               case 47 -> 63;
               case 48 -> 6;
               case 49 -> 54;
               case 50 -> 42;
               case 51 -> 44;
               case 52 -> 62;
               case 53 -> 58;
               case 54 -> 7;
               case 55 -> 5;
               case 56 -> 52;
               case 57 -> 27;
               case 58 -> 13;
               case 59 -> 15;
               case 60 -> 18;
               case 61 -> 50;
               case 62 -> 12;
               default -> 36;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "\u000f/V&cN\u0000o\u001b-iS\u00052\u0010kiW\t/\fkiW\t/\f6\"B\r-\u0014$nM\t2V\u0000zD\u00025;$bB\t-\u0014$nM\t";
      b[1] = boolean.class;
      c[1] = "java/lang/Boolean";
      b[2] = "Z=Od*on\u001e@$gdd\u0003Eyl\"l\u001eH\u007fhi/<Cnq`dJ";
      b[3] = "B\u001f\u000b\bj\u0019v<\u0004H'\u0012|!\u0001\u0015,Tt<\f\u0013(\u001f7\u001e\u0007\u00021\u0016|h";
      b[4] = void.class;
      c[4] = "java/lang/Void";
      b[5] = "yL[8:4rCJw[:yHN-";
      b[6] = "]<\u001cZ*\"SaC(\u000fB\u00078\u001f\u0017hs\u00071\u0019LU";
      b[7] = "TvG+\b\u0006Z+\u0018Y\u001bf\u000erDfJW\u000e{B=w]Y#\u001fiJZYsOY";
      b[8] = "\u000fW\u0006\u0015\u0013^\u0001\nYg\u0007W\tX\t\u0003\bS\u00033]\f\u000eY\u0000IX\u0016\u000bR";
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   @Override
   public boolean isCancelled() {
      return this.cancelled;
   }

   public static Module[] R() {
      return 何树树何友何树树树树;
   }

   @Override
   public void setCancelled(boolean state) {
      this.cancelled = state;
   }

   private static String LIU_YA_FENG() {
      return "何炜霖国企上班";
   }
}
