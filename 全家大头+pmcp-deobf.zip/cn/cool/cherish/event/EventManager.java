package cn.cool.cherish.event;

import cn.cool.cherish.event.events.Event;
import cn.cool.cherish.event.events.EventStoppable;
import cn.cool.cherish.event.types.Priority;
import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何树何何树何友何何何;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public final class EventManager implements 何树友 {
   private final Map<Class<? extends Event>, List<EventManager.MethodData>> REGISTRY_MAP = new ConcurrentHashMap<>();
   private static int 树何何树树何友友友友;
   private static final long a;
   private static final Object[] b = new Object[19];
   private static final String[] c = new String[19];
   private static String HE_JIAN_GUO;

   private void invoke(EventManager.MethodData data, Event argument) {
      try {
         data.getTarget().invoke(data.getSource(), argument);
      } catch (IllegalArgumentException | InvocationTargetException | IllegalAccessException var3) {
      }
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何树何何树何友何何何.a(-549293656013480885L, -397913727485633804L, MethodHandles.lookup().lookupClass()).a(253777246488809L);
      // $VF: monitorexit
      a = var10000;
      a();
      if (Y() == 0) {
         N(58);
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return a(var0, var1, var2, var3, var4);
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, 0L);
      Object var6 = b[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(c[var4]);
            b[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field b(Class var0, String var1, Class var2) {
      return a(var0, var1, var2);
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (var5 instanceof String) {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = a(var8, var10, var11);
         b[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = b[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = c[var4];
         int var7 = var6.indexOf(8);
         Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = a(var8, var10, var15, var13, var14);
         b[var4] = var21;
         return var21;
      }
   }

   private static Field a(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/event/EventManager" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static IllegalArgumentException a(IllegalArgumentException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (c[var4] != null) {
         return var4;
      } else {
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 1;
               case 1 -> 61;
               case 2 -> 29;
               case 3 -> 33;
               case 4 -> 18;
               case 5 -> 38;
               case 6 -> 21;
               case 7 -> 11;
               case 8 -> 4;
               case 9 -> 62;
               case 10 -> 41;
               case 11 -> 37;
               case 12 -> 7;
               case 13 -> 45;
               case 14 -> 22;
               case 15 -> 2;
               case 16 -> 17;
               case 17 -> 46;
               case 18 -> 40;
               case 19 -> 34;
               case 20 -> 35;
               case 21 -> 47;
               case 22 -> 10;
               case 23 -> 15;
               case 24 -> 5;
               case 25 -> 3;
               case 26 -> 23;
               case 27 -> 27;
               case 28 -> 44;
               case 29 -> 53;
               case 30 -> 14;
               case 31 -> 32;
               case 32 -> 30;
               case 33 -> 12;
               case 34 -> 16;
               case 35 -> 59;
               case 36 -> 57;
               case 37 -> 36;
               case 38 -> 48;
               case 39 -> 55;
               case 40 -> 52;
               case 41 -> 43;
               case 42 -> 56;
               case 43 -> 54;
               case 44 -> 9;
               case 45 -> 50;
               case 46 -> 20;
               case 47 -> 24;
               case 48 -> 58;
               case 49 -> 0;
               case 50 -> 42;
               case 51 -> 51;
               case 52 -> 26;
               case 53 -> 6;
               case 54 -> 19;
               case 55 -> 28;
               case 56 -> 63;
               case 57 -> 49;
               case 58 -> 31;
               case 59 -> 39;
               case 60 -> 25;
               case 61 -> 13;
               case 62 -> 60;
               default -> 8;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            c[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static void a() {
      b[0] = "\u0004lA l\f\u000b,\f+f\u0011\u000eq\u0007mf\u0015\u0002l\u001bmF\u0015\u0002l\u001b\u000eb\r\u0006e\n1";
      b[1] = "\u0013tAp?)\u0018{P?X)\u0015pPp}\u0004\u000brB|t+\rPOrt5\r|X\u007f";
      b[2] = "Q'S\\\u001d?O/I\u0013~+K";
      b[3] = int.class;
      c[3] = "java/lang/Integer";
      b[4] = void.class;
      c[4] = "java/lang/Void";
      b[5] = "r\u001e\u0018\u0011c1}^U\u001ai,x\u0003^\\a1u\u0005Z\u0017\"\u0013~\u0014C\u001ei";
      b[6] = "TI}]Md`jr\u001d\u0000ojww@\u000b)bjzF\u000fb!HqW\u0016kj>";
      b[7] = "Rp\u0005__&]0HTU;XmC\u0012U?Tp_\u0012D0A{X\u0012`;XqYUD0";
      b[8] = ".Q";
      b[9] = "s7uA;\rG\u0014z\u0001v\u0006M\t\u007f\\}@E\u0014rZy\u000b\u00066yK`\u0002M@";
      b[10] = "\u0019@b<1\u0006\u0012OssP\b\u0019Dw)";
      b[11] = "1OCwn&sKWdV\u0017\rHUzh!\u007f\u0019\\yhE";
      b[12] = "L.k;S[\u001b>*\u0004nkh\u0006OXnwp\u0002]\\4\u001fD\u007f.<S\u001fJ+t";
      b[13] = "\u000b\u000bjb\u0015h\\\u001b+]\u001b\u0015YSo/\u0002z\u000f_{0r,Q\u0018g-\u001dz]\fx]";
      b[14] = "R\u0017\u0001d\\\u0012\u0005\u0007@[}o\u0003\u0007\u0001\"QU\u0004NN>;T\u0007\f\u001e4_\rE\u0015E[";
      b[15] = "\u0007q(\u0018$GEu<\u000b\u001cz;v>\u0015\"@I'7\u0016\"$\u0000v'\u0011s@Y4>J\u001c";
      b[16] = "\u0014%Zah\u0001C5\u001b^^|E5Z'eFB|\u0015;\u000f";
      b[17] = "j\bA9b8=\u0018\u0000\u0006}E;\u0018A\u007fo\u007f<Q\u000ec\u0005";
      b[18] = "<78\u0015\u0014{|a!W/BH\u0018\u0019*xU[\u0006\r6/!{;*[Ss`a4";
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 220 && var8 != 'x' && var8 != 'o' && var8 != 'l') {
            Method var11 = d(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 245) {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 193) {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = c(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 220) {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 'x') {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 'o') {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private void register(Method method, Object object) {
      Class<? extends Event> indexClass = (Class<? extends Event>)method.getParameterTypes()[0];
      EventManager.MethodData data = new EventManager.MethodData(object, method, method.getAnnotation(EventTarget.class).value());
      if (!data.getTarget().isAccessible()) {
         data.getTarget().setAccessible(true);
      }

      if (this.REGISTRY_MAP.containsKey(indexClass)) {
         if (!this.REGISTRY_MAP.get(indexClass).contains(data)) {
            this.REGISTRY_MAP.get(indexClass).add(data);
            this.sortListValue(indexClass);
         }
      } else {
         this.REGISTRY_MAP.put(indexClass, new EventManager$1(this, data));
      }
   }

   public void register(Object object, Class<? extends Event> eventClass) {
      int var10000 = p();
      Method[] var6 = object.getClass().getDeclaredMethods();
      int var7 = var6.length;
      int var8 = 0;
      int a = var10000;
      if (0 < var7) {
         Method method = var6[0];
         if (this.isMethodBad(method, eventClass)) {
         }

         this.register(method, object);
         var8++;
      }

      if (Module.Z() == null) {
         N(++a);
      }
   }

   public void register(Object object) {
      for (Method method : object.getClass().getDeclaredMethods()) {
         if (!this.isMethodBad(method)) {
            this.register(method, object);
         }
      }
   }

   public static int p() {
      Y();

      try {
         return 78;
      } catch (IllegalArgumentException var0) {
         throw a(var0);
      }
   }

   public Event call(Event event) {
      p();
      List dataList = this.REGISTRY_MAP.get(event.getClass());
      if (event instanceof EventStoppable stoppable) {
         Iterator var7 = dataList.iterator();
         if (var7.hasNext()) {
            EventManager.MethodData data = (EventManager.MethodData)var7.next();
            this.invoke(data, event);
            if (stoppable.isStopped()) {
            }
         }
      }

      Iterator var9 = dataList.iterator();
      if (var9.hasNext()) {
         EventManager.MethodData data = (EventManager.MethodData)var9.next();
         this.invoke(data, event);
      }

      return event;
   }

   public void unregister(Object object, Class<? extends Event> eventClass) {
      p();
      if (this.REGISTRY_MAP.containsKey(eventClass)) {
         this.REGISTRY_MAP.get(eventClass).removeIf(data -> data.getSource().equals(object));
         this.cleanMap(true);
      }
   }

   public void unregister(Object object) {
      Y();
      Iterator var5 = this.REGISTRY_MAP.values().iterator();
      if (var5.hasNext()) {
         List<EventManager.MethodData> dataList = (List<EventManager.MethodData>)var5.next();
         dataList.removeIf(data -> data.getSource().equals(object));
         Module.V(new Module[5]);
      }

      this.cleanMap(true);
   }

   public static int Y() {
      return 树何何树树何友友友友;
   }

   public void removeEntry(Class<? extends Event> indexClass) {
      Y();
      Iterator mapIterator = this.REGISTRY_MAP.entrySet().iterator();

      while (mapIterator.hasNext()) {
         if (((Class)((Entry)mapIterator.next()).getKey()).equals(indexClass)) {
            mapIterator.remove();
            break;
         }
      }
   }

   public static void N(int var0) {
      树何何树树何友友友友 = var0;
   }

   public void cleanMap(boolean onlyEmptyEntries) {
      Y();
      Iterator mapIterator = this.REGISTRY_MAP.entrySet().iterator();

      while (mapIterator.hasNext()) {
         if (((List)((Entry)mapIterator.next()).getValue()).isEmpty()) {
            mapIterator.remove();
            break;
         }
      }
   }

   private static String LIU_YA_FENG() {
      return "何树友被何大伟克制了";
   }

   private boolean isMethodBad(Method method) {
      return method.getParameterTypes().length != 1 || !method.isAnnotationPresent(EventTarget.class);
   }

   private boolean isMethodBad(Method method, Class<? extends Event> eventClass) {
      p();
      return this.isMethodBad(method) || !method.getParameterTypes()[0].equals(eventClass);
   }

   private void sortListValue(Class<? extends Event> indexClass) {
      List<EventManager.MethodData> sortedList = new CopyOnWriteArrayList<>();

      for (byte priority : Priority.VALUE_ARRAY) {
         for (EventManager.MethodData data : this.REGISTRY_MAP.get(indexClass)) {
            if (data.getPriority() == priority) {
               sortedList.add(data);
            }
         }
      }

      this.REGISTRY_MAP.put(indexClass, sortedList);
   }

   private static final class MethodData implements 何树友 {
      private final Object source;
      private final Method target;
      private final byte priority;
      private static final long a;
      private static final Object[] b = new Object[7];
      private static final String[] c = new String[7];
      private static int _何炜霖230622200409390090 _;

      public MethodData(Object source, Method target, byte priority) {
         this.source = source;
         this.target = target;
         this.priority = priority;
      }

      // $VF: Could not create synchronized statement, marking monitor enters and exits
      // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
      static {
         synchronized (何树何何树何友何何何.g()){} // $VF: monitorenter 
         long var10000 = 何树何何树何友何何何.a(-3418361829301863269L, -2337368081052786806L, MethodHandles.lookup().lookupClass()).a(145338400298574L);
         // $VF: monitorexit
         a = var10000;
         a();
      }

      private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
         return a(var0, var1, var2, var3, var4);
      }

      private static Class b(long var0, long var2) {
         int var4 = a(var0, 0L);
         Object var6 = b[var4];
         Object var10000 = var6;

         try {
            if (var10000 instanceof String) {
               Class var5 = Class.forName(c[var4]);
               b[var4] = var5;
               return var5;
            }
         } catch (Exception var8) {
            throw new RuntimeException(var8.toString());
         }

         return (Class)var6;
      }

      private static Field b(Class var0, String var1, Class var2) {
         return a(var0, var1, var2);
      }

      private static Field c(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (var5 instanceof String) {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
            Field var13 = a(var8, var10, var11);
            b[var4] = var13;
            return var13;
         } else {
            return (Field)var5;
         }
      }

      private static Method d(long var0, long var2) {
         int var4 = a(var0, var2);
         Object var5 = b[var4];
         if (!(var5 instanceof String)) {
            return (Method)var5;
         } else {
            String var6 = c[var4];
            int var7 = var6.indexOf(8);
            Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
            int var9 = var6.indexOf(8, ++var7);
            String var10 = var6.substring(var7, var9);
            int var11 = -1;
            int var12 = var9;

            do {
               var11++;
               var12++;
            } while ((var12 = var6.indexOf(8, var12)) > -1);

            int var13;
            Class[] var14 = new Class[var13 = var11 - 1];
            Class var15 = null;
            var12 = var9 + 1;

            for (int var16 = 0; var16 < var11; var16++) {
               int var17 = var6.indexOf(8, var12);
               var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
               if (var16 < var13) {
                  var14[var16] = var15;
               }

               var12 = var17 + 1;
            }

            Method var21 = a(var8, var10, var15, var13, var14);
            b[var4] = var21;
            return var21;
         }
      }

      private static CallSite a(Lookup var0, String var1, MethodType var2) {
         MutableCallSite var3 = new MutableCallSite(var2);

         try {
            var3.setTarget(
               MethodHandles.explicitCastArguments(
                  MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
               )
            );
            return var3;
         } catch (Exception var5) {
            throw new RuntimeException("cn/cool/cherish/event/EventManager$MethodData" + " : " + var1 + " : " + var2.toString(), var5);
         }
      }

      private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
         label33:
         for (Method var8 : var0.getDeclaredMethods()) {
            if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
               Class[] var9 = var8.getParameterTypes();
               if (var9.length == var3) {
                  for (int var10 = 0; var10 < var3; var10++) {
                     if (var9[var10] != var4[var10]) {
                        continue label33;
                     }
                  }

                  return var8;
               }
            }
         }

         return null;
      }

      private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
         int var5 = var4.length - 2;
         long var6 = (Long)var4[var5];
         long var9 = (Long)var4[++var5];
         MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
         var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
         return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
      }

      private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
         char var8 = var2.charAt(0);
         Field var10 = null;

         try {
            MethodHandle var9;
            if (var8 != 214 && var8 != 205 && var8 != 'f' && var8 != 204) {
               Method var11 = d(var4, var6);
               Class var16 = var11.getDeclaringClass();
               String var18 = var11.getName();
               MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
               if (var8 == 'd') {
                  var9 = var0.findVirtual(var16, var18, var19);
               } else if (var8 == 200) {
                  var9 = var0.findStatic(var16, var18, var19);
               } else {
                  var9 = var0.findSpecial(var16, var18, var19, var16);
               }
            } else {
               var10 = c(var4, var6);
               Class var12 = var10.getDeclaringClass();
               String var17 = var10.getName();
               Class var14 = var10.getType();
               if (var8 == 214) {
                  var9 = var0.findGetter(var12, var17, var14);
               } else if (var8 == 205) {
                  var9 = var0.findSetter(var12, var17, var14);
               } else if (var8 == 'f') {
                  var9 = var0.findStaticGetter(var12, var17, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var17, var14);
               }
            }

            return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
         } catch (Exception var15) {
            StringBuilder var13 = new StringBuilder();
            var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
            throw new RuntimeException(var13.toString());
         }
      }

      private static void a() {
         b[0] = "w>/10Zx~b::G}#i|:Cq>u|\u001aCq>u\u001f>[u7d {xq$i=;qu$`";
         b[1] = byte.class;
         c[1] = "java/lang/Byte";
         b[2] = "+?d\u0006\u00007 0uIa9+;q\u0013";
         b[3] = "\u007fTj\u001339t[{\\o0sYy\u0011i{XPh\u001ar1";
         b[4] = "D\u001aMip.\u0000YTPv$\u0001JE,\nw\u0001\u0019\u00147v#F[T";
         b[5] = "R\u0010\u0000K\u001b[\u0016S\u0019r\u001a_\u0010U\u000e\u001fa\u0001\nF\u000e\u0018ZZ]J\u0003";
         b[6] = "\u0001a\u0014$'AE\"\r\u001d%X_9\u000b|!S>!\u0014|?X\u0006`K`";
      }

      private static int a(long var0, long var2) {
         var0 ^= var2 << 48 | var2;
         int var4 = (int)(var0 >>> 46);
         if (c[var4] != null) {
            return var4;
         } else {
            Object var5 = b[var4];
            if (!(var5 instanceof String)) {
               return var4;
            } else {
               byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
                  case 0 -> 54;
                  case 1 -> 57;
                  case 2 -> 29;
                  case 3 -> 39;
                  case 4 -> 60;
                  case 5 -> 63;
                  case 6 -> 37;
                  case 7 -> 49;
                  case 8 -> 61;
                  case 9 -> 51;
                  case 10 -> 28;
                  case 11 -> 58;
                  case 12 -> 14;
                  case 13 -> 48;
                  case 14 -> 25;
                  case 15 -> 46;
                  case 16 -> 9;
                  case 17 -> 44;
                  case 18 -> 18;
                  case 19 -> 50;
                  case 20 -> 2;
                  case 21 -> 45;
                  case 22 -> 13;
                  case 23 -> 59;
                  case 24 -> 43;
                  case 25 -> 0;
                  case 26 -> 55;
                  case 27 -> 30;
                  case 28 -> 33;
                  case 29 -> 8;
                  case 30 -> 5;
                  case 31 -> 62;
                  case 32 -> 24;
                  case 33 -> 15;
                  case 34 -> 27;
                  case 35 -> 1;
                  case 36 -> 53;
                  case 37 -> 4;
                  case 38 -> 20;
                  case 39 -> 22;
                  case 40 -> 11;
                  case 41 -> 19;
                  case 42 -> 16;
                  case 43 -> 12;
                  case 44 -> 36;
                  case 45 -> 6;
                  case 46 -> 47;
                  case 47 -> 35;
                  case 48 -> 10;
                  case 49 -> 42;
                  case 50 -> 40;
                  case 51 -> 31;
                  case 52 -> 41;
                  case 53 -> 3;
                  case 54 -> 17;
                  case 55 -> 56;
                  case 56 -> 34;
                  case 57 -> 21;
                  case 58 -> 26;
                  case 59 -> 23;
                  case 60 -> 7;
                  case 61 -> 38;
                  case 62 -> 32;
                  default -> 52;
               };
               int[] var7 = new int[6];

               for (int var8 = 0; var8 < 6; var8++) {
                  int var9 = 7 * (5 - var8);
                  int var10 = (int)(var0 >>> var9 & 127L);
                  var10 -= var6;
                  var10 += 128;
                  var7[var8] = var10;
               }

               char[] var12 = ((String)var5).toCharArray();

               for (int var13 = 0; var13 < var12.length; var13++) {
                  int var16 = var7[var13 % var7.length];
                  var12[var13] = (char)(var12[var13] ^ var16);
               }

               c[var4] = new String(var12);
               return var4;
            }
         }
      }

      private static Field a(Class var0, String var1, Class var2) {
         for (Field var6 : var0.getDeclaredFields()) {
            if (var6.getName().equals(var1) && var6.getType() == var2) {
               return var6;
            }
         }

         return null;
      }

      public byte getPriority() {
         return this.priority;
      }

      public Method getTarget() {
         return this.target;
      }

      public Object getSource() {
         return this.source;
      }

      private static String LIU_YA_FENG() {
         return "何炜霖国企上班";
      }
   }
}
