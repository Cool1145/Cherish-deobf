package cn.cool.cherish;

import cn.cool.cherish.module.Module;
import cn.cool.cherish.module.何友友树友何友何何何;
import cn.cool.cherish.utils.client.ClientUtils;
import heilongjiang.zhaoyuan.何树友;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class 树何树友树何何友友树 extends 友树树友树树友友何何 implements 何树友 {
   private static Module[] 何树树友友友树友何何;
   private static final long b;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] h = new Object[9];
   private static final String[] i = new String[9];
   private static String LIU_YA_FENG;

   public 树何树友树何何友友树() {
      long a = b ^ 11107285961635L;
      super(a<"r">(23772, 1915956915348524672L ^ a), "t");
   }

   // $VF: Could not create synchronized statement, marking monitor enters and exits
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   static {
      synchronized (何友友树友何友何何何.g()){} // $VF: monitorenter 
      long var10000 = 何友友树友何友何何何.a(-1574587686648839137L, 2421436775232121852L, MethodHandles.lookup().lookupClass()).a(85495958577008L);
      // $VF: monitorexit
      b = var10000;
      long var9 = b ^ 88003165512412L;
      b();
      c<"j">(null, -4114148253945942868L, var9);
      Cipher var0;
      Cipher var13 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)(var9 >>> 56), 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(var9 << var1 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[17];
      int var5 = 0;
      String var4 = "`2Þz\u0091\b\u0097Z3;NsÜÎ\u0086O\u0018c$Ä\bëûSGÜ\u009b3\u0007\u0002jáG®D¾o&\"(\u0094\u0010\u009bî°Än{S·\u0007£\u0088ü9/-\u0094\u0010\u0087\u0092\u0086Â*îF(]\u0087¹àÆ¦\u0082\r\u00104ÿ\u0016i×h>?|\u009b\u0015\u008déZ\fµ\u0010÷ Ú\u009b\\ÑÇï\u0081FôÔh¦A\u0012pÆN\u0000J²\u0095Hàq!Q\u0086Ú\u000bn\n\u001b»\u0096X\u008c\u0012\u0080\u008cÊy\u0097\u008e£ð?!¾m\u0002òèë\u0001EþúàÏ¸\b´çæ$b\u0004ñ^/ù¿Ð\u0092\u0015~\u009eÔÀ|Ð\u009a»ßö\u001fÚ»àHHíãäfÏ?Ú0É8Ëò\u0005T\u009aÖåÁ|9ÉO\u001aËrJ Ï,\u0018ê\b\u0000ºð\u0019\u00183à\u0005'ÖQ\\\u00152\u0017\u008b\u001aù2»)¼\u0083\u001aB)\u009b^\u0014\u0010ò!v¡Ï¡M¬*FÏ;²\u0018á~\u0010G²&`üç«)Pá'\u0012\u0011z\u000fB@M\u0005PÜ\u0096¾\u0013\u0006°Â\u0090\u0083Ù#\u0006Z\u0013ó®\u0017ýÚ¸PÔ\u0003Ç\u00ad\u0016«¹\u0017)ÞüÅq!@\u0089*\u000f\u0081ï×\u0094P#ò±á=:tA\u009cÝ´^\f{ó(\u0097\u0010mÿX\u0088¿fþS\u008fþÑºVbî\u001b û*\u009e´\u0005\u008e¦3þ<\u0086\u0007-gûÞJàÝ©øõ|§\u0096¸Éë¶Ð4\u007f hî¨\u0093$5;\u001c\u0015\u0001&Éø\u009f!\u008bj\u000fÆÏ~\u008eð¡ñîÛ\u0080\u0080ý\u0093¶\u0010Èeó\u0093µÀH!Ú+¯©.n\rg";
      short var6 = 446;
      char var3 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var14 = var4.substring(++var12, var12 + var3);
         byte var10001 = -1;

         while (true) {
            String var20 = a(var0.doFinal(var14.getBytes("ISO-8859-1"))).intern();
            switch (var10001) {
               case 0:
                  var7[var5++] = var20;
                  if ((var12 += var3) >= var6) {
                     c = var7;
                     d = new String[17];
                     return;
                  }

                  var3 = var4.charAt(var12);
                  break;
               default:
                  var7[var5++] = var20;
                  if ((var12 += var3) < var6) {
                     var3 = var4.charAt(var12);
                     continue label27;
                  }

                  var4 = "Ç¸}x\u00983©\u0091¸@§ãc:ã¼\u0010´'×\u0018\u001bL\u0085\"ê\u0087UÎ\u009fü\u009fÞ";
                  var6 = 33;
                  var3 = 16;
                  var12 = -1;
            }

            var14 = var4.substring(++var12, var12 + var3);
            var10001 = 0;
         }
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      if (i[var4] != null) {
         return var4;
      } else {
         Object var5 = h[var4];
         if (!(var5 instanceof String)) {
            return var4;
         } else {
            byte var6 = switch ((int)(var0 >>> 42 & 63L)) {
               case 0 -> 50;
               case 1 -> 16;
               case 2 -> 57;
               case 3 -> 30;
               case 4 -> 22;
               case 5 -> 55;
               case 6 -> 5;
               case 7 -> 18;
               case 8 -> 3;
               case 9 -> 35;
               case 10 -> 8;
               case 11 -> 53;
               case 12 -> 33;
               case 13 -> 34;
               case 14 -> 44;
               case 15 -> 17;
               case 16 -> 20;
               case 17 -> 60;
               case 18 -> 7;
               case 19 -> 47;
               case 20 -> 9;
               case 21 -> 26;
               case 22 -> 49;
               case 23 -> 56;
               case 24 -> 61;
               case 25 -> 42;
               case 26 -> 13;
               case 27 -> 4;
               case 28 -> 28;
               case 29 -> 43;
               case 30 -> 58;
               case 31 -> 45;
               case 32 -> 1;
               case 33 -> 52;
               case 34 -> 54;
               case 35 -> 11;
               case 36 -> 29;
               case 37 -> 14;
               case 38 -> 36;
               case 39 -> 25;
               case 40 -> 6;
               case 41 -> 24;
               case 42 -> 40;
               case 43 -> 31;
               case 44 -> 32;
               case 45 -> 63;
               case 46 -> 2;
               case 47 -> 0;
               case 48 -> 59;
               case 49 -> 10;
               case 50 -> 39;
               case 51 -> 41;
               case 52 -> 21;
               case 53 -> 12;
               case 54 -> 48;
               case 55 -> 19;
               case 56 -> 51;
               case 57 -> 38;
               case 58 -> 27;
               case 59 -> 37;
               case 60 -> 46;
               case 61 -> 15;
               case 62 -> 23;
               default -> 62;
            };
            int[] var7 = new int[6];

            for (int var8 = 0; var8 < 6; var8++) {
               int var9 = 7 * (5 - var8);
               int var10 = (int)(var0 >>> var9 & 127L);
               var10 -= var6;
               var10 += 128;
               var7[var8] = var10;
            }

            char[] var12 = ((String)var5).toCharArray();

            for (int var13 = 0; var13 < var12.length; var13++) {
               int var16 = var7[var13 % var7.length];
               var12[var13] = (char)(var12[var13] ^ var16);
            }

            i[var4] = new String(var12);
            return var4;
         }
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;

      try {
         MethodHandle var9;
         if (var8 != 'm' && var8 != 220 && var8 != 216 && var8 != 'M') {
            Method var11 = h(var4, var6);
            Class var16 = var11.getDeclaringClass();
            String var18 = var11.getName();
            MethodType var19 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
            if (var8 == 'V') {
               var9 = var0.findVirtual(var16, var18, var19);
            } else if (var8 == 'j') {
               var9 = var0.findStatic(var16, var18, var19);
            } else {
               var9 = var0.findSpecial(var16, var18, var19, var16);
            }
         } else {
            var10 = g(var4, var6);
            Class var12 = var10.getDeclaringClass();
            String var17 = var10.getName();
            Class var14 = var10.getType();
            if (var8 == 'm') {
               var9 = var0.findGetter(var12, var17, var14);
            } else if (var8 == 220) {
               var9 = var0.findSetter(var12, var17, var14);
            } else if (var8 == 216) {
               var9 = var0.findStaticGetter(var12, var17, var14);
            } else {
               var9 = var0.findStaticSetter(var12, var17, var14);
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var15) {
         StringBuilder var13 = new StringBuilder();
         var13.append(var15.getClass().getName()).append(" : ").append(var10.toString()).append(" : ").append(var15.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {
      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   }

   private static void b() {
      h[0] = "FfY)h\u0012I&\u0014\"b\u000fL{\u001fd栖伨栴參桦伟佒厶叮栙";
      h[1] = "D,R\u000e1pO#CAMi@9M\u0002zYV.A\u001fkuA#";
      h[2] = "; h0vp\u000f\u0003gp;{\u0005\u001eb-0=\r\u0003o+4vN!d:-\u007f\u0005W";
      h[3] = "u\u001a\u0002Rv\u0000A9\r\u0012;\u000bK$\bO0MC9\u0005I4\u0006\u0000\u001b\u000eX-\u000fKm";
      h[4] = void.class;
      i[4] = "java/lang/Void";
      h[5] = "2\r8FVO9\u0002)\t7A2\t-S";
      h[6] = "\u001ed%J\u0007MK3e0X#K=%\nL\u0019I6e\f=\u0018\u001fgfZ\u0007OAh}0";
      h[7] = "i\u0012i\u0005#r<E)\u007fp\u001c?\u0016j\u001c`~?R3O\u0019%?\u00142\u0006{%{Ma\u007f";
      h[8] = "F\u007f4J\\G\u0013(t0\u001b)\u0013&4\n\u0017\u0013\u0011-t\ff";
   }

   private static Field c(Class var0, String var1, Class var2) {
      for (Field var6 : var0.getDeclaredFields()) {
         if (var6.getName().equals(var1) && var6.getType() == var2) {
            return var6;
         }
      }

      return null;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("b".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1, var2), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/树何树友树何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      label33:
      for (Method var8 : var0.getDeclaredMethods()) {
         if (var8.getName().equals(var1) && var8.getReturnType() == var2) {
            Class[] var9 = var8.getParameterTypes();
            if (var9.length == var3) {
               for (int var10 = 0; var10 < var3; var10++) {
                  if (var9[var10] != var4[var10]) {
                     continue label33;
                  }
               }

               return var8;
            }
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (!(var5 instanceof String)) {
         return (Method)var5;
      } else {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         int var11 = -1;
         int var12 = var9;

         do {
            var11++;
            var12++;
         } while ((var12 = var6.indexOf(8, var12)) > -1);

         int var13;
         Class[] var14 = new Class[var13 = var11 - 1];
         Class var15 = null;
         var12 = var9 + 1;

         for (int var16 = 0; var16 < var11; var16++) {
            int var17 = var6.indexOf(8, var12);
            var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
            if (var16 < var13) {
               var14[var16] = var15;
            }

            var12 = var17 + 1;
         }

         Method var21 = c(var8, var10, var15, var13, var14);
         h[var4] = var21;
         return var21;
      }
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, 0L);
      Object var6 = h[var4];
      Object var10000 = var6;

      try {
         if (var10000 instanceof String) {
            Class var5 = Class.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var8) {
         throw new RuntimeException(var8.toString());
      }

      return (Class)var6;
   }

   private static Field d(Class var0, String var1, Class var2) {
      return c(var0, var1, var2);
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      return c(var0, var1, var2, var3, var4);
   }

   private static String a(byte[] var0) {
      int var1 = 0;
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {
      int var5 = var0 ^ (int)(var1 & 32767L) ^ 15808;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().getId();
            Object[] var10000 = (Object[])e.get(var3);
            var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
            e.put(var3, var4);
         } catch (Exception var10) {
            throw new RuntimeException("cn/cool/cherish/树何树友树何何友友树", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments("a".asCollector(Object[].class, var2.parameterCount()), 0, var0, var3, var1), var2
            )
         );
         return var3;
      } catch (Exception var5) {
         throw new RuntimeException("cn/cool/cherish/树何树友树何何友友树" + " : " + var1 + " : " + var2.toString(), var5);
      }
   }

   private static RuntimeException a(RuntimeException var0) {
      return var0;
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   public static void m(Module[] var0) {
      何树树友友友树友何何 = var0;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = h[var4];
      if (var5 instanceof String) {
         String var6 = i[var4];
         int var7 = var6.indexOf(8);
         Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
         int var9 = var6.indexOf(8, ++var7);
         String var10 = var6.substring(var7, var9);
         Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
         Field var13 = c(var8, var10, var11);
         h[var4] = var13;
         return var13;
      } else {
         return (Field)var5;
      }
   }

   public static Module[] u() {
      return 何树树友友友树友何何;
   }

   @Override
   public void W(String[] params) {
      long a = b ^ 86065036641407L;
      long ax = a ^ 10841031461261L;
      c<"j">(6937513959625022316L, a);
      if (params.length < 1) {
         ClientUtils.e(new Object[]{a<"r">(5270, 8286052281289558297L ^ a), ax});
      } else {
         Module module = Cherish.instance.getModuleManager().S(params[0]);
         if (module == null) {
            ClientUtils.e(new Object[]{a<"r">(16545, 8504873509830827299L ^ a) + params[0] + a<"r">(23865, 7183406411475484849L ^ a), ax});
         } else {
            boolean enable = !module.isEnabled();
            if (params.length == 2) {
               String var9 = params[1].toLowerCase();
               byte var10 = -1;
               switch (var9.hashCode()) {
                  case 3551:
                     if (!var9.equals(a<"r">(20774, 4316745841588571299L ^ a))) {
                        break;
                     }

                     var10 = 0;
                  case -1298848381:
                     if (!var9.equals(a<"r">(22756, 3047214534852904293L ^ a))) {
                        break;
                     }

                     var10 = 1;
                  case 119527:
                     if (!var9.equals(a<"r">(15194, 1232212489140594391L ^ a))) {
                        break;
                     }

                     var10 = 2;
                  case 3569038:
                     if (!var9.equals(a<"r">(7533, 287950175885869304L ^ a))) {
                        break;
                     }

                     var10 = 3;
                  case 49:
                     if (!var9.equals("1")) {
                        break;
                     }

                     var10 = 4;
                  case 109935:
                     if (!var9.equals(a<"r">(19965, 709669244913062003L ^ a))) {
                        break;
                     }

                     var10 = 5;
                  case 1671308008:
                     if (!var9.equals(a<"r">(25447, 5548173836241125088L ^ a))) {
                        break;
                     }

                     var10 = 6;
                  case 3521:
                     if (!var9.equals(a<"r">(10037, 4177236109997341375L ^ a))) {
                        break;
                     }

                     var10 = 7;
                  case 97196323:
                     if (!var9.equals(a<"r">(17836, 8514794754729809952L ^ a))) {
                        break;
                     }

                     var10 = 8;
                  case 48:
                     if (var9.equals("0")) {
                        var10 = 9;
                     }
               }
               enable = switch (var10) {
                  case 0, 1, 2, 3, 4 -> true;
                  case 5, 6, 7, 8, 9 -> false;
                  default -> {
                     ClientUtils.e(new Object[]{a<"r">(1078, 3390909665629067701L ^ a), ax});
                     yield enable;
                  }
               };
            }

            module.y(enable);
            ClientUtils.e(
               new Object[]{
                  a<"r">(25797, 4529930723976788289L ^ a) + module.i() + a<"r">(5738, 4416900495725808620L ^ a) + a<"r">(699, 3414373810321841968L ^ a) + ".",
                  ax
               }
            );
         }
      }
   }

   private static String HE_JIAN_GUO() {
      return "何炜霖230622200409390090";
   }
}
